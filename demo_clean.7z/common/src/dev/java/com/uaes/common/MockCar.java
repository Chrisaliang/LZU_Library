package com.uaes.common;

/**
 * Created by aber on 1/24/2018.
 * 开发环境
 */

public interface MockCar {
//    String MOCK_VIN = "LSVFA49J232037048"; // mock
//    String MOCK_IMEI = "863010033350856"; // mock

    String MOCK_VIN = "LNBSCUAK5HF00005"; // mock new car 百公里油耗
    String MOCK_IMEI = "20171219030"; // mock new car包公里友好
}
