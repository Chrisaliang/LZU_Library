package com.uaes.common;

/**
 * Created by aber on 11/13/2017.
 * Warning Intents
 */

public interface Intents {

    String ACTION_MESSAGE = "com.uaes.android.message";

    String ACTION_MESSAGE_JUMP = "com.uaes.android.message-jump";

    String EXTRA_MESSAGE = "com.uaes.android.EXTRA_message";


    String KEY_TOKEN = "com.uaes.android.TOKEN";
    String KEY_RETOKEN = "com.uaes.android.RETOKEN";

    String ACTION_AUTHORIZATION = "com.uaes.iot.INVALID_TOKEN";
    String MESSAGE_FRAGMENT_ARGUMENTS = "com.uaes.android.ui.message.MessageFragment.arguments";
    String MAINTENANCE_HELPER_FRAGMENT_ARGUMENTS = "com.uaes.android.ui.message.MaintenanceHelperFragment.arguments";
    String FOURSSHOP_FROM_TAG = "com.uaes.android.foursshop.TAG";

    interface MESSAGE {
        String EXTRA_MESSAGE_TITLE = "com.uaes.android.message.TITLE";
        String EXTRA_MESSAGE_CONTENT = "com.uaes.android.message.CONTENT";
        String EXTRA_MESSAGE_MESSAGECLASS = "com.uaes.android.message.MESSAGECLASS";

        String EXTRA_MESSAGE_SAVE = "com.uaes.android.message.save";
        String EXTRA_MESSAGE_UPDATE = "com.uaes.android.message.update";
        String EXTRA_MESSAGE_DELETE = "com.uaes.android.message.delete";
        String EXTRA_MESSAGE_QUERY = "com.uaes.android.message.query";
        String EXTRA_MESSAGE_QUERY_NUMBER = "com.uaes.android.message.query.number";
    }
}
