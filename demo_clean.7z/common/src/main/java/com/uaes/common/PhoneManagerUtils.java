package com.uaes.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Chrisaliang on 2017/12/13.
 * get imei and imsi
 */

@SuppressWarnings("WeakerAccess")
public class PhoneManagerUtils {

    private static final String TAG = "PhoneManagerUtils";

    @SuppressLint({"MissingPermission", "HardwareIds"})
    public static String getIMEIStr(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager != null ? telephonyManager.getDeviceId() : null;
    }

    @SuppressLint({"MissingPermission", "HardwareIds"})
    public static String getIMSIStr(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager != null ? telephonyManager.getSubscriberId() : null;
    }

    /**
     * get Vin Code on Specific Device(flycall device C51 android4.4)
     * if failed return empty string.
     */
    public static String getAutoId() {
        String emptyStr = "";
        String autoNum =
                getProp("persist.sys.autofly.carvin", emptyStr);
        if (!TextUtils.isEmpty(autoNum)) {
            // 必须是字母与数字组合，同时包含字母和数字，且位数为17位
            String regex = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{17}$";
            Matcher matcher = Pattern.compile(regex).matcher(autoNum.trim());
            boolean result = matcher.matches();
            Log.d(TAG, "getAutoId| matcher: " + regex);
            return result ? autoNum : emptyStr;
        }
        return emptyStr;
    }


    /**
     * Call privateApi in <b>android.os.SystemProperties</b>.get(String,String)
     * @param key the properties key
     * @param def if can't find out the value, return the def's value.
     * @return the value map by the <b>key</b>,if null or def is null return empty string.
     */
    @SuppressWarnings("TryWithIdenticalCatches")
    @SuppressLint("PrivateApi")
    public static String getProp(String key, String def) {
        if (null == key) return null;

        Class<?> clazz = null;
        try {
            clazz = Class.forName("android.os.SystemProperties");
            Method method = clazz.getMethod("get", String.class, String.class);
            return (String) method.invoke(null, key, def);
        } catch (ClassNotFoundException e) {
            Log.e(TAG, "key: " + key + ", def: " + def, e);
        } catch (NoSuchMethodException e) {
            Log.e(TAG, "key: " + key + ", def: " + def, e);
        } catch (IllegalAccessException e) {
            Log.e(TAG, "key: " + key + ", def: " + def, e);
        } catch (InvocationTargetException e) {
            Log.e(TAG, "key: " + key + ", def: " + def, e);
        }
        return null;
    }
}
