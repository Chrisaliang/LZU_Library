package com.uaes.common;

import android.content.Context;
import android.util.Log;

import com.google.common.hash.Hashing;

import java.nio.charset.Charset;
import java.util.Timer;

/**
 * Created by Chrisaliang on 2017/12/7.
 * Query Vin and sha384 code for
 */

@SuppressWarnings("WeakerAccess")
public class AuthProvider {

    private static final String TAG = AuthProvider.class.getSimpleName();

    private static final boolean PRE_BUILD = false;

    private static final String VIN = "LNBSCUAK1HF043619";
    private static final String IMEI = "863010033350799";

    private static AuthProvider INSTANCE;

    private String vinStr;

    private String sha384;

    private String imei;


    private AuthProvider(Context context) {
        parser(context, this);
    }

    public static AuthProvider getInstance(Context context) {
        if (INSTANCE == null)
            INSTANCE = new AuthProvider(context);
        return INSTANCE;
    }

    private static void parser(Context context, AuthProvider authProvider) {
        if (PRE_BUILD) {
            authProvider.vinStr = VIN;
            authProvider.imei = IMEI;
        } else {
            authProvider.vinStr = PhoneManagerUtils.getAutoId();
            authProvider.imei = PhoneManagerUtils.getIMEIStr(context);
        }
        authProvider.sha384 = Hashing.sha384().hashString(
                authProvider.vinStr + ":" + authProvider.imei,
                Charset.defaultCharset()).toString();
        Log.d(TAG, "vin: " + authProvider.vinStr + " ,imei: " + authProvider.imei + " ,sha384:" + authProvider.sha384);
    }

    public String getVinCode() {
        return vinStr;
    }

    public String getSha384WithIMEI() {
        return sha384;
    }
}
