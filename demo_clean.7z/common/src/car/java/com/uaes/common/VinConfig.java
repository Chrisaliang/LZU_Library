package com.uaes.common;

import com.google.common.hash.Hashing;

import java.nio.charset.Charset;

import static com.uaes.common.MockCar.MOCK_IMEI;
import static com.uaes.common.MockCar.MOCK_VIN;

/**
 * Created by aber on 1/26/2018.
 */

public class VinConfig {

    public String vin;

    public String imei;

    public String getHash() {
        return Hashing.sha384().hashString(MOCK_VIN + ":" + MOCK_IMEI, Charset.defaultCharset()).toString();
    }

    @Override
    public String toString() {
        return "VinConfig{" +
                "vin='" + vin + '\'' +
                ", imei='" + imei + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VinConfig vinConfig = (VinConfig) o;

        if (!vin.equals(vinConfig.vin)) return false;
        return imei.equals(vinConfig.imei);
    }

    @Override
    public int hashCode() {
        int result = vin.hashCode();
        result = 31 * result + imei.hashCode();
        return result;
    }
}
