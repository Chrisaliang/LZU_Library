package com.uaes.common;

import android.content.Context;
import android.util.Log;

import com.google.common.hash.Hashing;

import java.nio.charset.Charset;

/**
 * Created by Chrisaliang on 2017/12/7.
 * Query Vin and sha384 code for
 */

@SuppressWarnings("WeakerAccess")
public class AuthProvider {

    public static final boolean MOCK = false;

    public static final boolean FAKE = true;

    private static final String TAG = AuthProvider.class.getSimpleName();

    private static AuthProvider INSTANCE;

    private String vinStr;

    private String sha384;

    private String imei;

    private CarConfigManager manager;

    private AuthProvider(Context context) {
        manager = new CarConfigManager(context);
        parser(context, this);
    }

    public static AuthProvider getInstance(Context context) {
        if (INSTANCE == null)
            INSTANCE = new AuthProvider(context);
        return INSTANCE;
    }

    private static void parser(Context context, AuthProvider authProvider) {
        if (MOCK) {
            authProvider.vinStr = authProvider.manager.getSelect().vin;
            authProvider.imei = authProvider.manager.getSelect().imei;
        } else if (FAKE) {
            authProvider.vinStr = MockCar.MOCK_VIN;
            authProvider.imei = MockCar.MOCK_IMEI;
        } else {
            authProvider.vinStr = PhoneManagerUtils.getAutoId();
            authProvider.imei = PhoneManagerUtils.getIMEIStr(context);
        }
        Log.d(TAG, "parser: VIN: " + authProvider.vinStr + ", imei: " + authProvider.imei);
        authProvider.sha384 = Hashing.sha384().hashString(
                authProvider.vinStr + ":" + authProvider.imei,
                Charset.defaultCharset()).toString();
    }

    public String getVinCode() {
        if (MOCK) return manager.getSelect().vin;
        return vinStr;
    }

    public String getSha384WithIMEI() {
        if (MOCK) return manager.getSelect().getHash();
//            return Hashing.sha384().hashString(MOCK_VIN + ":" + MOCK_IMEI, Charset.defaultCharset()).toString();
        return sha384;
    }

    public CarConfigManager getManager() {
        return manager;
    }

}
