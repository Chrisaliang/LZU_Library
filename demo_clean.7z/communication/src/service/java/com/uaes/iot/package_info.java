package com.uaes.iot;

/**
 * Created by Chrisaliang on 2018/1/25.
 * Root holder
 */

public class package_info {
}
