package com.uaes.iot;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.uaes.iot.service.McuService;
import com.xdandroid.hellodaemon.DaemonEnv;

public class LogActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.simple);
    }

    public void onStartMcu(View view) {
        McuService.shouldStopService = false;
        DaemonEnv.startServiceMayBind(McuService.class);
    }
}
