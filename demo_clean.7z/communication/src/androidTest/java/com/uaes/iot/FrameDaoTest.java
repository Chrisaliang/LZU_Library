package com.uaes.iot;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.uaes.iot.room.FrameDao;
import com.uaes.iot.room.UaesDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;

/**
 * Created by aber on 1/18/2018.
 * Frame test
 * {@link com.uaes.iot.mcu.Frame}
 */

@RunWith(AndroidJUnit4.class)
public class FrameDaoTest {

    private UaesDatabase db;
    private FrameDao dao;

    private byte[] ecuFrame = new byte[]{
            0, 1, 1, 1,
            1, 2, 2, 1,
            -128, 1, -1, 1,
            -128, 127, -21, 2
    };

    @Before
    public void setDb() {
        Context context = InstrumentationRegistry.getTargetContext();
        db = Room.databaseBuilder(context, UaesDatabase.class, "hello.db")
                .build();
        dao = db.getFrameDao();
    }

    @After
    public void closeDb() {
        db.close();
    }
}
