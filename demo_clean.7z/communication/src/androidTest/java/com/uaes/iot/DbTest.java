package com.uaes.iot;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.uaes.iot.room.UaesDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;

/**
 * Created by aber on 12/19/2017.
 */
@RunWith(AndroidJUnit4.class)
public class DbTest {

    private UaesDatabase db;
    private UaesDatabase delayDb;


    @Before
    public void setDb() {
        Context context = InstrumentationRegistry.getTargetContext();
        db = Room.inMemoryDatabaseBuilder(context, UaesDatabase.class)
                .build();
        delayDb = Room.inMemoryDatabaseBuilder(context, UaesDatabase.class)
                .build();

    }


    @After
    public void closeDb() {
        db.close();
        delayDb.close();
    }
}
