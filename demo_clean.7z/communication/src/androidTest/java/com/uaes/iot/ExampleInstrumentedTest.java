package com.uaes.iot;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.uaes.common.AuthProvider;
import com.uaes.iot.iothub.IotHubResolver;
import com.uaes.iot.iothub.IotHubResolverImp;
import com.uaes.iot.iothub.RegisterResponse;
import com.uaes.iot.utils.IotBytes;
import com.uaes.iot.utils.PayloadCoder;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.zip.DataFormatException;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private static final String TAG = ExampleInstrumentedTest.class.getSimpleName();
    private byte[] CAN_0 = {0x00, 0x07, 0x00, 0x00};
    private byte[] CAN_1 = {0x01, 0x07, 0x00, 0x00};
    private byte[] CAN_4 = {0x04, 0x07, 0x00, 0x00};
    private Context context;


    @Test
    public void testVINCodeConfirm() throws IOException {
        AuthProvider authProvider = AuthProvider.getInstance(context);
        IotHubResolver resolver = new IotHubResolverImp(authProvider);
        try {
            RegisterResponse registerResponse = resolver.resolve();
            Assert.assertNotNull(registerResponse);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testPayload() throws IOException, DataFormatException {
//        String test = "eJxjYGBM8FL3zGdgZwAB5Z4F3DsAHOoDpA==\n";
//        String test = "eJxl1F1IU2Ecx/GzsyMbKLV5k1dJMyiCaFO3libtxa3llraXSNOsOZV8azVKuzsLoqAMRy+EBEkEvUGJdFPp8CrowgyCyOiiF6gIVs0RXQWnbc/znOfEb5c//uCH7zMnCLq4xbjtUsYgCHo5ZBbKn9JmrZOKm6AYLgiCyLYFwVA+qK6sYXe2qK64uVwLGxRFYVtOLG414kbxe0XaQ7b68/riZjYJAv8bDRZTcROD9oDf2thAtwKxBDWWxkzJoltruMot9s2qZRO7sy+ixTHILL8k+SLd/pYs1f9Ztl8pWfQOm5VvznpicWgszhelO12o3RP17neTbcco9msylc1Thpvc3HRfNTvYXbMPzc1fiblOXJXk22TbeRbNLeuxX0sW+7lrab+73OIuqBYfu/NMocW7hVm+SfInur3Et2wdwH6tCvbzTWM/vwP7+Zdpvzlu3j2hmmPsLrAOzYHH7M1XK+R5su3pQ3ObG/u1vcN+wRTtN88toTWqJcHuQnNo2Rtllh+S/JBuCr5l+3Xs12HHfh2vsN++QewXFmm/59wcnlbNKXYXsRFzVmOOvGXmL5KskC16EvvFqrBf7B7269TTfsvc0nlDtZxhd11OtHS9ZpbfkvyBbAdTaOk2Y7/uB9ivx4X9elaw36EU7bfCzb1G1Zxhd7230Hx4FzPnpHSEbh/RfOQO9ot7sV/8Pe33mVv6ZNUyw+4SFrQknjDLTyldRbb+MFr6C9hv4DL2O5rHfkOT2G/YUjbPGHLcPLyomh+xu5EDaB7Ja978GdlGr+H/zJgN+40tYb9jQ7TfH25JWlRLlt0ln6LleFjz+zdLtzz2O3EO+6Vqsd+pSew3vhX7jb8h3z+jwM0TSdW8xO5OV2rN/wCIqCxT";
        String test = "eJxtk01sDGEYx5+Z2Zltu7ofGt22m5isLm1JaGmbOpS1kgZR2hAXQeIjcXAUR1fvwakfEtELoi5EfZ2ccND1dUJ9xYEG3ZRWrY+w2+Gded95R/4mc/rlmXf+/1+el0jb33PidHncJNKIjoaJP5yd0fMea9ZaJRupvuexNC2Q7OwnznQKOdQg2bniuMvkw9l5h88ZuZJBRsjw2AXiLKQF50ar+LeGE2QXq/jc3zen2KV3fM4cCM5dLnFm/fPfK515l53UFBvrEz3qqEKyq/1eD80hW7JrO/h5YYsGyR3n7Pphfl5YGzugzrtxRHXTRbebx7DbrZ3Y4/YK4f64cn+nDd3fzYrMi1TmfMzLbDqUkex+Ct0/yGC+h02Y71Ebun+8GjM/qXDdDwbnnibQ/bMkup9oxB7PV3k9LIdaJHuxDt2/zKL7Vz3Y7fVu7Pa2A3t8rBHumXI/lUL3Bdvf+7hks7qXmRxaKdkXA93PxVQ+U+T7msB8xYXo/ls7Zv4ddd0PBedKcXRfTqD7+RrRY7G6v06t10N3aI1gjOqF+yHfPdNscM/0drjTzFgL3VhlJfRg0SnhfsB3z2Iz4J7FZyEzq33ju++SLFkA96xuBnaD1RcxX0MZ3LPUPGZOT7juh4NzSybBPWt8D+5ZZhr2ni0t+ve3W7ImU7gfVu6bE+i+xfa6/Qh0W74Mu7Va2KNjUrgfUe47p9F9Vxozd//yM2uSrSd0nw2h+w1hzJeLoPuNEcy86QO63zyH7rd8R/dbCe4v6zX8HbIk2xYT7k+pb7f/x31fEve+38Zuu35ijz2acD+q3O+tRvf7orj3Bwu++4hkhz4H3f8BkGVVfQ==";
        // eJxjYGBM8BLnXs7CzsDAIOjoaMj4A8gAifFPYQSKOTCs4m1oaGCEiAk3MoDUMTBY9Szg3gERE88D\n61VC1isdhalX3h1Tr7IJpr3qiph6tfkw9er9wrTX6DlUrwBCr9llqF5rhF6rg5j22m3A1Ou0CFOv\n20RMe70aMPX6FWDqDYrDtDfMB1NvlD2m3jgdTHuTpDD1prFj6s38gmlv7iNMvYXnMPWW7sa0t3I5\nVK8IQm/tZKheG5BeAMhAbyM\u003d\n
//eJxjYGBM8BJn38HAzgACVj0LuHcAAByGA7I\u003d\n

        byte[] decode = PayloadCoder.decompress(test);
        byte[] temp = new byte[20];
        for (int i = 0; i < decode.length; i += 20) {
            System.arraycopy(decode, i, temp, 0, 20);
            System.out.println(IotBytes.bytesToHexString(temp));
        }
    }

    @Test
    public void testOrigin() throws IOException, DataFormatException {
        Context context = InstrumentationRegistry.getTargetContext();
        InputStream is = context.getAssets().open("log.txt");
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String line;
        int can0 = 0;
        int can1 = 0;
        int can2 = 0;
        byte[] temp = new byte[4];
        while ((line = reader.readLine()) != null) {
            byte[] raw = PayloadCoder.decompress(line);
            for (int i = 0; i < raw.length; i += 20) {
                int canStart = i + 8;
                System.arraycopy(raw, canStart, temp, 0, 4);
                if (Arrays.equals(temp, CAN_0)) {
                    can0++;
                } else if (Arrays.equals(temp, CAN_1)) {
                    can1++;
                } else if (Arrays.equals(temp, CAN_4)) {
                    can2++;
                }
            }
        }

        Assert.assertEquals(360, can0);
        Assert.assertEquals(360, can1);
        Assert.assertEquals(360, can2);

    }
}
