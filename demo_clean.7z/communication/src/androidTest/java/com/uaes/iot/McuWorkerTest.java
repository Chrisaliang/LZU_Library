package com.uaes.iot;

import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import com.uaes.iot.mcu.CanFrameReader;
import com.uaes.iot.mcu.McuCanMsgReader;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;

/**
 * Created by aber on 12/20/2017.
 * Mock
 */
@RunWith(AndroidJUnit4.class)
public class McuWorkerTest {

    private static final String TAG = McuWorkerTest.class.getSimpleName();

    @Test
    public void mcuWorkTest() throws Exception {
        CanFrameReader canFrameReader = new McuCanMsgReader();
        byte[] arrys = new byte[16];
        while (true) {
            int count = canFrameReader.read(arrys);
            if (count == 16)
                Log.d(TAG, "mcuWorkTest: " + Arrays.toString(arrys));
            else
                Thread.sleep(100);
        }
    }
}
