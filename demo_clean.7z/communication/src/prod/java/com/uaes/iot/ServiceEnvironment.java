package com.uaes.iot;

/**
 * Created by aber on 12/20/2017.
 */

public interface ServiceEnvironment {
    String IOT_CONFIG_BASE_URL = "https://api-iot.uaes.com"; // 生产环境
}
