package com.uaes.iot;

/**
 * Created by aber on 12/7/2017.
 * file
 */

public class FuelChangeGenerator {

    private static final String PATH_NAME = "fuelchange.txt";
    private static final byte[] CANID = new byte[]{0x02, 0x07, 0x00, 0x00};
    private final static int maxFuel = 20;
    private final static int minFuel = 5;

    // 海拔系数
    private byte altitude = 0x0;
    //
    private byte tempterture = 0x15;
    private byte colddownWaterTemp = 0x20;
    private byte fuel = maxFuel;
    private byte fuelFactory1 = 1;
    private byte fuelFactory2 = 1;
    private byte fuelFactory3 = 1;
    private byte flag = 1;
    private boolean isAdd = false;



    public void readNextCanId(byte[] canMessage) {
        canMessage[0] = altitude;
        canMessage[1] = tempterture;
        canMessage[2] = colddownWaterTemp;
        canMessage[3] = fuel;
        canMessage[4] = fuelFactory1;
        canMessage[5] = fuelFactory2;
        canMessage[6] = fuelFactory3;
        canMessage[7] = flag;
    }

    private int getNextFuel() {
        if (isAdd && fuel < maxFuel) {
            fuel++;
        } else if (!isAdd && fuel > minFuel) {
            fuel--;
        }
        return 0;
    }


    /**
     * @param index base model
     */
    private int fuelFunction(int index) {
        if (index < 0 || index > 15) return -1;
        return 20 - index;
    }

}
