package com.uaes.iot;

/**
 * Created by aber on 12/7/2017.
 */

public class MileGenerator {

    private static final byte[] CANID = new byte[]{0x00, 0x07, 0x00, 0x00};

    private final static short DRIVETIME = 3600;

    private static short REMAINOILMILE = 3000;
    // 行驶里程
    private int mile = 1;

    private short driveTime = DRIVETIME;

    private short engineOil = REMAINOILMILE;
    private byte[] bytes2 = new byte[2];
    private byte[] bytes4 = new byte[4];

    private static void short2ByteArr(short shortNum, byte[] bytes) {
        bytes[0] = (byte) (shortNum);
        bytes[1] = (byte) (shortNum >> 8);
    }

    private static void int2ByteArr(int intNum, byte[] bytes) {
        int byteNum = (40 - Integer.numberOfLeadingZeros(intNum < 0 ? ~intNum : intNum)) / 8;
        for (int i = 0; i < byteNum; i++)
            bytes[3 - i] = (byte) (intNum >>> (i * 8));
    }

    public void getNextFrame(byte[] bytes) {
        mileFunction();
        driveTimeFunction();
        engineOilFunction();
        getMileByte(bytes);
    }

    public void reset() {
        // 行驶里程
        mile = 1;
        driveTime = DRIVETIME;
        engineOil = REMAINOILMILE;
    }

    private void mileFunction() {
        mile++;
    }

    private void driveTimeFunction() {
        // TODO;
    }

    private void engineOilFunction() {
        // TODO;
    }

    private byte[] getMileByte(byte[] bytes) {
        System.arraycopy(CANID, 0, bytes, 0, 4);
        int2ByteArr(mile, bytes4);
        System.arraycopy(bytes4, 0, bytes, 4, 4);
        short2ByteArr(driveTime, bytes2);
        System.arraycopy(bytes2, 0, bytes, 8, 2);
        short2ByteArr(engineOil, bytes2);
        System.arraycopy(bytes2, 0, bytes, 10, 2);
        return bytes;
    }

}
