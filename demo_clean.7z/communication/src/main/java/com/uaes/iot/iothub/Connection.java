package com.uaes.iot.iothub;

import android.content.Context;

import com.uaes.iot.InterruptedListener;
import com.uaes.iot.utils.SignUtil;

import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import javax.net.SocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

import timber.log.Timber;

/**
 * Created by aber on 1/19/2018.
 * Connection
 */

public abstract class Connection implements Runnable {

    public final static BlockingQueue<MqttMessage> blockingQueue = new ArrayBlockingQueue<>(256);

    public static Connection create(Context context, InterruptedListener listener, ConnectionResolver resolver) {
        return new MqttConnection(context, listener, resolver);
    }

    public abstract void connect() throws Exception;

    public abstract void disconnect() throws Exception;

    public abstract boolean isConnected();

    // for mqtt protocol
    private static class MqttConnection extends Connection {

        private static final String TAG = "MqttConnection";

        private static final boolean DEBUG = true;

        private static final long START_DELAY_TIME = 2 * 1000;

        private static final long END_DEALY_TIME = 64 * 1000;

        private String topic;

        private IMqttClient mqttClient;

        private MqttConnectOptions options;

        private ConnectionResolver resolver;

        private RegisterResponse registerResponse;

        private long retryDelayTime = START_DELAY_TIME;

        private InterruptedListener mListener;

        private Context context;

        private MqttConnection(Context context, InterruptedListener listener, ConnectionResolver resolver) {
            this.context = context;
            this.mListener = listener;
            this.resolver = resolver;
        }

        static MqttConnectOptions createNewOption(SocketFactory socketFactory, String mqttUsername,
                                                  String mqttPassword) {
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setMqttVersion(4); // MQTT 3.1.1
            connOpts.setSocketFactory(socketFactory);
            // 设置是否自动重连
            connOpts.setAutomaticReconnect(false);
            // 如果是true，那么清理所有离线消息，即Qos1或者2的所有未接收到的消息
            connOpts.setCleanSession(false);
            connOpts.setUserName(mqttUsername);
            connOpts.setMaxInflight(1);
            connOpts.setPassword(mqttPassword.toCharArray());
            return connOpts;
        }

        // to avoid memory leak
        private static SSLSocketFactory createSSLSocket(Context ctx) throws Exception {
            SSLContext context = SSLContext.getInstance("TLSV1.2");
            context.init(null, new TrustManager[]{ALiyunIotX509TrustManager.create(ctx)}, null);
            return context.getSocketFactory();
        }

        private static String createMqttClientId(String clientId, long t) {
            return clientId + "|securemode=2,signmethod=hmacsha1,timestamp=" + t + "|";
        }

        // get pack topic path string
        private static String createTopic(String productKey, String deviceName) {
            return "/" + productKey + "/" + deviceName + "/update";
        }

        // get mqtt server url string
        private static String createServerUrl(String productKey) {
            return "ssl://" + productKey + ".iot-as-mqtt.cn-shanghai.aliyuncs.com:1883";
        }

        // get mqtt password
        private static String createMqttPassword(String clientId, String productKey, String deviceName, String deviceSecret, long t) {
            Map<String, String> params = new HashMap<>();
            params.put("productKey", productKey); //这个是对应用户在控制台注册的 设备productkey
            params.put("deviceName", deviceName); //这个是对应用户在控制台注册的 设备name
            params.put("clientId", clientId);
            params.put("timestamp", String.valueOf(t));
            return SignUtil.sign(params, deviceSecret, "hmacsha1"); //签名
        }

        // get mqtt username
        private static String createMqttusername(String deviceName, String productKey) {
            return deviceName + "&" + productKey; //mqtt用户名格式
        }

        private void init()
                throws Exception {
            String clientId = InetAddress.getLocalHost().getHostAddress();
            SocketFactory socketFactory = createSSLSocket(context);
            topic = createTopic(registerResponse.productKey, registerResponse.deviceName);
            long t = System.currentTimeMillis();
            String targetServerUrl = createServerUrl(registerResponse.productKey);
            String mqttClientId = createMqttClientId(clientId, t);
            String mqttUsername = createMqttusername(registerResponse.deviceName, registerResponse.productKey);
            String mqttPassword = createMqttPassword
                    (clientId, registerResponse.productKey, registerResponse.deviceName, registerResponse.deviceSecret, t);
            options = createNewOption(socketFactory, mqttUsername, mqttPassword);
            mqttClient = new MqttClient(targetServerUrl, mqttClientId,
                    new MqttDefaultFilePersistence(context.getCacheDir().getAbsolutePath()));
        }

        @Override
        public void connect() throws MqttException {
            mqttClient.connect(options);
        }

        @Override
        public void disconnect() throws MqttException {
            mqttClient.disconnect();
        }

        @Override
        public void run() {
            if (registerResponse == null) {
                try {
                    registerResponse = resolver.resolve(null);
                    init();
                } catch (InterruptedException e) {
                    Timber.tag(TAG).d(e, "pack has stopped");
                    mListener.onIntercept(e);
                    return;
                } catch (Exception e) {
                    Timber.tag(TAG).d(e, "while init connection occur error");
                    return;
                }
            }

            if (!isConnected()) {
                try {
                    connect();
                    retryDelayTime = START_DELAY_TIME;
                    if (DEBUG) Timber.tag(TAG).d("connection has established.");
                } catch (Exception e) {
                    Timber.tag(TAG).d(e,
                            "failed to establish mqttConnection to mqtt server, try after %d s.",
                            retryDelayTime / 1000);
                    sleepForWhile();
                    return;
                }
            }

            try {
                MqttMessage mqttMessage = blockingQueue.take();
                mqttClient.publish(topic, mqttMessage);
                if (DEBUG)
                    Timber.tag(TAG).d("has push a message to iothub: %s", mqttMessage.toString());
            } catch (InterruptedException e) {
                mListener.onIntercept(e);
            } catch (MqttPersistenceException e) {
                Timber.tag(TAG).e(e, "MqttPersistenceException");

            } catch (MqttException e) {
                Timber.tag(TAG).e(e, "MqttException");
                sleepForWhile();
            }
        }

        @Override
        public boolean isConnected() {
            return mqttClient != null && mqttClient.isConnected();
        }

        private void sleepForWhile() {
            try {
                Thread.sleep(retryDelayTime);
                retryDelayTime *= 2;
                retryDelayTime = Math.min(retryDelayTime, END_DEALY_TIME);
            } catch (InterruptedException e1) {
                mListener.onIntercept(e1);
            }
        }
    }
}
