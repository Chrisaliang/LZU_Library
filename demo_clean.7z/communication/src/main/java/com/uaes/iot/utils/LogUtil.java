
package com.uaes.iot.utils;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


/**
 * @version $Id: LogUtil.java,v 0.1 2016年6月2日 下午4:39:18  Exp $
 */
class LogUtil {

    private static SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS", Locale.CHINA);
    /**
     * 是否打印日志
     **/
    @SuppressWarnings("FieldCanBeLocal")
    private static boolean showLog = true;

    /**
     * 简单日志打印
     *
     * @param msg log message
     */
    public static void print(String msg) {
        if (showLog) {
            String source = null;

            try {
                StackTraceElement st = Thread.currentThread().getStackTrace()[2];
                source = "[" + st.getFileName() + "] - " + st.getMethodName() + "("
                        + st.getLineNumber() + ")";
            } catch (Exception e) {
                Log.d("logUtils", "print: ", e);
            }

//            System.out.println(fm.format(new Date()) + " - " + source + ":" + msg);
            Log.d("FFF", fm.format(new Date()) + " - " + source + ":" + msg);
        }
    }

}
