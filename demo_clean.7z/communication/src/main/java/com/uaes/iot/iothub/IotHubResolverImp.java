package com.uaes.iot.iothub;

import android.text.TextUtils;

import com.uaes.common.AuthProvider;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;
import timber.log.Timber;

import static com.uaes.iot.ServiceEnvironment.IOT_CONFIG_BASE_URL;

/**
 * Created by hand on 2017/11/2.
 * Imp
 */

public class IotHubResolverImp implements IotHubResolver {

    private static final boolean DEBUG = true;
    private static final String TAG = IotHubResolverImp.class.getSimpleName();

    private IotService mIotService;
    private AuthProvider authProvider;

    public IotHubResolverImp(AuthProvider authProvider) {
        mIotService = createService();
        this.authProvider = authProvider;
    }

    private static IotService createService() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if (DEBUG) {
            HttpLoggingInterceptor log = new HttpLoggingInterceptor();
            log.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(log);
        }
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(IOT_CONFIG_BASE_URL)
                .client(builder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(IotService.class);
    }

    @Override
    public RegisterResponse resolve() throws InterruptedException {
//        String sha384 = Hashing.sha384().hashString(encode, Charset.defaultCharset()).toString();

        while (true) {
            Call<RegisterResponse> call = mIotService.register(authProvider.getSha384WithIMEI());
            try {
                Response<RegisterResponse> response = call.execute();
                if (response.isSuccessful()) {
                    RegisterResponse info = response.body();
                    if (info == null || TextUtils.isEmpty(info.deviceSecret)
                            || TextUtils.isEmpty(info.deviceName)) {
                        Timber.tag(TAG).d("resolved info is null,wait 5s for retry");
                        Thread.sleep(5000);
                    } else {
                        Timber.tag(TAG).d("Has get IotHub info: %s", info.toString());
                        return info;
                    }
                } else {
                    ResponseBody body = response.errorBody();
                    if (body != null)
                        Timber.tag(TAG).d("resolve errorbody%s", body.string());
                    Timber.tag(TAG).d("resolved info is error, waiting 10s for retry");
                    Thread.sleep(10000);
                }
            } catch (IOException e) {
                Timber.tag(TAG).d("resolveIotInformation: 10s to get iothub server url");
                Thread.sleep(10 * 1000);
            }
        }
    }

    interface IotService {
        @GET("/car/v1/carAuth/commAuth")
        Call<RegisterResponse> register(@Query("accessKey") String vinCode);
    }

}
