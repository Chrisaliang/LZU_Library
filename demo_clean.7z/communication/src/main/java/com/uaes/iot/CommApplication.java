package com.uaes.iot;

import android.app.Application;
import android.arch.persistence.room.Room;
import android.support.annotation.NonNull;

import com.orhanobut.logger.DiskLogAdapter;
import com.orhanobut.logger.Logger;
import com.uaes.iot.room.UaesDatabase;
import com.uaes.iot.service.McuService;
import com.xdandroid.hellodaemon.DaemonEnv;

import timber.log.Timber;

/**
 * Author: tianbing
 * Date: 2017/10/16
 * Overview:
 */

public class CommApplication extends Application {

    public static UaesDatabase instanceDb;
    public static UaesDatabase delayDb;
    public static UaesDatabase errorDb;

    @Override
    public void onCreate() {
        super.onCreate();
//        DaemonEnv.initialize(this, DaemonService.class, DaemonEnv.DEFAULT_WAKE_UP_INTERVAL);

        DaemonEnv.initialize(this, McuService.class, DaemonEnv.DEFAULT_WAKE_UP_INTERVAL);
//        DaemonEnv.initialize(this, PushService.class, DaemonEnv.DEFAULT_WAKE_UP_INTERVAL);
        Logger.addLogAdapter(new DiskLogAdapter());
        Timber.plant(new Timber.DebugTree() {
            @Override
            protected void log(int priority, String tag, @NonNull String message, Throwable t) {
                Logger.log(priority, tag, message, t);
            }
        });
        Timber.plant(new Timber.DebugTree());
        instanceDb = Room.databaseBuilder(getApplicationContext(), UaesDatabase.class, "uaes_instance").build();
        delayDb = Room.databaseBuilder(getApplicationContext(), UaesDatabase.class, "uaes_delay").build();
        errorDb = Room.databaseBuilder(getApplicationContext(), UaesDatabase.class, "uaes_error").build();
    }
}
