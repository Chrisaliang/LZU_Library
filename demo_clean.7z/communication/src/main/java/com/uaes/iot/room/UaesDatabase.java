package com.uaes.iot.room;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.uaes.iot.mcu.Frame;

/**
 * Created by aber on 12/11/2017.
 * Can message
 */
@Database(entities = {
        Frame.class
}, version = 1)
public abstract class UaesDatabase extends RoomDatabase {


    public abstract FrameDao getFrameDao();
}
