package com.uaes.iot.location;

import android.text.TextUtils;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationListener;
import com.uaes.common.AuthProvider;
import com.uaes.iot.iothub.Connection;
import com.uaes.iot.iothub.MessageConstructor;

import timber.log.Timber;

/**
 * Created by aber on 1/19/2018.
 * Location Worker
 */

public class LocationWorker implements AMapLocationListener {

    private static final String TAG = "LocationWorker";
    private static final boolean DEBUG = true;
    private AuthProvider authProvider;

    public LocationWorker(AuthProvider authProvider) {
        this.authProvider = authProvider;
    }

    @Override
    public void onLocationChanged(AMapLocation aMapLocation) {
        if (DEBUG)
            Timber.tag(TAG).d(aMapLocation.toStr());
        if (aMapLocation.getErrorCode() == 0 && !TextUtils.isEmpty(aMapLocation.getCityCode())) {
            try {
                Connection.blockingQueue.put(
                        MessageConstructor.createForLocation(authProvider.getVinCode(), aMapLocation));
            } catch (Exception e) {
                Timber.tag(TAG).e(e);
            }
        }
    }
}
