package com.uaes.iot.utils;

/**
 * Created by aber on 12/9/2017.
 * Byte Utils
 */

@SuppressWarnings("WeakerAccess")
public class IotBytes {

    private static final int LONG_BYTES = 8;

    /**
     * Convert a long value to a 8 bytes byte array.
     *
     * @param src    long value to be convert.
     * @param dest   destination byte array length must >= 8.
     * @param offset start position in dest array.
     * @return If copyRaw success return true, other wise return false.
     */
    public static boolean copyLongToByteArray(long src, byte[] dest, int offset) {
        if (dest.length < LONG_BYTES) return false;
        for (int i = 7; i >= 0; --i) {
            dest[offset + i] = (byte) (src & 0xFF);
            src >>= 8;
        }
        return true;
    }

    /**
     * Convert a byte array to a String
     * if src array is '{-1, 2, 34}' , then return value is
     * 0xFF 02 22
     *
     * @param src to be convert byte array.
     * @return hex value.
     */
    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("0x");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (byte item : src) {
            stringBuilder.append(String.format("%02X", item)).append(' ');
        }
        return stringBuilder.toString();
    }

    /**
     * Convert hex string to byte[]
     *
     * @param hexString the hex string
     * @return byte[]
     */
    public static byte[] hexStringToBytes(String hexString) {
        if (hexString == null || hexString.equals("")) {
            return null;
        }
        hexString = hexString.toUpperCase();
        int length = hexString.length() / 2;
        char[] hexChars = hexString.toCharArray();
        byte[] d = new byte[length];
        for (int i = 0; i < length; i++) {
            int pos = i * 2;
            d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
        }
        return d;
    }

    /**
     * Convert char to byte
     *
     * @param c char
     * @return byte
     */
    private static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }
}
