package com.uaes.iot.room;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.RoomDatabase;
import android.support.annotation.NonNull;

/**
 * Created by aber on 12/18/2017.
 * Timeout trigger for clear old data in database.
 */

public class UaesRoomCallback extends RoomDatabase.Callback {

    private static final String CREATE_TRIGGER = "CREATE TRIGGER timeoutCan "
            + "BEFORE INSERT "
            + "ON can "
            + "for each row "
            + "WHEN "
            + "BEGIN "
            + "DELETE FROM can WHERE (strftime('%s','now') * 1000 - time) > ?; "
            + "END";

    private long timeOutTimeInMills;

    public UaesRoomCallback(long timeOutTimeInMills) {
        this.timeOutTimeInMills = timeOutTimeInMills;
    }

    @Override
    public void onCreate(@NonNull SupportSQLiteDatabase db) {
        super.onCreate(db);

        // create timeout trigger to clear the data
        db.execSQL(CREATE_TRIGGER, new Long[]{timeOutTimeInMills});

    }
}
