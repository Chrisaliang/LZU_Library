package com.uaes.iot.iothub;

/**
 * Created by hand on 2017/11/2.
 * IotHub Information resolver
 */

public interface IotHubResolver {

    RegisterResponse resolve() throws InterruptedException;
}
