package com.uaes.iot.iothub;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Author: tianbing
 * Date: 2017/10/17
 * Overview:  阿里云物联网套件 加密管理器
 */

public class ALiyunIotX509TrustManager implements X509TrustManager {
    //根证书认证
    private X509TrustManager rootTrusm;

    private ALiyunIotX509TrustManager(Certificate ca) throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
        String keyStoreType = KeyStore.getDefaultType();
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        keyStore.load(null, null);
        keyStore.setCertificateEntry("ca", ca);
        String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
        tmf.init(keyStore);
        rootTrusm = (X509TrustManager) tmf.getTrustManagers()[0];
    }

    public static ALiyunIotX509TrustManager create(Context context) throws IOException, CertificateException, KeyStoreException, NoSuchAlgorithmException {
        InputStream in = context.getAssets().open("root.crt");
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate ca;
        //noinspection TryFinallyCanBeTryWithResources
        try {
            ca = cf.generateCertificate(in);
        } finally {
            in.close();
        }
        return new ALiyunIotX509TrustManager(ca);
    }

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        //TODO
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        rootTrusm.checkServerTrusted(chain, authType);
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}
