package com.uaes.iot.iothub;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Author: tianbing
 * Date: 2017/10/16
 * Overview:
 */

@SuppressWarnings("WeakerAccess")
public class RegisterResponse implements Parcelable {
    public static final Creator<RegisterResponse> CREATOR = new Creator<RegisterResponse>() {
        @Override
        public RegisterResponse createFromParcel(Parcel in) {
            return new RegisterResponse(in);
        }

        @Override
        public RegisterResponse[] newArray(int size) {
            return new RegisterResponse[size];
        }
    };
    @SerializedName("deviceId")
    public String deviceId;

    @SerializedName("deviceName")
    public String deviceName;

    @SerializedName("deviceSecret")
    public String deviceSecret;

    @SerializedName("deviceStatus")
    public String deviceStatus;

    @SerializedName("errorMessage")
    public String errorMessage;

    @SerializedName("productKey")
    public String productKey;

    @SerializedName("requestId")
    public String requestId;

    @SerializedName("success")
    boolean success;

    public RegisterResponse() {

    }

    protected RegisterResponse(Parcel in) {
        deviceId = in.readString();
        deviceName = in.readString();
        deviceSecret = in.readString();
        deviceStatus = in.readString();
        errorMessage = in.readString();
        productKey = in.readString();
        requestId = in.readString();
        success = in.readByte() != 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(deviceId);
        dest.writeString(deviceName);
        dest.writeString(deviceSecret);
        dest.writeString(deviceStatus);
        dest.writeString(errorMessage);
        dest.writeString(productKey);
        dest.writeString(requestId);
        dest.writeByte((byte) (success ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public String toString() {
        return "RegisterResponse{" +
                "deviceId='" + deviceId + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", deviceSecret='" + deviceSecret + '\'' +
                ", deviceStatus='" + deviceStatus + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                ", productKey='" + productKey + '\'' +
                ", requestId='" + requestId + '\'' +
                ", success=" + success +
                '}';
    }
}
