package com.uaes.iot.iothub;

import android.text.TextUtils;

import com.uaes.common.AuthProvider;

import org.eclipse.paho.client.mqttv3.MqttCallback;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import timber.log.Timber;

import static com.uaes.iot.ServiceEnvironment.IOT_CONFIG_BASE_URL;

/**
 * Created by aber on 1/5/2018.
 * info resolver
 */

public class ConnectionResolverImp implements ConnectionResolver {

    private static final boolean DEBUG = true;
    private static final String TAG = "ConnectionResolverImp";

    private IotHubResolverImp.IotService mIotService;
    private AuthProvider authProvider;

    public ConnectionResolverImp(AuthProvider authProvider) {
        mIotService = createService();
        this.authProvider = authProvider;
    }

    private static IotHubResolverImp.IotService createService() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if (DEBUG) {
            HttpLoggingInterceptor log = new HttpLoggingInterceptor();
            log.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(log);
        }
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(IOT_CONFIG_BASE_URL)
                .client(builder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(IotHubResolverImp.IotService.class);
    }

    @Override
    public RegisterResponse resolve(MqttCallback callback) throws InterruptedException {
        while (true) {
            Call<RegisterResponse> call = mIotService.register(authProvider.getSha384WithIMEI());
            try {
                Response<RegisterResponse> response = call.execute();
                if (response.isSuccessful()) {
                    RegisterResponse info = response.body();
                    if (info == null || TextUtils.isEmpty(info.deviceSecret)
                            || TextUtils.isEmpty(info.deviceName)) {
                        Timber.tag(TAG).d("resolved info is null,wait 5s for retry");
                        Thread.sleep(5000);
                    } else {
                        Timber.tag(TAG).d("Has get IotHub info: %s", info.toString());
                        return info;
                    }
                } else {
                    ResponseBody body = response.errorBody();
                    if (body != null)
                        Timber.tag(TAG).d("resolve errorbody%s", body.string());
                    Timber.tag(TAG).d("resolved info is error,wait 10s for retry");
                    Thread.sleep(10000);
                }
            } catch (IOException e) {
                Timber.tag(TAG).d(e, "resolveIotInformation: 10 retry to get iothub configuration");
                Thread.sleep(10 * 1000);
            } catch (Exception e) {
                e.printStackTrace();
                Timber.tag(TAG).d(e, "resolveIotInformation: 10 retry to get iothub configuration");
                Thread.sleep(10 * 1000);
            }
        }
    }
}
