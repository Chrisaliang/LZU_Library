package com.uaes.iot.mcu;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;
import android.support.v4.util.Pools;

import com.uaes.iot.room.Tables;
import com.uaes.iot.utils.IotBytes;

/**
 * Created by aber on 12/20/2017.
 * Represent 20 bytes frame array.
 * Performed for memory usage.
 */
@Entity(tableName = "frame")
public class Frame {
    /**
     * Frame offset time length in bytes;
     */
    public static final int OFFSET_TIME_BYTES = 4;
    /**
     * Frame  can id bytes length.
     */
    public static final int ID_BYTES = 4;
    /**
     * Frame payload bytes length.
     */
    public static final int PAYLOAD_BYTES = 8;
    /**
     * Frame timestamp bytes length.
     */
    public static final int TIMESTAMP_BYTES = 8;
    /**
     * Frame bytes length.
     * */
    public static final int FRAME_BYTES = TIMESTAMP_BYTES + ID_BYTES + PAYLOAD_BYTES;

    /**
     * Frame header byte length.
     * */
    public static final int FRAME_HEADER = TIMESTAMP_BYTES + ID_BYTES;
    /**
     * Ecu's Frame content bytes length.
     */
    public static final int ECU_FRAME_BYTES = OFFSET_TIME_BYTES + ID_BYTES + PAYLOAD_BYTES;
    private static final int MAX_FRAME_POOL_SIZE = 512;
    private static Pools.Pool<Frame> framePool = new Pools.SynchronizedPool<>(MAX_FRAME_POOL_SIZE);
    @ColumnInfo(name = Tables.COLUMN_CAN_ID, typeAffinity = ColumnInfo.BLOB)
    private final byte[] canId = new byte[ID_BYTES];
    @ColumnInfo(name = Tables.COLUMN_PAYLOAD, typeAffinity = ColumnInfo.BLOB)
    private final byte[] payload = new byte[PAYLOAD_BYTES];
    @PrimaryKey
    @ColumnInfo(name = Tables.COLUMN_TIME_STAMP, typeAffinity = ColumnInfo.INTEGER)
    private long timestamp;

    /**
     * obtain a frame for usage from memory pool.
     */
    public static Frame obtain() {
        Frame frame = framePool.acquire();
        return frame == null ? new Frame() : frame;
    }

    /**
     * release a frame to memory pool.
     */
    public static void release(@NonNull Frame frame) {
        framePool.release(frame);
    }

    public long getTimestamp() {
        return timestamp;
    }

    /**
     * Copy the frame's timestamp to dest byte array.
     * @param timestamp copy value to.
     * */
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * new a byte array and return.
     * */
    public byte[] getCanId() {
        byte[] copy = new byte[ID_BYTES];
        System.arraycopy(canId, 0, copy, 0, ID_BYTES);
        return copy;
    }

    /**
     * Copy frame's canId to dest array
     *
     * @param src copy value to.
     */
    public void setCanId(byte[] src) {
        System.arraycopy(src, 0, canId, 0, ID_BYTES);
    }

    /**
     * new a byte array and return.
     * */
    public byte[] getPayload() {
        byte[] copy = new byte[PAYLOAD_BYTES];
        System.arraycopy(payload, 0, copy, 0, PAYLOAD_BYTES);
        return copy;
    }

    /**
     * Copy frame's payload to dest array
     *
     * @param src copy value to.
     */
    public void setPayload(byte[] src) {
        System.arraycopy(src, 0, payload, 0, PAYLOAD_BYTES);
    }

    /**
     * Copy the Frame to dest byte array start with offset
     * */
    public void copyFrame(byte[] dest, int offset) {
        IotBytes.copyLongToByteArray(timestamp, dest, offset);
        System.arraycopy(canId, 0, dest, offset + TIMESTAMP_BYTES, ID_BYTES);
        System.arraycopy(payload, 0, dest, offset + ID_BYTES + TIMESTAMP_BYTES, PAYLOAD_BYTES);
    }

    /**
     * Update frame's content with byte array from ecu queue
     * the array's length is 16, and first
     * */
    public void update(byte[] ecuFrame, long timestamp) {
        this.timestamp = timestamp;
        System.arraycopy(ecuFrame, OFFSET_TIME_BYTES, canId, 0, ID_BYTES);
        System.arraycopy(ecuFrame, OFFSET_TIME_BYTES + ID_BYTES, payload, 0, PAYLOAD_BYTES);
    }

    // TODO
    public boolean isInstance() {
        return true;
    }

    @Override
    public String toString() {
        return "Frame{" +
                "timestamp= " + timestamp +
                ", canId= " + IotBytes.bytesToHexString(canId) +
                ", payload= " + IotBytes.bytesToHexString(payload) +
                '}';
    }
}
