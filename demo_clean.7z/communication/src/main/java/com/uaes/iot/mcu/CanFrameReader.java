package com.uaes.iot.mcu;

import java.io.Closeable;

/**
 * Created by aber on 12/11/2017.
 * Interface of CanMsg Reader.
 */

public interface CanFrameReader extends Closeable {

    /**
     * read a Can Msg , if failed  return -1 or throw out
     * IOException
     */
    int read(byte[] canFrame) throws Exception;
}
