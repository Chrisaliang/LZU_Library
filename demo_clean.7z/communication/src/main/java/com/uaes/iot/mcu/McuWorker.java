package com.uaes.iot.mcu;

import com.uaes.iot.room.FrameDao;

import timber.log.Timber;

/**
 * Created by aber on 12/19/2017.
 * McnWorker performed for memory usage.
 */

public class McuWorker implements Runnable {
    //  0x05C8 500ms 一次
    //  0x05C7 和 0x05C9 500ms 一次
    // 综合一秒钟 4个frame 读取间隔设置为250 以下可以保证不丢
    public static final long READ_INTER = 245;
    private static final String TAG = "McuWorker";
    private static final boolean DEBUG = true;
    private final Frame tempFrame = new Frame();
    private final byte[] tempBytes = new byte[Frame.ECU_FRAME_BYTES];
    private CanFrameReader reader;
    private FrameDao instance;
    private FrameDao delay;

    public McuWorker(CanFrameReader reader, FrameDao instance, FrameDao delay) {
        this.reader = reader;
        this.instance = instance;
        this.delay = delay;
    }

    public void clearResource() throws Exception {
        if (reader != null)
            reader.close();
    }

    private void saveFrame(byte[] f) {
        tempFrame.update(f, System.currentTimeMillis());
        if (DEBUG)
            Timber.tag(TAG).d("Frame: %s", tempFrame.toString());
        if (tempFrame.isInstance()) {
            instance.insert(tempFrame);
        } else {
            delay.insert(tempFrame);
        }
    }

    @Override
    public void run() {
        try {
            if (reader.read(tempBytes) == Frame.ECU_FRAME_BYTES) {
                saveFrame(tempBytes);
            } else {
                Thread.sleep(READ_INTER * 4);
            }
        } catch (Exception e) {
            Timber.tag(TAG).d(e, "read CanMsg from Can get an Error.");
        }
    }
}
