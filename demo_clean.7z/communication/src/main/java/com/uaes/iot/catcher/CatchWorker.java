package com.uaes.iot.catcher;

import com.uaes.common.AuthProvider;
import com.uaes.iot.InterruptedListener;
import com.uaes.iot.iothub.Connection;
import com.uaes.iot.room.FrameDao;

import org.eclipse.paho.client.mqttv3.MqttMessage;

import timber.log.Timber;

/**
 * Created by aber on 12/20/2017.
 * Pack data.
 */

public class CatchWorker implements Runnable {

    private static final String TAG = "CatchWorker";

    private static final boolean DEBUG = true;

    private FrameDao dao;
    private AuthProvider mAuth;
    private InterruptedListener mListener;
    private String type;

    public CatchWorker(String type, InterruptedListener listener, AuthProvider authProvider,
                       FrameDao canMsgDao) {
        this.dao = canMsgDao;
        this.mAuth = authProvider;
        this.mListener = listener;
        this.type = type;
    }


    @Override
    public void run() {
        MqttMessage mqttMessage = dao.pack(mAuth.getVinCode(), type);
//        MqttMessage mqttMessage = new MqttMessage(new byte[]{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1});
        try {
            if (mqttMessage == null) {
                Timber.tag(TAG).i("catch a null package, sleep 5s.");
                // if null we should sleep thread for the cache already.
                Thread.sleep(5000);
            } else {
                Timber.tag(TAG).d("catch message");
                Connection.blockingQueue.put(mqttMessage);
            }
        } catch (InterruptedException e) {
            mListener.onIntercept(e);
        }
    }
}
