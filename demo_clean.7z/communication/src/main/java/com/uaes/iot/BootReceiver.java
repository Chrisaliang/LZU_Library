package com.uaes.iot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.uaes.iot.service.McuService;
import com.xdandroid.hellodaemon.DaemonEnv;

import timber.log.Timber;

public class BootReceiver extends BroadcastReceiver {

    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            Timber.tag(TAG).d("start mcn service after boot");
            McuService.shouldStopService = false;
            DaemonEnv.startServiceMayBind(McuService.class);
        }
    }
}
