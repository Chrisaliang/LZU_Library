package com.uaes.iot.mcu;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import timber.log.Timber;

/**
 * Created by aber on 12/8/2017.
 * using for read Can msg from Can Queue file
 */
public class McuCanMsgReader implements CanFrameReader {

    private static final String MCU_CAN_MSG_PATH = "/sys/class/vendor_mcu_class/mcu_canmsg";

    private RandomAccessFile mMcuRandomAccessFile;

    public McuCanMsgReader() throws FileNotFoundException {
        mMcuRandomAccessFile = new RandomAccessFile(new File(MCU_CAN_MSG_PATH), "r");
    }

    @Override
    public int read(byte[] canFrame) throws Exception {
        if (canFrame == null)
            throw new IllegalArgumentException("canFrame argument must not null");
        ensureFile();
        int readCount = mMcuRandomAccessFile.read(canFrame);
        if (readCount != 16) {
            Timber.d("can't get complete frame from can bus, actual frame size is: %s", readCount);
            return -1;
        } else
            return readCount;
    }

    private void ensureFile() throws IOException {
        if (mMcuRandomAccessFile == null)
            throw new NullPointerException("Mcu RandomAccessFile is null");
        mMcuRandomAccessFile.seek(0);
    }

    @Override
    public void close() throws IOException {
        if (mMcuRandomAccessFile != null)
            mMcuRandomAccessFile.close();
    }
}
