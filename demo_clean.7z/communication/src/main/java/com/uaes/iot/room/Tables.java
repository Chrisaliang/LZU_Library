package com.uaes.iot.room;

/**
 * Created by aber on 1/18/2018.
 */

public interface Tables {
    String COLUMN_TIME_STAMP = "timestamp";
    String COLUMN_CAN_ID = "can_id";
    String COLUMN_PAYLOAD = "payload";
}
