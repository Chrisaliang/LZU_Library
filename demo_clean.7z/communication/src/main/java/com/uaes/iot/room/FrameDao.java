package com.uaes.iot.room;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;

import com.uaes.iot.iothub.MessageConstructor;
import com.uaes.iot.mcu.Frame;

import org.eclipse.paho.client.mqttv3.MqttMessage;

import timber.log.Timber;

/**
 * Created by aber on 1/18/2018.
 *
 */
@Dao
public abstract class FrameDao {
    private static final String TAG = "FrameDao";

    private static final int CACHE_SIZE = 40;

    private static final long SEVEN_DAY = 7 * 24 * 60 * 60 * 1000;

    private byte[] cachePackage = new byte[CACHE_SIZE * Frame.FRAME_BYTES];

    @Insert
    public abstract void insert(Frame... frames);

    @Transaction
    @Query("SELECT * FROM frame limit :limit ")
    public abstract Frame[] query(int limit);

    @Delete
    abstract void delete(Frame... frames);

    @Query("DELETE FROM frame where " + Tables.COLUMN_TIME_STAMP + " < :timeStamp")
    abstract void deleteTimeout(long timeStamp);

    /**
     * if the database cache not full
     * */
    @Transaction
    public MqttMessage pack(String vinCode, String type) {
        Frame[] frames = this.query(CACHE_SIZE);
        long currentTime = System.currentTimeMillis();
        deleteTimeout(currentTime - SEVEN_DAY);
        if (frames.length == CACHE_SIZE) {
            for (int i = 0; i < CACHE_SIZE; ++i) {
                frames[i].copyFrame(cachePackage, i * Frame.FRAME_BYTES);
            }
            try {
                delete(frames);
                return MessageConstructor.createFromMcu(
                        cachePackage, vinCode, type
                );
            } catch (Exception e) {
                Timber.tag(TAG).e(e);
                throw new IllegalStateException(e);
            }
        } else {
            return null;
        }
    }
}
