package com.uaes.iot.iothub;

import org.eclipse.paho.client.mqttv3.MqttCallback;

/**
 * Created by aber on 1/5/2018.
 * Create MqttConnection
 */

public interface ConnectionResolver {

    RegisterResponse resolve(MqttCallback callback) throws InterruptedException;

}
