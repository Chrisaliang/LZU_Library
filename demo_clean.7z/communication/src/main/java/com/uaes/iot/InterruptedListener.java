package com.uaes.iot;

/**
 * Created by aber on 1/5/2018.
 * Catch event listener
 */

public interface InterruptedListener {
    void onIntercept(InterruptedException e);
}
