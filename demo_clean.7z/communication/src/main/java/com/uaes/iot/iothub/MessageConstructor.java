package com.uaes.iot.iothub;

import com.amap.api.location.AMapLocation;
import com.uaes.iot.utils.PayloadCoder;

import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import timber.log.Timber;

/**
 * Created by aber on 12/6/2017.
 * Mqtt Json string structure.
 *
 * TODO Using pool to Cache the MqttMessage to memory problem.
 * TODO We don't know when the MqttMessage has been release by
 * TODO Paho library, so there is a lifecycle problem about MqttMessage.
 */

@SuppressWarnings("WeakerAccess")
public class MessageConstructor {

    public static final String VER = "VER";  // Json 版本
    public static final String DT = "DT"; // VIN 标识
    public static final String FR = "FR"; //类型信息 STS TEL ERR WARN OTHER
    public static final String TY = "TY"; // 时间字符串  20171010163022
    public static final String TS = "TS"; // 压缩后的字符串 先使用zlib压缩字节序，然后使用Base64转换为字符串
    private final static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault());
    private final static StringBuilder stringBuffer = new StringBuilder();
    private static final String VER_1_0 = "1.0";


    public static synchronized MqttMessage createFromMcu(byte[] message, String encodeVin, String type) {
        String compress;
        try {
            compress = PayloadCoder.compress(message);
        } catch (IOException e) {
            Timber.tag("zlib compress").d(e, "error");
            return null;
        }
        return createMqttMessage(VER_1_0, encodeVin, type, compress);
    }

    public static synchronized MqttMessage createForLocation(String encodeVin, AMapLocation location) {
        String payload = System.currentTimeMillis() + "|" + location.getLatitude()
                + "|" + location.getLongitude() + "|" + location.getCityCode();
        return createMqttMessage(VER_1_0, encodeVin, "GPS", payload);
    }

    private static MqttMessage createMqttMessage(String ver, String encodeVin, String type, String payload) {
        stringBuffer.delete(0, stringBuffer.length());
        stringBuffer.append('{');
        put(stringBuffer, VER, ver);
        stringBuffer.append(',');
        put(stringBuffer, FR, encodeVin);
        stringBuffer.append(',');
        put(stringBuffer, TS, simpleDateFormat.format(new Date()));
        stringBuffer.append(',');
        put(stringBuffer, TY, type);
        stringBuffer.append(',');
        put(stringBuffer, DT, payload);
        stringBuffer.append('}');
        return new MqttMessage(stringBuffer.toString().getBytes());
    }

    private static void put(StringBuilder stringBuffer, String key, String value) {
        stringBuffer.append('"').append(key).append('"')
                .append(':').append('"').append(value).append('"');
    }
}
