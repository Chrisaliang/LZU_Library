package com.uaes.iot;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Chrisaliang on 2017/10/17.
 * test the format of date
 */

public class DateFormatterTest {

    @Test
    public void convert() {
        SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmss", Locale.getDefault());
        Date date = new Date();
        String format = sdf.format(date);
        System.out.println(format);
    }


    @Test
    public void testTry() {
        int a = add();
        System.out.println(a);
    }

    private int add() {
        try {
            int a = 1 + 1;
            return a;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        } finally {
            System.out.println("finally");
        }
    }
}
