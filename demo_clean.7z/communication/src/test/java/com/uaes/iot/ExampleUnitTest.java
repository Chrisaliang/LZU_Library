package com.uaes.iot;

import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;

import org.junit.Assert;
import org.junit.Test;

import java.nio.charset.Charset;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }


    @Test
    public void blockingQueueTest() throws InterruptedException {
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(16);
        for (int i = 0; i< 20; i ++) {
            queue.put(1);
            System.out.println(queue.size());
        }
    }

    @Test
    public void sha384Test() {
        String test = "b1cdbaf7d937f2bad5ad171ad7e7a081c664d4f181b941f62ab4082aed5887901fcc44286f799f05f74a55d78b464a59";
        String src = "LNBSCUAK5HF043610:863010033346821";
        HashCode hashCode = Hashing.sha384().hashString(src, Charset.defaultCharset());
        Assert.assertEquals(test, hashCode.toString());
    }
}