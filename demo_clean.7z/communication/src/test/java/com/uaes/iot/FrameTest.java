package com.uaes.iot;

import com.google.common.primitives.Longs;
import com.uaes.iot.mcu.Frame;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by aber on 12/20/2017.
 * Frame Test
 */


public class FrameTest {

    private SimpleDateFormat simpleDateFormat;

    private byte[] bytes = new byte[]{
            1, 2, 3, 4,
            0, 0, 0, 1,
            2, 2, 2, 2,
            2, 2, 2, 2
    };

    @Before
    public void prepareDate() {
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS", Locale.CHINA);
    }

    @Test
    public void getTimeStr() {
        long longData = 1514445185024L;
        Date date = new Date(longData);
        String time = simpleDateFormat.format(date);
        System.out.println(time);
    }


    @Test
    public void frame() {
        Frame frame = new Frame();
        long time = System.currentTimeMillis();
        frame.update(bytes, time);
        Assert.assertEquals(time, frame.getTimestamp());
        Assert.assertArrayEquals(frame.getCanId(), new byte[]{0, 0, 0, 1});
        Assert.assertArrayEquals(frame.getPayload(), new byte[]{2, 2, 2, 2, 2, 2, 2, 2});

        byte[] temp = new byte[Frame.FRAME_BYTES];
        frame.copyFrame(temp, 0);
        long tempTime = Longs.fromBytes(
                temp[0],
                temp[1],
                temp[2],
                temp[3],
                temp[4],
                temp[5],
                temp[6],
                temp[7]
        );
        Assert.assertEquals(tempTime, time);
        Assert.assertArrayEquals(new byte[]
                {
                        0, 0, 0, 1,
                        2, 2, 2, 2,
                        2, 2, 2, 2
                }, new byte[]{
                temp[8],
                temp[9],
                temp[10],
                temp[11],
                temp[12],
                temp[13],
                temp[14],
                temp[15],
                temp[16],
                temp[17],
                temp[18],
                temp[19],
        });
    }
}
