package com.uaes.iot;

import com.uaes.iot.utils.IotBytes;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by aber on 12/9/2017.
 * Test
 */

public class ByteOperationTest {

    @Test
    public void testLongToByteArray() {
        long zero = 0x00;
        long two = 2;
        long three = 3;
        long four = 4;
        byte[] zeroBytes = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        byte[] twoBytes = {0, 0, 0, 0, 0, 0, 0, 0, 2};
        byte[] threeBytes = {0, 0, 0, 0, 0, 0, 0, 0, 3};
        byte[] fourBytes = {0, 0, 0, 0, 0, 0, 0, 0, 4};
        byte[] moneBytes = {0, -1, 0, 0, 0, 0, 0, 0, 0};
        byte[] dest = new byte[9];
        IotBytes.copyLongToByteArray(zero, dest, 0);
        Assert.assertArrayEquals(zeroBytes, dest);
        IotBytes.copyLongToByteArray(two, dest, 1);
        Assert.assertArrayEquals(twoBytes, dest);
        IotBytes.copyLongToByteArray(three, dest, 1);
        Assert.assertArrayEquals(threeBytes, dest);
        IotBytes.copyLongToByteArray(four, dest, 1);
        Assert.assertArrayEquals(fourBytes, dest);

    }

    @Test
    public void timestampPrint() {
        byte[] bytes = new byte[8];
        long timestamp = 1522050513961L;
        IotBytes.copyLongToByteArray(timestamp, bytes, 0);
        System.out.println(IotBytes.bytesToHexString(bytes));
    }
}
