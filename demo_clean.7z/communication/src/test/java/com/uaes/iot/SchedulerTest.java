package com.uaes.iot;

import org.junit.Test;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Created by aber on 1/22/2018.
 */

public class SchedulerTest {

    @Test
    public void testSchedule() throws InterruptedException {
        ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(1);
        ScheduledFuture scheduledFuture = scheduledExecutorService.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                System.out.println("------" + System.currentTimeMillis());
            }
        }, 2, 2, TimeUnit.SECONDS);

        Thread.sleep(30 * 1000);
        scheduledFuture.cancel(false);
        Thread.sleep(30 * 1000);
    }
}
