package com.uaes.iot;

import android.content.Context;

import com.uaes.iot.mcu.Frame;
import com.uaes.iot.room.FrameDao;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;

import timber.log.Timber;

/**
 * Created by aber on 11/15/2017.
 * 从日志文件中读取测试用的CAN FRAME
 */

@SuppressWarnings("WeakerAccess")
public class MockMcuWorker implements Runnable {

    private static final String TAG = MockMcuWorker.class.getSimpleName();

    private BufferedReader reader1;
    private BufferedReader reader2;
    private BufferedReader reader3;

    private int readFlag = 0;

    private int count = 0;
    private int count1 = 0;
    private int count2 = 0;

    private FrameDao dao;

    private Frame cacheFrame = new Frame();

    private FileWriter os;


    public MockMcuWorker(Context context, FrameDao dao) throws IOException {
        this.dao = dao;
        reader1 = new BufferedReader(new InputStreamReader(context.getAssets().open("fuel_desc.txt")));
        reader2 = new BufferedReader(new InputStreamReader(context.getAssets().open("mile.txt")));
        reader3 = new BufferedReader(new InputStreamReader(context.getAssets().open("timeOutFuel.txt")));
        readFlag = 0;
        os = new FileWriter(context.getExternalCacheDir().getAbsoluteFile() + "log.txt");
    }

    @Override
    public void run() {
        Timber.tag(TAG).d("Mock start");

        // start to read line from file
        String rawMessage;
        ByteBuffer byteBuffer = ByteBuffer.allocate(16);
        try {
            if (readFlag == 0) {
                rawMessage = reader1.readLine();
                if (rawMessage != null)
                    count++;
                readFlag = 1;
            } else if (readFlag == 1) {
                rawMessage = reader2.readLine();
                if (rawMessage != null)
                    count1++;
                readFlag = 2;
            } else if (readFlag == 2) {
                rawMessage = reader3.readLine();
                if (rawMessage != null)
                    count2++;
                readFlag = 0;
            } else {
                Timber.tag(TAG).d("readFlag error:%d", readFlag);
                return;
            }
            if (rawMessage == null) {
                Thread.sleep(10000);
                Timber.tag(TAG).d("读取完毕 循环 为空");
                return;
            }

            if (process(rawMessage, byteBuffer)) {
                dao.insert(cacheFrame);
                Timber.tag(TAG)
                        .d("Count: %d,Count1 %d, Count2 %d", count, count1, count2);
            }
        } catch (IOException e) {
            Timber.tag(TAG).d(e, "run: IOE");
        } catch (InterruptedException i) {
            Timber.tag(TAG).d(i, "run: Thread has shutDown");
        }
    }

    private boolean process(String rawMessage, ByteBuffer byteBuffer) {
        String[] xoCodes = rawMessage.split(" ");
        if (xoCodes.length == 12) {
            byteBuffer.clear();
            byteBuffer.putInt(1);
            for (int i = 0; i < 12; i++)
                byteBuffer.put((byte) Integer.parseInt(xoCodes[i], 16));
            cacheFrame.update(byteBuffer.array(), System.currentTimeMillis());
            return true;
        } else {
            return false;
        }
    }

    public void clearResource() {
        try {
            reader1.close();
            reader2.close();
            reader3.close();
        } catch (IOException e) {
            Timber.tag(TAG).e(e, "close file failed.");
        }
    }
}


