package com.uaes.iot;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.uaes.common.AuthProvider;
import com.uaes.common.CarConfigManager;
import com.uaes.common.VinConfig;
import com.uaes.iot.service.McuService;
import com.xdandroid.hellodaemon.DaemonEnv;

import java.util.ArrayList;
import java.util.List;

public class LogActivity extends AppCompatActivity implements OnItemSelectedListener {

    private CarConfigManager manager;

    private AuthProvider authProvider;

    private EditText vin;
    private EditText imei;

    private ArrayAdapter<VinConfig> adapter;

    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        authProvider = AuthProvider.getInstance(getApplicationContext());
        manager = authProvider.getManager();
        spinner = findViewById(R.id.list_item);
        List<VinConfig> configs = new ArrayList<>();
        manager.readConfig(configs);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, android.R.id.text1, configs);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        vin = findViewById(R.id.vin);
        imei = findViewById(R.id.imei);
    }

    public void onStartService(View view) {
        McuService.shouldStopService = false;
        DaemonEnv.startServiceMayBind(McuService.class);
    }

    public void onStopService(View view) {
        McuService.shouldStopService = true;
    }

    public void onSave(View view) {
        String vinstr = vin.getText().toString().trim();
        String imeiStr = imei.getText().toString().trim();
        if (TextUtils.isEmpty(vinstr) || TextUtils.isEmpty(imeiStr))
            return;
        VinConfig vinConfig = new VinConfig();
        vinConfig.vin = vinstr;
        vinConfig.imei = imeiStr;
        manager.saveConfig(vinConfig);
        adapter.add(vinConfig);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        setTitle("没有选择");
    }

    public void onSelect(View view) {
        if (spinner.getSelectedItem() != null) {
            manager.select((VinConfig) spinner.getSelectedItem());
            setTitle(spinner.getSelectedItem().toString());
        }
    }

    public void onClear(View view) {
        if (spinner.getSelectedItem() != null) {
            manager.clearVin((VinConfig) spinner.getSelectedItem());
            adapter.remove((VinConfig) spinner.getSelectedItem());
        }

    }
}
