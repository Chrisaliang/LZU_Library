package com.uaes.iot.service;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.uaes.common.AuthProvider;
import com.uaes.iot.CommApplication;
import com.uaes.iot.InterruptedListener;
import com.uaes.iot.MockSingleDummyWorker;
import com.uaes.iot.catcher.CatchWorker;
import com.uaes.iot.iothub.Connection;
import com.uaes.iot.iothub.ConnectionResolver;
import com.uaes.iot.iothub.ConnectionResolverImp;
import com.uaes.iot.location.LocationWorker;
import com.uaes.iot.mcu.McuWorker;
import com.xdandroid.hellodaemon.AbsWorkService;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import timber.log.Timber;

import static com.amap.api.location.AMapLocationClientOption.AMapLocationMode.Device_Sensors;

/**
 * Created by aber on 1/5/2018.
 * Mcu service
 */

public class McuService extends AbsWorkService {

    private static final String TAG = "McuService";
    private static final boolean DEBUG = true;
    private static final long PUSH_DELAY = 4000;
    private static final long CATCH_DELAY = 6000;
    private static final long LOCATION_DELAY = 10000;
    public static boolean shouldStopService = false;
    public static final ScheduledExecutorService scheduledExecutorService
            = Executors.newScheduledThreadPool(4);
    private static MockSingleDummyWorker mcuWorker;
    private static LocationWorker locationWorker;
    private static CatchWorker catchWorker;
    private static Connection connection;
    private static ConnectionResolver resolver;
    private static AMapLocationClient mapLocationClient;
    private static ScheduledFuture mcuFuture;
    private static ScheduledFuture catchFuture;
    private static ScheduledFuture connectionFuture;

    private static boolean isLocationStarted = false;

    private static final InterruptedListener listener = new InterruptedListener() {
        @Override
        public void onIntercept(InterruptedException e) {
            stop();
        }
    };

    @Override
    public Boolean shouldStopService(Intent intent, int flags, int startId) {
        return shouldStopService;
    }

    @Override
    public void startWork(Intent intent, int flags, int startId) {
        if (DEBUG)
            Timber.tag(TAG).d("has started.");
        if (mcuFuture == null || mcuFuture.isCancelled())
            startMcuWork();
        if (catchFuture == null || catchFuture.isCancelled())
            startCatchWork(getApplicationContext());
        if (connectionFuture == null || connectionFuture.isCancelled())
            startConnection(getApplicationContext());
        if (mapLocationClient == null || !isLocationStarted)
            startLocation(getApplication());
    }

    @Override
    public void stopWork(Intent intent, int flags, int startId) {
        stop();
    }

    @Override
    public Boolean isWorkRunning(Intent intent, int flags, int startId) {
        return false;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent, Void alwaysNull) {
        return null;
    }

    @Override
    public void onServiceKilled(Intent rootIntent) {
        // cache save.
        mapLocationClient.onDestroy();
    }

    private static void stopConnection() {
        connectionFuture.cancel(false);
        connection = null;
        resolver = null;
        connectionFuture = null;
    }

    private static void startConnection(Context context) {
        if (resolver == null) {
            resolver = new ConnectionResolverImp(AuthProvider.getInstance(context.getApplicationContext()));
        }
        connection = Connection.create(context.getApplicationContext(), listener, resolver);
        connectionFuture = scheduledExecutorService.scheduleWithFixedDelay(
                connection, PUSH_DELAY, PUSH_DELAY, TimeUnit.MILLISECONDS);
        if (DEBUG)
            Timber.tag(TAG).d("Push has start.");
    }

    private static void stopMcuWork() {
        mcuFuture.cancel(false);
        try {
            mcuWorker.clearResource();
        } catch (Exception e) {
            Timber.tag(TAG).d(e, "close mcu file failed.");
        }
        mcuWorker = null;
        mcuFuture = null;
    }

    private void startMcuWork() {
        try {
            mcuWorker = new MockSingleDummyWorker(
                    CommApplication.instanceDb.getFrameDao(),
                    getApplicationContext()

            );
            mcuFuture = scheduledExecutorService
                    .scheduleWithFixedDelay(mcuWorker, McuWorker.READ_INTER, McuWorker.READ_INTER, TimeUnit.MILLISECONDS);
            if (DEBUG)
                Timber.tag(TAG).d("Mcu has start.");
        } catch (IOException e) {
            shouldStopService = true;
            Timber.tag(TAG).e(e, "Can't find Mcu file for reading can frame.");
        }
    }

    private static void stopCatchWork() {
        catchFuture.cancel(false);
        catchWorker = null;
        catchFuture = null;
    }

    private static void startCatchWork(Context context) {
        catchWorker = new CatchWorker("STS", listener,
                AuthProvider.getInstance(context),
                CommApplication.instanceDb.getFrameDao());
        catchFuture
                = scheduledExecutorService.scheduleWithFixedDelay(catchWorker, CATCH_DELAY, CATCH_DELAY, TimeUnit.MILLISECONDS);
        if (DEBUG)
            Timber.tag(TAG).d("Catch has start.");
    }

    private static void stopLocation() {
        mapLocationClient.unRegisterLocationListener(locationWorker);
        mapLocationClient.stopLocation();
        mapLocationClient.onDestroy();
        mapLocationClient = null;
        locationWorker = null;
        isLocationStarted = false;
    }

    private static void startLocation(Context context) {
        locationWorker = new LocationWorker(AuthProvider.getInstance(context));
        mapLocationClient = new AMapLocationClient(context);
        AMapLocationClientOption option = new AMapLocationClientOption();
        option.setInterval(LOCATION_DELAY).setLocationMode(Device_Sensors)
                .setNeedAddress(true);
        mapLocationClient.setLocationOption(option);
        mapLocationClient.setLocationListener(locationWorker);
        isLocationStarted = true;
        mapLocationClient.startLocation();
        if (DEBUG)
            Timber.tag(TAG).d("Location has start.%s", mapLocationClient.isStarted());
    }

    public static void stop() {
        Timber.tag(TAG).i("mcuService has stop!");
        shouldStopService = true;
        stopMcuWork();
        stopCatchWork();
        stopConnection();
        stopLocation();
        scheduledExecutorService.shutdownNow();
    }
}
