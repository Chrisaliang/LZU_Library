package com.uaes.iot;

import android.content.Context;

import com.uaes.iot.mcu.Frame;
import com.uaes.iot.room.FrameDao;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;

import timber.log.Timber;

/**
 * Created by aber on 3/22/2018.
 */

public class MockSingleDummyWorker implements Runnable {
    private static final String TAG = "MockSingleDummyWorker";

    private BufferedReader reader;

    private FrameDao dao;

    private Frame cacheFrame = new Frame();

    private FileWriter os;

    private int count = 0;

    private ByteBuffer byteBuffer = ByteBuffer.allocate(16);

    public MockSingleDummyWorker(FrameDao dao, Context context) throws IOException {
        this.dao = dao;
        this.dao = dao;
        reader = new BufferedReader(new InputStreamReader(context.getAssets().open("single_dummy.txt")));
    }

    @Override
    public void run() {
        // start to read line from file
        String rawMessage;
        try {
            rawMessage = reader.readLine();
            if (rawMessage == null) {
                Thread.sleep(20000);
                Timber.tag(TAG).d("读取完毕 循环 为空");
                return;
            }

            if (process(rawMessage, byteBuffer)) {
                dao.insert(cacheFrame);
                count++;
                Timber.tag(TAG)
                        .d("Count: %d", count);
            }
        } catch (IOException e) {
            Timber.tag(TAG).d(e, "run: IOE");
        } catch (InterruptedException i) {
            Timber.tag(TAG).d(i, "run: Thread has shutDown");
        }
    }

    private boolean process(String rawMessage, ByteBuffer byteBuffer) {
        String[] xoCodes = rawMessage.split(" ");
        if (xoCodes.length == 12) {
            byteBuffer.clear();
            byteBuffer.putInt(1);
            for (int i = 0; i < 12; i++)
                byteBuffer.put((byte) Integer.parseInt(xoCodes[i], 16));
            cacheFrame.update(byteBuffer.array(), System.currentTimeMillis());
            return true;
        } else {
            return false;
        }
    }

    public void clearResource() {
        try {
            reader.close();
        } catch (IOException e) {
            Timber.tag(TAG).e(e, "close file failed.");
        }
    }
}
