package com.uaes.iot;

/**
 * Created by aber on 12/20/2017.
 */

public interface ServiceEnvironment {
    String IOT_CONFIG_BASE_URL = "http://dev.api.iot.i-dudu.com"; // 开发环境
}
