# v0.2.0
Perform the memory usage when fetch can frame(16 byte) from ecu buffer queue.
# v0.3.0 TODO
 由于 SQLite数据库查询无法使用内存缓冲模型进行数据获取，导致读取时会有大量得GC产生
 每次基本上35msGC时间，需要考虑优化方案。