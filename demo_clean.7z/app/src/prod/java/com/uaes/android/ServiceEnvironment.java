package com.uaes.android;

/**
 * Created by aber on 12/20/2017.
 * service
 */

public interface ServiceEnvironment {
    String baseUrl = "https://api-iot.uaes.com"; // 生产环境
}
