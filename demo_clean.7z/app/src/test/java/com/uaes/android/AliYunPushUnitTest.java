package com.uaes.android;

import android.support.annotation.NonNull;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.ProtocolType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.aliyuncs.push.model.v20160801.PushMessageToAndroidRequest;
import com.aliyuncs.push.model.v20160801.PushMessageToAndroidResponse;
import com.aliyuncs.push.model.v20160801.PushNoticeToAndroidRequest;
import com.aliyuncs.push.model.v20160801.PushNoticeToAndroidResponse;
import com.aliyuncs.push.model.v20160801.PushRequest;
import com.aliyuncs.push.model.v20160801.PushResponse;
import com.aliyuncs.utils.ParameterHelper;
import com.uaes.common.MockCar;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;

/**
 * Created by aber on 11/13/2017.
 * Ali Yun Push test
 */
public class AliYunPushUnitTest {

    private static final String accessKeyId = "LTAIrNFBbdmMIaef";
    private static final String accessKeySecret = "QQsBR9SaQxXX1iJzByHaL46nXBDLv8";

    //    private static final String deviceIds = "d23481d9308845e3aedb2bbbecfddfd6";
    //    private static final String deviceIds = "a66c6d9538db4c63b69445bcf84b9dfb";
    private static final String deviceIds = "99ce9623f5644c87b87de3eabcf5dad2";
    private static final String requestBody = "{" +
            "\"type\":\"fuelFill\"," +
            "\"eventId\":\"1\"," +
            "\"gasName\":\"我的加油站\"," +
            "\"fillDate\":\"2017-11-17 13:32:22\"," +
            "\"fillAmount\":45.3" +
            "}";

    private static final String messageRequestBody = "{" +
            "\"type\":\"fuelWarn\"," +
            "\"title\":\"消息推送测试推荐\"," +
            "\"messageClass\":\"通知\"," +
            "\"systemTime\":\"2017-11-17 13:32:22\"," +
            "\"body\":推荐警告你的车子已经没有机油了警告你的车子已经没有机油了警告你的车子已经没有机油了警告你的车子已经没有机油了警告你的车子已经没有机油了" +
            "}";

    private static final String fillWarnMessage = "{\"eventId\":\"113\",\"fillDate\":\"2018-02-27 11:30:00\",\"gasName\":\"壳牌加油站(小营站)\",\"price\":\"6.75\",\"fillAmount\":\"10.0\",\"systemTime\":\"2018-03-10 18:44:50\",\"messageClass\":\"通知\",\"type\":\"fuelFill\",\"body\":\"系统检查到您于2018-03-10 18:44:50左右在壳牌加油站(小营站)加过油，想要知道爱车耗油明细，请及时记账吧！\",\"title\":\"记账提醒\"}";

    private DefaultAcsClient client;

    @Before
    public void setUp() {
        IClientProfile profile = DefaultProfile.getProfile(
                "cn-hangzhou",
                accessKeyId,
                accessKeySecret
        );
        client = new DefaultAcsClient(profile);
        client.setAutoRetry(true);
    }

    @Test
    public void serviceNotificationPush() throws ClientException {


        PushNoticeToAndroidRequest pushNoticeToAndroidRequest
                = new PushNoticeToAndroidRequest();
        pushNoticeToAndroidRequest.setAppKey(ServiceEnvironment.appKey);
        pushNoticeToAndroidRequest.setProtocol(ProtocolType.HTTPS);
        pushNoticeToAndroidRequest.setTarget("DEVICE");
        pushNoticeToAndroidRequest.setTargetValue(deviceIds);
        pushNoticeToAndroidRequest.setTitle("HELLO");
        pushNoticeToAndroidRequest.setBody("BODY");
        pushNoticeToAndroidRequest.setExtParameters(requestBody);

        PushNoticeToAndroidResponse pushResponse = client.getAcsResponse(pushNoticeToAndroidRequest);
        System.out.printf("RequestId: %s, Message ID: %s\n",
                pushResponse.getRequestId(), pushResponse.getMessageId());
    }

    @Test
    public void serviceMessagePush() throws ClientException {
        PushMessageToAndroidRequest pushMessageToAndroidRequest = new PushMessageToAndroidRequest();
        pushMessageToAndroidRequest.setTarget("DEVICE");
        pushMessageToAndroidRequest.setTargetValue(deviceIds);
        pushMessageToAndroidRequest.setAppKey(ServiceEnvironment.appKey);
        pushMessageToAndroidRequest.setTitle("Message");
        pushMessageToAndroidRequest.setBody(requestBody);
        pushMessageToAndroidRequest.setProtocol(ProtocolType.HTTPS);

        PushMessageToAndroidResponse pushResponse = client.getAcsResponse(pushMessageToAndroidRequest);
        System.out.printf("RequestId: %s, Message ID: %s\n",
                pushResponse.getRequestId(), pushResponse.getMessageId());
    }

    @Test
    public void serviceAccountMessagePush() throws ClientException {
        PushMessageToAndroidRequest pushMessageToAndroidRequest
                = new PushMessageToAndroidRequest();
        pushMessageToAndroidRequest.setTarget("ACCOUNT");
        pushMessageToAndroidRequest.setTargetValue(MockCar.MOCK_VIN);
        pushMessageToAndroidRequest.setAppKey(ServiceEnvironment.appKey);
        pushMessageToAndroidRequest.setTitle("Message");
        pushMessageToAndroidRequest.setBody(messageRequestBody);
        pushMessageToAndroidRequest.setProtocol(ProtocolType.HTTPS);

        String expireTime = ParameterHelper.getISO8601Time(
                new Date(System.currentTimeMillis() + 12 * 3600 * 1000)); // 12小时后消息失效, 不会再发送
        PushMessageToAndroidResponse pushResponse = client.getAcsResponse(pushMessageToAndroidRequest);
        System.out.printf("RequestId: %s, Message ID: %s\n",
                pushResponse.getRequestId(), pushResponse.getMessageId());
    }

    @Test
    public void sendMessageMore() throws Exception {
        for (int i = 0; i < 50; i++) {
            PushMessageToAndroidRequest pushMessageToAndroidRequest
                    = new PushMessageToAndroidRequest();
            pushMessageToAndroidRequest.setTarget("ACCOUNT");
            pushMessageToAndroidRequest.setTargetValue(MockCar.MOCK_VIN);
            pushMessageToAndroidRequest.setAppKey(ServiceEnvironment.appKey);
            pushMessageToAndroidRequest.setTitle("Message: " + i);
            pushMessageToAndroidRequest.setBody(messageRequestBody);
            pushMessageToAndroidRequest.setProtocol(ProtocolType.HTTPS);

            PushMessageToAndroidResponse pushResponse = client.getAcsResponse(pushMessageToAndroidRequest);
            System.out.printf("RequestId: %s, Message ID: %s\n",
                    pushResponse.getRequestId(), pushResponse.getMessageId());
        }
    }

    @Test
    public void serviceAccountLowFuelWarningMessagePush() throws ClientException {
        PushMessageToAndroidRequest pushMessageToAndroidRequest
                = new PushMessageToAndroidRequest();
        pushMessageToAndroidRequest.setTarget("ACCOUNT");
        pushMessageToAndroidRequest.setTargetValue(MockCar.MOCK_VIN);
        pushMessageToAndroidRequest.setAppKey(ServiceEnvironment.appKey);
        pushMessageToAndroidRequest.setTitle("Message");
        pushMessageToAndroidRequest.setBody(fillWarnMessage);
        pushMessageToAndroidRequest.setProtocol(ProtocolType.HTTPS);


        PushMessageToAndroidResponse pushResponse = client.getAcsResponse(pushMessageToAndroidRequest);
        System.out.printf("RequestId: %s, Message ID: %s\n",
                pushResponse.getRequestId(), pushResponse.getMessageId());
    }

    @Test
    public void testMore() throws ClientException, InterruptedException {
        for (int i = 0; i < 50; i++) {
            PushRequest pushRequest = getPushRequest(i);
            String expireTime = ParameterHelper.getISO8601Time(
                    new Date(System.currentTimeMillis() + 16 * 3600 * 1000)); // 16小时后消息失效, 不会再发送
            pushRequest.setExpireTime(expireTime);
            pushRequest.setStoreOffline(true);
            PushResponse pushResponse = client.getAcsResponse(pushRequest);
            System.out.printf("RequestId: %s, Message ID: %s\n",
                    pushResponse.getRequestId(), pushResponse.getMessageId());
            Thread.sleep(500);
        }
    }

    @Test
    public void serviceAccountPushMessagePush() throws ClientException {
        PushRequest pushRequest = getPushRequest(0);
        String expireTime = ParameterHelper.getISO8601Time(
                new Date(System.currentTimeMillis() + 16 * 3600 * 1000)); // 16小时后消息失效, 不会再发送
        pushRequest.setExpireTime(expireTime);
        pushRequest.setStoreOffline(true);
        PushResponse pushResponse = client.getAcsResponse(pushRequest);
        System.out.printf("RequestId: %s, Message ID: %s\n",
                pushResponse.getRequestId(), pushResponse.getMessageId());
    }

    @NonNull
    private PushRequest getPushRequest(int id) {
        PushRequest pushRequest
                = new PushRequest();
        pushRequest.setTarget("ACCOUNT");
        pushRequest.setTargetValue(MockCar.MOCK_VIN);
        pushRequest.setAppKey(ServiceEnvironment.appKey);
        pushRequest.setTitle(String.valueOf(id));
        pushRequest.setBody(createMessagee(id));
        pushRequest.setProtocol(ProtocolType.HTTPS);
        pushRequest.setPushType("MESSAGE"); // 消息类型 MESSAGE NOTICE
        pushRequest.setDeviceType("ALL"); // 设备类型 ANDROID iOS ALL.
        return pushRequest;
    }

    private String createMessagee(int id) {
        return "{" +
                "\"type\":\"message\"," +
                "\"title\":\"消息推送测试推荐\"," +
                "\"messageClass\":\"通知\"," +
                "\"systemTime\":\"2017-11-17 13:32:22\"," +
                "\"body\":\"警告:" + id +
                "\"}";
    }
}
