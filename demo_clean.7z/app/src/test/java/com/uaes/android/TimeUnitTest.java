package com.uaes.android;

import org.junit.Test;

import java.time.LocalDate;

/**
 * Created by Chrisaliang on 2018/2/2.
 * test calendar
 */

public class TimeUnitTest {

    @Test
    public void yearTest() {
//        Calendar instance = Calendar.getInstance();
//        int year = instance.get(Calendar.YEAR);
//        int era = instance.get(Calendar.ERA);
//        int date = instance.get(Calendar.DATE);
//        System.out.println("date: " + date);
//        System.out.println("year: " + year);
//        System.out.println("era: " + era);

        LocalDate now = LocalDate.now();
        // 月份的第一天
        LocalDate localDate = now.minusDays(now.getDayOfMonth() - 1);
        System.out.println(localDate);
        // 每周的第一天
        LocalDate monday = now.minusDays(now.getDayOfWeek().getValue() - 1);
        System.out.println(monday);
        // 每年的第一天
        LocalDate dayOfYear = now.minusDays(now.getDayOfYear() - 1);
        System.out.println(dayOfYear);

        System.out.println(now);
    }
}
