package com.uaes.android;

import org.junit.Test;

/**
 * Created by Chrisaliang on 2018/2/2.
 * number test
 */

public class NumberTest {

    @Test
    public void numberMut() {
        float f = 9.968618F;
        float value = Math.round((f / 5.0F) * 4);
        System.out.println(value);
    }
}
