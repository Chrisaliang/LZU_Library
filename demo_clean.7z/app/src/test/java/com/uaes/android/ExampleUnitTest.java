package com.uaes.android;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.junit.Test;

import java.util.Date;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.exceptions.Exceptions;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import retrofit2.HttpException;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import uaes.com.view.RingChartView;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    RingChartView.RangeInterpolator interpolater = i -> (int) ((i / 55.0) * 100);

    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        Gson gson = gsonBuilder.create();
        Date date = new Date();
        System.out.println(gson.toJson(date));
        System.out.println(date);
    }

    @Test
    public void gson() {
        Gson gson = new GsonBuilder()
                .serializeNulls().create();
        String json = "{" +
                "\"name\":null" +
                "}";

        Name n = gson.fromJson(json, Name.class);
        System.out.printf("%s", n.name);
    }

    @Test
    public void apiText() {
        MockWebServer mockWebServer = new MockWebServer();
        mockWebServer.enqueue(new MockResponse().setResponseCode(400).setBody("nihaoa"));
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(mockWebServer.url("/"))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        Hello api = retrofit.create(Hello.class);
        api.hello().onErrorReturn(throwable -> {
            if (throwable instanceof HttpException) {
                HttpException httpException = (HttpException) throwable;
                Response<?> response = httpException.response();
                return response.errorBody().string();
            }
            throw Exceptions.propagate(throwable);
        }).subscribe(new SingleObserver<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onSuccess(String receive) {
                System.out.println(receive);
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
            }
        });
    }

    @Test
    public void inter() {
        for (int i = 0; i < 10; i++) {
            int sum = interpolater.onMap(i);
            System.out.println(sum);
        }
    }


    public interface Hello {
        @GET("message")
        Single<String> hello();
    }

    public static class Name {
        public String name;
    }
}