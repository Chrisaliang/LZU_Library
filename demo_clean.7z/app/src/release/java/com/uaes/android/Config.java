package com.uaes.android;

/**
 * Created by aber on 1/24/2018.
 * RELEASE 配置
 */

public interface Config {

    boolean DEBUG = false;

    String APP_SIGNATURE = "869BDF06EF2195A487ABCA91329BBB902AA3B9BB";

    String AMAP_STYLE_ID = "4783c5c58b9d98ecf624be3dd1369682";
}
