package com.uaes.android;

import android.content.Context;
import android.content.pm.PackageManager;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.uaes.common.SignatureChecker;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by aber on 1/27/2018.
 */

@RunWith(AndroidJUnit4.class)
public class SignatureTest {

    @Test
    public void checkSignatureTest() throws PackageManager.NameNotFoundException {
        Context context = InstrumentationRegistry.getTargetContext();
        boolean result = SignatureChecker.validateAppSignature(context, Config.APP_SIGNATURE);
        Assert.assertEquals(true, result);
    }
}
