package com.uaes.android;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.MessagePushEntity;
import com.uaes.android.data.room.UaesDatabase;
import com.uaes.android.domain.pojo.DomainMessage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;

/**
 * Created by aber on 3/10/2018.
 */
@RunWith(AndroidJUnit4.class)
public class SqliteTest {

    private UaesDatabase database;
    private CacheDao dao;
    private static final String fillWarnMessage = "{\"eventId\":\"113\",\"fillDate\":\"2018-02-27 11:30:00\",\"gasName\":\"壳牌加油站(小营站)\",\"price\":\"6.75\",\"fillAmount\":\"10.0\",\"systemTime\":\"2018-03-10 18:44:50\",\"messageClass\":\"通知\",\"type\":\"fuelFill\",\"body\":\"系统检查到您于2018-03-10 18:44:50左右在壳牌加油站(小营站)加过油，想要知道爱车耗油明细，请及时记账吧！\",\"title\":\"记账提醒\"}";


    @Before
    public void setUpClient() {
        Context context = InstrumentationRegistry.getTargetContext();
        database = Room.inMemoryDatabaseBuilder(context, UaesDatabase.class)
                .build();
        dao = database.getCacheDao();
    }

    @Test
    public void messageTest() {
        MessagePushEntity entity = new MessagePushEntity();
        entity.extraJson = fillWarnMessage;
        entity.title = "title";
        entity.body = "body";
        entity.hasRead = 0;
        entity.messageClass = MessagePushEntity.MESSAGE_CLASS_WARN;
        entity.type = DomainMessage.MESSAGE_TYPE_0;
        entity.systemTime = "sss";
        dao.insertMessagePush(entity);

        MessagePushEntity[] entities = dao.queryMessagePushType(MessagePushEntity.MESSAGE_CLASS_WARN);
        Log.d(getClass().getName(), "messageTest: " + Arrays.toString(entities));
    }

    @After
    public void closeDb() {
        database.close();
    }
}
