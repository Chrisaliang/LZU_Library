package com.uaes.android;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import static junit.framework.Assert.assertEquals;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    public static final int USER_INITIATED = 0x1000;
    public static final int APP_INITIATED = 0x2000;
    public static final int SERVER_INITIATED = 0x3000;

    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("com.uaes.uaesandroid", appContext.getPackageName());
    }

    @Test
    public void locationSignal() throws Exception {


        final BlockingQueue<AMapLocation> locations = new ArrayBlockingQueue<>(16);

        Context appContext = InstrumentationRegistry.getTargetContext();
        AMapLocationClient client = new AMapLocationClient(appContext);
        AMapLocationClientOption option = new AMapLocationClientOption();
        option.setInterval(2000);
        option.setGpsFirst(true);
        option.setHttpTimeOut(5000);
        client.setLocationOption(option);
        client.setLocationListener(aMapLocation -> {
            try {
                locations.put(aMapLocation);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Log.d("AMAP_LOCATION", "onLocationChanged: " + aMapLocation);
        });
        client.startLocation();
        while (true) {
            Log.d("read", "locationSignal: " + locations.take());
        }
    }
}
