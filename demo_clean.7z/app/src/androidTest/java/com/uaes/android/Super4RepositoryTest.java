package com.uaes.android;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.amap.api.location.AMapLocationClient;

import org.junit.Before;
import org.junit.runner.RunWith;

/**
 * Created by aber on 1/23/2018.
 * Unit Test for Super4 Shop API
 */
@RunWith(AndroidJUnit4.class)
public class Super4RepositoryTest {

    private AMapLocationClient locationClient;

    @Before
    public void setUpClient() {
        Context context = InstrumentationRegistry.getTargetContext();
    }

}
