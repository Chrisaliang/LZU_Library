package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.S4ShopApi;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.domain.pojo.Domain4SShop;
import com.uaes.android.domain.pojo.DomainAd;

import java.util.List;

import io.reactivex.Single;

/**
 * Author : 张 涛
 * Time : 2018/1/25.
 * Des : This is
 */

public class MockS4ShopApi extends MockBase implements S4ShopApi {

     MockS4ShopApi(Context context, Gson gson) {
        super(context, gson);
    }

    @Override
    public Single<GeneralAttributeReceive<List<Domain4SShop>>> getShops(String province, String latlog) {
        Single<String> pSingle = Single.just(province);
        Single<String> lSingle = Single.just(latlog);

        return pSingle.zipWith(lSingle, (s, s2) ->
                JsonReaderUtil.readJson(context, "S4Shop.json",
                        new TypeToken<GeneralAttributeReceive<List<Domain4SShop>>>() {
                        }, gson));
    }

    @Override
    public Single<GeneralAttributeReceive<DomainAd>> getAdByType(String type) {
        return Single.just(type).map(s -> {
            if (s.equals(DomainAd.AD_TYPE_ENGINE_OIL)) {
                return JsonReaderUtil.readJson(context, "ad_engine_oil.json", new TypeToken<GeneralAttributeReceive<DomainAd>>() {
                }, gson);
            } else if (s.equals(DomainAd.AD_TYPE_SPARKING_PLUGS)) {
                return JsonReaderUtil.readJson(context, "ad_spark_plug.json", new TypeToken<GeneralAttributeReceive<DomainAd>>() {
                }, gson);
            }
            return null;
        });
    }
}
