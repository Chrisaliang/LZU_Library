package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.FuelManagerApi;
import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.data.json.FuelFillHistory;
import com.uaes.android.data.json.FuelFillRecordPoint;
import com.uaes.android.data.json.FuelStatus;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.json.SingleFuelRecord;

import java.util.List;

import io.reactivex.Single;
import okhttp3.RequestBody;

/**
 * Created by aber on 1/24/2018.
 * Mock FuelManagerApi.
 */

public class MockFuelManagerApi extends MockBase implements FuelManagerApi {
    MockFuelManagerApi(Context context, Gson gson) {
        super(context, gson);
    }

    @Override
    public Single<GeneralAttributeReceive<List<FuelFillRecordPoint>>> fuelRecord() {
        return Single.just(1)
                .flatMap(integer -> {
                    GeneralAttributeReceive<List<FuelFillRecordPoint>> listGeneralAttributeReceive = new GeneralAttributeReceive<>();
                    listGeneralAttributeReceive.msgContent = JsonReaderUtil.readJson(context, "record.json",
                            new TypeToken<List<FuelFillRecordPoint>>() {
                            }, gson);
                    return Single.just(listGeneralAttributeReceive);
                });
    }

    @Override
    public Single<SingleFuelRecord> singleFuelRecord(int page, int size) {
        return Single.just(page).map(i -> {
            String filepath = null;
            if (i == 0) filepath = "single_record_0.json";
            else if (i == 1) filepath = "single_record_1.json";

            return JsonReaderUtil.readJson(context, filepath,
                    new TypeToken<SingleFuelRecord>() {
                    }, gson);
        });
    }

    @Override
    public Single<GeneralAttributeReceive<FuelStatus>> fuelStatus() {
        return Single.just(1).map(
                integer -> JsonReaderUtil.readJson(context, "fuel_status.json",
                        new TypeToken<GeneralAttributeReceive<FuelStatus>>() {
                        }, gson));
    }

    @Override
    public Single<GeneralAttributeReceive<FuelFillHistory>> getFuelHistoryByYear(Integer year) {
        return Single.just(year).map(integer -> JsonReaderUtil.readJson(context, "fuel_history_year.json",
                new TypeToken<GeneralAttributeReceive<FuelFillHistory>>() {
                }, gson));
    }

    @Override
    public Single<GeneralAttributeReceive<FuelFillHistory>> getFuelHistoryByMile(Integer mile) {
        return Single.just(mile).map(integer -> JsonReaderUtil.readJson(context, "fuel_history_mile.json",
                new TypeToken<GeneralAttributeReceive<FuelFillHistory>>() {
                }, gson));
    }

    @Override
    public Single<FuelBookkeeping> setFuelAccount(RequestBody body) {
        return Single.just(body).map(body1 ->
                JsonReaderUtil.readJson(context, "fuel_account.json", FuelBookkeeping.class, gson));
    }
}
