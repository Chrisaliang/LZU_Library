package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.http.FuelAccountApi;
import com.uaes.android.data.http.FuelManagerApi;
import com.uaes.android.data.http.GasStationApi;
import com.uaes.android.data.http.MaintenanceApi;
import com.uaes.android.data.http.S4ShopApi;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.http.TokenApi;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by aber on 1/24/2018.
 * Dummy Api
 */
@Module
public abstract class NetModule {

    @Provides
    @Singleton
    public static TokenApi tokenInterface(UaesIotApplication context, Gson gson) {
        return new MockTokenApi(context.getApplicationContext(), gson);
    }

    @Provides
    @Singleton
    public static FuelManagerApi fuelManagerApi(UaesIotApplication application, Gson gson) {
        return new MockFuelManagerApi(application.getApplicationContext(), gson);
    }

    @Provides
    @Singleton
    public static SettingApi settingApi(UaesIotApplication app, Gson gson) {
        return new MockSettingApi(app, gson);
    }

    @Provides
    @Singleton
    public static GasStationApi gasStationApi(UaesIotApplication app, Gson gson) {
        return new MockGasStationApi(app.getApplicationContext(), gson);
    }

    @Provides
    @Singleton
    public static FuelAccountApi fuelAccountApi(UaesIotApplication context, Gson gson) {
        return new MockFuelAccountApi(context.getApplicationContext(), gson);
    }

    @Provides
    @Singleton
    public static MaintenanceApi carHealthApi(UaesIotApplication app, Gson gson) {
        return new MockCarHealthApi(app, gson);
    }

    @Provides
    @Singleton
    public static S4ShopApi s4ShopApi(UaesIotApplication app, Gson gson) {
        return new MockS4ShopApi(app, gson);
    }
}
