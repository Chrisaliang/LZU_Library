package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.TokenApi;
import com.uaes.android.data.json.TokenResponse;

import io.reactivex.Single;

/**
 * Created by aber on 1/24/2018.
 * Mock Token Interface
 * TODO
 */

public class MockTokenApi extends MockBase implements TokenApi {

    MockTokenApi(Context context, Gson gson) {
        super(context, gson);
    }

    @Override
    public Single<TokenResponse> getToken(String vinCode) {
        return Single.just(vinCode)
                .map(s -> JsonReaderUtil.readJson(context,
                        "token.json", new TypeToken<TokenResponse>() {
                        }, gson));
    }

}
