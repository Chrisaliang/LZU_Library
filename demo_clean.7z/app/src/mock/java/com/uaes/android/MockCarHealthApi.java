package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.MaintenanceApi;
import com.uaes.android.data.json.CarHealth;
import com.uaes.android.data.json.GeneralAttributeReceive;

import io.reactivex.Single;

/**
 * Created by Chrisaliang on 2018/1/25.
 * car health api
 */

public class MockCarHealthApi extends MockBase implements MaintenanceApi {

    MockCarHealthApi(Context context, Gson gson) {
        super(context, gson);
    }

    @Override
    public Single<GeneralAttributeReceive<CarHealth>> carHealth() {
//        GeneralAttributeReceive<CarHealth> receive = new GeneralAttributeReceive<>();
//        receive.msg = "1";
//        receive.msgCode = "10000";
//        receive.msg = "OK";
//        receive.status = "1";
//        CarHealth carHealth = new CarHealth();
//        carHealth.batteryState = 0;
//        carHealth.engineOilHealth = 0;
//        carHealth.engineOilState = 0;
//        carHealth.sparkPlugState = 1;
//        receive.msgContent = carHealth;
//        return Single.just(receive);
        return Single.just(0).map(integer ->
                JsonReaderUtil.readJson(context, "car_health.json",
                        new TypeToken<GeneralAttributeReceive<CarHealth>>() {
                        }, gson));
    }

    @Override
    public Single<Boolean> maintenanceRecord() {
        // TODO: 2018/3/7 mock record
        return Single.just(true);
    }
}
