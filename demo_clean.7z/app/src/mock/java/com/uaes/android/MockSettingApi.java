package com.uaes.android;

import android.content.Context;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.JsonRequestBody;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.json.GeneralAttributeSent;

import io.reactivex.Single;

/**
 * Created by aber on 1/24/2018.
 * Setting Mock
 */

public class MockSettingApi extends MockBase implements SettingApi {

    private static final String LOW_FUEL_JSON_TYPE = "CSthreshold";
    private static final String TAG = "MockSettingApi";
    private final TypeToken<GeneralAttributeReceive<GeneralAttributeSent>> type;
    private GeneralAttributeReceive<GeneralAttributeSent> attr;


    MockSettingApi(Context context, Gson gson) {
        super(context, gson);
        type = new TypeToken<GeneralAttributeReceive<GeneralAttributeSent>>() {
        };
//        attr = new GeneralAttributeReceive<>();
//        attr.msgContent = new GeneralAttributeSent();
    }

    @Override
    public Single<GeneralAttributeReceive<GeneralAttributeSent>> lowFuelWarningSent(JsonRequestBody body) {
        return Single.just(body).map(jsonRequestBody -> {
            GeneralAttributeReceive<GeneralAttributeSent> r = gson.fromJson(jsonRequestBody.getJson(),
                    type.getType());
            GeneralAttributeSent.GeneralAttribute attribute = r.msgContent.attributeList.get(0);
            if (TextUtils.equals(LOW_FUEL_JSON_TYPE, attribute.attributeType)) {
                attr.msgContent.attributeList.add(0, attribute);
                return attr;
            } else {
                throw new IllegalArgumentException("Can't modify setting for type: " + LOW_FUEL_JSON_TYPE);
            }
        });
    }

    @Override
    public Single<GeneralAttributeReceive<GeneralAttributeSent>> lowFuelWarningReceive(JsonRequestBody body) {
        return Single.just(body).map(jsonRequestBody -> {
            if (attr == null)
                attr = JsonReaderUtil.readJson(context, "setting.json",
                        type, gson);
            return attr;
        });
    }
}
