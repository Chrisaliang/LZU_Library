package com.uaes.android;

/**
 * Created by aber on 12/20/2017.
 * mock 使用了 开发环境的配置
 */

public interface ServiceEnvironment {
    String baseUrl = "http://dev.api.iot.i-dudu.com"; // 开发环境
    long appKey = 24675829;
}
