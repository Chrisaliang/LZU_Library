package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;

/**
 * Created by Chrisaliang on 2018/1/25.
 * Base Mock Class for rest http interface call.
 */

public abstract class MockBase {

    protected final Context context;

    protected final Gson gson;

    MockBase(Context context, Gson gson) {
        this.context = context;
        this.gson = gson;
    }
}
