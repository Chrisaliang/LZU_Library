package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.uaes.android.data.http.FuelAccountApi;
import com.uaes.android.data.json.FuelBookkeeping;

import io.reactivex.Single;
import okhttp3.RequestBody;

/**
 * Created by aber on 1/24/2018.
 * Mock FuelAccount Api.
 */

public class MockFuelAccountApi extends MockBase implements FuelAccountApi {
    MockFuelAccountApi(Context context, Gson gson) {
        super(context, gson);
    }

    @Override
    public Single<FuelBookkeeping> setFuelAccount(RequestBody body) {

        return Single.just(body).map(body1 ->
                JsonReaderUtil.readJson(context, "fuel_account.json", FuelBookkeeping.class, gson));
    }
}
