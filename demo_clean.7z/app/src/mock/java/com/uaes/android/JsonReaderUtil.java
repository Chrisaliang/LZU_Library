package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by Chrisaliang on 2018/1/25.
 * json reader util
 */

public class JsonReaderUtil {

    static <T> T readJson(Context context, String jsonFile, TypeToken<T> typeToken, Gson gson) throws IOException {
        InputStreamReader isr = new InputStreamReader(context.getAssets().open(jsonFile));
        JsonReader reader = new JsonReader(isr);
        return gson.fromJson(reader, typeToken.getType());
    }

    static <T> T readJson(Context context, String jsonFile, Class<T> clazz, Gson gson) throws IOException {
        InputStreamReader isr = new InputStreamReader(context.getAssets().open(jsonFile));
        JsonReader reader = new JsonReader(isr);
        return gson.fromJson(reader, clazz);
    }
}
