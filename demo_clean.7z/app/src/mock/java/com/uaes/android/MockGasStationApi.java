package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.GasStationApi;
import com.uaes.android.data.json.GasStation;
import com.uaes.android.data.json.GeneralAttributeReceive;

import java.util.List;

import io.reactivex.Single;

/**
 * Created by aber on 1/24/2018.
 * Mock of GasStationApi
 */

public class MockGasStationApi extends MockBase implements GasStationApi {

     MockGasStationApi(Context context, Gson gson) {
        super(context, gson);
    }

    @Override
    public Single<GeneralAttributeReceive<List<GasStation>>> gasStationList(String location, int strategy) {
        return Single.just(strategy).map(s -> {
            String file;
            if (s == 0) file = "gas_station_0.json";
            else if (s == 1) file = "gas_station_1.json";
            else file = "gas_station_2.json";
            return JsonReaderUtil.readJson(context, file, new TypeToken<GeneralAttributeReceive<List<GasStation>>>() {
            }, gson);
        });
    }
}
