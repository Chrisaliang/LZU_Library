package com.uaes.android.data.room;

/**
 * Created by aber on 1/17/2018.
 * Table names.
 */

public interface Tables {
    /**
     * 加油记录点
     */
    interface FUEL_RECORD_POINT {
        /**
         * 加油记账点表
         */
        String TABLE_NAME = "table_fuelRecord";

        String COLUMN_MILEAGE = "mileage";

        String COLUMN_FUEL_USE_SUM = "fuelUseSum";
    }

    /**
     * 加油状态表
     */
    interface FUEL_STATUS {

        String TABLE_NAME = "table_fuelStatus";
        /*
        * 汽油牌号
        * */
        String COLUMN_FUEL_GRADE = "fuelGrade";
        /*
         * 剩余油量
         * */
        String COLUMN_FUEL_REST = "fuelRest";
        /*
        * 百公里油耗
        * */
        String COLUMN_FUEL_USE_KM = "fuelUsedKm";
        /*
        * 剩余里程
        * */
        String COLUMN_MILEAGE_REST = "mileageRest";
        /*
         * 经济性排名
         */
        String COLUMN_ECONOMIC_RANK = "economicRank";
    }

    /**
     * 单次加油记账表
     */
    interface FUEL_SINGLE_FILL_RECORD {

        String TABLE_NAME = "table_fuelSingleFillRecord";

        String COLUMN_EVENT_ID = "eventId";

        String COLUMN_FILL_DATE = "fillDate";

        String COLUMN_FILL_CHARGE = "fillCharge";

        String COLUMN_FILL_AMOUNT = "fillAmount";

        String COLUMN_ECU_FILL_AMOUNT = "ecuFillAmount";

        String COLUMN_GAS_NAME = "gasName";

        String COLUMN_GAS_LOCATION = "gasLocation";

        String COLUMN_FILL_USED = "fuelUsed";

        String COLUMN_SPEED_AVG = "speedAvg";

        String COLUMN_USED_AVG = "usedAvg";

        String COLUMN_MILLAGE_DRIVE = "millageDrive";

        String COLUMN_ECONOMIC_RANK = "economicRank";

        String COLUMN_EVALUATE_LEVEL = "evaluateLevel";
    }

    /**
     * 单次加油记录 总数据
     */
    interface FUEL_SINGLE_FILL_RECORD_COUNT {

        String TABLE_NAME = "table_fuelSingleFillRecordCount";

        String COLUMN_FILL_COUNT = "fillCount";  // 加油次数

        String COLUMN_FILL_AMOUNT_SUM = "fillAmountSum"; // 加油量

        String COULMN_TOTAL_PAGE = "totalPage";

        String COLUMN_TOTAL_ELEMENT = "totalElements";

        String COLUMN_PAGE_SIZE = "size";

        String COLUMN_CURRENT_PAGE = "currentPageNumber";
    }

    /**
     * 加油历史表
     */
    interface FUEL_FILL_HISTORY {

        String TABLE_NAME = "table_fuelHistory";

        /**
         * 总消费
         */
        String COLUMN_FUEL_COST = "fuelCost";

        /**
         * 总耗油量
         */
        String COLUMN_FUEL_USE = "fuelUse";

        /**
         * 怠速耗油
         */
        String COLUMN_IDLE_USE = "idleUse";

//        /**
//         * 怠速耗油 费用
//         */
//        String COLUMN_IDLE_USE_MONEY = "idleUse1";

        /**
         * 行驶耗油
         */
        String COLUMN_DRIVER_USE = "driverUse";

//        /**
//         * 行驶耗油 费用
//         */
//        String COLUMN_DRIVER_USE_MONEY = "driverUse1";

        /**
         * 空调耗油
         */
        String COLUMN_AC_USE = "acUse";

//        /**
//         * 空调耗油 费用
//         */
//        String COLUMN_AC_USE_MONEY = "acUse1";

        /**
         * 其他耗油
         */
        String COLUMN_OTHER_USE = "otherUse";

//        /**
//         * 其他耗油 费用
//         */
//        String COLUMN_OTHER_USE_MONEY = "otherUse1";
    }

    /**
     * 时间
     */
    interface CACHE_EXPIRE {
        /**
         * 缓存的元信息，比如缓存时间
         */
        String TABLE_NAME = "table_cacheExpire";
        /**
         * Table name
         */
        String COLUMN_TABLE_NAME = "name";
        /**
         * Cache timestamp
         */
        String COLUMN_TIMESTAMP = "timestamp";
    }

    /**
     * 车辆健康度
     */
    interface CAR_HEALTH {
        /**
         * 车辆健康度 表名
         */
        String TABLE_NAME = "table_carHealth";
        /**
         * 机油状态
         */
        String COLUMN_ENGINE_OIL_STATE = "engineOilStatus";
        /**
         * 机油剩余行驶里程
         */
        String COLUMN_ENGINE_OIL_MILEAGE = "engineOilMileage";
        /**
         * 机油健康度
         */
        String COLUMN_ENGINE_OIL_HEALTH = "engineOilHealth";
        /**
         * 火花塞状态
         */
        String COLUMN_SPARK_PLUG_STATE = "sparkPlugStatus";
        /**
         * 电池状态
         */
        String COLUMN_BATTERY_STATE = "batteryStatus";
    }

    /**
     * 消息推送表
     */
    interface PUSH_MESSAGE {

        /**
         * 消息推送 表名
         */
        String TABLE_NAME = "messagePush";

        /**
         * 消息的头
         */
        String COLUMN_TITLE = "title";

        /**
         * 消息的内容
         */
        String COLUMN_BODY = "body";

        /**
         * 消息小类
         */
        String COLUMN_TYPE = "type";

        /**
         * 消息大类
         */
        String COLUMN_MESSAGE_CLASS = "messageClass";

        /**
         * 消息的的系统时间
         */
        String COLUMN_SYSTEM_TIME = "systemTime";

        /**
         * 额外的必要信息必要信息根据
         */
        String COLUMN_EXTRA_JSON = "extraJson";

        /**
         * 消息阅读状态
         */
        String COLUMN_HAS_READ = "hasRead";
    }
}
