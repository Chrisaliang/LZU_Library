package com.uaes.android.domain;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.uaes.android.domain.pojo.Domain4SShop;
import com.uaes.android.domain.pojo.DomainAd;
import com.uaes.android.domain.pojo.DomainMyLocation;

import java.util.List;

import io.reactivex.Single;

/**
 * Created by aber on 1/23/2018.
 * 4s
 */

public interface Super4SRepository {

    /**
     * 获取4s店 列表
     * 请求封装了定位请求， 如果定位发生错误,会抛出{@link com.uaes.android.domain.exception.LocationFailException}
     * 如果UI层需要根据错误类型来选择UI的反馈效果，需要在{@link io.reactivex.SingleObserver#onError(Throwable)}
     * 回调实现里检查接收到的{@link Throwable}的类型，抛出的异常类型如下：
     * - {@link com.uaes.android.domain.exception.LocationFailException} 定位出错
     * - {@link com.uaes.android.domain.exception.HTTPApiResponseFormatException} 相应的数据格式出错，一般响应数据均为json格式
     * - 其他与网络IO，和Json语法相关的错误.
     *
     * @see Domain4SShop
     * @see AMapLocation
     */
    Single<DomainMyLocation<List<Domain4SShop>>> get4SShop(AMapLocationClient client);


    /**
     * 获取广告信息提示，提示只有模板信息，无任何点击事件
     *
     * @param adType 广告类型 目前支持{@link DomainAd#AD_TYPE_ENGINE_OIL},{@link DomainAd#AD_TYPE_SPARKING_PLUGS}
     */
    Single<DomainAd> getAd(String adType);
}
