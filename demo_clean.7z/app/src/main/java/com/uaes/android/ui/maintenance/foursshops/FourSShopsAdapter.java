package com.uaes.android.ui.maintenance.foursshops;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.ui.gasstation.MapMarkerListener;
import com.uaes.android.ui.message.adapter.BindingViewHolder;
import com.uaes.android.viewobservable.FourSShopsObservable;
import com.uaes.android.viewobservable.FourSShopsOverallObservable;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/26.
 * Des : This is
 */

public class FourSShopsAdapter extends RecyclerView.Adapter<BindingViewHolder> {

    public static final Object BACKGROUND_UPDATE = new Object();

    private static final String TAG = "FourSShopsAdapter";
    private List<FourSShopsObservable> mFourSShops;
    private FourSShopsOverallObservable overallObservable;
    private FourSShopListener mListener;
    private MapMarkerListener markerListener;
    private int selectedIndex = -1;

    FourSShopsAdapter(FourSShopsOverallObservable overallObservable,
                      FourSShopListener listener, MapMarkerListener mapMarkerListener) {
        this.mListener = listener;
        this.overallObservable = overallObservable;
        this.markerListener = mapMarkerListener;
        mFourSShops = new ArrayList<>();
    }

    @Override
    public BindingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ViewDataBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.adapter_foursshops_item, parent, false);
        binding.setVariable(BR.fourSShopListener, mListener);
        return new BindingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(BindingViewHolder holder, int position, List<Object> payloads) {
        if (payloads.contains(BACKGROUND_UPDATE)) {
            holder.getBinding().setVariable(BR.fourSShopData, mFourSShops.get(position));
            holder.getBinding().executePendingBindings();
        } else {
            super.onBindViewHolder(holder, position, payloads);
        }
    }

    @Override
    public void onBindViewHolder(BindingViewHolder holder, int position) {
        FourSShopsObservable mFourSShop = mFourSShops.get(position);
        holder.getBinding().setVariable(BR.fourSShopData, mFourSShop);
        holder.getBinding().executePendingBindings();
        Timber.tag(TAG).d("onBindViewHolder: position: %s", position);
    }

    @Override
    public int getItemCount() {
        return mFourSShops.size();
    }

    public void addAll(List<FourSShopsObservable> shops) {
        mFourSShops.clear();
        mFourSShops.addAll(shops);
        notifyDataSetChanged();
    }

    public void selectItem(int index) {
        FourSShopsObservable item = mFourSShops.get(index);
        final int olderIndex = selectedIndex;

        if (olderIndex == item.getPosition()) {
            overallObservable.setShowStatus(FourSShopsOverallObservable.DETAIL);
        } else {
            if (olderIndex != -1) {
                FourSShopsObservable old = mFourSShops.get(olderIndex);
                old.setSelected(false);
                notifyItemChanged(olderIndex, BACKGROUND_UPDATE);
            }
            overallObservable.setFourSShopsObservable(item);
            selectedIndex = index;
            item.setSelected(true);
            notifyItemChanged(index, BACKGROUND_UPDATE);
            markerListener.onMarkerSelected(olderIndex, index);
        }
    }

    /**
     * If select not -1
     */
    public int getSelectedIndex() {
        return selectedIndex;
    }
}
