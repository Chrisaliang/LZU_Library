package com.uaes.android.viewmodel;

/**
 * Created by aber on 11/27/2017.
 * Single record view model
 * TODO eventId 表示事件
 */

public class SingleRecordItemViewModel {
    public int count;
    public String descriptionOne;
    public String descriptionTwo;
    public int eventId;
}
