package com.uaes.android.data.internal;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationListener;
import com.uaes.android.domain.exception.LocationFailException;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.exceptions.CompositeException;
import io.reactivex.exceptions.Exceptions;
import io.reactivex.plugins.RxJavaPlugins;
import timber.log.Timber;

/**
 * Created by aber on 1/23/2018.
 * Using for RxJava2 single location.
 */

public class AMapLocationSingle extends Single<AMapLocation> {
    private static final String TAG = "AMapLocationSingle";

    private AMapLocationClient client;

    public AMapLocationSingle(AMapLocationClient client) {
        this.client = client;
    }

    @Override
    protected void subscribeActual(SingleObserver<? super AMapLocation> observer) {
        AMapLocationDisposable disposable = new AMapLocationDisposable(client, observer);
        observer.onSubscribe(disposable);
        client.setLocationListener(disposable);
        client.startLocation();
    }

    private static class AMapLocationDisposable implements Disposable, AMapLocationListener {

        private AMapLocationClient client;

        private SingleObserver<? super AMapLocation> observer;

        AMapLocationDisposable(AMapLocationClient client, SingleObserver<? super AMapLocation> observer) {
            this.client = client;
            this.observer = observer;
        }

        @Override
        public void dispose() {
            client.unRegisterLocationListener(this);
            client.stopLocation();
        }

        @Override
        public boolean isDisposed() {
            return !client.isStarted();
        }

        @Override
        public void onLocationChanged(AMapLocation aMapLocation) {
            Timber.tag(TAG).d("location type: %s, debug: %s", aMapLocation.getLocationType(), aMapLocation.toStr());
            try {
                if (aMapLocation.getErrorCode() == 0)
                    observer.onSuccess(aMapLocation);
                else
                    observer.onError(new LocationFailException(aMapLocation.clone()));
            } catch (Throwable t) {
                try {
                    observer.onError(t);
                } catch (Throwable throwable) {
                    Exceptions.throwIfFatal(throwable);
                    RxJavaPlugins.onError(new CompositeException(t, throwable));
                }
            } finally {
                dispose();
            }
        }
    }
}
