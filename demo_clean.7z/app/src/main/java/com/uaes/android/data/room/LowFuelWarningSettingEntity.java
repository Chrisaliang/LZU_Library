package com.uaes.android.data.room;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

/**
 * Created by Chrisaliang on 2017/12/28.
 * low fuel warning
 */

@SuppressWarnings("WeakerAccess")
@Entity(tableName = "lowFuel")
public class LowFuelWarningSettingEntity {

    @ColumnInfo(typeAffinity = ColumnInfo.INTEGER)
    public int lowFuelWarning;
    @PrimaryKey
    private long id;
    @ColumnInfo(typeAffinity = ColumnInfo.INTEGER)
    private long time;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
