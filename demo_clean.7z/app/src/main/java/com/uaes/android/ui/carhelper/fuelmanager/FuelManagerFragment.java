package com.uaes.android.ui.carhelper.fuelmanager;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.utils.CheckUtils;

/**
 * Created by hand on 2017/11/1.
 * 油管家页面
 */
public class FuelManagerFragment extends NavigatorFragment
        implements View.OnClickListener {

    private static final String EXTRA_SELECTED = "com.uaes.android.FuelManagerFragment.SELECTED";

    private static final String TAG = FuelManagerFragment.class.getSimpleName();
    private final SparseArray<Fragment> mFragments = new SparseArray<>();
    private View fuelStatusMenu;
    private int selectedId = View.NO_ID;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null)
            selectedId = savedInstanceState.getInt(EXTRA_SELECTED);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fuel_manager, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fuelStatusMenu = view.findViewById(R.id.fuel_manager_fuel_status_menu);
        fuelStatusMenu.setOnClickListener(this);
        View singleRecordMenu = view.findViewById(R.id.fuel_manager_fuel_single_record_menu);
        singleRecordMenu.setOnClickListener(this);
        View recordMenu = view.findViewById(R.id.fuel_manager_fuel_record_menu);
        recordMenu.setOnClickListener(this);
        View historyMenu = view.findViewById(R.id.fuel_manager_fuel_history_menu);
        historyMenu.setOnClickListener(this);
        // 显示
        mNavigator.showBackButton();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (selectedId != View.NO_ID)
            outState.putInt(EXTRA_SELECTED, selectedId);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (selectedId == View.NO_ID)
            updateSelectedMenu(R.id.fuel_manager_fuel_status_menu);
        else
            updateSelectedMenu(selectedId);
    }

    @Override
    public void onPause() {
        super.onPause();
        mNavigator.hideBackButton();
    }

    @Override
    public void onClick(View v) {
        updateSelectedMenu(v.getId());
    }

    private void updateSelectedMenu(int clickId) {
        CheckUtils.checkNoViewIdIfThrow(clickId);
        View view = getView();
        if (view != null) {
            updateSelectedMenu(view.findViewById(selectedId), view.findViewById(clickId));
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden)
            mNavigator.hideBackButton();
        else
            mNavigator.showBackButton();
    }

    private void updateSelectedMenu(View selectedView, View clickView) {
        if (clickView == null)
            clickView = fuelStatusMenu;
        if (selectedView != null && selectedView != clickView)
            selectedView.setSelected(false);
        switchFragment(clickView);
        clickView.setSelected(true);
        selectedId = clickView.getId();
    }

    private void switchFragment(View view) {
        realTransactFragment(getFragment(view.getId()), getFragment(selectedId));
    }

    private Fragment getFragment(@IdRes int id) {

        Fragment fragment = mFragments.get(id);
        if (fragment == null) {
            fragment = createFragmentByViewId(id);
        }
        return fragment;
    }

    private Fragment createFragmentByViewId(@IdRes int id) {
        Fragment fragment;
        if (id == R.id.fuel_manager_fuel_status_menu) {
            fragment = new FuelStatusFragment();
        } else if (id == R.id.fuel_manager_fuel_history_menu) {
            fragment = new FuelHistoryFragment();
        } else if (id == R.id.fuel_manager_fuel_record_menu) {
            fragment = new FuelRecordFragment();
        } else if (id == R.id.fuel_manager_fuel_single_record_menu) {
            fragment = new FuelSingleRecordFragment();
        } else {
            fragment = null;
        }
        mFragments.put(id, fragment);
        return fragment;
    }

    private void realTransactFragment(Fragment shouldShow, Fragment shouldHidden) {
        if (shouldShow == null) return;
        if (shouldShow == shouldHidden) return;
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.replace(R.id.fuel_manager_fragment_replace_layout, shouldShow, null);
//        if (!shouldShow.isAdded()) {
//            transaction.add(R.id.fuel_manager_fragment_replace_layout, shouldShow, null);
//        } else if (shouldShow.isHidden()) {
//            transaction.show(shouldShow);
//        }
//        if (shouldHidden != null) {
//            if (!shouldHidden.isAdded()) {
//                transaction.add(R.id.fuel_manager_fragment_replace_layout, shouldHidden, null);
//            }
//            if (!shouldHidden.isHidden()) {
//                transaction.hide(shouldHidden);
//            }
//        }
        transaction.commit();
    }
}
