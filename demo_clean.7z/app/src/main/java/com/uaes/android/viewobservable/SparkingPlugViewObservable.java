package com.uaes.android.viewobservable;

import android.content.Intent;
import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.view.View;

import com.uaes.android.BR;
import com.uaes.android.domain.pojo.DomainAd;
import com.uaes.android.ui.gasstation.MapMarkerActivity;
import com.uaes.android.viewmodel.SparkingPlugViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Author : 张 涛
 * Time : 2018/1/24.
 * Des : This is
 */

public class SparkingPlugViewObservable extends BaseObservable {

    private final SparkingPlugViewModel mSparkingPlugViewModel;
    private boolean fistVat;//火花塞 缸1 的健康状况
    private boolean secondVat;//火花塞 缸2 的健康状况
    private boolean thirdVat;//火花塞 缸3 的健康状况
    private boolean fourthVat;//火花塞 缸4 的健康状况
    private boolean isHealth;//火花塞 整体的健康状况（4个火花塞只要有一个不健康，这个值就是false）
    private String title;//火花塞的建议标题
    private String suggest;//火花塞的建议
    private int status = RetryView.RETRY_LOADING;


    public SparkingPlugViewObservable(SparkingPlugViewModel mSparkingPlugViewModel) {
        this.mSparkingPlugViewModel = mSparkingPlugViewModel;
    }

    public void onClick(RetryView view) {
        mSparkingPlugViewModel.getCarState();
    }

    public void onGoToFourSShopClick(View view) {
        Intent intent = new Intent(view.getContext(), MapMarkerActivity.class);
        intent.putExtra(MapMarkerActivity.EXTRA_TYPE, MapMarkerActivity.SHOP_$_TAG);
        intent.putExtra(MapMarkerActivity.EXTRA_SUBTYPE, DomainAd.AD_TYPE_SPARKING_PLUGS);
        view.getContext().startActivity(intent);
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public boolean getFistVat() {
        return fistVat;
    }

    public void setFistVat(boolean fistVat) {
        this.fistVat = fistVat;
        notifyPropertyChanged(BR.fistVat);
    }

    @Bindable
    public boolean getSecondVat() {
        return secondVat;
    }

    public void setSecondVat(boolean secondVat) {
        this.secondVat = secondVat;
        notifyPropertyChanged(BR.secondVat);
    }

    @Bindable
    public boolean getThirdVat() {
        return thirdVat;
    }

    public void setThirdVat(boolean thirdVat) {
        this.thirdVat = thirdVat;
        notifyPropertyChanged(BR.thirdVat);
    }

    @Bindable
    public boolean getFourthVat() {
        return fourthVat;
    }

    public void setFourthVat(boolean fourthVat) {
        this.fourthVat = fourthVat;
        notifyPropertyChanged(BR.fourthVat);
    }

    @Bindable
    public boolean getHealth() {
        return isHealth;
    }

    public void setHealth(boolean health) {
        isHealth = health;
        notifyPropertyChanged(BR.health);
    }

    @Bindable
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
        notifyPropertyChanged(BR.title);
    }

    @Bindable
    public String getSuggest() {
        return suggest;
    }

    public void setSuggest(String suggest) {
        this.suggest = suggest;
        notifyPropertyChanged(BR.suggest);
    }
}
