package com.uaes.android.viewmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by aber on 11/21/2017.
 * UI object for account
 */

@SuppressWarnings("WeakerAccess")
public class DomainFuelAccountFillRecord implements Parcelable {
    public static final Creator<DomainFuelAccountFillRecord> CREATOR = new Creator<DomainFuelAccountFillRecord>() {
        @Override
        public DomainFuelAccountFillRecord createFromParcel(Parcel in) {
            return new DomainFuelAccountFillRecord(in);
        }

        @Override
        public DomainFuelAccountFillRecord[] newArray(int size) {
            return new DomainFuelAccountFillRecord[size];
        }
    };
    @SerializedName("fillDate")
    public String mFillDate;// 加油日期
    @SerializedName("gasName")
    public String mStationName;// 加油站名称
    @SerializedName("fuelGrade")
    public String mFuelNum; // 汽油牌号

    @SerializedName("fillAmount")
    private double mFuelAmount; // 总加油量

    public float mAppraise;// 评分
    @SerializedName("eventId")
    public int mEventId;
    @SerializedName("price")
    private double mFuelUnitPrice;// 油单价

    private double totalPrice;

    public DomainFuelAccountFillRecord() {

    }

    protected DomainFuelAccountFillRecord(Parcel in) {
        mFuelNum = in.readString();
        mFillDate = in.readString();
        mStationName = in.readString();
        mFuelUnitPrice = in.readDouble();
        mFuelAmount = in.readDouble();
        mAppraise = in.readFloat();
        mEventId = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mFuelNum);
        dest.writeString(mFillDate);
        dest.writeString(mStationName);
        dest.writeDouble(mFuelUnitPrice);
        dest.writeDouble(mFuelAmount);
        dest.writeFloat(mAppraise);
        dest.writeInt(mEventId);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public void setPrice(double unitPrice) {
        mFuelUnitPrice = unitPrice;
        updateAmount();
    }

    public double getPrice() {
        return mFuelUnitPrice;
    }

    public double getFillAmount() {
        return mFuelAmount;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
        updateAmount();
    }

    public double getTotalPrice() {
        return this.totalPrice;
    }


    public void updateAmount() {
        if (mFuelUnitPrice == 0 || totalPrice == 0) return;
        mFuelAmount = totalPrice / mFuelUnitPrice;
    }

    public void updateTotal() {
        totalPrice = mFuelAmount * mFuelUnitPrice;
    }
}
