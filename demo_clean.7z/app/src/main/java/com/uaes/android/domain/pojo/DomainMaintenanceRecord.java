package com.uaes.android.domain.pojo;

/**
 * Created by Chrisaliang on 2018/3/6.
 * maintenance record
 */

public class DomainMaintenanceRecord {
}
