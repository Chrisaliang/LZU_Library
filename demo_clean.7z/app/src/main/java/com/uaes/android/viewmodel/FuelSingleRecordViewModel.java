package com.uaes.android.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import android.widget.Toast;

import com.uaes.android.R;
import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.domain.AuthorizationSingleObserver;
import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;
import com.uaes.android.widget.RetryView;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by Chrisalaing on 01/22/2018.
 * View Model for Single FuelRecord
 */

public class FuelSingleRecordViewModel extends ViewModel implements SingleObserver<DomainFuelSingleRecord> {

    private static final String TAG = "FuelSingleRecordViewMod";

    private final MutableLiveData<DomainFuelSingleRecord> singleRecord = new MutableLiveData<>();

    private final MutableLiveData<Integer> status = new MutableLiveData<>();

    private final FuelManagerRepository repository;

    private Disposable disposable;

    FuelSingleRecordViewModel(FuelManagerRepository repository) {
        this.repository = repository;
    }

    public void update(int page, int size) {
        repository.singleFuelRecord(page, size).subscribe(this);
    }

    public MutableLiveData<DomainFuelSingleRecord> getSingleRecord() {
        return singleRecord;
    }

    public MutableLiveData<Integer> getStatus() {
        return status;
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSubscribe(Disposable d) {
        this.disposable = d;
        status.setValue(RetryView.RETRY_LOADING);
    }

    @Override
    public void onSuccess(DomainFuelSingleRecord record) {
//        feedDataSet(record);
//        if (record.barData.contents.isEmpty()) {
//            retryView.update(RetryView.RETRY_EMPTY, "暂无记录");
//        } else {
//            retryView.update(RetryView.RETRY_GONE, null);
//            contentView.setVisibility(View.VISIBLE);
//        }
//        popupWindow.dismiss();
//        barChart.highlightValue(null);
        if (record == DomainFuelSingleRecord.getEmptySingleRecord()) {
            status.setValue(RetryView.RETRY_EMPTY);
            return;
        }
        singleRecord.setValue(record);
        status.setValue(RetryView.RETRY_GONE);
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).d(e);
        status.postValue(RetryView.RETRY_RETRY);
    }

    public void updateFuelAccount(FuelBookkeeping fuelAccount, Context context) {
        repository.setFuelAccount(fuelAccount)
                .subscribe(new FuelAccountObserver(context));
    }

    private class FuelAccountObserver extends AuthorizationSingleObserver<FuelBookkeeping> {
        FuelAccountObserver(Context context) {
            super(context);
        }

        @Override
        public void onSubscribe(Disposable d) {
            disposable = d;
        }

        @Override
        public void onSuccess(FuelBookkeeping fuelAccount) {
            Timber.tag(TAG).i("记账更改成功");
            Toast.makeText(context, R.string.fuel_account_fuel_amount_success_update, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(Throwable e) {
            super.onError(e);
            Timber.tag(TAG).e(e, "记账保存失败");
            Toast.makeText(context, R.string.fuel_account_fuel_amount_fail_save, Toast.LENGTH_SHORT).show();
        }
    }
}
