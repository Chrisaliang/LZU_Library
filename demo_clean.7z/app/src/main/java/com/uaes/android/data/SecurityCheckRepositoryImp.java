package com.uaes.android.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.uaes.android.Config;
import com.uaes.android.domain.SecurityCheckRepository;
import com.uaes.android.domain.pojo.DomainSecurityResult;
import com.uaes.common.RootChecker;
import com.uaes.common.SignatureChecker;

import io.reactivex.Single;
import timber.log.Timber;

/**
 * Created by aber on 2/27/2018.
 * 安全检查模块
 */

public class SecurityCheckRepositoryImp implements SecurityCheckRepository {

    private static final String TAG = "SecurityCheckRepository";

    private static final String KEY_USER_AGREE = "user_agree";

    private Context context;
    private SharedPreferences sharedPreferences;
    private DomainSecurityResult result;


    public SecurityCheckRepositoryImp(Context context, SharedPreferences sharedPreferences) {
        this.context = context.getApplicationContext();
        this.sharedPreferences = sharedPreferences;
    }

    @Override
    public Single<DomainSecurityResult> checkSecurity() {
        return Single.just(context).map(ctx -> {
            boolean isRooted = RootChecker.isDeviceRooted();
            boolean signCheck;
            try {
                signCheck = SignatureChecker.validateAppSignature(ctx, Config.APP_SIGNATURE);
            } catch (Exception e) {
                signCheck = false;
                Timber.tag(TAG).d(e, "signature check error!");
            }

            boolean userAgreeCheck = sharedPreferences.getBoolean(KEY_USER_AGREE, false);
            if (result == null)
                result = new DomainSecurityResult();
            result.resultCode = 0;
            if (isRooted) {
                result.resultCode += DomainSecurityResult.FLAG_ROOT;
            }
            if (!signCheck) {
                result.resultCode += DomainSecurityResult.FLAG_SIGNATURE;
            }
            if (!userAgreeCheck)
                result.resultCode += DomainSecurityResult.FLAG_USER_AGREEMENT;
            return result;
        });
    }
}
