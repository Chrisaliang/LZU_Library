package com.uaes.android;

import android.content.Context;
import android.content.Intent;

import com.alibaba.sdk.android.push.MessageReceiver;
import com.alibaba.sdk.android.push.notification.CPushMessage;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.domain.MessageRepository;
import com.uaes.android.domain.pojo.DomainMessage;

import java.lang.reflect.Type;
import java.util.Map;

import javax.inject.Inject;

import dagger.android.AndroidInjection;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by hand on 2017/10/30.
 * Push Message Receiver
 */

public class APushMessageReceiver extends MessageReceiver {
    public static final String NOTIFICATION_CHANNEL_ID = "com.uaes.iot.CHANNEL_ID";
    public static final int NOTIFICATION_ID = 11;
    private static final String EXT_PARAMETER_TYPE = "type";
    private static final String EXT_PARAMETER_TITLE = "title";
    private static final String EXT_PARAMETER_BODY = "body";
    private static final String EXT_PARAMETER_MESSAGE_CLASS = "messageClass";
    private static final String EXT_PARAMETER_SYSTEM_TIME = "systemTime";


    @Inject
    MessageRepository messageRepository;
    @Inject
    Gson gson;
    private AppStatusTracker appStatusTracker = AppStatusTracker.getInstance();
    private Disposable mDisposable;

    @Override
    public void onReceive(Context context, Intent intent) {
        AndroidInjection.inject(this, context);
        super.onReceive(context, intent);
    }

    @Override
    public void onNotification(Context context, String title, String summary, Map<String, String> extraMap) {
        // TODO 处理推送通知
        Timber.tag("MyMessageReceiver").e("Receive notification, title: " + title + ", summary: " + summary + ", extraMap: " + extraMap);
    }

    @Override
    public void onMessage(Context context, CPushMessage cPushMessage) {
        Timber.tag("MyMessageReceiver").e("onMessage, messageId: " + cPushMessage.getMessageId()
                + ", title: " + cPushMessage.getTitle() + ", content:" + cPushMessage.getContent());
        Type type = new TypeToken<Map<String, String>>() {
        }.getType();
        try {
            Map<String, String> map
                    = gson.fromJson(cPushMessage.getContent(), type);
            DomainMessage message = new DomainMessage(
                    map.get(EXT_PARAMETER_TITLE)
                    , map.get(EXT_PARAMETER_BODY)
                    , map.get(EXT_PARAMETER_TYPE)
                    , map.get(EXT_PARAMETER_MESSAGE_CLASS),
                    map.get(EXT_PARAMETER_SYSTEM_TIME),
                    cPushMessage.getContent()
            );
            messageRepository.saveMessage(message).subscribe(new SingleObserver<Boolean>() {
                @Override
                public void onSubscribe(Disposable d) {
                    mDisposable = d;
                }

                @Override
                public void onSuccess(Boolean aBoolean) {
                    releaseDisposable();
                }

                @Override
                public void onError(Throwable e) {
                    Timber.tag(TAG).e(e, "APushMessageReceiver_message");
                    releaseDisposable();
                }
            });
//            }
        } catch (Exception e) {
            // ignore exception
            Timber.tag("MyMessageReceiver").e(e);
        }
    }

    @Override
    public void onNotificationOpened(Context context, String title, String summary, String extraMap) {
    }

    @Override
    protected void onNotificationClickedWithNoAction(Context context, String title, String summary, String extraMap) {
        Timber.tag("MyMessageReceiver").e("onNotificationClickedWithNoAction, title: " + title + ", summary: " + summary + ", extraMap:" + extraMap);
    }

    @Override
    protected void onNotificationReceivedInApp(Context context, String title, String summary, Map<String, String> extraMap, int openType, String openActivity, String openUrl) {
        Timber.tag("MyMessageReceiver").e("onNotificationReceivedInApp, title: " + title + ", summary: " + summary + ", extraMap:" + extraMap + ", openType:" + openType + ", openActivity:" + openActivity + ", openUrl:" + openUrl);
    }

    @Override
    protected void onNotificationRemoved(Context context, String messageId) {
        Timber.tag("MyMessageReceiver").e("onNotificationRemoved");
    }

    private void releaseDisposable() {
        if (mDisposable != null) {
            mDisposable.dispose();
        }
    }
}
