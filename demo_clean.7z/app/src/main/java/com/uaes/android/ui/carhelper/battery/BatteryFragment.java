package com.uaes.android.ui.carhelper.battery;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentBatteryAssistantBinding;
import com.uaes.android.domain.pojo.DomainCarHealth;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.viewmodel.BatteryAssistantViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.BatteryAssistantViewObservable;

import javax.inject.Inject;

/**
 * Created by hand on 2017/11/2.
 * 电池状态
 */

public class BatteryFragment extends NavigatorFragment implements Observer<DomainCarHealth> {

    private static final String TAG = BatteryFragment.class.getSimpleName();
    @Inject
    RepositoryVMProvider factory;
    private FragmentBatteryAssistantBinding binding;
    private BatteryAssistantViewModel viewModel;
    private BatteryAssistantViewObservable viewObservable;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(BatteryAssistantViewModel.class);
        viewObservable = new BatteryAssistantViewObservable(viewModel);
    }

    @Override
    public void refresh() {
        viewModel.update();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_battery_assistant, container, false);
        binding.setBattery(viewObservable);
        viewModel.getCarHealth().observe(this, this);
        viewModel.getStatus().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            viewObservable.setStatus(integer);
        });
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        // 显示
        mNavigator.showBackButton();
    }

    @Override
    public void onStart() {
        super.onStart();
        viewModel.update();
    }

    @Override
    public void onPause() {
        super.onPause();
        mNavigator.hideBackButton();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden)
            mNavigator.hideBackButton();
        else
            mNavigator.showBackButton();
    }

    @Override
    public void onChanged(@Nullable DomainCarHealth domainCarHealth) {
        if (domainCarHealth == null) return;
        viewObservable.setBatteryStatus(domainCarHealth.batteryStatus);
        refreshTime(Tables.CAR_HEALTH.TABLE_NAME);
    }
}
