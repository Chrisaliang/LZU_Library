package com.uaes.android.ui.gasstation;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.navi.AMapNavi;
import com.amap.api.navi.model.AMapNaviPath;
import com.amap.api.navi.model.NaviLatLng;
import com.amap.api.navi.view.RouteOverLay;
import com.uaes.android.R;
import com.uaes.android.ui.BaseAMapNaviActivity;
import com.uaes.android.ui.maintenance.foursshops.FourSShopsFragment;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * 加油站 父视图，背景为 地图全屏幕
 */
public class MapMarkerActivity extends BaseAMapNaviActivity
        implements MapMarkerListener, AMap.OnMarkerClickListener {

    private static final String TAG = "MapMarkerActivity";

    public static final String EXTRA_TYPE = "MAP_PAGE_TYPE";
    public static final String EXTRA_SUBTYPE = "MAP_PAGE_SUBTYPE";

    public static final String STATION_TAG = "station_tag";
    public static final String SHOP_$_TAG = "shop_s_tag";
    public static final String ROUTER_TAG = "router_tag";

    private final SparseArray<BitmapDescriptor> iconBitmapsBlue = new SparseArray<>();
    private final SparseArray<BitmapDescriptor> iconBitmapsRed = new SparseArray<>();
    private MapView mapView;
    private RouteOverLay routeOverLay;
    private List<Marker> markers;
    private OnMarkerClickListener onMarkerClickListener;
    private OnRouteListener routeListener;

    private List<NaviLatLng> wayPoints = new ArrayList<>();
    private List<NaviLatLng> endPoints = new ArrayList<>();

    private AMap aMap;

    private String tag;

    private AMapNavi mapNavi;
    private boolean mapNaviInit = false;

    private Canvas canvas = new Canvas();

    private TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gas_station_station_map);
        mapView = findViewById(R.id.map_view);
        mapView.onCreate(savedInstanceState);
        mapNavi = AMapNavi.getInstance(getApplicationContext());
        mapNavi.addAMapNaviListener(this);
        final Intent intent = getIntent();
        tag = intent.getStringExtra(EXTRA_TYPE);
        if (TextUtils.isEmpty(tag))
            throw new IllegalArgumentException("can't launcher " + TAG);
        initMap();
        if (savedInstanceState == null) {
            Fragment fragment = getFragment(TAG);
            if (fragment == null) {
                if (STATION_TAG.equals(tag)) {
                    fragment = new GasStationListFragment();
                } else if (SHOP_$_TAG.equals(tag)) {
                    Bundle args = new Bundle();
                    args.putString(
                            MapMarkerActivity.EXTRA_SUBTYPE,
                            intent.getStringExtra(MapMarkerActivity.EXTRA_SUBTYPE));
                    fragment = new FourSShopsFragment();
                    fragment.setArguments(args);
                } else {
                    throw new IllegalStateException("the tag:" + tag + " unknown!!");
                }
            }
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_layout, fragment, tag)
                    .addToBackStack(null)
                    .commit();
        }

        initBitmapDescriptor();
//        for (int i = 0; i < 10; i++) {
//            iconBitmapsBlue.append(i, BitmapDescriptorFactory.fromBitmap(
//                    getMyBitmap(String.valueOf(i + 1), R.drawable.foursshop_site_blue)));
//            iconBitmapsRed.append(i, BitmapDescriptorFactory.fromBitmap(
//                    getMyBitmap(String.valueOf(i + 1), R.drawable.foursshop_site_red)));
//        }
    }





    private Bitmap getMyBitmap(String pm_val, int baseImage) {
        Bitmap bitmap = BitmapDescriptorFactory.fromResource(
                baseImage).getBitmap();
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
                bitmap.getHeight()).copy(Bitmap.Config.ARGB_8888, true);
        canvas.setBitmap(bitmap);
        TextPaint textPaint = new TextPaint();
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(30f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(getResources().getColor(R.color.sparking_plug_item_textColor));
        canvas.drawText(pm_val, bitmap.getWidth() / 2, bitmap.getHeight() / 2, textPaint);// 设置bitmap上面的文字位置
        return bitmap;
    }

    private void initMap() {
        aMap = mapView.getMap();
//        aMap.setMyLocationEnabled(true);
//        MyLocationStyle style = new MyLocationStyle();
//        style.myLocationType(MyLocationStyle.LOCATION_TYPE_MAP_ROTATE_NO_CENTER);
//        aMap.setMyLocationStyle(style);
        aMap.setOnMarkerClickListener(this);
        UiSettings uiSettings = aMap.getUiSettings();
        uiSettings.setZoomControlsEnabled(false);
//        uiSettings.setMyLocationButtonEnabled(true);
        uiSettings.setAllGesturesEnabled(true);
        uiSettings.setRotateGesturesEnabled(false);
        uiSettings.setTiltGesturesEnabled(false);
//        aMap.setCustomMapStyleID(AMAP_STYLE_ID);
//        aMap.setMapCustomEnable(true);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mapView != null) mapView.onSaveInstanceState(outState);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mapView != null) mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mapView != null) mapView.onPause();
    }

    public void onBack(View view) {
        finish();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (mapView != null) mapView.onLowMemory();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mapView != null) mapView.onDestroy();
        if (routeOverLay != null) routeOverLay.destroy();
        mapNavi.removeAMapNaviListener(this);
        endPoints.clear();
        wayPoints.clear();
        mapNavi.destroy();
        recycleBitmapDescriptor();
    }

    private void initBitmapDescriptor() {
        textPaint.setTextSize(30f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(getResources().getColor(R.color.sparking_plug_item_textColor));
        for (int i = 0; i < 10; i++) {
            iconBitmapsBlue.append(i,createDescriptor(String.valueOf(i + 1), false));
            iconBitmapsRed.append(i, createDescriptor(String.valueOf(i + 1), true));
        }
    }

    private void recycleBitmapDescriptor() {
        for (int i = 0 ; i < 10; i++) {
            iconBitmapsBlue.get(i).recycle();
            iconBitmapsRed.get(i).recycle();
        }
    }

    private BitmapDescriptor createDescriptor(String markerNum, boolean selected) {
        BitmapDescriptor  descriptor = null;
        if (selected)
            descriptor = BitmapDescriptorFactory.fromResource(R.drawable.foursshop_site_red);
        else
            descriptor = BitmapDescriptorFactory.fromResource(R.drawable.foursshop_site_blue);
        Bitmap temp = descriptor.getBitmap();
        canvas.setBitmap(temp);
        canvas.drawText(markerNum, temp.getWidth() / 2, temp.getHeight() / 2, textPaint);// 设置bitmap上面的文字位置
        return descriptor;
    }

    @Override
    public void showListLayout() {
        findViewById(R.id.cv_list_layout).setVisibility(View.VISIBLE);
    }

    @Override
    public List<Marker> updateMarker(ArrayList<MarkerOptions> markerOptions) {
        clearMarker();
        if (markerOptions != null && !markerOptions.isEmpty()) {
            for (int i = 0; i < markerOptions.size(); i++) {
                markerOptions.get(i).icon(iconBitmapsRed.get(i))
                        .setFlat(false);
            }
            this.markers = aMap.addMarkers(markerOptions, true);
            Timber.tag(TAG).d("updateMarker: %s", markerOptions);
            return this.markers;
        } else {
            return null;
        }
    }

    @Override
    public void onMarkerSelected(@Nullable Marker older, @NonNull Marker newer) {
        if (older != null) {
            older.setIcon(iconBitmapsRed.get(findMarkerIndex(older)));
            older.hideInfoWindow();
            newer.setToTop();
        }
        newer.setIcon(iconBitmapsBlue.get(findMarkerIndex(newer)));
        if (!newer.isInfoWindowShown())
            newer.showInfoWindow();
    }

    @Override
    public void onMarkerSelected(int older, int newer) {
        Marker newerMarker = markers.get(newer);
        if (older != -1) {
            Marker marker = markers.get(older);
            marker.setIcon(iconBitmapsRed.get(older));
            marker.hideInfoWindow();
            newerMarker.setToTop();
        }
        newerMarker.setIcon(iconBitmapsBlue.get(newer));
        if (!newerMarker.isInfoWindowShown())
            newerMarker.showInfoWindow();
    }

    private int findMarkerIndex(Marker marker) {
        return markers.indexOf(marker);
    }

    @Override
    public void clearMarker() {
        if (markers != null && !markers.isEmpty())
            for (Marker marker : this.markers) {
                marker.remove();
            }
    }

    @Override
    public void onRouterShow(NaviLatLng to) {
        clearMarker();
        endPoints.clear();
        endPoints.add(to);
        Fragment fragment = getFragment(ROUTER_TAG);
        if (fragment == null)
            fragment = new MapRouterFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(MapRouterFragment.KEY_LAT_LNG_TO, to);
        fragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_layout, fragment, ROUTER_TAG)
                .setCustomAnimations(android.R.anim.slide_in_left,
                        android.R.anim.slide_out_right,
                        R.anim.slide_in_right, R.anim.slide_out_left)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void calculateRoute() {
        int strategy = mapNavi.strategyConvert(true, false, false, false, true);
        mapNavi.calculateDriveRoute(endPoints, wayPoints, strategy);
    }

    @Override
    public void backPreviewLevel() {
        getSupportFragmentManager().popBackStack();
        if (routeOverLay != null)
            routeOverLay.removeFromMap();
        mapView.getMap().animateCamera(CameraUpdateFactory.zoomTo(20));
    }

    @Override
    public void animateToLocation(LatLng target) {
        mapView.getMap().animateCamera(CameraUpdateFactory.changeLatLng(
                target));
    }

    @Override
    public void animateToBound(LatLngBounds targets,
                               int paddingLeft,
                               int paddingRight,
                               int paddingTop,
                               int paddingBottom) {
        mapView.getMap().animateCamera(
                CameraUpdateFactory.newLatLngBoundsRect(
                        targets, paddingLeft, paddingRight, paddingTop, paddingBottom));
    }

    @Override
    public void setOnMarkerClickListener(OnMarkerClickListener OnMarkerClickListener) {
        this.onMarkerClickListener = OnMarkerClickListener;
    }

    @Override
    public void setRouteListener(OnRouteListener listener) {
        this.routeListener = listener;
    }

    @Override
    public void selectRoute(int routeIndex) {
        mapNavi.selectRouteId(routeIndex);
        AMapNaviPath path = mapNavi.getNaviPaths().get(routeIndex);
        if (routeOverLay != null) {
            routeOverLay.removeFromMap();
            routeOverLay.setAMapNaviPath(path);
        } else {
            routeOverLay = new RouteOverLay(mapView.getMap(), path, this);
        }
        routeOverLay.addToMap();
        mapView.getMap().animateCamera(CameraUpdateFactory.newLatLngBoundsRect(path.getBoundsForPath(),
                480, 96, 48, 48));
    }

    private Fragment getFragment(String tag) {
        return getSupportFragmentManager().findFragmentByTag(tag);
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        Timber.tag(TAG).d("onMarkerClick: DisplayLevel: " + marker.getDisplayLevel() + " zLevel: " + marker.getZIndex());
        int markerIndex = findMarkerIndex(marker);
        if (markerIndex != -1 && onMarkerClickListener != null)
            onMarkerClickListener.onMarkerClick(markerIndex);
        return true;
    }

    @Override
    public void onInitNaviFailure() {
        super.onInitNaviFailure();
        mapNaviInit = false;
    }

    @Override
    public void onInitNaviSuccess() {
        super.onInitNaviSuccess();
        mapNaviInit = true;
    }

    @Override
    public void onCalculateRouteFailure(int i) {
        super.onCalculateRouteFailure(i);
        routeListener.onRouteFailed(i);
    }

    @Override
    public void onCalculateRouteSuccess(int[] ints) {
        super.onCalculateRouteSuccess(ints);
        routeListener.onRouteSuccess(ints, mapNavi.getNaviPaths());
    }
}
