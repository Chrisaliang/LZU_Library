package com.uaes.android;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

/**
 * Created by aber on 11/22/2017.
 * app activity tracker
 */

@SuppressWarnings("WeakerAccess")
public class AppStatusTracker implements Application.ActivityLifecycleCallbacks {

    private static AppStatusTracker instance;
    private int activityNum = 0;

    private AppStatusTracker() {
    }

    public static AppStatusTracker getInstance() {

        if (instance == null)
            instance = new AppStatusTracker();
        return instance;
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

    }

    @Override
    public void onActivityStarted(Activity activity) {
        activityNum++;
    }

    @Override
    public void onActivityStopped(Activity activity) {
        activityNum--;
    }

    @Override
    public void onActivityResumed(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {
    }

    public boolean isActivityResume() {
        return activityNum > 0;
    }
}
