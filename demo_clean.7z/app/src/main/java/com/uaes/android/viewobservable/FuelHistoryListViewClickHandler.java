package com.uaes.android.viewobservable;

import android.databinding.DataBindingUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.ItemFuelManagerFuelHistorySearchListBinding;
import com.uaes.android.ui.carhelper.fuelmanager.FuelHistoryListViewData;
import com.uaes.android.viewmodel.FuelHistoryViewModel;

import java.util.List;

import timber.log.Timber;

/**
 * Created by Chrisaliang on 2017/12/6.
 * fuel history list view click event handler
 */

public class FuelHistoryListViewClickHandler {
//    private static final String TAG = FuelHistoryListViewClickHandler.class.getSimpleName();

    private FuelHistoryViewModel viewModel;

    public FuelHistoryListViewClickHandler(
            FuelHistoryViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void click(FuelHistoryListViewData fuelHistoryListViewData) {
        viewModel.search(fuelHistoryListViewData);
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        private FuelHistoryListViewData fuelHistoryViewModel;
        //        private FuelHistoryListItemObservable observable = new FuelHistoryListItemObservable();
        private ItemFuelManagerFuelHistorySearchListBinding binding;

        ViewHolder(View itemView, FuelHistoryListViewClickHandler handler) {
            super(itemView);
            binding = DataBindingUtil.bind(itemView);
            binding.setHandler(handler);
//            binding.setItem(observable);
        }

//        ItemFuelManagerFuelHistorySearchListBinding getBinding() {
//            return binding;
//        }

        void bind(FuelHistoryListViewData fuelHistoryViewModel) {
            this.fuelHistoryViewModel = fuelHistoryViewModel;
//            observable.setData(fuelHistoryViewModel);
            binding.setItem(this.fuelHistoryViewModel);
            binding.executePendingBindings();
            binding.btnOilItem.setSelected(fuelHistoryViewModel.isSelected);
        }

        void updateSelected() {
            binding.btnOilItem.setSelected(fuelHistoryViewModel.isSelected);
        }
    }

    public static class FuelHistoryListViewAdapter extends RecyclerView.Adapter<ViewHolder> {
        private final Object SelectedUpdate = new Object();
        public int selectedPosition = -1;
        private List<FuelHistoryListViewData> mSets;
        private String mName;
        private FuelHistoryListViewClickHandler handler;

        public FuelHistoryListViewAdapter(String name, FuelHistoryListViewClickHandler handler, List<FuelHistoryListViewData> fuelHistoryViewModelList) {
            this.mSets = fuelHistoryViewModelList;
            this.mName = name;
            this.handler = handler;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_fuel_manager_fuel_history_search_list,
                            parent, false);
            return new ViewHolder(view, this.handler);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            FuelHistoryListViewData fuelHistoryViewModel = mSets.get(position);
            holder.bind(fuelHistoryViewModel);
            Timber.tag(mName).d(" onBindViewHolder%s", holder.fuelHistoryViewModel);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position, List<Object> payloads) {
            if (payloads.contains(SelectedUpdate)) {
                holder.updateSelected();
            } else
                super.onBindViewHolder(holder, position, payloads);
        }

        @Override
        public int getItemCount() {
            return mSets.size();
        }

        public void updateSelected(int clickIndex) {
            if (selectedPosition != -1) {
                mSets.get(selectedPosition).isSelected = false;
                notifyItemChanged(selectedPosition, SelectedUpdate);
            }

            if (clickIndex != -1) {
                mSets.get(clickIndex).isSelected = true;
                notifyItemChanged(clickIndex, SelectedUpdate);
            }
            selectedPosition = clickIndex;
        }
    }
}
