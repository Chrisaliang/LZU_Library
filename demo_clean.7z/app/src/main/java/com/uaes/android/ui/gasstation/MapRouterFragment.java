package com.uaes.android.ui.gasstation;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.navi.model.AMapNaviLink;
import com.amap.api.navi.model.AMapNaviPath;
import com.amap.api.navi.model.AMapNaviStep;
import com.amap.api.navi.model.NaviLatLng;
import com.uaes.android.R;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import timber.log.Timber;

/**
 * Author: tianbing
 * Date: 2017/10/19
 * Overview: 显示路由查询路径
 */

public class MapRouterFragment extends MapMarkerBaseFragment
        implements MapMarkerListener.OnRouteListener {

    public static final String KEY_LAT_LNG_TO = "LatLng_TO";
    private static final String TAG = "MapRouterFragment";
    private final Handler handler = new Handler();

    private View btnActionNavigation;
    private View failLayout;
    private View loadingLayout;
    private View layoutRouterList;
    private View layoutProgress;

    private final Runnable timeoutWatchDog = this::showRouterFail;
    private final View.OnClickListener LoadFailListener = v -> startCalculate();
    private RecyclerView recyclerView;
    private RouteListAdapter adapter;

    private NaviLatLng targetLatLng;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            Bundle args = getArguments();
            if (args == null) {
                Timber.tag(TAG).d("onCreate: 没有有效的定位信息");
                Toast.makeText(getActivity().getApplicationContext(), "没有有效的定位信息", Toast.LENGTH_SHORT).show();
                mListener.backPreviewLevel();
                return;
            }
            targetLatLng = args.getParcelable(KEY_LAT_LNG_TO);
        } else {
            targetLatLng = savedInstanceState.getParcelable(KEY_LAT_LNG_TO);
        }
        adapter = new RouteListAdapter();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(KEY_LAT_LNG_TO, targetLatLng);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_gas_staiton_router_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mListener.setRouteListener(this);
        layoutRouterList = view.findViewById(R.id.router_list);
        layoutProgress = view.findViewById(R.id.layout_progress);
        recyclerView = view.findViewById(R.id.rv_car_router);
        loadingLayout = view.findViewById(R.id.loading_layout);
        failLayout = view.findViewById(R.id.layout_fail);
        failLayout.setOnClickListener(LoadFailListener);
        view.findViewById(R.id.ivb_back).setOnClickListener(v -> mListener.backPreviewLevel());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(),
                DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(adapter);

        btnActionNavigation = view.findViewById(R.id.btn_action_navigation);
        btnActionNavigation.setOnClickListener(v -> {
            if (adapter.selectedRouteIndex != -1) {
                Intent intent = new Intent(getActivity().getApplicationContext(), NavigationActivity.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public void onStart() {
        super.onStart();
        // 开始算路
        startCalculate();
    }

    @NonNull
    private String getTotalLen(int length) {
        if (length < 0) return "";
        if (length < 1000) return length + "米";
        else return new DecimalFormat("#.0").format(length / 1000.0) + "公里";
    }

    @NonNull
    private String getTimeString(int second) {
        if (second < 0) return "";
        StringBuilder time = new StringBuilder("约");
        if (second < 60) return time.append(second).append("秒").toString();
        int minutes = (int) Math.round(second / 60.0);
        if (minutes < 60) return time.append(minutes).append("分钟").toString();
        else {
            int hour = minutes / 60;
            time.append(hour).append("小时");
            if (minutes % 60 != 0) time.append(minutes % 60).append("分钟");
        }
        return time.toString();
    }

    private void showRouterResult(HashMap<Integer, AMapNaviPath> routes) {
        if (routes != null && routes.size() > 0) {
            adapter.update(routes);
            layoutRouterList.setVisibility(View.VISIBLE);
            btnActionNavigation.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            layoutProgress.setVisibility(View.GONE);
        } else {
            Timber.tag(TAG).d("算路结果为空");
        }
    }

    private void showRouterFail() {
        layoutRouterList.setVisibility(View.GONE);
        layoutProgress.setVisibility(View.VISIBLE);
        loadingLayout.setVisibility(View.GONE);
        failLayout.setVisibility(View.VISIBLE);
        btnActionNavigation.setVisibility(View.GONE);
    }

    private void showRouterLoading() {
        layoutRouterList.setVisibility(View.GONE);
        layoutProgress.setVisibility(View.VISIBLE);
        loadingLayout.setVisibility(View.VISIBLE);
        failLayout.setVisibility(View.GONE);
    }

    private void startCalculate() {
        showRouterLoading();
        mListener.calculateRoute();
    }

    @Override
    public void onRouteSuccess(int[] routeIds, HashMap<Integer, AMapNaviPath> routes) {
        Timber.tag(TAG).d("onCalculateRouteSuccess: %d", routes.size());
        handler.removeCallbacks(timeoutWatchDog);
        showRouterResult(routes);
    }

    @Override
    public void onRouteFailed(int errorCode) {
        handler.removeCallbacks(timeoutWatchDog);
        Toast.makeText(getContext(), "算路失败: " + errorCode, Toast.LENGTH_SHORT).show();
        showRouterFail();
    }

    private class RouteListAdapter extends RecyclerView.Adapter<RouteViewHolder> {
        int selectedRouteIndex = -1;
        ArrayList<Integer> routeIds = new ArrayList<>();
        private HashMap<Integer, AMapNaviPath> routes;

        @Override
        public RouteViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext())
                    .inflate(R.layout.item_gas_station_item_station_router, viewGroup, false);
            return new RouteViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RouteViewHolder holder, int i) {
            int routeId = routeIds.get(i);
            AMapNaviPath path = routes.get(routeId);
            holder.bind(path);
        }

        @Override
        public int getItemCount() {
            return routeIds.size();
        }

        void update(HashMap<Integer, AMapNaviPath> routes) {
            this.routes = routes;
            routeIds.clear();
            if (routes.size() != 0) {
                routeIds.addAll(routes.keySet());
                // 默认选择第一个路径
                selectItem(0);
            }
            notifyDataSetChanged();
        }

        void selectItem(int index) {
            if (index != -1 && index != this.selectedRouteIndex) {
                this.selectedRouteIndex = index;
                adapter.notifyDataSetChanged();
                mListener.selectRoute(routeIds.get(selectedRouteIndex));
            }
        }
    }

    private class RouteViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final TextView routerName;
        private final TextView routerSummary;
        private final TextView routerPath;

        RouteViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            routerName = itemView.findViewById(R.id.tv_router_name);
            routerSummary = itemView.findViewById(R.id.tv_router_summary);
            routerPath = itemView.findViewById(R.id.tv_router_path);
        }

        void bind(AMapNaviPath path) {

            routerName.setText(path.getLabels());
            routerSummary.setText(String.format(Locale.CHINA, "%s | %s | 红绿灯%d个",
                    getTimeString(path.getAllTime()),
                    getTotalLen(path.getAllLength()),
                    path.getLightList().size()
            ));
            StringBuilder stringBuilder = new StringBuilder("途径：");
            String roadName = "无名道路";
            for (AMapNaviStep aMapNaviStep : path.getSteps()) {
                for (AMapNaviLink aMapNaviLink : aMapNaviStep.getLinks()) {
                    if (!TextUtils.equals(aMapNaviLink.getRoadName(), roadName)) {
                        roadName = aMapNaviLink.getRoadName();
                        stringBuilder.append(roadName).append(" > ");
                    }
                }
            }
            String noName = "> 无名道路 > ";
            int start = stringBuilder.lastIndexOf(noName);
            if (start != -1)
                stringBuilder.delete(start, start + noName.length());
            routerPath.setText(stringBuilder.toString().trim());
            if (getAdapterPosition() == adapter.selectedRouteIndex) {
                itemView.setSelected(true);
            } else {
                itemView.setSelected(false);
            }
        }

        @Override
        public void onClick(View v) {
            if (getAdapterPosition() == RecyclerView.NO_POSITION) {
                Timber.tag(TAG).d("onClick: 点击到正在layout中的holder");
                return;
            }
            if (adapter.selectedRouteIndex != getAdapterPosition()) {
                adapter.selectItem(getAdapterPosition());
            }
        }
    }
}