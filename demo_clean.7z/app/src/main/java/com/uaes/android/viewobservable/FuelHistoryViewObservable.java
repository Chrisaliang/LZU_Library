package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.uaes.android.BR;
import com.uaes.android.viewmodel.FuelHistoryViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Created by Chrisaliang on 2017/12/6.
 * data binding for fuel history
 */

public class FuelHistoryViewObservable extends BaseObservable {

    private final FuelHistoryViewModel viewModel;
    //*总消费*/
    private String fuelCost;
    //*总耗油量*/
    private String fuelUse;
    //*怠速耗油量*/
    private String idleUse;
    //*怠速耗油 费用*/
    private String idleUseMoney;
    //*怠速耗油量 百分比*/
    private String idleUsePercent;
    //*行驶消耗油量 */
    private String driverUse;
    //*行驶消耗 费用*/
    private String driverUseMoney;
    // 行驶消耗 百分比
    private String driverUsePercent;
    //*空调消耗 多少油量 L*/
    private String acUse;
    //*空调消耗 费用*/
    private String acUseMoney;
    //*空调消耗 百分比 L*/
    private String acUsePercent;
    //*其他消耗油量*/
    private String otherUse;
    //*其他消耗 费用*/
    private String otherUseMoney;
    //*其他消耗油量 百分比*/
    private String otherUsePercent;
    private int status = RetryView.RETRY_LOADING;

    public FuelHistoryViewObservable(FuelHistoryViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void onClick(RetryView view) {
        viewModel.queryAgain();
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public String getFuelCost() {
        return fuelCost;
    }


    public void setFuelCost(String fuelCost) {
        this.fuelCost = fuelCost;
        notifyPropertyChanged(BR.fuelCost);
    }

    @Bindable
    public String getFuelUse() {
        return fuelUse;
    }

    public void setFuelUse(String fuelUse) {
        this.fuelUse = fuelUse;
        notifyPropertyChanged(BR.fuelUse);
    }

    @Bindable
    public String getIdleUseMoney() {
        return idleUseMoney;
    }

    public void setIdleUseMoney(String idleUseMoney) {
        this.idleUseMoney = idleUseMoney;
        notifyPropertyChanged(BR.idleUseMoney);
    }

    @Bindable
    public String getIdleUse() {
        return idleUse;
    }

    public void setIdleUse(String idleUse) {
        this.idleUse = idleUse;
        notifyPropertyChanged(BR.idleUse);
    }

    @Bindable
    public String getIdleUsePercent() {
        return idleUsePercent;
    }

    public void setIdleUsePercent(String idleUsePercent) {
        this.idleUsePercent = idleUsePercent;
        notifyPropertyChanged(BR.idleUsePercent);
    }

    @Bindable
    public String getDriverUse() {
        return driverUse;
    }

    public void setDriverUse(String driverUse) {
        this.driverUse = driverUse;
        notifyPropertyChanged(BR.driverUse);
    }

    @Bindable
    public String getDriverUseMoney() {
        return driverUseMoney;
    }

    public void setDriverUseMoney(String driverUseMoney) {
        this.driverUseMoney = driverUseMoney;
        notifyPropertyChanged(BR.driverUseMoney);
    }

    @Bindable
    public String getDriverUsePercent() {
        return driverUsePercent;
    }

    public void setDriverUsePercent(String driverUsePercent) {
        this.driverUsePercent = driverUsePercent;
        notifyPropertyChanged(BR.driverUsePercent);
    }

    @Bindable
    public String getAcUse() {
        return acUse;
    }

    public void setAcUse(String acUse) {
        this.acUse = acUse;
        notifyPropertyChanged(BR.acUse);
    }

    @Bindable
    public String getAcUseMoney() {
        return acUseMoney;
    }

    public void setAcUseMoney(String acUseMoney) {
        this.acUseMoney = acUseMoney;
        notifyPropertyChanged(BR.acUseMoney);
    }

    @Bindable
    public String getAcUsePercent() {
        return acUsePercent;
    }

    public void setAcUsePercent(String acUsePercent) {
        this.acUsePercent = acUsePercent;
        notifyPropertyChanged(BR.acUsePercent);
    }

    @Bindable
    public String getOtherUse() {
        return otherUse;
    }


    public void setOtherUse(String otherUse) {
        this.otherUse = otherUse;
        notifyPropertyChanged(BR.otherUse);
    }

    @Bindable
    public String getOtherUseMoney() {
        return otherUseMoney;
    }

    public void setOtherUseMoney(String otherUseMoney) {
        this.otherUseMoney = otherUseMoney;
        notifyPropertyChanged(BR.otherUseMoney);
    }

    @Bindable
    public String getOtherUsePercent() {
        return otherUsePercent;
    }


    public void setOtherUsePercent(String otherUsePercent) {
        this.otherUsePercent = otherUsePercent;
        notifyPropertyChanged(BR.otherUsePercent);
    }


}
