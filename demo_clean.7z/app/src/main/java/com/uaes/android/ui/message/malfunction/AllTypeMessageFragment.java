package com.uaes.android.ui.message.malfunction;

import android.arch.lifecycle.ViewModelProviders;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentMalfunctionBinding;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.ui.message.adapter.MessagesAdapter;
import com.uaes.android.ui.message.listener.ImageChooseClickListener;
import com.uaes.android.viewmodel.MessageStateViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.AllTypeMessageObservable;
import com.uaes.android.viewobservable.MessageStatesItemObservable;
import com.uaes.common.Intents;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/11.
 * Des : This is 消息故障Fragment界面
 */

public class AllTypeMessageFragment extends NavigatorFragment implements ImageChooseClickListener {
    private static final String TAG = AllTypeMessageFragment.class.getSimpleName();
    private final List<MessageStatesItemObservable> data = new ArrayList<>();
    @Inject
    RepositoryVMProvider factory;
    private FragmentMalfunctionBinding binding;
    private MessageStateViewModel mViewModel;
    private MessagesAdapter adapter;
    private String fragmentTag;//页面属性 推荐 故障 预警 通知
    private AllTypeMessageObservable mAllTypeMessageObservable;
    private Disposable mDisposable;

    private final BroadcastReceiver messageChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intents.MESSAGE.EXTRA_MESSAGE_SAVE.equals(action) ||
                    Intents.MESSAGE.EXTRA_MESSAGE_DELETE.equals(action)) {
                refresh();
            } else {
                Timber.tag(TAG).e("error action: %s", action);
            }
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mViewModel = ViewModelProviders.of(this, factory).get(MessageStateViewModel.class);
        mAllTypeMessageObservable = new AllTypeMessageObservable(mViewModel);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_malfunction, container, false);
        binding.setListener(this);
        binding.setHasDisplay(mAllTypeMessageObservable);
        binding.malfunctionFragmentRvMessage.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new MessagesAdapter(mViewModel, this);
        binding.malfunctionFragmentRvMessage.setAdapter(adapter);
        if (getArguments() != null)
            fragmentTag = getArguments().getString(Intents.MESSAGE_FRAGMENT_ARGUMENTS);
        mViewModel.getMessageList().observe(this, messagePushEntities -> {
            data.clear();
            if (messagePushEntities != null) {
                for (int i = messagePushEntities.size() - 1; i >= 0; i--) {
                    data.add(new MessageStatesItemObservable(messagePushEntities.get(i)));
                }
            }
            adapter.addNewAll(data);

            if (messagePushEntities != null && messagePushEntities.size() != 0) {
                mAllTypeMessageObservable.setHasDisplay(true);
            } else {
                mAllTypeMessageObservable.setHasDisplay(false);
            }
        });

        mViewModel.getStatue().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            mAllTypeMessageObservable.setStatus(integer);
        });
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onStart() {
        super.onStart();
        mAllTypeMessageObservable.setFragmentTag(fragmentTag);
        mViewModel.queryMessage(fragmentTag);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_SAVE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_DELETE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_QUERY);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(messageChangeReceiver, intentFilter);
    }

    @Override
    public void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(messageChangeReceiver);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mDisposable != null) {
            mDisposable.dispose();
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden)
            mNavigator.hideBackButton();
        else
            mNavigator.showBackButton();
    }

    @Override
    public void onClick(View v) {
        if (v == binding.malfunctionFragmentIvOperate) {
            if (adapter != null) {
                adapter.setEditMode(true);
                adapter.setClearClick();
            }
            changeViewState(true);
        } else if (v == binding.malfunctionFragmentIvDelete) {
            deleteMessage();
        } else if (v == binding.malfunctionFragmentIvCancel) {
            if (adapter != null) {
                adapter.setEditMode(false);
                adapter.setAllSelect(false);
                adapter.setClearClick();
                binding.malfunctionFragmentRbSelectall.setChecked(false);
            }
            changeViewState(false);
        }
    }

    @Override
    public void onCheckedChanged(View view, boolean isChecked) {
        if (isChecked) {//选中
            adapter.setAllSelect(true);
        } else {
            adapter.setAllSelect(false);
        }
    }

    @Override
    public void jumpToMessageType(MessageStatesItemObservable message) {
        Intent intent = new Intent(Intents.ACTION_MESSAGE_JUMP);
        intent.putExtra(Intents.EXTRA_MESSAGE, message.getMessageEntity());
        LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);
    }

    @Override
    public void refresh() {
        mViewModel.queryMessage(fragmentTag);
        refreshTime(Tables.PUSH_MESSAGE.TABLE_NAME);
    }

    private void deleteMessage() {
        if (adapter != null) {
            mViewModel.deleteMessage(adapter.getNeedDelete(fragmentTag)).subscribe(new SingleObserver<Boolean>() {
                @Override
                public void onSubscribe(Disposable d) {
                    mDisposable = d;
                }

                @Override
                public void onSuccess(Boolean aBoolean) {
                    mViewModel.queryMessage(fragmentTag);
                    sendMessageInAppBroadCast(getActivity());
                }

                @Override
                public void onError(Throwable e) {

                }
            });

            adapter.setEditMode(false);
            adapter.setAllSelect(false);
            adapter.setClearClick();
            binding.malfunctionFragmentRbSelectall.setChecked(false);
            changeViewState(false);
        }
    }

    private void sendMessageInAppBroadCast(Context context) {
        Intent intent = new Intent(Intents.MESSAGE.EXTRA_MESSAGE_DELETE);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    private void changeViewState(boolean state) {
        if (state) {
            binding.malfunctionFragmentIvOperate.setVisibility(View.GONE);
            binding.malfunctionFragmentRbSelectall.setVisibility(View.VISIBLE);
            binding.malfunctionFragmentIvDelete.setVisibility(View.VISIBLE);
            binding.malfunctionFragmentIvCancel.setVisibility(View.VISIBLE);
        } else {
            binding.malfunctionFragmentIvOperate.setVisibility(View.VISIBLE);
            binding.malfunctionFragmentRbSelectall.setVisibility(View.GONE);
            binding.malfunctionFragmentIvDelete.setVisibility(View.GONE);
            binding.malfunctionFragmentIvCancel.setVisibility(View.GONE);
        }
    }

}
