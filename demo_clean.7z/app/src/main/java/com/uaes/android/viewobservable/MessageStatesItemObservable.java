package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.uaes.android.BR;
import com.uaes.android.domain.pojo.DomainMessage;

/**
 * Author : 张 涛
 * Time : 2018/1/18.
 * Des : This is
 */

public class MessageStatesItemObservable extends BaseObservable {
    private DomainMessage messageEntity;
    private boolean isSelect;//选中
    private boolean allowEdit;//是否可以编辑
    private boolean currentClick;//当前是否被点击

    public MessageStatesItemObservable(DomainMessage messageEntity) {
        this.messageEntity = messageEntity;
        this.isSelect = false;
        this.allowEdit = false;//是否可以编辑
        this.currentClick = false;//是否可以编辑
    }

    @Bindable
    public DomainMessage getMessageEntity() {
        return messageEntity;
    }

    public void setMessageEntity(DomainMessage messageEntity) {
        this.messageEntity = messageEntity;
        notifyPropertyChanged(BR.messageEntity);
    }

    @Bindable
    public boolean getSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
        notifyPropertyChanged(BR.select);
    }

    @Bindable
    public boolean getAllowEdit() {
        return allowEdit;
    }

    public void setAllowEdit(boolean allowEdit) {
        this.allowEdit = allowEdit;
        notifyPropertyChanged(BR.allowEdit);
    }

    @Bindable
    public boolean getCurrentClick() {
        return currentClick;
    }

    public void setCurrentClick(boolean currentClick) {
        this.currentClick = currentClick;
        notifyPropertyChanged(BR.currentClick);
    }
}
