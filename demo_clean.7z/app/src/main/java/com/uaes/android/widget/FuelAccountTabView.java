package com.uaes.android.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.uaes.android.R;

/**
 * Created by hand on 2017/11/9.
 * show a label or edit
 */

@BindingMethods({
        @BindingMethod(type = FuelAccountTabView.class, attribute = "onEditActionListener", method = "setOnEditorActionListener")
})
public class FuelAccountTabView extends FrameLayout {

    private OnEditorListener onEditorActionListener;
    private InputMethodManager imm;
    //    private boolean isEdit = false;
    private AutoCompleteTextView editText;
    private View displayView;
    private View editLayout;
    private TextView.OnEditorActionListener delegate = new TextView.OnEditorActionListener() {

        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            return onEditorActionListener != null && onEditorActionListener.onEditorAction(FuelAccountTabView.this, v, actionId, event);
        }
    };

    public FuelAccountTabView(@NonNull Context context) {
        this(context, null);
    }

    public FuelAccountTabView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FuelAccountTabView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @BindingAdapter(value = "onEditActionListener")
    public static void setOnEditorActionListener(FuelAccountTabView view, OnEditorListener listener) {
        view.onEditorActionListener = listener;
    }

    private void init(Context context, AttributeSet attrs) {
        inflate(context, R.layout.widget_fuel_text_editor, this);
        editText = findViewById(R.id.tab_text_edit);
        editText.setOnEditorActionListener(delegate);
        displayView = findViewById(R.id.label_layout);
        editLayout = findViewById(R.id.edit_layout);
        TextView unitLeft = findViewById(R.id.tv_unit_left);
        TextView unitRight = findViewById(R.id.tv_unit_right);
        ImageView labelIcon = findViewById(R.id.label_icon);
        TextView labelTitle = findViewById(R.id.label_title);
        TextView textView = findViewById(R.id.label_value);
        imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FuelAccountTabView);
        Drawable icon = a.getDrawable(R.styleable.FuelAccountTabView_label_icon);
        if (icon != null)
            labelIcon.setImageDrawable(icon);
        String labelTitleText = a.getString(R.styleable.FuelAccountTabView_label_title);
        labelTitle.setText(labelTitleText);
        String unitLeftText = a.getString(R.styleable.FuelAccountTabView_unit_left);
        if (!TextUtils.isEmpty(unitLeftText)) {
            unitLeft.setText(unitLeftText);
            unitLeft.setVisibility(VISIBLE);
        }
        String unitRightText = a.getString(R.styleable.FuelAccountTabView_unit_right);
        if (!TextUtils.isEmpty(unitRightText)) {
            unitRight.setText(unitRightText);
            unitRight.setVisibility(VISIBLE);
        }

        Drawable endIcon = a.getDrawable(R.styleable.FuelAccountTabView_editor_endIcon);
        if (endIcon != null)
            textView.setCompoundDrawables(null, null, endIcon, null);

        String title = a.getString(R.styleable.FuelAccountTabView_editor_title);
        HomeMenuTabTextView editTitle = findViewById(R.id.tab_edit_title);
        editTitle.setText(title);
        Drawable editIcon = a.getDrawable(R.styleable.FuelAccountTabView_edit_icon);
        if (editIcon != null)
            editTitle.setIcon(editIcon);


        int color = a.getColor(R.styleable.FuelAccountTabView_editor_editColor, Color.WHITE);
        int size = a.getDimensionPixelSize(R.styleable.FuelAccountTabView_editor_editSize, 22);
//        editText.setHint(title);
        editText.setHintTextColor(color);
        editText.setTextColor(color);
        editText.setTextSize(size);
        int padding = a.getDimensionPixelSize(R.styleable.FuelAccountTabView_editor_drawable_padding, 0);
        textView.setCompoundDrawablePadding(padding);

        int textSize = a.getDimensionPixelSize(R.styleable.FuelAccountTabView_editor_titleSize, 32);
        textView.setTextSize(textSize);

        int textColor = a.getColor(R.styleable.FuelAccountTabView_editor_titleColor, Color.WHITE);
        textView.setTextColor(textColor);
        a.recycle();
    }

    public void setEdit(boolean isEdit) {
//        this.isEdit = isEdit;
//        toggle(isEdit);
//    }
//
//    private void toggle(boolean isEdit) {
        if (isEdit) {
            editLayout.setVisibility(VISIBLE);
            displayView.setVisibility(INVISIBLE);
            postDelayed(() -> {
                editText.requestFocus();
                imm.viewClicked(editText);
                imm.showSoftInput(editText, 0);
            }, 500);
        } else {
            editLayout.setVisibility(INVISIBLE);
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
            editText.clearFocus();
            displayView.setVisibility(VISIBLE);
        }
    }

    public String getText() {
        return editText.getText().toString();
    }

    public void setValue(CharSequence text) {
        ((TextView) findViewById(R.id.label_value)).setText(text);
    }

    @Override
    public void clearFocus() {
        super.clearFocus();
        editText.clearFocus();
    }

    public void setAutoCompleteTextArray(String[] arr) {
        editText.setAdapter(new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arr));
    }

    public interface OnEditorListener {
        boolean onEditorAction(FuelAccountTabView parent, TextView v, int actionId, KeyEvent event);
    }
}
