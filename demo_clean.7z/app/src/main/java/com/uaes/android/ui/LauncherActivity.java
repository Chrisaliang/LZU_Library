package com.uaes.android.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.uaes.android.R;
import com.uaes.android.domain.SecurityCheckRepository;
import com.uaes.android.domain.TokenRepository;
import com.uaes.android.domain.pojo.DomainSecurityResult;

import javax.inject.Inject;

import dagger.android.support.DaggerAppCompatActivity;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class LauncherActivity extends DaggerAppCompatActivity implements View.OnClickListener {

    private static final String TAG = LauncherActivity.class.getSimpleName();

    private static final int DELAY_MILLIS = 1500;
    private static final String KEY_USER_AGREE = "user_agree";
    private final Handler handler = new Handler();

    @Inject
    TokenRepository mTokenInterface;
    private final Runnable queryTokeRunnable = new Runnable() {
        @Override
        public void run() {
            mTokenInterface.queryToken().subscribe(new TokenObserver());
        }
    };
    //    private BroadcastReceiver vinReceiver = new VinCodeReceiver();
    @Inject
    SharedPreferences sp;

    @Inject
    SecurityCheckRepository securityCheckRepository;

    private Disposable disposable;
    private PopupWindow popupWindow;
    private View result;

    private final Runnable timeOutRunnable = () -> {
        Toast.makeText(LauncherActivity.this, R.string.login_time_out, Toast.LENGTH_SHORT).show();
        finishAffinity();
        handler.removeCallbacks(queryTokeRunnable);
    };

    @SuppressLint("InflateParams")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lanucher);
        // 验证签名
        securityCheckRepository.checkSecurity().subscribe(new CheckObserver());
//        if (checkSignature()) {
//            // 验签通过,检查是否有本地同意使用标记
//            if (sp.getBoolean(KEY_USER_AGREE, false)) {
//                queryToken();
//                return;
//            }
//            // 没有本地同意标记 显示同意界面
//            result = getLayoutInflater().inflate(R.layout.user_readme_layout, null);
//            result.findViewById(R.id.iv_user_agree).setOnClickListener(this);
//            result.findViewById(R.id.iv_user_disagree).setOnClickListener(this);
//        } else {
//            // 验签不通过 ,显示验签失败界面
//            result = getLayoutInflater().inflate(R.layout.signature_out_layout, null);
//            result.findViewById(R.id.iv_signature_quit).setOnClickListener(this);
//        }
//        popupWindow = new PopupWindow(this);
//        popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
//        popupWindow.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
//        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#B2000000")));
//        popupWindow.setOutsideTouchable(false);
//        popupWindow.setFocusable(true);
//        popupWindow.setContentView(result);
    }

    @Override
    protected void onStart() {
        super.onStart();
        handler.postDelayed(() -> {
            if (popupWindow != null)
                popupWindow.showAtLocation(findViewById(R.id.launcher_view), Gravity.CENTER, 0, 0);
        }, 1000);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (disposable != null)
            disposable.dispose();
        handler.removeCallbacks(timeOutRunnable);
        handler.removeCallbacks(queryTokeRunnable);
    }

    private void homeActivity() {
        handler.postDelayed(() -> {
            Intent intent = new Intent(
                    LauncherActivity.this,
                    HomeActivity.class);
            startActivity(intent);
            finish();
            handler.removeCallbacks(timeOutRunnable);
        }, DELAY_MILLIS);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_signature_quit:
            case R.id.iv_user_disagree:
                finishAffinity();
                break;
            case R.id.iv_user_agree:
                popupWindow.dismiss();
                sp.edit().putBoolean(KEY_USER_AGREE, true).apply();
                queryToken();
                break;
        }
    }

    private void queryToken() {
//                IntentFilter intentFilter = new IntentFilter();
//                intentFilter.addAction(Intents.ACTION_VIN);
//                registerReceiver(vinReceiver, intentFilter);
        handler.postDelayed(timeOutRunnable, 30 * 1000);
        mTokenInterface.queryToken().subscribe(new TokenObserver());
    }

    private class TokenObserver implements SingleObserver<Boolean> {

        @Override
        public void onSubscribe(Disposable d) {
            if (disposable != null && !disposable.isDisposed()) {
                disposable.dispose();
            }
            disposable = d;
        }

        @Override
        public void onSuccess(Boolean s) {
            if (s) homeActivity();
        }

        @Override
        public void onError(Throwable e) {
            Timber.tag(TAG).e(e, "Query Token Failed ");
            Toast.makeText(LauncherActivity.this,
                    R.string.get_token_fail, Toast.LENGTH_LONG).show();
            handler.postDelayed(queryTokeRunnable, 10 * 1000);
        }
    }

    private Disposable securityDisposable;

    private class CheckObserver implements SingleObserver<DomainSecurityResult> {

        @Override
        public void onSubscribe(Disposable d) {
            if (securityDisposable != null) {
                securityDisposable.dispose();
            }
            securityDisposable = d;
        }

        @Override
        public void onSuccess(DomainSecurityResult domainSecurityResult) {

            int agreement = DomainSecurityResult.FLAG_USER_AGREEMENT & domainSecurityResult.resultCode;
            int rooted = DomainSecurityResult.FLAG_ROOT & domainSecurityResult.resultCode;
            int signature = DomainSecurityResult.FLAG_SIGNATURE & domainSecurityResult.resultCode;

            if (signature == DomainSecurityResult.FLAG_SIGNATURE) {
                result = getLayoutInflater().inflate(R.layout.signature_out_layout, null);
                result.findViewById(R.id.iv_signature_quit).setOnClickListener(LauncherActivity.this);
            } else {
                if (agreement == DomainSecurityResult.FLAG_USER_AGREEMENT) {
                    result = getLayoutInflater().inflate(R.layout.user_readme_layout, null);
                    result.findViewById(R.id.iv_user_agree).setOnClickListener(LauncherActivity.this);
                    result.findViewById(R.id.iv_user_disagree).setOnClickListener(LauncherActivity.this);
                } else {
                    queryToken();
                    return;
                }
                if (rooted == DomainSecurityResult.FLAG_ROOT) {
                    // TODO: 2/28/2018  // 添加设备被rooted 风险信息提示.
                }
            }
            popupWindow = new PopupWindow(LauncherActivity.this);
            popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
            popupWindow.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
            popupWindow.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#B2000000")));
            popupWindow.setOutsideTouchable(false);
            popupWindow.setFocusable(true);
            popupWindow.setContentView(result);
        }

        @Override
        public void onError(Throwable e) {
            Timber.tag(TAG).e(e);
            finish();
        }
    }
}
