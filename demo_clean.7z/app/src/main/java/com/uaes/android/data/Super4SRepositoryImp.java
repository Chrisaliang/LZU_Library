package com.uaes.android.data;

import com.amap.api.location.AMapLocationClient;
import com.uaes.android.data.http.S4ShopApi;
import com.uaes.android.data.internal.AMapLocationSingle;
import com.uaes.android.domain.Super4SRepository;
import com.uaes.android.domain.pojo.Domain4SShop;
import com.uaes.android.domain.pojo.DomainAd;
import com.uaes.android.domain.pojo.DomainMyLocation;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by aber on 1/23/2018.
 * 4s店接口
 */

public class Super4SRepositoryImp implements Super4SRepository {

    private final S4ShopApi api;

    private DomainMyLocation<List<Domain4SShop>> domainMyLocation;

    public Super4SRepositoryImp(S4ShopApi api) {
        this.api = api;
    }

    // TODO: 2018/2/9 subscribe on io thread
    @Override
    public Single<DomainMyLocation<List<Domain4SShop>>> get4SShop(AMapLocationClient client) {

        return new AMapLocationSingle(client)
                .flatMap(location -> {
                    if (domainMyLocation == null)
                        domainMyLocation = new DomainMyLocation<>();
                    domainMyLocation.myLocation = location;
                    return api.getShops(location.getProvince(), location.getLongitude() + "," + location.getLatitude())
                            .subscribeOn(Schedulers.io());
                }).map(shops -> {
                    domainMyLocation.dataSet = shops.msgContent;
                    return domainMyLocation;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<DomainAd> getAd(String adType) {
        return api.getAdByType(adType).map(json -> json.msgContent)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }


}
