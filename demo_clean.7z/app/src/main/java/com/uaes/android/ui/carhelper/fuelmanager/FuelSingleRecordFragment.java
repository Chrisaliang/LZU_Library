package com.uaes.android.ui.carhelper.fuelmanager;

import android.annotation.SuppressLint;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentFuelManagerSingleFuelRecordBinding;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.viewmodel.FuelSingleRecordViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.FuelSingleRecordViewObservable;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Created by hand on 2017/11/6.
 * 单次用油记录
 */

public class FuelSingleRecordFragment extends NavigatorFragment
        implements Observer<DomainFuelSingleRecord>, FuelSingleRecordListener {
    private static final String TAG = FuelSingleRecordFragment.class.getSimpleName();
    @Inject
    RepositoryVMProvider factory;
    private View detailView;
    private PopupWindow popupWindow;
    private FragmentFuelManagerSingleFuelRecordBinding binding;
    private FuelSingleRecordViewModel viewModel;
    private FuelSingleRecordViewObservable viewObservable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        popupWindow = new PopupWindow(getActivity());
        popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#B2000000")));
        popupWindow.setOutsideTouchable(false);
        popupWindow.setFocusable(true);

        viewModel = ViewModelProviders.of(this, factory).get(FuelSingleRecordViewModel.class);
        viewObservable = new FuelSingleRecordViewObservable(viewModel);
    }

    @SuppressLint("InflateParams")
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        detailView = inflater.inflate(R.layout.fuel_manager_single_record_detail, null);
        detailView.findViewById(R.id.btn_single_record_cancel).setOnClickListener(this);
        detailView.findViewById(R.id.btn_single_record_confirm).setOnClickListener(this);

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_fuel_manager_single_fuel_record, container, false);
        binding.setSingleRecord(viewObservable);
        viewModel.getSingleRecord().observe(this, this);
        viewModel.getStatus().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            viewObservable.setStatus(integer);
        });
        initChart(binding.barChart);
        return binding.getRoot();
    }

    private void initChart(BarChart barChart) {
        barChart.setPinchZoom(false);
        barChart.setNoDataText("没有数据");
        barChart.setNoDataTextColor(Color.WHITE);
        barChart.setScaleEnabled(false);
        barChart.setExtraOffsets(0, 24, 24, 24);
        barChart.setOnChartValueSelectedListener(this);
        // XAxis config
        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawLabels(true);
        xAxis.setDrawAxisLine(true);
        xAxis.setGranularity(1f); // one year
        xAxis.setLabelCount(6);
        xAxis.setTextSize(20);
        xAxis.setAxisMaximum(5.5f);
        xAxis.setAxisMinimum(-0.5f);
        xAxis.setTextColor(Color.WHITE);
        xAxis.setAxisLineColor(Color.WHITE);
        barChart.getDescription().setText("");
        // YAxis
        barChart.getAxisRight().setEnabled(false);
        YAxis leftyAxis = barChart.getAxisLeft();
        leftyAxis.setDrawGridLines(true);
        leftyAxis.setGranularity(5f);
        leftyAxis.setDrawAxisLine(false);
        leftyAxis.setPosition(YAxis.YAxisLabelPosition.OUTSIDE_CHART);
        leftyAxis.setAxisLineColor(Color.WHITE);
        leftyAxis.setTextColor(Color.WHITE);
        leftyAxis.setTextSize(20);
        leftyAxis.setAxisMinimum(0f);
        leftyAxis.setValueFormatter((value, axis) -> {
            int intValue = (int) value;
            if (intValue >= 5) return String.valueOf(intValue);
            else return "";
        });

        Legend l = barChart.getLegend();
        l.setEnabled(false);
    }

    @Override
    public void onStart() {
        super.onStart();
        refresh();
    }

    @Override
    public void refresh() {
        viewObservable.refresh();
    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {
        Timber.tag(TAG).d("onValueSelected: " + e + " , Highlight: " + h);
        viewObservable.onValueSelected(popupWindow, detailView, e);
    }

    @Override
    public void onNothingSelected() {
        popupWindow.dismiss();
        binding.barChart.highlightValue(null);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_single_record_confirm) {
            viewObservable.updateFuelAccount(popupWindow, detailView);
        } else if (id == R.id.btn_single_record_cancel) {
            popupWindow.dismiss();
            binding.barChart.highlightValue(null);
        }
    }

    @Override
    public void onChanged(@Nullable DomainFuelSingleRecord singleRecord) {
        if (singleRecord == null) return;
        viewObservable.setRecord(singleRecord);
        viewObservable.setFillAmountSum(singleRecord.fillAmountSum);
        viewObservable.setFillCount(singleRecord.fillCount);
        refreshTime(Tables.FUEL_SINGLE_FILL_RECORD.TABLE_NAME);
    }
}
