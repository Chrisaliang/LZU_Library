package com.uaes.android.data.http;

import com.uaes.android.data.json.TokenResponse;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by hand on 2017/11/7.
 * Token query
 */

public interface TokenApi {
    @GET("car/v1/carAuth/viewAuth")
    Single<TokenResponse> getToken(@Query("accessKey") String vinCode);
}
