package com.uaes.android.data;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;

import com.uaes.android.AuthFunction;
import com.uaes.android.data.maper.MessageMapper;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.MessagePushEntity;
import com.uaes.android.domain.MessageRepository;
import com.uaes.android.domain.pojo.DomainMessage;
import com.uaes.common.Intents;

import java.util.Arrays;
import java.util.List;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Author : 张 涛
 * Time : 2018/1/16.
 * Des : This is
 */

public class MessageRepositoryImp implements MessageRepository {

    private final CacheDao cacheDao;
    private final MessageMapper mMessageMapper;
    private final Context context;

    public MessageRepositoryImp(CacheDao cacheDao, Context context) {
        this.cacheDao = cacheDao;
        this.context = context;
        mMessageMapper = new MessageMapper();
    }

    @Override
    public Single<Boolean> saveMessage(final DomainMessage... messages) {
        return Single.just(messages).map(domainMessages -> {
            cacheDao.insertMessagePushWithTime(mMessageMapper.getArrayEntity(domainMessages));
            sendMessageInAppBroadCast(context, Intents.MESSAGE.EXTRA_MESSAGE_SAVE);
            sendShowMessage(context, domainMessages[0]);
            return true;
        }).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<Boolean> updateMessage(DomainMessage... messages) {
        return Single.just(messages).map(domainMessages -> {
            cacheDao.updateMessageWithTime(mMessageMapper.getArrayEntity(domainMessages));
            sendMessageInAppBroadCast(context, Intents.MESSAGE.EXTRA_MESSAGE_UPDATE);
            return true;
        }).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<Boolean> deleteMessage(DomainMessage... messages) {
        return Single.just(messages).map(domainMessages -> {
            cacheDao.deleteMessageWithTime(mMessageMapper.getArrayEntity(domainMessages));
            sendMessageInAppBroadCast(context, Intents.MESSAGE.EXTRA_MESSAGE_DELETE);
            return true;
        }).onErrorReturn(new AuthFunction<>(context)).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<List<DomainMessage>> queryMessage(int readState) {
        return Single.just(readState).map(integer -> {
            List<MessagePushEntity> temp = Arrays.asList(cacheDao.queryMessagePushNoRead());
            return mMessageMapper.mapToDomain(temp);
        }).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<Integer> countUnreadMessage(String messageClass) {
        return Single.just(messageClass).map(cacheDao::countUnreadMessage);
    }

    @Override
    public Single<List<DomainMessage>> queryMessage(String messageClass) {

        return Single.just(messageClass)
                .map(s -> {
                    List<MessagePushEntity> temp = Arrays.asList(cacheDao.queryMessagePushType(s));
                    return mMessageMapper.mapToDomain(temp);

                }).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    private void sendMessageInAppBroadCast(Context context, String action) {
        Intent intent = new Intent(action);
        LocalBroadcastManager.getInstance(context)
                .sendBroadcast(intent);
    }

    private void sendShowMessage(Context context, DomainMessage message) {
        Intent intent = new Intent(Intents.ACTION_MESSAGE);
        intent.putExtra("message", message);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }
}
