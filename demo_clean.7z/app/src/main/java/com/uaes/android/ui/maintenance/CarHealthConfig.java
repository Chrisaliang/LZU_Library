package com.uaes.android.ui.maintenance;

/**
 * Author : 张 涛
 * Time : 2018/1/30.
 * Des : This is
 */

public class CarHealthConfig {
    public static int engineOilDangerRange = 10;//机油危险范围
    public static int engineOilWarnRange = 20;//机油警告范围
    public static int engineOilHealthRange = 100;//机油健康范围
}
