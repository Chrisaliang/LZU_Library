package com.uaes.android.data.http;

import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.domain.pojo.Domain4SShop;
import com.uaes.android.domain.pojo.DomainAd;

import java.util.List;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by aber on 1/23/2018.
 * 4S 店接口列表
 */

public interface S4ShopApi {

    /**
     * 获取4s店网络接口
     *
     * @param province 省
     */
    @GET("/iss/v1/car/app/query4S")
    Single<GeneralAttributeReceive<List<Domain4SShop>>> getShops(@Query("province") String province,
                                                                 @Query("location") String latlog);


    /**
     * 获取4s店广告
     */
    @GET("/pub/v1/organization/app/findByCode/{type}")
    Single<GeneralAttributeReceive<DomainAd>> getAdByType(@Path("type") String type);
}
