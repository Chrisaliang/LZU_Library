package com.uaes.android.domain;

import io.reactivex.Single;

/**
 * Created by aber on 11/20/2017.
 * Token
 */

public interface TokenRepository {
    /**
     * 请求Token
     */
    Single<Boolean> queryToken();
}
