package com.uaes.android.ui.gasstation;

import android.os.Bundle;
import android.view.View;

import com.amap.api.navi.AMapNavi;
import com.amap.api.navi.AMapNaviView;
import com.amap.api.navi.AMapNaviViewListener;
import com.amap.api.navi.enums.NaviType;
import com.uaes.android.R;
import com.uaes.android.ui.BaseAMapNaviActivity;

public class NavigationActivity extends BaseAMapNaviActivity implements AMapNaviViewListener {

    private AMapNavi mAMapNavi;
    private AMapNaviView mAMapNaviView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gas_station_navigation);
        mAMapNavi = AMapNavi.getInstance(getApplicationContext());
        mAMapNavi.setUseInnerVoice(true);
        mAMapNaviView = findViewById(R.id.navigation_view);
        mAMapNaviView.onCreate(savedInstanceState);
        mAMapNaviView.setAMapNaviViewListener(this);
    }


    @Override
    protected void onStart() {
        super.onStart();
        mAMapNavi.startNavi(NaviType.GPS);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAMapNaviView != null) mAMapNaviView.onResume();
        mAMapNavi.resumeNavi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAMapNaviView != null) mAMapNaviView.onPause();
        mAMapNavi.pauseNavi();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAMapNaviView.setAMapNaviViewListener(null);
        mAMapNavi.stopNavi();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mAMapNaviView != null)
            mAMapNaviView.onDestroy();
        //noinspection StatementWithEmptyBody
    }


    @Override
    public void onNaviSetting() {

    }

    @Override
    public void onNaviCancel() {

    }

    @Override
    public boolean onNaviBackClick() {
        finish();
        return false;
    }

    @Override
    public void onNaviMapMode(int i) {

    }

    @Override
    public void onNaviTurnClick() {

    }

    @Override
    public void onNextRoadClick() {

    }

    @Override
    public void onScanViewButtonClick() {

    }

    @Override
    public void onLockMap(boolean b) {

    }

    @Override
    public void onNaviViewLoaded() {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    public void onBack(View view) {
        finish();
    }
}
