package com.uaes.android.ui;

/**
 * Created by hand on 2017/11/1.
 * 导航工具接口
 */
public interface IPageNavigator {
    /**
     * 跳转到车辆助手页面
     */
    void backCarHelper();

    /**
     * 回退到上一个页面
     */
    void back();

    /**
     * 显示加载进度
     */
    void showLoading();

    /**
     * 隐藏进度显示
     */
    void dismissLoading();

    /**
     * 显示返回按钮
     */
    void showBackButton();

    /**
     * 隐藏返回按钮
     */
    void hideBackButton();

    /**
     * 数据更新时间
     */
    void updateTime(long time);
}
