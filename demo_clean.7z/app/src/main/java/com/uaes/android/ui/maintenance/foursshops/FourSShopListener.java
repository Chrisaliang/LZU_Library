package com.uaes.android.ui.maintenance.foursshops;

import android.view.View;

import com.uaes.android.viewobservable.FourSShopsObservable;
import com.uaes.android.viewobservable.FourSShopsOverallObservable;

/**
 * Author : 张 涛
 * Time : 2018/1/25.
 * Des : This is
 */

public interface FourSShopListener {
    /**
     * 去除广告
     */
    void onCloseAd(View view); //广告去除的×

    /**
     * 返回上一页
     */
    void onBack(View view);//返回去list界面

    /**
     * 点击显示可用路径
     */
    void onShowRoute(FourSShopsOverallObservable item);//去4s店的点击事件

    /**
     * 点击重新加载
     */
    void onLoadClick(View view);//重新加载点击

    /**
     * 选中一个Item
     *
     * @param newer 新选中的item
     */
    void onItemClick(FourSShopsObservable newer);
}
