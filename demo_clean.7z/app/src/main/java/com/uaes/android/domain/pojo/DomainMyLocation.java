package com.uaes.android.domain.pojo;

import com.amap.api.location.AMapLocation;

/**
 * Created by aber on 1/25/2018.
 * data with mylocation.
 */

public class DomainMyLocation<T> {

    public AMapLocation myLocation;

    public T dataSet;
}
