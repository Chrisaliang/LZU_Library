package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.android.databinding.library.baseAdapters.BR;
import com.uaes.android.ui.carhelper.fuelmanager.FuelHistoryListViewData;

/**
 * Created by Chrisaliang on 2017/12/6.
 * item
 */

public class FuelHistoryListItemObservable extends BaseObservable {

    private FuelHistoryListViewData data;

    @Bindable
    public FuelHistoryListViewData getData() {
        return data;
    }

    public void setData(FuelHistoryListViewData data) {
        this.data = data;
        notifyPropertyChanged(BR.item);
    }
}
