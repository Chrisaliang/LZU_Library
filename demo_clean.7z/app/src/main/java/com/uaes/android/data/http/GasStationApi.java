package com.uaes.android.data.http;

import com.uaes.android.data.json.GasStation;
import com.uaes.android.data.json.GeneralAttributeReceive;

import java.util.List;

import io.reactivex.Single;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by Chrisaliang on 2017/11/1.
 * get net data for station list
 */

public interface GasStationApi {
    /**
     * @param location 当前车辆位置
     * @param strategy 查询条件
     * @return 加油站列表
     */
    @POST("/gas/v1/gasStation/getGasStationNearBy")
    @FormUrlEncoded
    Single<GeneralAttributeReceive<List<GasStation>>> gasStationList(@Field("location") String location,
                                                                     @Field("strategy") int strategy);
}
