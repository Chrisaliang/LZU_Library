package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.data.Entry;
import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;
import com.uaes.android.viewmodel.FuelSingleRecordViewModel;
import com.uaes.android.viewmodel.SingleRecordItemViewModel;
import com.uaes.android.widget.RatingBar;
import com.uaes.android.widget.RetryView;

import java.util.Locale;

import timber.log.Timber;

/**
 * Created by Chrisaliang on 2018/1/22.
 * data binding for fuel single record
 */

public class FuelSingleRecordViewObservable extends BaseObservable {

    private static final String TAG = "FuelSingleRecordViewObs";
    private final FuelSingleRecordViewModel viewModel;
    private final Handler handler = new Handler();

    private int status = RetryView.RETRY_LOADING;
    // 加油次数 // 文字
    private String fillCount;
    // 加油总量 // 文字
    private String fillAmountSum;

    private DomainFuelSingleRecord singleRecord = DomainFuelSingleRecord.getEmptySingleRecord();
    private boolean mToastEnable = true;
    private SingleRecordItemViewModel currentSelectedItem;

    public FuelSingleRecordViewObservable(FuelSingleRecordViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void onClick(View view) {
        int id = view.getId();
        int number = 0;
        int size = 6;
        if (singleRecord == DomainFuelSingleRecord.getEmptySingleRecord())
            viewModel.update(number, size);
        else {
            if (id == R.id.single_fuel_record_previous) {
                if (singleRecord.barData.isFirstPage()) {
                    if (mToastEnable) {
                        handler.postDelayed(() -> mToastEnable = true, 1000);
                        mToastEnable = false;
                        Toast.makeText(view.getContext(), "已经是第一页了", Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                number = singleRecord.barData.getPreviousPageIndex();
            } else if (id == R.id.single_fuel_record_next) {
                if (singleRecord.barData.isLastPage()) {
                    if (mToastEnable) {
                        handler.postDelayed(() -> mToastEnable = true, 1000);
                        mToastEnable = false;
                        Toast.makeText(view.getContext(), "已经是最后一页了", Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                number = singleRecord.barData.getNextPageIndex();
            }
            viewModel.update(number, size);
        }
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public DomainFuelSingleRecord getSingleRecord() {
        return singleRecord;
    }

    public void setRecord(DomainFuelSingleRecord singleRecord) {
        this.singleRecord = singleRecord;
        notifyPropertyChanged(BR.singleRecord);
    }

    @Bindable
    public String getFillCount() {
        return fillCount;
    }

    public void setFillCount(String fillCount) {
        this.fillCount = fillCount;
        notifyPropertyChanged(BR.fillCount);
    }

    @Bindable
    public String getFillAmountSum() {
        return fillAmountSum;
    }

    public void setFillAmountSum(String fillAmountSum) {
        this.fillAmountSum = fillAmountSum;
        notifyPropertyChanged(BR.fillAmountSum);
    }

    public void refresh() {
        int number = 0;
        int size = 6;
        if (singleRecord != null)
            number = singleRecord.barData.currentPageIndex;
        viewModel.update(number, size);
    }

    public void onValueSelected(PopupWindow popupWindow, View detailView, Entry data) {
        try {
            currentSelectedItem = (SingleRecordItemViewModel) data.getData();
            int num = singleRecord.barData.contents.indexOf(data) + 1;
            if (currentSelectedItem != null)
                feedDetail(popupWindow, detailView, currentSelectedItem, num);
            else
                Timber.tag(TAG).i("onValueSelected: get null from Single'Record'ItemViewModel");
        } catch (Exception ex) {
            Timber.tag(TAG).d(ex, "onValueSelected: ");
        }
    }

    private void feedDetail(PopupWindow popupWindow, View detailView, SingleRecordItemViewModel item, int num) {
//        Toast.makeText(detailView.getContext(), "显示详细信息", Toast.LENGTH_SHORT).show();

        TextView tvPageSum = detailView.findViewById(R.id.tv_page_sum);
        RatingBar rateBar = detailView.findViewById(R.id.single_oil_detail_seek);
        TextView container1 = detailView.findViewById(R.id.text_container_1);
        TextView container2 = detailView.findViewById(R.id.text_container_2);
        tvPageSum.setText(String.format(Locale.CHINA, "%s/%d", singleRecord.fillCount, num));
        container1.setText(item.descriptionOne);
        container2.setText(item.descriptionTwo);
        rateBar.setCount(item.count);
        showDetail(popupWindow, detailView);
    }

    private void showDetail(PopupWindow popupWindow, View detailView) {
        popupWindow.setContentView(detailView);
        popupWindow.showAtLocation(detailView, Gravity.CENTER, 0, 0);
    }

    public void updateFuelAccount(PopupWindow popupWindow, View detailView) {
        RatingBar rateBar = detailView.findViewById(R.id.single_oil_detail_seek);
        FuelBookkeeping fuelAccount = new FuelBookkeeping();
        fuelAccount.eventId = currentSelectedItem.eventId;
        fuelAccount.evaluate = rateBar.getCount();
        viewModel.updateFuelAccount(fuelAccount, detailView.getContext());
        popupWindow.dismiss();
        handler.postDelayed(this::refresh, 100);
    }
}
