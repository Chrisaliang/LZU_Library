package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Date;

import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_ECONOMIC_RANK;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_ECU_FILL_AMOUNT;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_EVALUATE_LEVEL;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_EVENT_ID;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_FILL_AMOUNT;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_FILL_CHARGE;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_FILL_DATE;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_FILL_USED;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_GAS_LOCATION;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_GAS_NAME;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_MILLAGE_DRIVE;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_SPEED_AVG;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.COLUMN_USED_AVG;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD.TABLE_NAME;

/**
 * Created by aber on 1/17/2018.
 * 单词加油记录
 */
@Entity(tableName = TABLE_NAME)
public class FuelSingleFillRecord {

    @PrimaryKey(autoGenerate = true)
    @Expose(serialize = false, deserialize = false)
    public long id;

    @SerializedName(COLUMN_EVENT_ID)
    @ColumnInfo(name = COLUMN_EVENT_ID)
    public int eventId; // 加油记账eventId

    @SerializedName(COLUMN_FILL_DATE)
    @ColumnInfo(name = COLUMN_FILL_DATE)
    public Date fillDate;// 加油日期

    @SerializedName(COLUMN_FILL_CHARGE)
    @ColumnInfo(name = COLUMN_FILL_CHARGE)
    public double fillCharge; // 加油费用

    @SerializedName(COLUMN_FILL_AMOUNT)
    @ColumnInfo(name = COLUMN_FILL_AMOUNT)
    public double fillAmount; // 记账后加油数量

    @SerializedName(COLUMN_ECU_FILL_AMOUNT)
    @ColumnInfo(name = COLUMN_ECU_FILL_AMOUNT)
    public double ecuFillAmount; // ecu加油数量

    @SerializedName(COLUMN_GAS_NAME)
    @ColumnInfo(name = COLUMN_GAS_NAME)
    public String gasName; // 加油站名称

    @SerializedName(COLUMN_GAS_LOCATION)
    @ColumnInfo(name = COLUMN_GAS_LOCATION)
    public String gasLocation; // 加油站地址

    @SerializedName(COLUMN_FILL_USED)
    @ColumnInfo(name = COLUMN_FILL_USED)
    public double fillUsed; // 用油量

    @SerializedName(COLUMN_SPEED_AVG)
    @ColumnInfo(name = COLUMN_SPEED_AVG)
    public double speedAvg;//平均速度

    @SerializedName(COLUMN_USED_AVG)
    @ColumnInfo(name = COLUMN_USED_AVG)
    public double usedAvg; //平均油耗

    @SerializedName(COLUMN_MILLAGE_DRIVE)
    @ColumnInfo(name = COLUMN_MILLAGE_DRIVE)
    public double millageDrive; // 行驶里程

    @SerializedName(COLUMN_ECONOMIC_RANK)
    @ColumnInfo(name = COLUMN_ECONOMIC_RANK)
    public double economicRank; // 经济性排行

    @SerializedName(COLUMN_EVALUATE_LEVEL)
    @ColumnInfo(name = COLUMN_EVALUATE_LEVEL)
    public double evaluateLevel; // 评价等级

    @Override
    public String toString() {
        return "FuelSingleFillRecord{" +
                "id=" + id +
                ", eventId=" + eventId +
                ", fillDate=" + fillDate +
                ", fillCharge=" + fillCharge +
                ", fillAmount=" + fillAmount +
                ", ecuFillAmount=" + ecuFillAmount +
                ", gasName='" + gasName + '\'' +
                ", gasLocation='" + gasLocation + '\'' +
                ", fillUsed=" + fillUsed +
                ", speedAvg=" + speedAvg +
                ", usedAvg=" + usedAvg +
                ", millageDrive=" + millageDrive +
                ", economicRank=" + economicRank +
                ", evaluateLevel=" + evaluateLevel +
                '}';
    }
}
