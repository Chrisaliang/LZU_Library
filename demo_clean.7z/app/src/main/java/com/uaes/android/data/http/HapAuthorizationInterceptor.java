package com.uaes.android.data.http;

import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.uaes.common.Intents;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import timber.log.Timber;

/**
 * Created by hand on 2017/11/7.
 * Hello
 */
@SuppressWarnings("WeakerAccess")
@Singleton
public class HapAuthorizationInterceptor implements Interceptor {

    private static final String TAG = HapAuthorizationInterceptor.class.getSimpleName();
    private final SharedPreferences sp;
    private String mToken;

    @Inject
    public HapAuthorizationInterceptor(SharedPreferences sharedPreferences) {
        sp = sharedPreferences;
    }

    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        if (mToken == null)
            mToken = sp.getString(Intents.KEY_TOKEN, null);
        Request request;
        if (!TextUtils.isEmpty(mToken)) {
            Request.Builder builder = chain.request().newBuilder()
                    .header("Authorization", "Bearer " + mToken);
            request = builder.build();
        } else
            request = chain.request();
        Timber.tag(TAG).d("intercept: Headers: %s", request.headers());
        return chain.proceed(request);
    }

    public void inValid() {
        sp.edit().remove(Intents.KEY_TOKEN)
                .apply();
        mToken = null;
    }
}
