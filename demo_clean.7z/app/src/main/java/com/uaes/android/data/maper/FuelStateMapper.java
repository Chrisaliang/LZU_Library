package com.uaes.android.data.maper;

import android.content.res.Resources;
import android.text.TextUtils;

import com.uaes.android.R;
import com.uaes.android.data.json.FuelStatus;
import com.uaes.android.domain.pojo.DomainFuelState;

/**
 * Created by aber on 11/27/2017.
 * Fuel State Mapper
 */

public class FuelStateMapper {

    private final Resources resources;

    public FuelStateMapper(Resources resources) {
        this.resources = resources;
    }

    public DomainFuelState map(FuelStatus status) {
        DomainFuelState model = new DomainFuelState();
        model.rank = (int) (status.economicRank * 100);
//                = resources.getString(R.string.fuel_manager_fuel_status_economic_rank, status.economicRank);
//        model.fuelRest
//                = resources.getString(R.string.fuel_manager_fuel_status_remain_fuel, status.fuelRest);
        model.fuelRestValue = (int) status.fuelRest;
        model.fuelNum = TextUtils.isEmpty(status.fuelGrade) ? "92#" :
                resources.getString(R.string.fuel_manager_fuel_status_fuel_num, status.fuelGrade);
        model.fuelMiles
                = resources.getString(R.string.fuel_manager_fuel_status_remain_mile, status.mileageRest);
        model.costOfHundredMiles
                = resources.getString(R.string.fuel_manager_fuel_status_hundred_mile_fuel, status.fuelUsedKm);
        return model;
    }
}
