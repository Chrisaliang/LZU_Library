package com.uaes.android.ui.message.listener;

import android.view.View;

import com.uaes.android.viewobservable.MessageStatesItemObservable;

/**
 * Author : 张 涛
 * Time : 2018/1/17.
 * Des : This is
 */

public interface ImageChooseClickListener {
    void onClick(View view);

    void onCheckedChanged(View view, boolean isClick);

    void jumpToMessageType(MessageStatesItemObservable message);
}
