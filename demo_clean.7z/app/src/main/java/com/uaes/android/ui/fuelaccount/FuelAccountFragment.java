package com.uaes.android.ui.fuelaccount;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.uaes.android.R;
import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.databinding.FragmentFuelAccountFuelAccountBinding;
import com.uaes.android.domain.AuthorizationSingleObserver;
import com.uaes.android.domain.FuelAccountRepository;
import com.uaes.android.domain.pojo.DomainMessage;
import com.uaes.android.ui.TopLevelFragment;
import com.uaes.android.viewmodel.DomainFuelAccountFillRecord;
import com.uaes.android.widget.FuelAccountTabView;
import com.uaes.android.widget.RatingBar;

import java.util.Locale;

import javax.inject.Inject;

import io.reactivex.disposables.Disposable;

/**
 * Created by Administrator on 2017/11/8 0008.
 * 记账界面
 */

public class FuelAccountFragment extends TopLevelFragment
        implements FuelAccountListener {

    private static final int[] fuelNumListPicIds = {
            R.drawable.fuel_account_fuel_brand_list_1,
            R.drawable.fuel_account_fuel_brand_list_2,
            R.drawable.fuel_account_fuel_brand_list_3
    };
    private static final String[] fuelNumGrands = {"92#", "95#", "98#"};
    @Inject
    FuelAccountRepository repository;

    @Inject
    Gson gson;

    FragmentFuelAccountFuelAccountBinding binding;

    private FuelNumAdapter fuelNumAdapter;
    //    private InputMethodManager imm;
    private Disposable disposable;
    private DomainFuelAccountFillRecord mRecord;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            Bundle arguments = getArguments();

            DomainMessage domainMessage = arguments.getParcelable("account");
            if (domainMessage != null)
                mRecord = gson.fromJson(domainMessage.contentJson, DomainFuelAccountFillRecord.class);
        } else {
            mRecord = savedInstanceState.getParcelable("record");
        }
        if (mRecord == null) {
            back();
            Toast.makeText(getActivity(), getString(R.string.fuel_account_invalided_record), Toast.LENGTH_SHORT).show();
            return;
        } else
            mRecord.updateTotal();
        fuelNumAdapter = new FuelNumAdapter();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("record", mRecord);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_fuel_account_fuel_account, container, false);
        binding.setListener(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.fuelBrand.setAdapter(fuelNumAdapter);
        binding.oteFuelCost.setAutoCompleteTextArray(
                getResources().getStringArray(R.array.fuel_account_fuel_cast_perform_list));
        binding.ratingBarFuelFillingAppraise.setCount((int) mRecord.mAppraise);
        binding.fuelFillingDate.setValue(mRecord.mFillDate);
        binding.fuelFillingStation.setValue(mRecord.mStationName);

        updateFuelInfoView();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fuel_brand:
                binding.fuelBrand.setEdit(true);
                binding.oteFuelCost.setEdit(false);
                binding.fuelPrice.setEdit(false);
                break;
            case R.id.ote_fuel_cost:
                binding.oteFuelCost.setEdit(true);
                binding.fuelBrand.setEdit(false);
                binding.fuelPrice.setEdit(false);
                break;
            case R.id.fuel_price:
                binding.fuelPrice.setEdit(true);
                binding.oteFuelCost.setEdit(false);
                binding.fuelBrand.setEdit(false);
                break;
            case R.id.btn_fuel_account_cancel:
                //取消
                back();
                break;
            case R.id.btn_fuel_account_save:
                //提交
                postFuelAccount();
                break;
            default:
                break;
        }

    }

    private void postFuelAccount() {
        if (mRecord.getPrice() == 0) {
            Toast.makeText(getActivity(), "油费没有填写", Toast.LENGTH_SHORT).show();
            return;
        }
        FuelBookkeeping fuelAccount = new FuelBookkeeping();
        fuelAccount.fuelCost = mRecord.getTotalPrice();
        fuelAccount.fuelGrade = mRecord.mFuelNum;
        fuelAccount.eventId = mRecord.mEventId;
        fuelAccount.fillingDate = mRecord.mFillDate;
        fuelAccount.evaluate = (int) mRecord.mAppraise;
        fuelAccount.fuelStation = mRecord.mStationName;
        fuelAccount.fuelPrice = mRecord.getPrice();
        repository.setFuelAccount(fuelAccount)
                .subscribe(new Observer(getActivity()));
    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//        Log.e(TAG, "brand:");
        mRecord.mFuelNum = fuelNumGrands[i];
        binding.fuelBrand.setValue(mRecord.mFuelNum);
        binding.fuelBrand.setEdit(false);
    }

    @Override
    public boolean onEditorAction(FuelAccountTabView view, TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            double cost_num;
            double price_num;
            if (view == binding.oteFuelCost) {
                String cast = binding.oteFuelCost.getText().trim();
                if (!TextUtils.isEmpty(cast)) {
                    try {
                        cost_num = Double.parseDouble(cast);
                        if (cost_num < 1 || cost_num > 1500) {
                            Toast.makeText(getActivity(), R.string.fuel_account_fuel_amount_fuel_valid_cast, Toast.LENGTH_SHORT).show();
                            return true;
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(getActivity(), R.string.fuel_account_fuel_amount_fuel_valid_cast, Toast.LENGTH_SHORT).show();
                        return true;
                    }
                    mRecord.setTotalPrice(cost_num);
                    updateFuelInfoView();
                }
                binding.oteFuelCost.setEdit(false);
            } else if (view == binding.fuelPrice) {
                String price_text = binding.fuelPrice.getText().trim();
                if (!TextUtils.isEmpty(price_text)) {
                    try {
                        price_num = Double.parseDouble(price_text);
                        if (price_num < 1 || price_num > 20) {
                            Toast.makeText(getActivity(), R.string.fuel_account_fuel_amount_fuel_valid_price, Toast.LENGTH_SHORT).show();
                            return true;
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(getActivity(), R.string.fuel_account_fuel_amount_fuel_valid_price, Toast.LENGTH_SHORT).show();
                        return true;
                    }
                    mRecord.setPrice(price_num);
                    updateFuelInfoView();
                }
                binding.fuelPrice.setEdit(false);
            }
            return true;
        }
        return false;
    }

    private void updateFuelInfoView() {
        binding.fuelFillingAmount.setValue(String.format(Locale.CHINA, "%.2f", mRecord.getFillAmount()));
        binding.fuelPrice.setValue(String.valueOf(mRecord.getPrice()));
        binding.oteFuelCost.setValue(String.format(Locale.CHINESE, "%.2f", mRecord.getTotalPrice()));
        binding.fuelBrand.setValue(mRecord.mFuelNum);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (disposable != null && !disposable.isDisposed())
            disposable.dispose();
    }

    @Override
    public void onTouchStarted(RatingBar ratingBar) {

    }

    @Override
    public void onChange(RatingBar ratingBar, int preCount, int curCount) {
        mRecord.mAppraise = curCount;
    }

    @Override
    public void onTouchEnd(RatingBar ratingBar) {

    }

    @Override
    public void back() {
        mNavigator.backCarHelper();
    }

    private class Observer extends AuthorizationSingleObserver<FuelBookkeeping> {

        Observer(Context context) {
            super(context);
        }

        @Override
        public void onSubscribe(Disposable d) {
            disposable = d;
        }

        @Override
        public void onSuccess(FuelBookkeeping fuelBookkeeping) {
//            Log.i(TAG, "记账提交成功");
            Toast.makeText(getActivity(), R.string.fuel_account_fuel_amount_success_save, Toast.LENGTH_SHORT).show();
            back();
        }

        @Override
        public void onError(Throwable e) {
            super.onError(e);
            Toast.makeText(getActivity(), R.string.fuel_account_fuel_amount_fail_save, Toast.LENGTH_SHORT).show();
//            Log.e(TAG, "error");
        }
    }

    private class FuelNumAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return fuelNumListPicIds.length;
        }

        @Override
        public Object getItem(int position) {
            return fuelNumListPicIds[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_fuel_account_fuel_brand_list, parent, false);
            }
            ((ImageView) convertView).
                    setImageDrawable(getResources()
                            .getDrawable(fuelNumListPicIds[position]));
            return convertView;
        }
    }
}
