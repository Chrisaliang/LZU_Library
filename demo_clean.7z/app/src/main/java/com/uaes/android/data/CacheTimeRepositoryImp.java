package com.uaes.android.data;

import com.uaes.android.data.room.CacheDao;
import com.uaes.android.domain.CacheTimeRepository;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by aber on 1/27/2018.
 * get Cache timestamp.
 */

public class CacheTimeRepositoryImp implements CacheTimeRepository {

    private final CacheDao cacheDao;

    public CacheTimeRepositoryImp(CacheDao cacheDao) {
        this.cacheDao = cacheDao;
    }

    @Override
    public Single<Long> queryCacheTimeByTableName(String tableName) {
        return Single.just(tableName)
                .flatMap(name -> cacheDao.queryTimestampOfTable(name)
                        .map(result -> result.timestamp.getTime()))
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }
}
