package com.uaes.android.ui;

import android.view.View;

import dagger.android.support.DaggerAppCompatActivity;

/**
 * Created by hand on 2017/11/8.
 * 基础Activity
 */

public abstract class BaseActivity extends DaggerAppCompatActivity {

    public abstract void refresh(View view);
}
