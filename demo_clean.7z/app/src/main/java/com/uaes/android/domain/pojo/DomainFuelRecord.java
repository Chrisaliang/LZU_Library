package com.uaes.android.domain.pojo;

import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;

/**
 * Created by Chrisaliang on 2017/11/27.
 * data for fuel record chart
 */

@SuppressWarnings("WeakerAccess")
public class DomainFuelRecord {
    private static DomainFuelRecord EMPTY;

    // x轴最大值
    public final float xMax;
    // Y轴最大值
    public final float yMax;
    /**
     * 数据集合
     * there is a bug if use List
     */
    public final ArrayList<ILineDataSet> lineData;

    public DomainFuelRecord(float xMax, float yMax, ArrayList<ILineDataSet> lineData) {
        this.xMax = xMax;
        this.yMax = yMax;
        this.lineData = lineData;
    }

    public static DomainFuelRecord getEmptyRecord() {
        if (EMPTY == null) {
            ArrayList<ILineDataSet> data = new ArrayList<>(0);
            EMPTY = new DomainFuelRecord(0, 0, data);
        }
        return EMPTY;
    }

    @Override
    public String toString() {
        return "DomainFuelRecord{" +
                "xMax=" + xMax +
                ", yMax=" + yMax +
                ", lineData=" + lineData +
                '}';
    }
}
