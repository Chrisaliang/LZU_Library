package com.uaes.android.data.maper;

import android.util.Base64;

import com.uaes.android.data.room.MessagePushEntity;
import com.uaes.android.domain.pojo.DomainMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * Author : 张 涛
 * Time : 2018/1/29.
 * Des : This is
 */

public class MessageMapper {

    private List<MessagePushEntity> toMessagePushEntityList = new ArrayList<>();
    private List<DomainMessage> toDomainMessageList = new ArrayList<>();

    public DomainMessage map(MessagePushEntity from) {
        DomainMessage toDomainMessage = new DomainMessage();
        toDomainMessage.id = from.id;
        toDomainMessage.title = from.title;
        toDomainMessage.body = from.body;
        toDomainMessage.type = from.type;
        toDomainMessage.messageClass = from.messageClass;
        toDomainMessage.systemTime = from.systemTime;
        toDomainMessage.hasRead = from.hasRead;
        toDomainMessage.contentJson = new String(Base64.decode(from.extraJson.getBytes(), Base64.DEFAULT));
        return toDomainMessage;
    }

    public MessagePushEntity map(DomainMessage from) {
        MessagePushEntity toMessagePushEntity = new MessagePushEntity();
        toMessagePushEntity.id = from.id;
        toMessagePushEntity.title = from.title;
        toMessagePushEntity.body = from.body;
        toMessagePushEntity.type = from.type;
        toMessagePushEntity.messageClass = from.messageClass;
        toMessagePushEntity.systemTime = from.systemTime;
        toMessagePushEntity.hasRead = from.hasRead;
        toMessagePushEntity.extraJson = Base64.encodeToString(from.contentJson.getBytes(), Base64.DEFAULT);
        return toMessagePushEntity;
    }

    public List<DomainMessage> mapToDomain(List<MessagePushEntity> from) {
        toDomainMessageList.clear();
        for (int i = 0; i < from.size(); i++) {
            toDomainMessageList.add(map(from.get(i)));
        }
        return toDomainMessageList;
    }

    public List<MessagePushEntity> mapToEntity(List<DomainMessage> from) {
        toMessagePushEntityList.clear();
        for (DomainMessage mDomainMessage : from) {
            toMessagePushEntityList.add(this.map(mDomainMessage));
        }
        return toMessagePushEntityList;
    }

    public MessagePushEntity[] getArrayEntity(DomainMessage... from) {
        MessagePushEntity[] to = new MessagePushEntity[from.length];
        for (int i = 0; i < from.length; i++) {
            to[i] = map(from[i]);
        }
        return to;
    }

    public DomainMessage[] getArrayDomain(MessagePushEntity... from) {
        DomainMessage[] to = new DomainMessage[from.length];
        for (int i = 0; i < from.length; i++) {
            to[i] = map(from[i]);
        }
        return to;
    }
}
