package com.uaes.android.domain.pojo;

/**
 * Created by aber on 12/4/2017.
 * Data object
 */

public class DomainFuelState {
    // 经济性排名 百分数
    public int rank;
//    // 剩余油量
//    public String fuelRest;

    // 剩余油量 0-55 升
    public int fuelRestValue;
    // 汽油牌号
    public String fuelNum;
    // 剩余里程
    public String fuelMiles;
    // 百公里油耗
    public String costOfHundredMiles;
}
