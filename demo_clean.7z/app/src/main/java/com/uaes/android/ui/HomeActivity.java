package com.uaes.android.ui;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.uaes.android.R;
import com.uaes.android.domain.message.CountAllUnreadMessage;
import com.uaes.android.domain.pojo.DomainMessage;
import com.uaes.android.ui.carhelper.CarAssistantFragment;
import com.uaes.android.ui.carhelper.battery.BatteryFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelStatusFragment;
import com.uaes.android.ui.fuelaccount.FuelAccountFragment;
import com.uaes.android.ui.home.HomeFragment;
import com.uaes.android.ui.maintenance.MaintenanceFragment;
import com.uaes.android.ui.maintenance.engineoil.EngineOilFragment;
import com.uaes.android.ui.maintenance.sparkingplug.SparkingPlugFragment;
import com.uaes.android.ui.malfunction.MalfunctionFragment;
import com.uaes.android.ui.message.MessageFragment;
import com.uaes.android.ui.setting.SettingFragment;
import com.uaes.android.widget.HomeMenuTabTextView;
import com.uaes.common.Intents;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.inject.Inject;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * 顶层背景 以及操作，其余操作
 */
public class HomeActivity extends AuthorizationActivity
        implements IPageNavigator, View.OnClickListener {
    public static final String REFRESH_ACTION = "com.uaes.android.REFRESH_ACTION";
    private static final String TAG = HomeActivity.class.getName();
    private static final String EXTRA_SELECTED_ID = TAG + ".SELECTED_ID";
    private final SparseArray<TopLevelFragment> mFragments = new SparseArray<>();
    private final SimpleDateFormat timeUpdateSdf = new SimpleDateFormat("HH:mm", Locale.CHINA);
    @Inject
    CountAllUnreadMessage countAllUnreadMessage;
    private View backImageButton;
    private HomeMenuTabTextView messageTv;

    private int selectedId = View.NO_ID;
    private AlertDialog mLoadingDialog;
    private View viewAccount;
    private Disposable mDisposable;
    private TextView timeTv;
    private SlideFromTopPopup slideFromTopPopup;
    private DomainMessage currentMessage;
    private final BroadcastReceiver messageChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intents.MESSAGE.EXTRA_MESSAGE_SAVE.equals(action) ||
                    Intents.MESSAGE.EXTRA_MESSAGE_UPDATE.equals(action) ||
                    Intents.MESSAGE.EXTRA_MESSAGE_DELETE.equals(action)) {
                queryMessage();
            } else if (Intents.ACTION_MESSAGE.equals(intent.getAction())) {
                currentMessage = intent.getParcelableExtra("message");
                showMessage(currentMessage.title, currentMessage.body);
            } else {
                Timber.tag(TAG).e("error action: %s", action);
            }
        }
    };

    private final BroadcastReceiver messageJupreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intents.ACTION_MESSAGE_JUMP.equals(action)) {
                DomainMessage message = intent.getParcelableExtra(Intents.EXTRA_MESSAGE);
                processMessage(message);
            }
        }
    };

    private View.OnClickListener onClick = v -> {
        try {
            if (currentMessage.type.contains(DomainMessage.MESSAGE_TYPE_0)) {
                showAccount(currentMessage);
            }
            Timber.tag(TAG).d(currentMessage.type);
            slideFromTopPopup.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    };

    @SuppressLint("InflateParams")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        viewAccount = new View(this);
        viewAccount.setId(R.id.home_fuel_account);
        HomeMenuTabTextView homeTv = findViewById(R.id.home_bottom_menu_home);
        HomeMenuTabTextView malfunctionTv = findViewById(R.id.home_bottom_menu_malfunction);
        HomeMenuTabTextView assistantTv = findViewById(R.id.home_bottom_menu_assistant);
        HomeMenuTabTextView maintenanceTv = findViewById(R.id.home_bottom_menu_maintenance);
        timeTv = findViewById(R.id.tv_refresh_time);
        messageTv = findViewById(R.id.home_bottom_menu_message);
        backImageButton = findViewById(R.id.imageButton);

        homeTv.setOnClickListener(this);
        malfunctionTv.setOnClickListener(this);
        assistantTv.setOnClickListener(this);
        maintenanceTv.setOnClickListener(this);
        messageTv.setOnClickListener(this);

        mLoadingDialog = new AlertDialog.Builder(this)
                .setCancelable(false)
                .setView(LayoutInflater.from(this).inflate(R.layout.widget_progress_fail, null))
                .create();
        Window window = mLoadingDialog.getWindow();
        if (window != null)
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        final Intent intent = getIntent();
        if (savedInstanceState == null) {
            if (intent != null) {
                String action = intent.getAction();
                if (Intents.ACTION_MESSAGE.equals(action)) {
                    Timber.tag(TAG).d(action);
                } else
                    updateSelectedMenu(assistantTv, null);
            }
        }
        queryMessage();

        slideFromTopPopup = new SlideFromTopPopup(this);
        slideFromTopPopup.setOnClickListener(onClick);

    }

    private void processMessage(DomainMessage message) {
        switch (message.type) {
            case DomainMessage.MESSAGE_TYPE_0:
                showAccount(message);
                break;
            case DomainMessage.MESSAGE_TYPE_1:
                showFuelStatus();
                break;
            case DomainMessage.MESSAGE_TYPE_7:
            case DomainMessage.MESSAGE_TYPE_2:
                showOil();
                break;
            case DomainMessage.MESSAGE_TYPE_3:
            case DomainMessage.MESSAGE_TYPE_4:
            case DomainMessage.MESSAGE_TYPE_5:
            case DomainMessage.MESSAGE_TYPE_6:
                showSpark();
                break;
            case DomainMessage.MESSAGE_TYPE_8:
                showBattery();
                break;
        }
    }

    private void showFuelStatus() {
        Bundle args = new Bundle();
        args.putString("subPage", FuelStatusFragment.class.getSimpleName());
        updateSelectedMenu(findViewById(R.id.home_bottom_menu_assistant), args);
    }

    private void showBattery() {
        Bundle args = new Bundle();
        args.putString("subPage", BatteryFragment.class.getSimpleName());
        updateSelectedMenu(findViewById(R.id.home_bottom_menu_assistant), args);
    }

    private void showSpark() {
        Bundle args = new Bundle();
        args.putString("subPage", SparkingPlugFragment.class.getSimpleName());
        updateSelectedMenu(findViewById(R.id.home_bottom_menu_maintenance), args);
    }

    private void showOil() {
        Bundle args = new Bundle();
        args.putString("subPage", EngineOilFragment.class.getSimpleName());
        updateSelectedMenu(findViewById(R.id.home_bottom_menu_maintenance), args);
    }

    private void showMessage(String title, String content) {
        Timber.tag(TAG).d("title : %s", title);
        slideFromTopPopup.updateText(title, content);
        slideFromTopPopup.showPopupDismissWithDelay(3000);
    }


    @Override
    public void refresh(View view) {
        Intent intent = new Intent(REFRESH_ACTION);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_SAVE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_UPDATE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_DELETE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_QUERY);
        intentFilter.addAction(Intents.ACTION_MESSAGE);
        IntentFilter intentFilterJump = new IntentFilter();
        intentFilterJump.addAction(Intents.ACTION_MESSAGE_JUMP);
        LocalBroadcastManager.getInstance(this).registerReceiver(messageChangeReceiver, intentFilter);
        LocalBroadcastManager.getInstance(this).registerReceiver(messageJupreceiver, intentFilterJump);
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(messageChangeReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(messageJupreceiver);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (selectedId != R.id.home_fuel_account)
            outState.putInt(EXTRA_SELECTED_ID, selectedId);
    }

    private void showAccount(DomainMessage message) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("account", message);
        updateSelectedMenu(viewAccount, bundle);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        selectedId = savedInstanceState.getInt(EXTRA_SELECTED_ID, R.id.home_bottom_menu_home);
        updateSelectedMenu(findViewById(selectedId), null);
    }

    public void popBack(View view) {
        back();
    }

    public void onHome(View view) {
        finish();
    }

    @Override
    public void backCarHelper() {
        updateSelectedMenu(findViewById(R.id.home_bottom_menu_assistant), null);
    }

    @Override
    public void back() {
        TopLevelFragment fragment = mFragments.get(selectedId);
        if (fragment != null && fragment.isVisible())
            fragment.back();
    }

    @Override
    public void showLoading() {
        if (!mLoadingDialog.isShowing())
            mLoadingDialog.show();
    }

    @Override
    public void dismissLoading() {
        mLoadingDialog.dismiss();
    }

    @Override
    public void showBackButton() {
        backImageButton.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideBackButton() {
        backImageButton.setVisibility(View.INVISIBLE);
    }

    @Override
    public void updateTime(long time) {
        String dateStr = timeUpdateSdf.format(new Date(time));
        timeTv.setText(dateStr);
    }

    @Override
    public void onClick(View v) {
        updateSelectedMenu(v, null);
    }

    public void toggle(View view) {
        view.setSelected(!view.isSelected());
    }

    // show Selected Menu
    private void updateSelectedMenu(@NonNull View clickView, Bundle args) {
        View view = getWindow().getDecorView().getRootView();
        View selectedView = null;
        if (view != null)
            selectedView = view.findViewById(selectedId);
        if (selectedView != null && selectedView != clickView)
            selectedView.setSelected(false);
        Fragment fragment = getFragment(clickView.getId());
        if (fragment != null) {
            fragment.setArguments(args);
        }
        realTransactFragment(fragment, getFragment(selectedId));
        clickView.setSelected(true);
        selectedId = clickView.getId();
    }

    private void realTransactFragment(Fragment shouldShow, Fragment shouldHidden) {
        if (shouldShow == null) return;
        if (shouldHidden == shouldShow) return;
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//        transaction.setCustomAnimations(android.R.anim.slide_in_left,
//                android.R.anim.slide_out_right,
//                R.anim.slide_in_right,
//                R.anim.slide_out_left);

        if (shouldHidden != null)
            transaction.remove(shouldHidden);
        transaction.add(R.id.replace_layout, shouldShow, null);
        Log.d(TAG, "realTransactFragment: " + shouldShow  + " , " + shouldHidden);
//        transaction.replace(R.id.replace_layout, shouldShow, null);
        transaction.commit();
    }

    private Fragment getFragment(@IdRes int id) {
        Fragment fragment = mFragments.get(id);
        if (fragment == null) {
            fragment = createFragmentByViewId(id);
        }
        return fragment;
    }

    private Fragment createFragmentByViewId(@IdRes int id) {
        TopLevelFragment fragment;
        switch (id) {
            case R.id.home_bottom_menu_home:
                fragment = new HomeFragment();
                break;
            case R.id.home_bottom_menu_assistant:
                fragment = new CarAssistantFragment();
                break;
            case R.id.home_bottom_menu_malfunction:
                fragment = new MalfunctionFragment();
                break;
            case R.id.home_bottom_menu_maintenance:
                fragment = new MaintenanceFragment();
                break;
            case R.id.home_bottom_menu_message:
                fragment = new MessageFragment();
                break;
            case R.id.home_fuel_account:
                fragment = new FuelAccountFragment();
                break;
            case R.id.home_top_setting:
                fragment = new SettingFragment();
                break;
            default:
                fragment = null;
        }
        mFragments.put(id, fragment);
        return fragment;
    }

    public void onSetting(View view) {
        updateSelectedMenu(view, null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDisposable != null && !mDisposable.isDisposed())
            mDisposable.dispose();
    }

    private void queryMessage() {
        countAllUnreadMessage.execute().subscribe(new SingleObserver<Map<String, Integer>>() {
            @Override
            public void onSubscribe(Disposable d) {
                mDisposable = d;
            }

            @Override
            public void onSuccess(Map<String, Integer> stringIntegerMap) {
                int count = 0;
                for (Map.Entry<String, Integer> item : stringIntegerMap.entrySet()) {
                    count += item.getValue();
                }
                messageTv.setMessageNum(count);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }
        });
    }

}
