package com.uaes.android.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.MessageRepository;
import com.uaes.android.domain.pojo.DomainMessage;
import com.uaes.android.widget.RetryView;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;

/**
 * Author : 张 涛
 * Time : 2018/1/15.
 * Des : This is 消息界面的Model
 */

public class MessageStateViewModel extends ViewModel implements SingleObserver<List<DomainMessage>> {

    private final MutableLiveData<Integer> noRead = new MutableLiveData<>();

    private final MutableLiveData<Boolean> deleteSuces = new MutableLiveData<>();

    private final MutableLiveData<List<DomainMessage>> messageList = new MutableLiveData<>();

    private final MutableLiveData<Integer> status = new MutableLiveData<>();

    private final MessageRepository mMessageRepository;

    private Disposable disposable;

    public MessageStateViewModel(MessageRepository mMessageRepository) {
        this.mMessageRepository = mMessageRepository;
    }

    public LiveData<Integer> getStatus() {
        return noRead;
    }

    public LiveData<List<DomainMessage>> getMessageList() {
        return messageList;
    }

    public LiveData<Boolean> getDelete() {
        return deleteSuces;
    }

    public LiveData<Integer> getStatue() {
        return status;
    }

    public Single<Boolean> deleteMessage(DomainMessage... messages) {
        return mMessageRepository.deleteMessage(messages);
    }

    public void queryMessage(String type) {
        mMessageRepository.queryMessage(type).subscribe(this);
    }

    public Single<Boolean> updateMessage(DomainMessage... messages) {
        return mMessageRepository.updateMessage(messages);
    }

    @Override
    public void onSubscribe(@NonNull Disposable d) {
        disposable = d;
    }

    @Override
    public void onSuccess(@NonNull List<DomainMessage> messagePushEntities) {
        messageList.setValue(messagePushEntities);
        status.setValue(RetryView.RETRY_GONE);
    }

    @Override
    public void onError(@NonNull Throwable e) {
        status.postValue(RetryView.RETRY_RETRY);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }
}
