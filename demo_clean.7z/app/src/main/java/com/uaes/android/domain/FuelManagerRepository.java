package com.uaes.android.domain;

import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.domain.pojo.DomainFuelHistory;
import com.uaes.android.domain.pojo.DomainFuelRecord;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;
import com.uaes.android.domain.pojo.DomainFuelState;

import io.reactivex.Single;

/**
 * Created by Chrisaliang on 2017/11/6.
 * data repository for oil manager
 * 燃油管家 数据层 数据接口
 */
public interface FuelManagerRepository {

    /**
     * */
    Single<DomainFuelRecord> FuelRecord();

    /**
     * 查询逻辑 是
     * @param page page index
     * @param size element number of one page
     */
    Single<DomainFuelSingleRecord> singleFuelRecord(int page, int size);

    /**
     * 获取加油状态
     */
    Single<DomainFuelState> getFuelStatus();


    /**
     * 通过年份查询用油历史
     *
     * @param time 年份
     * @return OilHistory
     */
    Single<DomainFuelHistory> getFuelHistoryByYear(Integer time);

    /**
     * 通过里程用油历史
     *
     * @param mile 里程
     * @return OilHistory
     */
    Single<DomainFuelHistory> getFuelHistoryByMile(Integer mile);

    /**
     * 更新加油评价
     *
     * @param fuelBookkeeping account对象
     * @return 返回结果
     */
    Single<FuelBookkeeping> setFuelAccount(FuelBookkeeping fuelBookkeeping);
}
