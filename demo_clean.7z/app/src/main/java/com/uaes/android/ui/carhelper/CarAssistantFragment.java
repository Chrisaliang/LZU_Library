package com.uaes.android.ui.carhelper;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.ui.TopLevelFragment;
import com.uaes.android.ui.carhelper.battery.BatteryFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelManagerFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelStatusFragment;
import com.uaes.android.ui.gasstation.MapMarkerActivity;

import java.util.List;

/**
 * Created by hand on 2017/11/1.
 * 用车助手首页
 */

public class CarAssistantFragment extends TopLevelFragment implements View.OnClickListener {

    private static final String FUEL_MANAGER_TAG = "FUEL_MANAGER_FRAGMENT";
    private static final String BATTERY_ASSISTANT_TAG = "BATTERY_ASSISTANT_FRAGMENT";

    private View fuelManagerView;
    private View gasStationView;
    private View batteryView;
    private View home;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_car_helper, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fuelManagerView = view.findViewById(R.id.car_helper_fuel_manager);
        gasStationView = view.findViewById(R.id.car_helper_gas_station);
        batteryView = view.findViewById(R.id.car_helper_battery_assistant);
        fuelManagerView.setOnClickListener(this);
        gasStationView.setOnClickListener(this);
        batteryView.setOnClickListener(this);
        home = view.findViewById(R.id.car_helper_home);

        Bundle args = getArguments();
        if (args != null) {
            String subPage = args.getString("subPage");
            if (BatteryFragment.class.getSimpleName().equals(subPage)) {
                onClick(batteryView);
            } else if (FuelStatusFragment.class.getSimpleName().equals(subPage)) {
                onClick(fuelManagerView);
            }
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        List<Fragment> fragments = getChildFragmentManager().getFragments();
        for (Fragment fragment : fragments) {
            fragment.onHiddenChanged(hidden);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == fuelManagerView) {
            home.setVisibility(View.INVISIBLE);
            transactionFragment(FUEL_MANAGER_TAG);
        } else if (v == gasStationView) {
            Intent intent = new Intent(getActivity(), MapMarkerActivity.class);
            intent.putExtra(MapMarkerActivity.EXTRA_TYPE, MapMarkerActivity.STATION_TAG);
            startActivity(intent);
        } else if (v == batteryView) {
            home.setVisibility(View.INVISIBLE);

            transactionFragment(BATTERY_ASSISTANT_TAG);
        }
    }

    private void transactionFragment(String TAG) {
        Fragment fragment = getFragment(TAG);
        getChildFragmentManager().beginTransaction()
                .replace(R.id.car_helper_parent, fragment, TAG)
                .addToBackStack(TAG)
                .commit();
    }

    private Fragment getFragment(String TAG) {
        Fragment fragment = getChildFragmentManager().findFragmentByTag(TAG);
        if (fragment == null)
            fragment = createFragmentByTag(TAG);
        return fragment;
    }

    private Fragment createFragmentByTag(String TAG) {
        Fragment fragment;
        switch (TAG) {
            case FUEL_MANAGER_TAG:
                fragment = new FuelManagerFragment();
                break;
            case BATTERY_ASSISTANT_TAG:
                fragment = new BatteryFragment();
                break;
            default:
                fragment = null;
                break;
        }
        return fragment;
    }

    @Override
    public void back() {
        home.setVisibility(View.VISIBLE);
        getChildFragmentManager().popBackStack();
    }
}
