package com.uaes.android.widget;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.support.annotation.IntDef;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.uaes.android.R;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by aber on 12/1/2017.
 * Common View
 */
@BindingMethods({
        @BindingMethod(type = RetryView.class, attribute = "retryview_update", method = "update"),
        @BindingMethod(type = RetryView.class, attribute = "retryview_OnRetryOnClickListener", method = "setRetryOnClickListener"),
})
public class RetryView extends LinearLayoutCompat {

    public static final int RETRY_GONE = 0;
    public static final int RETRY_LOADING = 1;
    public static final int RETRY_RETRY = 2;
    public static final int RETRY_EMPTY = 3;
    private final static String RETRY_EMPTY_STR = "暂无记录";
    private final static String RETRY_NET_ERR_STR = "网络错误";
    private ImageButton retry;
    private TextView hint;
    private ProgressBar mProgressBar;
    private ImageView imageView;
    private @State
    int status;
    //    private String hintStr;
    private OnRetryClickListener listener;
    private final View.OnClickListener internalClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            update(false);
            if (listener != null)
                listener.onClick(RetryView.this);
        }
    };

    public RetryView(Context context) {
        super(context);
        init();
    }

    public RetryView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RetryView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @BindingAdapter(value = "retryview_OnRetryOnClickListener")
    public static void setRetryOnClickListener(RetryView view, OnRetryClickListener listener) {
        view.setRetryOnClickListener(listener);
    }

    @BindingAdapter(value = "retryview_update")
    public static void update(RetryView view, @State int status) {
        if (status == RETRY_EMPTY)
            view.update(status, RETRY_EMPTY_STR);
        view.update(status, RETRY_NET_ERR_STR);
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.common_load_failed, this, true);
        retry = findViewById(R.id.common_retry_button);
        hint = findViewById(R.id.common_retry_hint);
        mProgressBar = findViewById(R.id.common_retry_progress);
        mProgressBar.setVisibility(GONE);
        imageView = findViewById(R.id.common_image);
        retry.setOnClickListener(internalClick);
        setOrientation(VERTICAL);
        update(RETRY_RETRY, RETRY_NET_ERR_STR);
    }

    public void setRetryOnClickListener(OnRetryClickListener listener) {
        this.listener = listener;
    }

    public void update(@State int state, String hint) {
        if (this.status == state) return;
        this.status = state;
        if (state == RETRY_GONE) {
            setVisibility(GONE);
        } else if (state == RETRY_LOADING) {
            setVisibility(VISIBLE);
            showLoading();
        } else if (state == RETRY_RETRY) {
            setVisibility(VISIBLE);
            showRetry();
//            this.hint.setText(hint);
        } else if (state == RETRY_EMPTY) {
            setVisibility(VISIBLE);
            this.hint.setText(hint);
            this.hint.setVisibility(VISIBLE);
            this.imageView.setVisibility(GONE);
            this.mProgressBar.setVisibility(GONE);
            this.retry.setVisibility(GONE);
        }
    }

    public void showRetry() {
        update(true);
    }

    public void showLoading() {
        update(false);
    }

    private void update(boolean isRetry) {
        int retryVisibility = isRetry ? View.VISIBLE : View.GONE;
        int loadingVisibility = isRetry ? View.GONE : View.VISIBLE;
        mProgressBar.setVisibility(loadingVisibility);
        retry.setVisibility(retryVisibility);
        imageView.setVisibility(retryVisibility);
        hint.setVisibility(retryVisibility);
    }

    @IntDef({RETRY_GONE, RETRY_LOADING, RETRY_RETRY, RETRY_EMPTY})
    @Retention(RetentionPolicy.SOURCE)
    @interface State {
    }

    public interface OnRetryClickListener {
        void onClick(RetryView retryView);
    }
}
