package com.uaes.android.di;

import android.arch.persistence.room.Room;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.uaes.android.UaesIotApplication;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.LowFuelWarningDao;
import com.uaes.android.data.room.UaesDatabase;
import com.uaes.common.AuthProvider;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by aber on 1/24/2018.
 * 持久化模块
 */
@Module
public abstract class PersistentModule {

    private static final String DB_NAME = "cache_uaes.db";

    @Provides
    @Singleton
    public static SharedPreferences sharedPreferences(UaesIotApplication application) {
        return PreferenceManager.getDefaultSharedPreferences(application);
    }

    @Provides
    @Singleton
    public static UaesDatabase getDatabase(UaesIotApplication application) {
        return Room.databaseBuilder(application, UaesDatabase.class, DB_NAME)
                .build();
    }

    @Provides
    @Singleton
    public static CacheDao getCacheDao(UaesDatabase database) {
        return database.getCacheDao();
    }

    @Provides
    @Singleton
    public static LowFuelWarningDao getLowFuelWarningDao(UaesDatabase db) {
        return db.getLowFuelWarningDao();
    }

    @Provides
    @Singleton
    public static AuthProvider getAuthProvider(UaesIotApplication application) {
        return AuthProvider.getInstance(application.getApplicationContext());
    }
}
