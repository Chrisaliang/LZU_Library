package com.uaes.android.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.widget.AppCompatImageView;
import android.text.TextPaint;
import android.util.AttributeSet;

/**
 * Author : 张 涛
 * Time : 2018/1/16.
 * Des : This is 带有气泡的ImageView
 */

public class BubbleImageView extends AppCompatImageView {

    private Paint mPaint;//画笔
    private TextPaint textPaint;
    private int num = 0;//显示的数字
    private float textSize = 18;//字体的大小
    private float radius;//原点的半径

    private boolean showNum = true;

    private String numStr = String.valueOf(num);

    public BubbleImageView(Context context) {
        this(context, null);
    }

    public BubbleImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BubbleImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);//抗锯齿
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setColor(Color.RED);
        textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTextSize(textSize);
        textPaint.setColor(Color.WHITE);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w == oldw && h == oldh) return;
        radius = w / 5;
        textPaint.setTextSize(radius * 2);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (num > 0) {//如果数据大于0的时候才绘制原点
            //画圆形
            int width = getWidth();
            canvas.drawCircle(width - radius, radius, radius, mPaint);
            //画字
            Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
            if (showNum)
                canvas.drawText(numStr, (num < 10 ? width - radius - textSize / 4 : width - radius - textSize / 2), radius + Math.abs(fontMetrics.top + fontMetrics.bottom) / 2, textPaint);
        }
    }

    public void setNum(int num) {
        if (this.num == num) return;
        if (num < 0) this.num = 0;
        if (num > 99) this.num = 99;
        else {
            this.num = num;
        }
        numStr = String.valueOf(this.num);
        invalidate();
    }

    public void enableNum(boolean isShowNum) {
        showNum = isShowNum;
        invalidate();
    }

    public float getTextSize() {
        return textPaint.getTextSize();
    }

    public void setTextSize(float size) {
        textPaint.setTextSize(textSize);
    }
}
