package com.uaes.android.ui;

import android.content.Context;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.OvershootInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.TextView;

import com.uaes.android.R;

import razerdp.basepopup.BasePopupWindow;

/**
 * Created by aber on 2018/1/24.
 * <p>
 * 从顶部下滑的Poup
 */

@SuppressWarnings("WeakerAccess")
public class SlideFromTopPopup extends BasePopupWindow {

    private final Handler handler;
    private final Runnable dismissRunnable = this::dismissWithOutAnima;
    private TextView title;
    private TextView content;

    private View.OnClickListener listener;

    public SlideFromTopPopup(Context context) {
        super(context, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        setBackPressEnable(false);
        setDismissWhenTouchOutside(true);
        getPopupWindow().setOutsideTouchable(true);
        handler = new Handler();
        setPopupWindowFullScreen(false);
    }

    @Override
    protected Animation initShowAnimation() {
        float offset = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 350f, getContext().getResources().getDisplayMetrics());
        TranslateAnimation translateAnimation = new TranslateAnimation(0f, 0f, -offset, 0);
        translateAnimation.setDuration(450);
        translateAnimation.setInterpolator(new OvershootInterpolator(1));
        return translateAnimation;
    }

    @Override
    protected Animation initExitAnimation() {
        float offset = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 350f, getContext().getResources().getDisplayMetrics());
        TranslateAnimation translateAnimation = new TranslateAnimation(0f, 0f, 0, offset);
        translateAnimation.setDuration(450);
        translateAnimation.setInterpolator(new OvershootInterpolator(-4));
        return translateAnimation;
    }

    @Override
    public View getClickToDismissView() {
        return null;
    }

    @Override
    public View onCreatePopupView() {
        return createPopupById(R.layout.simple_text);
    }

    @Override
    public View initAnimaView() {
        title = getPopupWindowView().findViewById(R.id.title);
        content = getPopupWindowView().findViewById(R.id.content);
        if (listener != null)
            getPopupWindowView().findViewById(R.id.holder).setOnClickListener(listener);
        return getPopupWindowView().findViewById(R.id.holder);
    }

    @SuppressWarnings("SameParameterValue")
    public void showPopupDismissWithDelay(long delay) {
        handler.removeCallbacks(dismissRunnable);
        handler.postDelayed(dismissRunnable, delay);
        showPopupWindow();
    }

    public void updateText(String title, String content) {
        if (title != null)
            this.title.setText(title);
        if (content != null)
            this.content.setText(content);
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }
}
