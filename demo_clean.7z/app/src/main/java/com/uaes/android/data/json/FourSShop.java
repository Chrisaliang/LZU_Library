package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by aber on 2/8/2018.
 * four s shop json
 * todo maybe use it to replace data layer four s shop obj
 */

public class FourSShop {

    // 4S 店名字
    @SerializedName("name")
    public String name;

    // 地址
    @SerializedName("serviceAddress")
    public String serviceAddress;

    // 服务电话
    @SerializedName("serviceTel")
    public String serviceTel;

    // 距离
    @SerializedName("distance")
    public int distance;

    // 耗时
    @SerializedName("duration")
    public int duration;

    // 经度
    @SerializedName("longitude")
    public double longitude;

    //维度
    @SerializedName("latitude")
    public double latitude;
}
