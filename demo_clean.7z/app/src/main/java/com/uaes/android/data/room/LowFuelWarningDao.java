package com.uaes.android.data.room;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

/**
 * Created by Chrisaliang on 2017/12/28.
 * low fuel warning dao
 */

@Dao
public abstract class LowFuelWarningDao {

    @Query("select * from lowFuel where id = 0")
    public abstract LowFuelWarningSettingEntity queryLowFuelWarning();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract long insertLowFuelWarning(LowFuelWarningSettingEntity entity);
}
