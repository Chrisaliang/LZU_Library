package com.uaes.android.ui.carhelper.fuelmanager;

/**
 * Created by Chrisaliang on 2017/12/6.
 * data obj to fuel history list view data
 */

public class FuelHistoryListViewData {
    public String text;//显示值
    public Integer value;//实际值
    public Type mType;
    public int position;
    public boolean isSelected = false;

    public FuelHistoryListViewData(int position, String text, Integer value, Type type) {
        this.text = text;
        this.value = value;
        this.mType = type;
        this.position = position;
    }

    @Override
    public String toString() {
        return "FuelHistoryListViewData{" +
                "text='" + text + '\'' +
                ", value=" + value +
                ", mType=" + mType +
                ", position=" + position +
                ", isSelected=" + isSelected +
                '}';
    }

    public enum Type {
        YEAR,
        MILE
    }
}
