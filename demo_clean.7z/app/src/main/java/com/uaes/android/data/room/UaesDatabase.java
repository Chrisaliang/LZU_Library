package com.uaes.android.data.room;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;

import com.uaes.android.data.json.CacheTimestamp;
import com.uaes.android.data.json.CarHealth;
import com.uaes.android.data.json.FuelFillHistory;
import com.uaes.android.data.json.FuelFillRecordPoint;
import com.uaes.android.data.json.FuelSingleFillRecord;
import com.uaes.android.data.json.FuelStatus;
import com.uaes.android.data.json.SingleFuelRecord;

/**
 * Created by Chrisaliang on 2017/12/28.
 * all database
 */
@Database(
        entities = {
                LowFuelWarningSettingEntity.class,
                MessagePushEntity.class,
                FuelFillHistory.class,
                FuelFillRecordPoint.class,
                FuelSingleFillRecord.class,
                FuelStatus.class,
                SingleFuelRecord.class,
                CacheTimestamp.class,
                CarHealth.class
        }, version = 1)
@TypeConverters({RoomTypeConverters.class})
public abstract class UaesDatabase extends RoomDatabase {
    public abstract LowFuelWarningDao getLowFuelWarningDao();

    public abstract CacheDao getCacheDao();

}
