package com.uaes.android.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.pojo.DomainFuelHistory;
import com.uaes.android.ui.carhelper.fuelmanager.FuelHistoryListViewData;
import com.uaes.android.widget.RetryView;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;

/**
 * Created by Chrisaliang on 2017/12/8
 * show text and value in fuel history
 */

public class FuelHistoryViewModel extends ViewModel implements SingleObserver<DomainFuelHistory> {

//    private static final int START_YEAR = 2017;

    private MutableLiveData<DomainFuelHistory> fuelHistory = new MutableLiveData<>();

    private MutableLiveData<Integer> status = new MutableLiveData<>();

    private FuelManagerRepository repository;

    private Disposable disposable;

    private List<FuelHistoryListViewData> yearDataSets = new ArrayList<>();
    private List<FuelHistoryListViewData> mileDataSets = new ArrayList<>();

    private MutableLiveData<FuelHistoryListViewData> selectedItem = new MutableLiveData<>();

    FuelHistoryViewModel(FuelManagerRepository repository) {
        this.repository = repository;
        initMile(mileDataSets);
        initYear(yearDataSets);
        selectedItem.setValue(yearDataSets.get(0));
    }

    private void initYear(List<FuelHistoryListViewData> sets) {

        sets.add(new FuelHistoryListViewData(0, "昨日",
                0, FuelHistoryListViewData.Type.YEAR));
        sets.add(new FuelHistoryListViewData(1, "本周",
                1, FuelHistoryListViewData.Type.YEAR));
        sets.add(new FuelHistoryListViewData(2, "本月",
                2, FuelHistoryListViewData.Type.YEAR));
        sets.add(new FuelHistoryListViewData(3, "今年",
                3, FuelHistoryListViewData.Type.YEAR));
        sets.add(new FuelHistoryListViewData(4, "全部",
                4, FuelHistoryListViewData.Type.YEAR));
    }

    public void search(FuelHistoryListViewData item) {
        selectedItem.setValue(item);
        if (item.mType == FuelHistoryListViewData.Type.MILE) {
            repository.getFuelHistoryByMile(item.value).subscribe(this);
        } else if (item.mType == FuelHistoryListViewData.Type.YEAR) {
            repository.getFuelHistoryByYear(item.value).subscribe(this);
        }
    }

    public void queryAgain() {
        search(selectedItem.getValue());
    }

    public MutableLiveData<DomainFuelHistory> getFuelHistory() {
        return fuelHistory;
    }

    public MutableLiveData<Integer> getStatus() {
        return status;
    }

    public LiveData<FuelHistoryListViewData> getSelectedItem() {
        return selectedItem;
    }

    public List<FuelHistoryListViewData> getYearDataSets() {
        return yearDataSets;
    }

    public List<FuelHistoryListViewData> getMileDataSets() {
        return mileDataSets;
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSubscribe(Disposable d) {
        disposable = d;
        status.setValue(RetryView.RETRY_LOADING);
    }

    @Override
    public void onSuccess(DomainFuelHistory domainFuelHistory) {
        fuelHistory.setValue(domainFuelHistory);
        status.setValue(RetryView.RETRY_GONE);
    }

    @Override
    public void onError(Throwable e) {
        status.setValue(RetryView.RETRY_RETRY);
    }

    private void initMile(List<FuelHistoryListViewData> sets) {
//        sets.add(new FuelHistoryListViewData(0, "近50",
//                50, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(0, "近100",
                100, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(1, "近200",
                200, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(2, "近500",
                500, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(3, "近1千",
                1000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(4, "近2千",
                2000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(5, "近5千",
                5000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(6, "近1万",
                10000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(7, "近2万",
                20000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(8, "近5万",
                50000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(9, "近10万",
                100000, FuelHistoryListViewData.Type.MILE));
        sets.add(new FuelHistoryListViewData(10, "全部",
                null, FuelHistoryListViewData.Type.MILE));
//        for (int i = 0; i < 60; i++) {
//            if (i == 0)
//                sets.add(new FuelHistoryListViewData(i * 2,
//                        String.valueOf("5000"), 5000, FuelHistoryListViewData.Type.MILE));
//            else
//                sets.add(new FuelHistoryListViewData(i * 2,
//                        String.format(Locale.CHINESE, "%d", (int) ((i + 0.5f) * 10000)),
//                        (int) ((i + 0.5f) * 10000), FuelHistoryListViewData.Type.MILE));
//            sets.add(new FuelHistoryListViewData(i * 2 + 1,
//                    String.format(Locale.CHINESE, "%d", (i + 1) * 10000),
//                    ((i + 1) * 10000), FuelHistoryListViewData.Type.MILE));
//        }
    }

}
