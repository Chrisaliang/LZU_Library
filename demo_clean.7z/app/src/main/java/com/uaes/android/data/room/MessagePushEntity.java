package com.uaes.android.data.room;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_BODY;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_EXTRA_JSON;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_HAS_READ;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_MESSAGE_CLASS;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_SYSTEM_TIME;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_TITLE;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.COLUMN_TYPE;
import static com.uaes.android.data.room.Tables.PUSH_MESSAGE.TABLE_NAME;

/**
 * Author : 张 涛
 * Time : 2018/1/15.
 * Des : This is
 */
@Entity(tableName = TABLE_NAME)
public class MessagePushEntity {
    public static final String MESSAGE_CLASS_ADVICE = "推荐"; // 推荐
    public static final String MESSAGE_CLASS_MALFUNCTION = "故障"; //故障
    public static final String MESSAGE_CLASS_WARN = "预警"; // 预警
    public static final String MESSAGE_CLASS_NOTIFICATION = "通知"; // 通知
    public static final int MESSAGE_READ = 1;// 消息已读
    public static final int MESSAGE_UNREAD = 0;// 消息未读


    @PrimaryKey(autoGenerate = true)
    public long id;//自增的id
    @ColumnInfo(name = COLUMN_TITLE, typeAffinity = ColumnInfo.TEXT)
    public String title;//消息的头
    @ColumnInfo(name = COLUMN_BODY, typeAffinity = ColumnInfo.TEXT)
    public String body;//消息的内容
    @ColumnInfo(name = COLUMN_TYPE, typeAffinity = ColumnInfo.TEXT)
    public String type;//消息小类，APP 根据该key 决定下一步具体操作。
    @ColumnInfo(name = COLUMN_MESSAGE_CLASS, typeAffinity = ColumnInfo.TEXT)
    public String messageClass;//消息大类，APP 根据该key 决定推送汇总界面的显示
    @ColumnInfo(name = COLUMN_SYSTEM_TIME, typeAffinity = ColumnInfo.TEXT)
    public String systemTime;//消息的的系统时间

    @ColumnInfo(name = COLUMN_EXTRA_JSON, typeAffinity = ColumnInfo.TEXT)
    public String extraJson; // 额外的必要信息必要信息根据 type, messageClass 不能而不同，需要运行时动态解析

    @ColumnInfo(name = COLUMN_HAS_READ)
    public int hasRead;

}
