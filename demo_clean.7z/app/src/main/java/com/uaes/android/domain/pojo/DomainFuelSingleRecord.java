package com.uaes.android.domain.pojo;

import com.github.mikephil.charting.data.BarEntry;
import com.uaes.android.viewmodel.PageViewModel;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Chrisaliang on 2018/1/22.
 * data for fuel single record chart
 */

@SuppressWarnings("ALL")
public class DomainFuelSingleRecord {
    private static DomainFuelSingleRecord EMPTY;

    public String[] labels;
    /**
     * 数据集合
     */
    public PageViewModel<BarEntry> barData;
    public String fillCount;  // 加油次数 // 文字
    public String fillAmountSum; // 加油量// 文字

    public DomainFuelSingleRecord() {
    }

    public DomainFuelSingleRecord(String[] labels, PageViewModel<BarEntry> barData, String fillCount, String fillAmountSum) {
        this.labels = labels;
        this.barData = barData;
        this.fillCount = fillCount;
        this.fillAmountSum = fillAmountSum;
    }

    public static DomainFuelSingleRecord getEmptySingleRecord() {
        if (EMPTY == null) {
            PageViewModel<BarEntry> barData = new PageViewModel<>();
            barData.contents = new ArrayList<>(0);
            EMPTY = new DomainFuelSingleRecord(new String[0], barData, null, null);
        }
        return EMPTY;
    }

    @Override
    public String toString() {
        return "DomainFuelSingleRecord{" +
                "labels=" + Arrays.toString(labels) +
                ", barData=" + barData +
                ", fillCount='" + fillCount + '\'' +
                ", fillAmountSum='" + fillAmountSum + '\'' +
                '}';
    }
}
