package com.uaes.android.ui.gasstation;

import android.content.Context;
import android.support.annotation.NonNull;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.uaes.android.domain.AuthorizationSingleObserver;
import com.uaes.android.domain.GasStationRepository;
import com.uaes.android.viewmodel.GasStationViewModel;

import java.util.List;

import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by Chrisaliang on 2017/11/2.
 * decoupling ui and data
 */

public class GasStationUIAdapter implements GasStationUIInterface {

    private static final String TAG = GasStationUIAdapter.class.getSimpleName();
    private final Context context;
    private final AMapLocationClient mLocationClient;
    private final GasStationRepository repository;
    private AMapLocation mLocation;
    private GasUIListener mListener;
    private int currentPage = 1;
    private List<GasStationViewModel> mGasStationList;
    private Disposable mDisposable;

    GasStationUIAdapter(Context context, GasStationRepository repository, AMapLocationClient client) {
        this.context = context;
        this.repository = repository;
        this.mLocationClient = client;
    }

    @Override
    public void onLocationChanged(AMapLocation aMapLocation) {
        if (mListener == null)
            return;
        if (aMapLocation.getErrorCode() == 0) {
            if (mLocation == null) {
                mLocation = aMapLocation;
                mListener.onFirstLocationUpdate(aMapLocation);
            } else {
                mListener.onLocationUpdate(aMapLocation);
            }
        } else {
            if (mLocation == null) {
                mListener.onFirstLocationError();
            } else {
                mListener.onLocationError(aMapLocation.getErrorCode());
            }
            Timber.tag(TAG).d("error location: %s", aMapLocation.toString());
        }
        // 手动启动 定位程序
        mLocationClient.stopLocation();
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public AMapLocation getLocation() {
        return mLocation;
    }

    public void queryStation(int strategy) {
        if (mListener == null) return;
        if (mLocation == null) mListener.onLocationError(404);
        else {
            currentPage = 1;
//            if (mDisposable == null || !mDisposable.isDisposed()) {
                double lat = mLocation.getLatitude();
                double lon = mLocation.getLongitude();
                repository.gasStationList(lat, lon, strategy)
                        .subscribe(new ListStationObserver(context));
//            } else
//                mDisposable.dispose();
        }
    }

    public void queryNext() {

        if (mGasStationList == null || mGasStationList.isEmpty()) {
            if (mListener != null)
                mListener.onNextResultError(1);
        } else {
            if (mGasStationList.size() < currentPage * 10) {
                if (mListener != null)
                    mListener.onNoMoreResult();
            } else {
                currentPage++;
                if (mListener != null)
                    mListener.onResult(getNextSubList());
            }
        }
    }

    @NonNull
    private List<GasStationViewModel> getNextSubList() {
        int tempEnd = currentPage * 10;
        if (mGasStationList.size() < tempEnd)
            tempEnd = mGasStationList.size();
        return mGasStationList.subList((currentPage - 1) * 10, tempEnd);
    }

    public void queryPrevious() {
        if (mListener != null) {
            if (currentPage - 2 < 0)
                mListener.onFirstPageNumArrived();
            else {
                if (mGasStationList == null || mGasStationList.isEmpty())
                    mListener.onPreviousResultError(1);
                else {
                    currentPage--;
                    mListener.onResult(getPreviousSubList());
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        mLocationClient.onDestroy();
        mLocation = null;
        mListener = null;
        if (mDisposable != null && !mDisposable.isDisposed())
            mDisposable.dispose();
    }

    private List<GasStationViewModel> getPreviousSubList() {
        int tempEnd = (currentPage) * 10;
        if (mGasStationList.size() < tempEnd)
            tempEnd = mGasStationList.size();
        return mGasStationList.subList((currentPage - 1) * 10, tempEnd);
    }

    /**
     * 开始定位
     */
    void requestLocation() {
        mLocationClient.startLocation();
    }

    /**
     * 停止定位
     */
    void cancelRequest() {
        mLocationClient.stopLocation();
    }

    /**
     * 注册事件回调器
     */
    void registerListener(@NonNull GasUIListener listener) {
        mListener = listener;
        mLocationClient.setLocationListener(this);
    }

    /**
     * 移除事件回调器
     */
    void unRegisterListener(GasUIListener listener) {
        mLocationClient.unRegisterLocationListener(this);
        mListener = null;
    }

    private class ListStationObserver extends AuthorizationSingleObserver<List<GasStationViewModel>> {

        ListStationObserver(Context context) {
            super(context);
        }

        @Override
        public void onSubscribe(Disposable d) {
            mDisposable = d;
            Timber.tag(TAG).d("onSubscribe: Disposable:%s", d);
        }

        @Override
        public void onSuccess(List<GasStationViewModel> gasStations) {
            mGasStationList = gasStations;
            if (mListener != null)
                mListener.onResult(getNextSubList());
        }

        @Override
        public void onError(Throwable e) {
            super.onError(e);
            Timber.tag(TAG).e(e, "onError: ");
            if ((mGasStationList == null || mGasStationList.isEmpty()) && mListener != null)
                mListener.onFirstResultError();
            else if (mListener != null)
                mListener.onResultError();
        }
    }
}
