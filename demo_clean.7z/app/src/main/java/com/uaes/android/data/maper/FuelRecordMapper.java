package com.uaes.android.data.maper;

import android.graphics.Color;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.uaes.android.data.json.FuelFillRecordPoint;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.domain.pojo.DomainFuelRecord;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Created by aber on 11/27/2017.
 * Fuel Record Mapper
 */

public class FuelRecordMapper {

    private static final String TAG = FuelRecordMapper.class.getSimpleName();
    private final static int[] COLORS = new int[]{Color.parseColor("#8076DDFB"), Color.RED, Color.GREEN, Color.BLUE, Color.CYAN};

    public DomainFuelRecord map(GeneralAttributeReceive<List<FuelFillRecordPoint>> receive) {
        List<FuelFillRecordPoint> list = receive.msgContent;
        return map(list);
    }

    public DomainFuelRecord map(List<FuelFillRecordPoint> list) {
        if (list.size() <= 0)
            return DomainFuelRecord.getEmptyRecord();
        List<Entry> entries = new ArrayList<>();
        for (FuelFillRecordPoint point : list) {
            entries.add(new Entry(point.xValue, point.yValue));
        }
//        float tx = (float) (entries.size() / 20.0 + 1);
//        int num = (int) tx;
        float yMax = list.get(list.size() - 1).yValue;
        float xMax = ((int) ((list.get(list.size() - 1).xValue - 1) / 5000) + 1) * 5000;

        ArrayList<ILineDataSet> dataSets = new ArrayList<>();

        List<Entry> entryList = new ArrayList<>(entries);
        entryList.add(0, new Entry(0, 0));
        LineDataSet lineDataSet = initDataSet(new LineDataSet(entryList, "累计用油"), COLORS[0]);
        dataSets.add(lineDataSet);

//        Entry firstEntry = new Entry(0, 0);
//        int pointer = 0;
//        while (pointer < entries.size()) {
//            int size = 20;
//            List<Entry> yVals = new ArrayList<>(entries.subList(pointer,
//                    (pointer + size) > entries.size() ? entries.size() : pointer + size));
//            yVals.add(0, firstEntry);
//            firstEntry = new Entry(entries.get(size - 1).getX(), entries.get(size - 1).getY());
//            LineDataSet lineDataSet = initDataSet(new LineDataSet(yVals, ""), COLORS[0]);
////            LineDataSet lineDataSet = initDataSet(new LineDataSet(yVals, ""), COLORS[pointer / 20]);
//            if (pointer != 0)
//                dataSets.add(lineDataSet);
//            pointer += 20;
//        }
        DomainFuelRecord data = new DomainFuelRecord(xMax, yMax, dataSets);
        Timber.tag(TAG).d("map: %s", data);
        return data;
    }

    private LineDataSet initDataSet(LineDataSet lineDataSet, int fillColor) {
        lineDataSet.setColor(Color.parseColor("#0BA9FC"));
        lineDataSet.setLineWidth(2f);//设置线宽
        lineDataSet.setCircleRadius(1f);//设置焦点圆心的大小
        lineDataSet.setCircleColor(Color.parseColor("#0BA9FC"));
        lineDataSet.setHighlightEnabled(false);//是否禁用点击高亮线
        lineDataSet.setValueTextSize(9f);//设置显示值的文字大小
        lineDataSet.setDrawFilled(true);//设置禁用范围背景填充
        lineDataSet.setFillColor(fillColor);
        lineDataSet.setDrawValues(false);
        lineDataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);// 贝塞尔曲线显示
        return lineDataSet;
    }

}
