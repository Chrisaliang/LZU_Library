package com.uaes.android.ui.carhelper.fuelmanager;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentFuelManagerFuelRecordBinding;
import com.uaes.android.domain.pojo.DomainFuelRecord;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.viewmodel.FuelRecordViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.FuelRecordViewObservable;

import javax.inject.Inject;

/**
 * Created by hand on 2017/11/6.
 * 累计用油记录
 */

public class FuelRecordFragment extends NavigatorFragment implements Observer<DomainFuelRecord> {

    private static final String TAG = FuelRecordFragment.class.getSimpleName();
    @Inject
    RepositoryVMProvider factory;
    private FragmentFuelManagerFuelRecordBinding binding;
    private FuelRecordViewModel viewModel;
    private FuelRecordViewObservable viewObservable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(FuelRecordViewModel.class);
        viewObservable = new FuelRecordViewObservable(viewModel);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_fuel_manager_fuel_record, container, false);
        binding.setRecord(viewObservable);
        viewModel.getFuelRecord().observe(this, this);
        viewModel.getStatus().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            viewObservable.setStatus(integer);
        });
        initChart(binding.lineChart);
        return binding.getRoot();
    }

    @Override
    public void refresh() {
        viewModel.update();
    }

    private void initChart(LineChart lineChart) {
        Description desc = new Description();
        desc.setEnabled(false);
        lineChart.setTouchEnabled(false);
        lineChart.setDescription(desc);
        lineChart.setNoDataText("没有数据");
        lineChart.setNoDataTextColor(Color.BLUE);//没有数据时显示文字的颜色
        lineChart.setDrawGridBackground(false);//chart 绘图区后面的背景矩形将绘制
        lineChart.setDrawBorders(false);//禁止绘制图表边框的线
        lineChart.setScaleEnabled(false);
        lineChart.setPinchZoom(true);
        lineChart.setExtraOffsets(24, 24, 24, 24);
        // 图示，显示label
        Legend legend = lineChart.getLegend();
        legend.setEnabled(false);
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setGranularityEnabled(true);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setAxisLineWidth(1);
        xAxis.setAxisLineColor(Color.WHITE);
        xAxis.setTextSize(16);
        xAxis.setTextColor(Color.WHITE);
        xAxis.setDrawGridLines(false);
        xAxis.setAxisMinimum(0f);
        YAxis y1 = lineChart.getAxisLeft();
        // 设置Y轴从0开始
        y1.setAxisMinimum(0);
        y1.setDrawAxisLine(false);
        y1.setDrawGridLines(true);
        y1.setDrawTopYLabelEntry(true);
        y1.setDrawLabels(true);
        y1.setLabelCount(5);
        y1.setTextColor(Color.WHITE);
        y1.setTextSize(20);
        y1.setAxisLineColor(Color.WHITE);
        //y1.setSpaceTop(20);
        y1.setDrawLimitLinesBehindData(true);

        // 设置右侧Y轴不显示
        lineChart.getAxisRight().setEnabled(false);
        lineChart.setExtraBottomOffset(16);
        // 设置动画
        lineChart.animateY(300, Easing.EasingOption.Linear);
        lineChart.animateX(300, Easing.EasingOption.Linear);
    }

    @Override
    public void onStart() {
        super.onStart();
        viewModel.update();
    }

    @Override
    public void onChanged(@Nullable DomainFuelRecord domainFuelRecord) {
        if (domainFuelRecord == null) return;
        viewObservable.setRecord(domainFuelRecord);
        refreshTime(Tables.FUEL_RECORD_POINT.TABLE_NAME);
    }
}
