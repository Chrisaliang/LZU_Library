package com.uaes.android.data.http;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.uaes.android.ServiceEnvironment;
import com.uaes.android.data.json.TokenResponse;
import com.uaes.common.Intents;

import java.io.IOException;

import javax.annotation.Nullable;

import okhttp3.Authenticator;
import okhttp3.Call;
import okhttp3.Credentials;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;


/**
 * Created by aber on 2/13/2018.
 * refresh token
 */

public class TokenAuthenticator implements Authenticator {

    private static final String REFRESH_TOKEN = "refresh_token";
    private static final String URL = ServiceEnvironment.baseUrl + "/oauth/oauth/token";

    private SharedPreferences sharedPreferences;

    private LocalBroadcastManager manager;

    private Gson gson;

    private OkHttpClient okHttpClient;

    private HapAuthorizationInterceptor interceptor;

    public TokenAuthenticator(Gson gson, SharedPreferences sharedPreferences, LocalBroadcastManager manager, HapAuthorizationInterceptor authorizationInterceptor) {
        this.manager = manager;
        this.sharedPreferences = sharedPreferences;
        this.interceptor = authorizationInterceptor;
        this.gson = gson;
        this.okHttpClient = new OkHttpClient.Builder().build();
    }

    @Nullable
    @Override
    public Request authenticate(Route route, Response response) throws IOException {
        if (response.request().header("Authorization") != null) {
            return null; // Give up, we've already failed to authenticate.
        }
        String reToken = sharedPreferences.getString(Intents.KEY_RETOKEN, null);
        if (TextUtils.isEmpty(reToken)) {
            Intent intent = new Intent(Intents.ACTION_AUTHORIZATION);
            manager.sendBroadcast(intent);
            return null;
        }
        String credential = Credentials.basic("client", "secret");

        Request request = new Request.Builder().url(URL).post(new FormBody.Builder().add("grant_type", "refresh_token")
                .add("refresh_token", reToken).build()).header("Authorization", credential).build();
        Call call = okHttpClient.newCall(request);
        Response refreshResponse = call.execute();
        if (refreshResponse != null && refreshResponse.isSuccessful()) {
            TokenResponse tokenResponse = gson.fromJson(refreshResponse.body().string(), TokenResponse.class);
            interceptor.inValid();
            sharedPreferences.edit().putString(Intents.KEY_RETOKEN, tokenResponse.refresh_token)
                    .putString(Intents.KEY_TOKEN, tokenResponse.access_token).apply();
            return response.request().newBuilder()
                    .header("Authorization", "Bearer " + tokenResponse.access_token).build();
        } else {
            Intent intent = new Intent(Intents.ACTION_AUTHORIZATION);
            manager.sendBroadcast(intent);
            return null;
        }
    }
}
