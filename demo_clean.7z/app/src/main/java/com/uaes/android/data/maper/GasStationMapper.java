package com.uaes.android.data.maper;

import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.text.Html;

import com.uaes.android.R;
import com.uaes.android.data.json.GasStation;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.viewmodel.GasStationViewModel;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by Chrisaliang on 2017/11/30.
 * map gas station data model to view model
 */

public class GasStationMapper {

    private static final String UNKNOWN = "未知";

    private final Resources resources;

    public GasStationMapper(Resources resources) {
        this.resources = resources;
    }

    public List<GasStationViewModel> map(GeneralAttributeReceive<List<GasStation>> receive, int strategy) {
        List<GasStation> msgContent = receive.msgContent;
        return map(msgContent, strategy);
    }

    public List<GasStationViewModel> map(List<GasStation> msgContent, int strategy) {
        List<GasStationViewModel> list = new ArrayList<>();
        for (GasStation gasStation : msgContent) {
            GasStationViewModel viewModel = new GasStationViewModel();
            viewModel.stationName = gasStation.stationName;
            viewModel.stationAddr = resources.getString(R.string.gas_station_station_address_label, gasStation.stationAddr);
            viewModel.stationBrand = resources.getString(R.string.gas_station_station_brand_label, gasStation.stationBrand);
            viewModel.stationDistance = Html.fromHtml(String.format(Locale.CHINA,
                    "距离：<font color='#2c9bd3'>%.1f</font> 公里", gasStation.stationDistance / 1000.0));
            viewModel.stationDuration = Html.fromHtml(String.format(Locale.CHINA,
                    "行驶耗时：<font color='#2c9bd3'>%.1f</font> 分钟", gasStation.stationDuration / 60.0));
            viewModel.stationRate = gasStation.stationRate;
            if (gasStation.fillTime > 0) {
                viewModel.stationFillDuration = Html.fromHtml(String.format(Locale.CHINA,
                        "加油耗时：<font color='#2c9bd3'>%.1f</font> 分钟", gasStation.fillTime / 60.0));
            } else {
                viewModel.stationFillDuration = Html.fromHtml("加油耗时：<font color='#2c9bd3'>未知</font> 分钟");
            }
            viewModel.lat = gasStation.lat;
            viewModel.lon = gasStation.lon;
            viewModel.fillTime = gasStation.fillTime;
            // todo: add moreStr
            viewModel.moreStr = resources.getString(R.string.gas_station_unknown_open_time);

            switch (strategy) {
                case 0:
                    viewModel.secondStr = getTwoString(getTotalLen(gasStation.stationDistance),
                            gasStation.stationAddr);
                    break;
                case 1:
                    viewModel.moreStr = String.format("行程耗时：%s\n加油耗时： %s",
                            getTimeStr(gasStation.stationDuration), getTimeStr(gasStation.fillTime));
                    viewModel.secondStr = getTwoString(getTimeStr(gasStation.stationDuration),
                            gasStation.stationAddr);
                    break;
                case 2:
                    viewModel.secondStr = getTwoString(String.format(Locale.CHINA, "%.1f 分",
                            gasStation.stationRate),
                            gasStation.stationAddr);
                    break;
            }
            list.add(viewModel);
        }
        return list;
    }

    private String getTimeStr(int second) {
        if (second <= 0) return "未知";
        StringBuilder time = new StringBuilder("约");
        if (second < 60) return time.append(second).append("秒").toString();
        int minutes = (int) Math.round(second / 60.0);
        if (minutes < 60) return time.append(minutes).append("分钟").toString();
        else {
            int hour = minutes / 60;
            time.append(hour).append("小时");
            if (minutes % 60 != 0) time.append(minutes % 60).append("分钟");
        }
        return time.toString();
    }


    @NonNull
    private String getTotalLen(int length) {
        if (length < 0) return "";
        if (length < 1000) return length + "米";
        else return new DecimalFormat("#.0").format(length / 1000.0) + "公里";
    }

    private String getTwoString(String s1, String s2) {
        return String.format(Locale.CHINA, "%s·%s", s1, s2);
    }
}
