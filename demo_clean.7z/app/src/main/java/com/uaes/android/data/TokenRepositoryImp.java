package com.uaes.android.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.uaes.android.data.http.TokenApi;
import com.uaes.android.data.json.TokenResponse;
import com.uaes.android.domain.TokenRepository;
import com.uaes.common.AuthProvider;
import com.uaes.common.Intents;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import timber.log.Timber;

/**
 * Created by aber on 11/20/2017.
 * Token Manager
 */

public class TokenRepositoryImp implements TokenRepository {

    private final AuthProvider mAuthProvider;
    private final TokenApi mTokenApi;
    private final SharedPreferences mSharedPreferences;

    public TokenRepositoryImp(AuthProvider provider, TokenApi mTokenApi, Context context) {
        this.mAuthProvider = provider;
        this.mTokenApi = mTokenApi;
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    @Override
    public Single<Boolean> queryToken() {
        return Single.just(mAuthProvider)
                .flatMap(provider -> {
                    // first check token cache
                    String token = mSharedPreferences.getString(Intents.KEY_TOKEN, null);
                    String reToken = mSharedPreferences.getString(Intents.KEY_RETOKEN, null);
                    if (!TextUtils.isEmpty(token)) {
                        TokenResponse tokenResponse = new TokenResponse();
                        tokenResponse.access_token = token;
                        tokenResponse.refresh_token = reToken;
                        return Single.just(tokenResponse);
                    }

                    String sha384 = provider.getSha384WithIMEI();
                    Timber.tag("Origin Code").d(sha384);
                    return mTokenApi.getToken(sha384);
                }).map(tokenResponse -> {
                    if (TextUtils.isEmpty(tokenResponse.access_token))
                        return false;
                    mSharedPreferences.edit()
                            .putString(Intents.KEY_TOKEN,
                                    tokenResponse.access_token)
                            .putString(Intents.KEY_RETOKEN,
                                    tokenResponse.refresh_token)
                            .apply();
                    return true;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
