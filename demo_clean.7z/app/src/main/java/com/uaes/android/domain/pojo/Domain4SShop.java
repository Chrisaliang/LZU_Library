package com.uaes.android.domain.pojo;

import com.google.gson.annotations.SerializedName;

/**
 * Created by aber on 1/22/2018.
 * 4S 店信息 // 缺营业时间
 */

public class Domain4SShop {

    // 4S 店名字
    @SerializedName("name")
    public String name;

    // 地址
    @SerializedName("serviceAddress")
    public String serviceAddress;

    // 服务电话
    @SerializedName("serviceTel")
    public String serviceTel;

    // 距离
    @SerializedName("distance")
    public int distance;

    // 耗时
    @SerializedName("duration")
    public int duration;

    // 经度
    @SerializedName("longitude")
    public double longitude;

    //维度
    @SerializedName("latitude")
    public double latitude;

}
