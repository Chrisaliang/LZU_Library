package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.COLUMN_CURRENT_PAGE;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.COLUMN_FILL_AMOUNT_SUM;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.COLUMN_FILL_COUNT;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.COLUMN_PAGE_SIZE;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.COLUMN_TOTAL_ELEMENT;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.COULMN_TOTAL_PAGE;
import static com.uaes.android.data.room.Tables.FUEL_SINGLE_FILL_RECORD_COUNT.TABLE_NAME;

/**
 * Created by hand on 2017/11/7.
 * Json and Database entity
 */

@Entity(tableName = TABLE_NAME)
public class SingleFuelRecord {

    @PrimaryKey
    @NonNull
    public String name;

    @ColumnInfo(name = COLUMN_FILL_COUNT)
    @SerializedName(COLUMN_FILL_COUNT)
    public int fillCount;  // 加油次数

    @ColumnInfo(name = COLUMN_FILL_AMOUNT_SUM)
    @SerializedName(COLUMN_FILL_AMOUNT_SUM)
    public double fillAmountSum; // 加油量

    @ColumnInfo(name = COLUMN_TOTAL_ELEMENT)
    @SerializedName(COLUMN_TOTAL_ELEMENT)
    public int totalElements;

    @ColumnInfo(name = COULMN_TOTAL_PAGE)
    @SerializedName(COULMN_TOTAL_PAGE)
    public int totalPage;

    @ColumnInfo(name = COLUMN_PAGE_SIZE)
    @SerializedName(COLUMN_PAGE_SIZE)
    public int size;

    @ColumnInfo(name = COLUMN_CURRENT_PAGE)
    @SerializedName(COLUMN_CURRENT_PAGE)
    public int currentPageNumber;

    @Ignore
    @SerializedName("page")
    public Page page; //

    public SingleFuelRecord(@NonNull String name) {
        this.name = name;
    }

    /**
     * number start with 0.
     */
    public static class Page {
        @SerializedName("totalPages")
        public int totalPages;// 总页数
        @SerializedName("totalElements")
        public int totalElements;// 总元素个数
        @SerializedName("numberOfElements")
        public int numberOfElements;// 当前页实际显示元素个数
        @SerializedName("size")
        public int size;// 当前页显示的最大可能显示的数据格式
        @SerializedName("number")
        public int number;// 当前显示页码
        @SerializedName("content")
        public List<FuelSingleFillRecord> content;
    }
}
