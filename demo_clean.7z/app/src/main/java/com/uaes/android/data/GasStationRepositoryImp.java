package com.uaes.android.data;

import android.content.res.Resources;

import com.uaes.android.data.http.GasStationApi;
import com.uaes.android.data.maper.GasStationMapper;
import com.uaes.android.domain.GasStationRepository;
import com.uaes.android.viewmodel.GasStationViewModel;

import java.util.List;
import java.util.Locale;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by Chrisaliang on 2017/11/2.
 * repository for gasStation list
 */

public class GasStationRepositoryImp implements GasStationRepository {

    private final GasStationApi stationApi;
    private final GasStationMapper stationMapper;

    public GasStationRepositoryImp(GasStationApi stationApi, Resources resources) {
        this.stationApi = stationApi;
        stationMapper = new GasStationMapper(resources);
    }

    @Override
    public Single<List<GasStationViewModel>> gasStationList(double lat, double lon, final int strategy) {
        String location = String.format(Locale.CHINA, "%f,%f", lon, lat);
        return stationApi.gasStationList(location, strategy)
                .map(receive -> stationMapper.map(receive, strategy))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
