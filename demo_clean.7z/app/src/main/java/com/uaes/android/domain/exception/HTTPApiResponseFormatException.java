package com.uaes.android.domain.exception;

/**
 * Created by aber on 1/23/2018.
 * 接口请求时发送数据解析或其他错误
 * TODO add api url info for debug
 */

public class HTTPApiResponseFormatException extends IllegalArgumentException {
    final Class<?> errorClass;

    public HTTPApiResponseFormatException(Class<?> errorClass) {
        this.errorClass = errorClass;
    }
}
