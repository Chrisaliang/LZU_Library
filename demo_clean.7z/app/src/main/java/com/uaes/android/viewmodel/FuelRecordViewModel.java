package com.uaes.android.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.pojo.DomainFuelRecord;
import com.uaes.android.widget.RetryView;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by Chrisaliang on 2017/11/27.
 * data for fuel record chart
 */

@SuppressWarnings("WeakerAccess")
public class FuelRecordViewModel extends ViewModel implements SingleObserver<DomainFuelRecord> {

    private static final String TAG = "FuelRecordViewModel";

    private final MutableLiveData<DomainFuelRecord> fuelRecord = new MutableLiveData<>();

    private final MutableLiveData<Integer> status = new MutableLiveData<>();

    private final FuelManagerRepository repository;

    private Disposable disposable;

    public FuelRecordViewModel(FuelManagerRepository repository) {
        this.repository = repository;
    }

    public void update() {
        repository.FuelRecord().subscribe(this);
    }

    public MutableLiveData<DomainFuelRecord> getFuelRecord() {
        return fuelRecord;
    }

    public MutableLiveData<Integer> getStatus() {
        return status;
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSubscribe(Disposable d) {
        this.disposable = d;
        status.setValue(RetryView.RETRY_LOADING);
    }

    @Override
    public void onSuccess(DomainFuelRecord domainFuelRecord) {
        if (domainFuelRecord == DomainFuelRecord.getEmptyRecord()) {
            status.setValue(RetryView.RETRY_EMPTY);
            return;
        }
        fuelRecord.setValue(domainFuelRecord);
        status.setValue(RetryView.RETRY_GONE);
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).d(e);
        status.postValue(RetryView.RETRY_RETRY);
    }
}
