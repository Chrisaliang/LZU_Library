package com.uaes.android.ui.maintenance.listener;

import android.view.View;

/**
 * Author : 张 涛
 * Time : 2018/1/22.
 * Des : This is
 */

public interface LeftMenuSelectListener {

    void onClick(View view);

}
