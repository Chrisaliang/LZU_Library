package com.uaes.android.utils;

import android.support.annotation.IdRes;
import android.view.View;

/**
 * Created by hand on 2017/11/10.
 * check utils
 */

public class CheckUtils {

    public static void checkNoViewIdIfThrow(@IdRes int id) {
        if (id == View.NO_ID)
            throw new IllegalStateException("Can't get a valid id,please check you layout");
    }
}
