package com.uaes.android.ui.setting;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.ui.TopLevelFragment;

import timber.log.Timber;

/**
 * Created by Chrisaliang on 2017/11/3.
 * setting fragment
 */

public class SettingFragment extends TopLevelFragment implements View.OnClickListener {

    private static final String TAG = SettingFragment.class.getSimpleName();

    private static final String CHILD_LOW_FUEL_MENU = "CHILD_LOW_FUEL_MENU" + TAG;
    private static final String CHILD_ABOUT_MENU = "CHILD_ABOUT_MENU" + TAG;
    private View lowFuelMenu;
    private int selectedId = View.NO_ID;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_setting, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        lowFuelMenu = view.findViewById(R.id.setting_low_fuel_menu);
        View aboutMenu = view.findViewById(R.id.setting_about_menu);
        lowFuelMenu.setTag(CHILD_LOW_FUEL_MENU);
        aboutMenu.setTag(CHILD_ABOUT_MENU);
        lowFuelMenu.setOnClickListener(this);
        aboutMenu.setOnClickListener(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        updateSelectedMenu(selectedId);
    }

    @Override
    public void onClick(View v) {
        updateSelectedMenu(v.getId());
    }

    private void updateSelectedMenu(int clickId) {
        View view = getView();
        if (view != null)
            updateSelectedMenu(view.findViewById(selectedId), view.findViewById(clickId));
    }

    private void updateSelectedMenu(View selectedView, View clickView) {
        if (clickView == null)
            clickView = lowFuelMenu;
        clickView.setSelected(true);
        selectedId = clickView.getId();
        if (selectedView != null && selectedView != clickView)
            selectedView.setSelected(false);
        switchFragment(clickView);
    }


    private void switchFragment(View view) {
        FragmentManager fragmentManager = getChildFragmentManager();
        String tag;
        if (view == null) {
            tag = CHILD_LOW_FUEL_MENU;
        } else {
            tag = (String) view.getTag();
        }

        Fragment fragment = getFragment(fragmentManager, tag);
        if (fragment == null) {
            Timber.tag(TAG).d("switchFragment: The tag:" + tag + " is not implemented!");
            return;
        }
        if (!fragment.isAdded())
            fragmentManager.beginTransaction()
                    .replace(R.id.fragment_setting_layout,
                            getFragment(fragmentManager, tag))
                    .commit();
    }

    private Fragment getFragment(FragmentManager manager, String tag) {
        Fragment fragment = manager.findFragmentByTag(tag);
        if (fragment == null) {
            fragment = createFragmentByTag(tag);
        }
        return fragment;
    }

    private Fragment createFragmentByTag(String tag) {
        if (CHILD_LOW_FUEL_MENU.equals(tag)) {
            return new SettingLowFuelWarningFragment();
        } else if (CHILD_ABOUT_MENU.equals(tag)) {
            return new SettingAboutFragment();
        }
        return null;
    }

    @Override
    public void back() {

    }
}
