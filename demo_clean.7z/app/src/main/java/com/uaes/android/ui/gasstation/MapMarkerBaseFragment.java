package com.uaes.android.ui.gasstation;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationListener;

import dagger.android.support.DaggerFragment;
import timber.log.Timber;

/**
 * Author: tianbing
 * Date: 2017/10/19
 * Overview:
 */

public abstract class MapMarkerBaseFragment extends DaggerFragment implements AMapLocationListener {
    private static final String TAG = MapMarkerBaseFragment.class.getSimpleName();

    protected MapMarkerListener mListener;

    protected AMapLocationClient mClient;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (MapMarkerListener) context;
        } catch (ClassCastException e) {
            Timber.tag(TAG).d("onAttach: parent activity must implement");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mClient = new AMapLocationClient(getActivity().getApplicationContext());
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (MapMarkerListener) activity;
        } catch (ClassCastException e) {
            Timber.tag(TAG).d("onAttach: parent activity must implement");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mClient.onDestroy();
    }

    @Override
    public void onLocationChanged(AMapLocation aMapLocation) {

    }
}
