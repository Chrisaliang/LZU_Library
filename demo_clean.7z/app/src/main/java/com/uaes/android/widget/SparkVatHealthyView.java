package com.uaes.android.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.uaes.android.R;

/**
 * Created by Chrisaliang on 2018/3/5.
 * spark vat healthy view
 */

@BindingMethods({
        @BindingMethod(type = SparkVatHealthyView.class, attribute = "svv_spark_healthy", method = "sparkHealthy")
})
public class SparkVatHealthyView extends FrameLayout {

    private FrameLayout layout;
    private ImageView icon;
    private ImageView labelIcon;
    private TextView titleTv;

    public SparkVatHealthyView(@NonNull Context context) {
        this(context, null);
    }

    public SparkVatHealthyView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SparkVatHealthyView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.widget_spark_vat_healthy, this);
        layout = findViewById(R.id.layout_spark_vat_healthy);
        icon = findViewById(R.id.icon_svv);
        labelIcon = findViewById(R.id.label_icon_svv);
        TextView labelTv = findViewById(R.id.label_tv_svv);
        titleTv = findViewById(R.id.tv_svv_title);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SparkVatHealthyView);
        String labelText = a.getString(R.styleable.SparkVatHealthyView_svv_label_text);
        labelTv.setText(labelText);
        boolean healthy = a.getBoolean(R.styleable.SparkVatHealthyView_svv_spark_healthy, true);
        if (healthy) {
            layout.setBackgroundResource(R.drawable.sparking_plug_healthy_image_back);
            icon.setImageResource(R.drawable.sparkingplug_healthy);
            labelIcon.setImageResource(R.drawable.sparkingplug_healthy_label);
            titleTv.setText(R.string.sparking_plug_vat_view_title_healthy);
        } else {
            layout.setBackgroundResource(R.drawable.sparking_plug_ageing_image_back);
            icon.setImageResource(R.drawable.sparking_plug_ageing);
            labelIcon.setImageResource(R.drawable.sparking_plug_ageing_label);
            titleTv.setText(R.string.sparking_plug_vat_view_title_ageing);
        }
        a.recycle();
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public SparkVatHealthyView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @BindingAdapter(value = "svv_spark_healthy")
    public static void sparkHealthy(SparkVatHealthyView view, Boolean healthy) {
        if (healthy) {
            view.layout.setBackgroundResource(R.drawable.sparking_plug_healthy_image_back);
            view.icon.setImageResource(R.drawable.sparkingplug_healthy);
            view.labelIcon.setImageResource(R.drawable.sparkingplug_healthy_label);
            view.titleTv.setText(R.string.sparking_plug_vat_view_title_healthy);
        } else {
            view.layout.setBackgroundResource(R.drawable.sparking_plug_ageing_image_back);
            view.icon.setImageResource(R.drawable.sparking_plug_ageing);
            view.labelIcon.setImageResource(R.drawable.sparking_plug_ageing_label);
            view.titleTv.setText(R.string.sparking_plug_vat_view_title_ageing);
        }
    }
}
