package com.uaes.android.di;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;

import javax.inject.Scope;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Created by hand on 2017/11/7.
 * TODO
 */
@Scope
@Documented
@Retention(RUNTIME)
public @interface ChildFragmentScope {
}
