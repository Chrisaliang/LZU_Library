package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.COLUMN_AC_USE;
import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.COLUMN_DRIVER_USE;
import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.COLUMN_FUEL_COST;
import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.COLUMN_FUEL_USE;
import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.COLUMN_IDLE_USE;
import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.COLUMN_OTHER_USE;
import static com.uaes.android.data.room.Tables.FUEL_FILL_HISTORY.TABLE_NAME;

/**
 * Created by Administrator on 2017/11/9 0009.
 * get fuel history for FuelHistoryFragment by year or mail(distance)
 */
@Entity(tableName = TABLE_NAME)
public class FuelFillHistory {

//             "economicRank": 55.0,
//             "fuelUsedKm": 33.0,
//             "mileage": 900.0,

    @PrimaryKey(autoGenerate = true)
    @Expose(deserialize = false, serialize = false)
    public long id;

    /*总消费*/
    @SerializedName(COLUMN_FUEL_COST)
    @ColumnInfo(name = COLUMN_FUEL_COST)
    public double fuelCost;

    /*总耗油量*/
    @SerializedName(COLUMN_FUEL_USE)
    @ColumnInfo(name = COLUMN_FUEL_USE)
    public double fuelUse;

    /*怠速耗油量*/
    @SerializedName(COLUMN_IDLE_USE)
    @ColumnInfo(name = COLUMN_IDLE_USE)
    public double idleUse;

//    //*怠速耗 费用*/
//    @SerializedName(COLUMN_IDLE_USE_MONEY)
//    @ColumnInfo(name = COLUMN_IDLE_USE_MONEY)
//    public double idleUseMoney;

    /*行驶消耗油量 */
    @SerializedName(COLUMN_DRIVER_USE)
    @ColumnInfo(name = COLUMN_DRIVER_USE)
    public double driverUse;

//    //*行驶消耗 费用 */
//    @SerializedName(COLUMN_DRIVER_USE_MONEY)
//    @ColumnInfo(name = COLUMN_DRIVER_USE_MONEY)
//    public double driverUseMoney;

    /*空调消耗 多少油量 L*/
    @SerializedName(COLUMN_AC_USE)
    @ColumnInfo(name = COLUMN_AC_USE)
    public double acUse;

//    //*空调消耗 费用 */
//    @SerializedName(COLUMN_AC_USE_MONEY)
//    @ColumnInfo(name = COLUMN_AC_USE_MONEY)
//    public double acUseMoney;

    /*其他消耗油量*/
    @SerializedName(COLUMN_OTHER_USE)
    @ColumnInfo(name = COLUMN_OTHER_USE)
    public double otherUse;


//    //*其他消耗 费用*/
//    @SerializedName(COLUMN_OTHER_USE_MONEY)
//    @ColumnInfo(name = COLUMN_OTHER_USE_MONEY)
//    public double otherUseMoney;

    @Override
    public String toString() {
        return "FuelFillHistory{" +
                "id=" + id +
                ", fuelCost=" + fuelCost +
                ", fuelUse=" + fuelUse +
                ", idleUse=" + idleUse +
                ", driverUse=" + driverUse +
                ", acUse=" + acUse +
                ", otherUse=" + otherUse +
                '}';
    }
}
