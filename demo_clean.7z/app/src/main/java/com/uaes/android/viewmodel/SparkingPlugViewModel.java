package com.uaes.android.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.MaintenanceRepository;
import com.uaes.android.domain.pojo.DomainCarHealth;
import com.uaes.android.widget.RetryView;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/24.
 * Des : This is
 */

public class SparkingPlugViewModel extends ViewModel implements SingleObserver<DomainCarHealth> {
    private static final String TAG = "SparkingPlugViewModel";

    private final MutableLiveData<DomainCarHealth> fuelStatus = new MutableLiveData<>();

    private final MutableLiveData<Integer> status = new MutableLiveData<>();

    private final MaintenanceRepository maintenanceRepository;

    private Disposable disposable;

    public SparkingPlugViewModel(MaintenanceRepository maintenanceRepository) {
        this.maintenanceRepository = maintenanceRepository;
    }

    public LiveData<DomainCarHealth> getCarHealth() {
        return fuelStatus;
    }

    public LiveData<Integer> getStatue() {
        return status;
    }

    public void getCarState() {
        maintenanceRepository.getCarHealth().subscribe(this);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSubscribe(Disposable d) {
        disposable = d;
        status.setValue(RetryView.RETRY_LOADING);
    }

    @Override
    public void onSuccess(DomainCarHealth domainCarHealth) {
        if (domainCarHealth == DomainCarHealth.EMPTY) {
            status.setValue(RetryView.RETRY_EMPTY);
        } else {
            fuelStatus.setValue(domainCarHealth);
            status.setValue(RetryView.RETRY_GONE);
        }
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).e(e, "SparkingPlugViewModel");
        status.postValue(RetryView.RETRY_RETRY);
    }
}
