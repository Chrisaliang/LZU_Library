package com.uaes.android.di;

import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.uaes.android.UaesIotApplication;
import com.uaes.android.data.CacheTimeRepositoryImp;
import com.uaes.android.data.FuelAccountRepositoryImpl;
import com.uaes.android.data.FuelManagerRepositoryImpl;
import com.uaes.android.data.GasStationRepositoryImp;
import com.uaes.android.data.MaintenanceRepositoryImpl;
import com.uaes.android.data.MessageRepositoryImp;
import com.uaes.android.data.SecurityCheckRepositoryImp;
import com.uaes.android.data.SettingRepositoryImpl;
import com.uaes.android.data.Super4SRepositoryImp;
import com.uaes.android.data.TokenRepositoryImp;
import com.uaes.android.data.http.FuelAccountApi;
import com.uaes.android.data.http.FuelManagerApi;
import com.uaes.android.data.http.GasStationApi;
import com.uaes.android.data.http.MaintenanceApi;
import com.uaes.android.data.http.S4ShopApi;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.http.TokenApi;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.LowFuelWarningDao;
import com.uaes.android.domain.CacheTimeRepository;
import com.uaes.android.domain.FuelAccountRepository;
import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.GasStationRepository;
import com.uaes.android.domain.MaintenanceRepository;
import com.uaes.android.domain.MessageRepository;
import com.uaes.android.domain.SecurityCheckRepository;
import com.uaes.android.domain.SettingRepository;
import com.uaes.android.domain.Super4SRepository;
import com.uaes.android.domain.TokenRepository;
import com.uaes.common.AuthProvider;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by aber on 1/24/2018.
 * Repository Provider.
 */

@Module
public abstract class RepositoryModule {

    @Provides
    @Singleton
    public static GasStationRepository gasStationRepository(GasStationApi api, UaesIotApplication app) {
        return new GasStationRepositoryImp(api, app.getResources());
    }

    @Provides
    @Singleton
    public static FuelAccountRepository fuelAccountRepository(UaesIotApplication context, FuelAccountApi api, Gson gson) {
        return new FuelAccountRepositoryImpl(context, api, gson);
    }


    @Provides
    @Singleton
    public static FuelManagerRepository fuelManagerRepository(UaesIotApplication context, FuelManagerApi api,
                                                              Gson gson, CacheDao dao) {
        return new FuelManagerRepositoryImpl(context.getApplicationContext(), api, gson, dao);
    }

    @Provides
    @Singleton
    public static SettingRepository settingRepository(LowFuelWarningDao dao, SettingApi api, Gson gson, UaesIotApplication context) {
        return new SettingRepositoryImpl(dao, api, gson, context);
    }

    @Provides
    @Singleton
    public static TokenRepository tokenRepository(AuthProvider sharedPreferences, TokenApi tokenApi,
                                                  UaesIotApplication application) {
        return new TokenRepositoryImp(sharedPreferences, tokenApi, application.getApplicationContext());
    }

    @Provides
    @Singleton
    public static MessageRepository messageRepository(CacheDao dao, UaesIotApplication context) {
        return new MessageRepositoryImp(dao, context);
    }

    @Provides
    @Singleton
    public static Super4SRepository carSuper4SRepository(S4ShopApi api) {
        return new Super4SRepositoryImp(api);
    }

    @Provides
    @Singleton
    public static MaintenanceRepository carRepository(MaintenanceApi api, CacheDao dao, UaesIotApplication app) {
        return new MaintenanceRepositoryImpl(api, dao, app);
    }

    @Provides
    @Singleton
    public static CacheTimeRepository timeRepository(CacheDao dao) {
        return new CacheTimeRepositoryImp(dao);
    }

    @Provides
    @Singleton
    public static SecurityCheckRepository securityCheckRepository(SharedPreferences sh, UaesIotApplication app) {
        return new SecurityCheckRepositoryImp(app, sh);
    }

}
