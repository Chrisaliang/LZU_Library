package com.uaes.android.viewobservable;

import android.content.Intent;
import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.graphics.drawable.Drawable;
import android.view.View;

import com.uaes.android.BR;
import com.uaes.android.domain.pojo.DomainAd;
import com.uaes.android.ui.gasstation.MapMarkerActivity;
import com.uaes.android.ui.maintenance.listener.GoFourSShopClickListener;
import com.uaes.android.viewmodel.SparkingPlugViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Author : 张 涛
 * Time : 2018/1/24.
 * Des : This is
 */

public class EngineOilViewObservable extends BaseObservable implements GoFourSShopClickListener {
    private int engineOilHealth;//机油健康度0~100

    private String engineOilMileage;//剩余行驶里程

    private String title;//建议头

    private String suggest;//建议实体

    private int healthTag;//健康分类  0：表示健康   1：不健康（尽快） 2：不健康（立即）

    private int mainColor;//主要的色调

    private Drawable leftBackFrame;//左边的色调边框

    private Drawable rightBackFrame;//右边的色调边框

    private SparkingPlugViewModel mSparkingPlugViewModel;

    private int status = RetryView.RETRY_LOADING;

    public EngineOilViewObservable(SparkingPlugViewModel mSparkingPlugViewModel) {
        this.mSparkingPlugViewModel = mSparkingPlugViewModel;
    }

    public void onClick(RetryView view) {
        mSparkingPlugViewModel.getCarState();
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public int getEngineOilHealth() {
        return engineOilHealth;
    }

    public void setEngineOilHealth(int engineOilHealth) {
        this.engineOilHealth = engineOilHealth;
        notifyPropertyChanged(BR.engineOilHealth);
    }

    @Bindable
    public String getEngineOilMileage() {
        return engineOilMileage;
    }

    public void setEngineOilMileage(String engineOilMileage) {
        this.engineOilMileage = engineOilMileage;
        notifyPropertyChanged(BR.engineOilMileage);
    }

    @Bindable
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
        notifyPropertyChanged(BR.title);
    }

    @Bindable
    public String getSuggest() {
        return suggest;
    }

    public void setSuggest(String suggest) {
        this.suggest = suggest;
        notifyPropertyChanged(BR.suggest);
    }

    @Bindable
    public int getHealthTag() {
        return healthTag;
    }

    public void setHealthTag(int healthTag) {
        this.healthTag = healthTag;
        notifyPropertyChanged(BR.healthTag);
    }

    @Bindable
    public int getMainColor() {
        return mainColor;
    }

    public void setMainColor(int mainColor) {
        this.mainColor = mainColor;
        notifyPropertyChanged(BR.mainColor);
    }

    @Bindable
    public Drawable getLeftBackFrame() {
        return leftBackFrame;
    }

    public void setLeftBackFrame(Drawable leftBackFrame) {
        this.leftBackFrame = leftBackFrame;
        notifyPropertyChanged(BR.leftBackFrame);
    }

    @Bindable
    public Drawable getRightBackFrame() {
        return rightBackFrame;
    }

    public void setRightBackFrame(Drawable rightBackFrame) {
        this.rightBackFrame = rightBackFrame;
        notifyPropertyChanged(BR.rightBackFrame);
    }

    @Override
    public void onGoClick(View view) {
        Intent intent = new Intent(view.getContext(), MapMarkerActivity.class);
        intent.putExtra(MapMarkerActivity.EXTRA_TYPE, MapMarkerActivity.SHOP_$_TAG);
        intent.putExtra(MapMarkerActivity.EXTRA_SUBTYPE, DomainAd.AD_TYPE_ENGINE_OIL);
        view.getContext().startActivity(intent);
    }
}
