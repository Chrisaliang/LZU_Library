package com.uaes.android.ui.gasstation;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.lcodecore.tkrefreshlayout.IBottomView;
import com.uaes.android.R;

/**
 * Created by Chrisaliang on 2017/10/30.
 * footer view for refresh layout
 */

public class GasFooterView extends FrameLayout implements IBottomView {

    private ImageView refreshArrow;
    private ImageView loadingView;
    private TextView refreshTextView;
    private String pullUpStr = "上拉刷新";
    private String releaseRefreshStr = "释放刷新";
    private String refreshingStr = "正在刷新";

    public GasFooterView(Context context) {
        this(context, null);
    }

    public GasFooterView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public GasFooterView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        View rootView = View.inflate(getContext(), com.lcodecore.tkrefreshlayout.R.layout.view_sinaheader, null);
        refreshArrow = rootView.findViewById(com.lcodecore.tkrefreshlayout.R.id.iv_arrow);
        refreshTextView = rootView.findViewById(com.lcodecore.tkrefreshlayout.R.id.tv);
        refreshTextView.setTextColor(getResources().getColor(R.color.gas_station_list_refresh_dark));
        loadingView = rootView.findViewById(com.lcodecore.tkrefreshlayout.R.id.iv_loading);
        addView(rootView);
    }

    public void setArrowResource(@DrawableRes int resId) {
        refreshArrow.setImageResource(resId);
    }

    public void setTextColor(@ColorInt int color) {
        refreshTextView.setTextColor(color);
    }

    public void setPullUpStr(String pullUpStr1) {
        pullUpStr = pullUpStr1;
    }

    public void setReleaseRefreshStr(String releaseRefreshStr1) {
        releaseRefreshStr = releaseRefreshStr1;
    }

    public void setRefreshingStr(String refreshingStr1) {
        refreshingStr = refreshingStr1;
    }

    @Override
    public View getView() {
        return this;
    }

    @Override
    public void onPullingUp(float fraction, float maxBottomHeight, float bottomHeight) {
        if (fraction < 1f) refreshTextView.setText(pullUpStr);
        if (fraction > 1f) refreshTextView.setText(releaseRefreshStr);
//        refreshArrow.setRotation(fraction * headHeight / maxHeadHeight * 180);
    }

    @Override
    public void onPullReleasing(float fraction, float maxHeadHeight, float headHeight) {
        if (fraction < 1f) {
            refreshTextView.setText(pullUpStr);
//            refreshArrow.setRotation(fraction * headHeight / maxHeadHeight * 180);
            if (refreshArrow.getVisibility() == GONE) {
                refreshArrow.setVisibility(VISIBLE);
                loadingView.setVisibility(GONE);
            }
        }
    }

    @Override
    public void onFinish() {
        AnimationDrawable drawable = (AnimationDrawable) loadingView.getDrawable();
        if (drawable.isRunning()) {
            drawable.stop();
        }
    }

    @Override
    public void startAnim(float maxHeadHeight, float headHeight) {
        refreshTextView.setText(refreshingStr);
        refreshArrow.setVisibility(GONE);
        loadingView.setVisibility(VISIBLE);
        ((AnimationDrawable) loadingView.getDrawable()).start();
    }

    @Override
    public void reset() {
        refreshArrow.setVisibility(VISIBLE);
        loadingView.setVisibility(GONE);
        refreshTextView.setText(pullUpStr);
    }
}
