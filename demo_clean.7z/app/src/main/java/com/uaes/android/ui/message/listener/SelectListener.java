package com.uaes.android.ui.message.listener;

import android.view.View;

/**
 * Author : 张 涛
 * Time : 2018/1/17.
 * Des : This is
 */

public interface SelectListener {

    void onClick(View view);
}
