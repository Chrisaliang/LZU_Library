package com.uaes.android.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.uaes.android.domain.Super4SRepository;
import com.uaes.android.domain.pojo.Domain4SShop;
import com.uaes.android.domain.pojo.DomainAd;
import com.uaes.android.domain.pojo.DomainMyLocation;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/25.
 * Des : This is
 */

public class FourSShopsViewModel extends ViewModel {

    private static final String TAG = FourSShopsViewModel.class.getSimpleName();

    private final MutableLiveData<List<Domain4SShop>> fourSShops = new MutableLiveData<>();//4S店

    private final MutableLiveData<AMapLocation> location = new MutableLiveData<>();//当前定位的地点

    private final MutableLiveData<DomainAd> ad = new MutableLiveData<>();//广告

    private final Super4SRepository repository;

    private Disposable locationDisposable;

    private Disposable adDisposable;


    public FourSShopsViewModel(Super4SRepository repository) {
        this.repository = repository;
    }

    public LiveData<List<Domain4SShop>> getFourSShopList() {
        return fourSShops;
    }

    public LiveData<AMapLocation> getLocation() {
        return location;
    }

    public LiveData<DomainAd> getAdFromType() {
        return ad;
    }

    public void getFourSShops(AMapLocationClient client) {
        repository.get4SShop(client).subscribe(new SingleObserver<DomainMyLocation<List<Domain4SShop>>>() {

            @Override
            public void onSubscribe(Disposable d) {
                locationDisposable = d;
            }

            @Override
            public void onSuccess(DomainMyLocation<List<Domain4SShop>> listDomainMyLocation) {
                fourSShops.setValue(listDomainMyLocation.dataSet);
                location.setValue(listDomainMyLocation.myLocation);
            }

            @Override
            public void onError(Throwable e) {
                fourSShops.setValue(null);
                Timber.tag(TAG).e(e, "get 4S shop error.");
            }
        });
    }

    public void getAD(String type) {
        repository.getAd(type).subscribe(new SingleObserver<DomainAd>() {

            @Override
            public void onSubscribe(Disposable d) {
                adDisposable = d;
            }

            @Override
            public void onSuccess(DomainAd domainAd) {
                ad.setValue(domainAd);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e, "AD_onError");
            }
        });
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        if (adDisposable != null)
            adDisposable.dispose();
        if (locationDisposable != null)
            locationDisposable.dispose();
    }
}
