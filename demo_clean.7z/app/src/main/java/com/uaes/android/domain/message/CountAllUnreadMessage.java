package com.uaes.android.domain.message;

import android.util.ArrayMap;

import com.uaes.android.data.room.MessagePushEntity;
import com.uaes.android.domain.MessageRepository;
import com.uaes.android.domain.UseCase;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by Chrisaliang on 2018/3/8.
 * count unread message
 */
@Singleton
public class CountAllUnreadMessage implements UseCase<Map<String, Integer>> {

    private MessageRepository repository;

    @Inject
    public CountAllUnreadMessage(MessageRepository repository) {
        this.repository = repository;
    }

    @Override
    public Single<Map<String, Integer>> execute() {
        Single<Integer> advice = repository.countUnreadMessage(MessagePushEntity.MESSAGE_CLASS_ADVICE);
        Single<Integer> malfunction = repository.countUnreadMessage(MessagePushEntity.MESSAGE_CLASS_MALFUNCTION);
        Single<Integer> notification = repository.countUnreadMessage(MessagePushEntity.MESSAGE_CLASS_NOTIFICATION);
        Single<Integer> warn = repository.countUnreadMessage(MessagePushEntity.MESSAGE_CLASS_WARN);
        Single<Map<String, Integer>> zipPackage = advice.zipWith(malfunction, (integer, integer2) -> {
            Map<String, Integer> zip = new ArrayMap<>();
            zip.put(MessagePushEntity.MESSAGE_CLASS_ADVICE, integer);
            zip.put(MessagePushEntity.MESSAGE_CLASS_MALFUNCTION, integer2);
            return zip;
        }).zipWith(notification, (stringIntegerMap, integer) -> {
            stringIntegerMap.put(MessagePushEntity.MESSAGE_CLASS_NOTIFICATION, integer);
            return stringIntegerMap;
        }).zipWith(warn, (stringIntegerMap, integer) -> {
            stringIntegerMap.put(MessagePushEntity.MESSAGE_CLASS_WARN, integer);
            return stringIntegerMap;
        });
        return zipPackage.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
