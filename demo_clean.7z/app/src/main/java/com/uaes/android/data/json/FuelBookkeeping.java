package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Administrator on 2017/11/10 0010.
 * account 加油记账
 */

public class FuelBookkeeping {

    //加油站名称
    @SerializedName("gasName")
    public String fuelStation;

    // 加油事件ID
    @SerializedName("eventId")
    public int eventId;

    //加油日期
    @SerializedName("fillDate")
    public String fillingDate;

    //汽油牌号
    @SerializedName("fuelGrade")
    public String fuelGrade;

    //总油费（元）
    @SerializedName("fillCost")
    public double fuelCost;

    //油单价（元/升）
    @SerializedName("fillPrice")
    public double fuelPrice;

    //油等级评价
    @SerializedName("evaluate")
    public int evaluate;

    @Override
    public String toString() {
        return "FuelBookkeeping{" +
                "fuelStation='" + fuelStation + '\'' +
                ", eventId=" + eventId +
                ", fillingDate='" + fillingDate + '\'' +
                ", fuelGrade='" + fuelGrade + '\'' +
                ", fuelCost=" + fuelCost +
                ", fuelPrice=" + fuelPrice +
                ", evaluate=" + evaluate +
                '}';
    }
}
