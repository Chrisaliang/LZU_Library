package com.uaes.android.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.uaes.android.R;
import com.uaes.android.view.FontTextView;

/**
 * Created by hand on 2017/11/9.
 * FuelNumber picker
 */

@BindingMethods({
        @BindingMethod(type = FuelNumberPicker.class, attribute = "onItemSelected", method = "setOnItemSelectedListener")
})
public class FuelNumberPicker extends FrameLayout {

    private AdapterView.OnItemClickListener onItemSelectedListener;
    private final AdapterView.OnItemClickListener delegate = new AdapterView.OnItemClickListener() {

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
            if (onItemSelectedListener != null)
                onItemSelectedListener.onItemClick(adapterView, view, position, l);
        }
    };
    private View displayView;
    private ListView listView;
    private FontTextView tvValue;
//    private boolean isEdit;

    public FuelNumberPicker(@NonNull Context context) {
        this(context, null);
    }

    public FuelNumberPicker(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FuelNumberPicker(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public FuelNumberPicker(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs);
    }

    @BindingAdapter(value = "onItemSelected")
    public static void setOnItemSelectedListener(FuelNumberPicker view, AdapterView.OnItemClickListener listener) {
        view.onItemSelectedListener = listener;
    }

    private void init(Context context, AttributeSet attrs) {
        inflate(context, R.layout.widget_fuel_number_picker, this);

        displayView = findViewById(R.id.label_layout);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.FuelNumberPicker);
        ImageView topIcon = findViewById(R.id.label_icon);
        Drawable labelIcon = a.getDrawable(R.styleable.FuelNumberPicker_picker_icon);
        if (labelIcon != null)
            topIcon.setImageDrawable(labelIcon);
        String labelTitle = a.getString(R.styleable.FuelNumberPicker_picker_title);
        TextView tvLabelTitle = findViewById(R.id.label_title);
        tvLabelTitle.setText(labelTitle);

        listView = findViewById(R.id.number_picker);
        listView.setOnItemClickListener(delegate);

        Drawable endIcon = a.getDrawable(R.styleable.FuelNumberPicker_picker_end_icon);
        tvValue = findViewById(R.id.label_value);
        if (endIcon != null)
            tvValue.setCompoundDrawables(null, null, endIcon, null);

        int padding = a.getDimensionPixelSize(R.styleable.FuelNumberPicker_picker_drawable_padding, 0);
        tvValue.setCompoundDrawablePadding(padding);

        int textSize = a.getDimensionPixelSize(R.styleable.FuelNumberPicker_picker_title_size, 32);
        tvValue.setTextSize(textSize);

        int color = a.getColor(R.styleable.FuelNumberPicker_picker_titleColor, Color.WHITE);
        tvValue.setTextColor(color);
        a.recycle();
    }

    public void setAdapter(ListAdapter adapter) {
        listView.setAdapter(adapter);
    }

//    public boolean isEdit() {
//        return isEdit;
//    }

    public void setEdit(boolean isEdit) {
        if (isEdit) {
            listView.setVisibility(VISIBLE);
            displayView.setVisibility(INVISIBLE);
        } else {
            listView.setVisibility(INVISIBLE);
            displayView.setVisibility(VISIBLE);
        }
//        this.isEdit = isEdit;
//        toggle(isEdit);
//    }

//    private void toggle(boolean isEdit) {
//        if (isEdit) {
//            listView.setVisibility(VISIBLE);
//            displayView.setVisibility(INVISIBLE);
//        } else {
//            listView.setVisibility(INVISIBLE);
//            displayView.setVisibility(VISIBLE);
//        }
    }

    public void setValue(CharSequence item) {
        tvValue.setText(item);
    }
}
