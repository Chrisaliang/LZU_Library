package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.uaes.android.BR;
import com.uaes.android.domain.pojo.Domain4SShop;

/**
 * Author : 张 涛
 * Time : 2018/1/26.
 * Des : This is
 */

public class FourSShopsObservable extends BaseObservable {

    // 4S 店名字
    private String name;

    // 地址
    private String serviceAddress;

    // 服务电话
    private String serviceTel;

    // 距离
    private int distance;

    // 耗时
    private int duration;

    // 经度
    private double longitude;

    //维度
    private double latitude;

    //当前位置
    private final int position;

    private boolean isSelected;


    public FourSShopsObservable(Domain4SShop shop, int position) {
        this.name = (position + 1) + "." + shop.name;
        this.serviceAddress = shop.serviceAddress;
        this.serviceTel = shop.serviceTel;
        this.distance = shop.distance;
        this.duration = shop.duration;
        this.longitude = shop.longitude;
        this.latitude = shop.latitude;
        this.position = position;
        this.isSelected = false;
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
    }

    @Bindable
    public String getServiceAddress() {
        return serviceAddress;
    }

    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
        notifyPropertyChanged(BR.serviceAddress);
    }

    @Bindable
    public String getServiceTel() {
        return serviceTel;
    }

    public void setServiceTel(String serviceTel) {
        this.serviceTel = serviceTel;
        notifyPropertyChanged(BR.serviceTel);
    }

    @Bindable
    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
        notifyPropertyChanged(BR.distance);
    }

    @Bindable
    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
        notifyPropertyChanged(BR.duration);
    }

    @Bindable
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
        notifyPropertyChanged(BR.longitude);
    }

    @Bindable
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
        notifyPropertyChanged(BR.latitude);
    }

    @Bindable
    public int getPosition() {
        return position;
    }

    @Bindable
    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
        notifyPropertyChanged(BR.selected);
    }
}
