package com.uaes.android.ui.maintenance.engineoil;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentEngineOilBinding;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewmodel.SparkingPlugViewModel;
import com.uaes.android.viewobservable.EngineOilViewObservable;

import javax.inject.Inject;

/**
 * Author : 张 涛
 * Time : 2018/1/10.
 * Des : This is 机油Fragment界面
 */

public class EngineOilFragment extends NavigatorFragment {
    private static final String TAG = EngineOilFragment.class.getSimpleName();
    @Inject
    RepositoryVMProvider factory;
    private FragmentEngineOilBinding binding;
    private SparkingPlugViewModel viewModel;
    private EngineOilViewObservable mEngineOilViewObservable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(SparkingPlugViewModel.class);
        mEngineOilViewObservable = new EngineOilViewObservable(viewModel);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_engine_oil, container, false);
//        binding.setListener(this);
        binding.setEngineoil(mEngineOilViewObservable);
        viewModel.getCarHealth().observe(this, domainCarHealth -> {
            if (domainCarHealth == null)
                return;
            mEngineOilViewObservable.setEngineOilHealth(domainCarHealth.engineOilHealth);
            mEngineOilViewObservable.setEngineOilMileage(domainCarHealth.engineOilMileage + "KM");
            if (domainCarHealth.engineOilStatus == 2) {
                mEngineOilViewObservable.setTitle(getString(R.string.engine_oil_danger_hint));
                mEngineOilViewObservable.setSuggest(getString(R.string.engine_oil_danger_suggest));
                mEngineOilViewObservable.setHealthTag(2);
                mEngineOilViewObservable.setMainColor(getResources().getColor(R.color.ring_chart_ring_color_empty));
                mEngineOilViewObservable.setLeftBackFrame(getResources().getDrawable(R.drawable.engineoil_ill_now_magnet_first));
                mEngineOilViewObservable.setRightBackFrame(getResources().getDrawable(R.drawable.engineoil_ill_now_magnet_second));
            } else if (domainCarHealth.engineOilStatus == 1) {
                mEngineOilViewObservable.setTitle(getString(R.string.engine_oil_danger_hint));
                mEngineOilViewObservable.setSuggest(getString(R.string.engine_oil_warn_suggest));
                mEngineOilViewObservable.setHealthTag(1);
                mEngineOilViewObservable.setMainColor(getResources().getColor(R.color.ring_chart_ring_color_half));
                mEngineOilViewObservable.setLeftBackFrame(getResources().getDrawable(R.drawable.engineoil_ill_fast_magnet_first));
                mEngineOilViewObservable.setRightBackFrame(getResources().getDrawable(R.drawable.engineoil_ill_fast_magnet_second));
            } else if (domainCarHealth.engineOilStatus == 0) {
                mEngineOilViewObservable.setTitle(getString(R.string.engine_oil_health_hint));
                mEngineOilViewObservable.setSuggest(getString(R.string.engine_oil_health_suggest));
                mEngineOilViewObservable.setHealthTag(0);
                mEngineOilViewObservable.setMainColor(getResources().getColor(R.color.ring_chart_ring_color_full));
                mEngineOilViewObservable.setLeftBackFrame(getResources().getDrawable(R.drawable.engineoil_healthy_magnet_first));
                mEngineOilViewObservable.setRightBackFrame(getResources().getDrawable(R.drawable.engineoil_healthy_magnet_second));
            }
            refreshTime(Tables.CAR_HEALTH.TABLE_NAME);
        });

        viewModel.getStatue().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            mEngineOilViewObservable.setStatus(integer);
        });
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void refresh() {
        super.refresh();
        viewModel.getCarState();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onStart() {
        super.onStart();
        viewModel.getCarState();
    }

    @Override
    public void onPause() {
        super.onPause();
    }


}
