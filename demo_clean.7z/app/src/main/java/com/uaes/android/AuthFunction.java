package com.uaes.android;

import android.content.Context;
import android.support.v4.content.LocalBroadcastManager;

import io.reactivex.functions.Function;
import retrofit2.HttpException;
import timber.log.Timber;

/**
 * Created by Chrisaliang on 2017/12/7.
 * Function
 */

public class AuthFunction<R> implements Function<Throwable, R> {
    private static final String TAG = AuthFunction.class.getSimpleName();

    private LocalBroadcastManager mLocalBroadcastManager;

    public AuthFunction(Context context) {
        this.mLocalBroadcastManager = LocalBroadcastManager
                .getInstance(context.getApplicationContext());
    }

    @Override
    public R apply(Throwable e) throws Exception {
        if (e instanceof HttpException) {
            Timber.tag(TAG).e(e);
//            HttpException exception = (HttpException) e;
//            if (exception.code() == 401) {
//                Intent intent = new Intent(Intents.ACTION_AUTHORIZATION);
//                mLocalBroadcastManager.sendBroadcast(intent);
//            }
        }
        throw (Exception) e;
    }
}
