package com.uaes.android.data.room;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;
import android.arch.persistence.room.Update;

import com.uaes.android.data.json.CacheTimestamp;
import com.uaes.android.data.json.CarHealth;
import com.uaes.android.data.json.FuelFillHistory;
import com.uaes.android.data.json.FuelFillRecordPoint;
import com.uaes.android.data.json.FuelSingleFillRecord;
import com.uaes.android.data.json.FuelStatus;
import com.uaes.android.data.json.SingleFuelRecord;

import java.util.Date;
import java.util.List;

import io.reactivex.Single;

/**
 * Created by aber on 1/17/2018.
 * Cache Operation.
 */
@Dao
public abstract class CacheDao {
    //----------------------query--------------------------//

    /**
     * 获取加油记录点
     */
    @Query("SELECT * FROM " + Tables.FUEL_RECORD_POINT.TABLE_NAME)
    public abstract Single<List<FuelFillRecordPoint>> queryFuelRecord();

    /**
     * 获取用油状态
     */
    @Query("SELECT * FROM " + Tables.FUEL_STATUS.TABLE_NAME + " LIMIT 1")
    public abstract Single<FuelStatus> queryFuelStatus();

    /**
     * 获取用油历史
     */
    @Query("SELECT * FROM " + Tables.FUEL_FILL_HISTORY.TABLE_NAME + " LIMIT 1")
    public abstract Single<FuelFillHistory> queryFuelHistoryYear();

    /**
     * 获取用油历史
     */
    @Query("SELECT * FROM " + Tables.FUEL_FILL_HISTORY.TABLE_NAME + " LIMIT 1")
    public abstract Single<FuelFillHistory> queryFuelHistoryMile();

    /**
     * 获取时间戳
     */
    @Query("SELECT * FROM " + Tables.CACHE_EXPIRE.TABLE_NAME + " WHERE "
            + Tables.CACHE_EXPIRE.COLUMN_TABLE_NAME + "=:name")
    public abstract Single<CacheTimestamp> queryTimestampOfTable(String name);

    /**
     * 获取单次加油记录
     */
    @Query("SELECT * FROM " + Tables.FUEL_SINGLE_FILL_RECORD.TABLE_NAME)
    public abstract Single<List<FuelSingleFillRecord>> queryFuelSingleRecord();

    /**
     * 获取单次加油记录 总集数
     */
    @Query("SELECT * FROM " + Tables.FUEL_SINGLE_FILL_RECORD_COUNT.TABLE_NAME + " LIMIT 1")
    public abstract Single<SingleFuelRecord> querySingleRecordCount();


    /**
     * 查询车辆健康度
     */
    @Query("SELECT * FROM " + Tables.CAR_HEALTH.TABLE_NAME + " WHERE id = 0")
    public abstract Single<CarHealth> queryCarHealth();

    /**
     * 统计某类型休息未读数量
     */
    @Query("select count(*) from " + Tables.PUSH_MESSAGE.TABLE_NAME + " where "
            + Tables.PUSH_MESSAGE.COLUMN_HAS_READ + " = " + MessagePushEntity.MESSAGE_UNREAD + " and "
            + Tables.PUSH_MESSAGE.COLUMN_MESSAGE_CLASS + " = :messageClass")
    public abstract Integer countUnreadMessage(String messageClass);

    /**
     * 查询大类消息
     *
     * @param type 消息大类
     * @return 消息列表数据
     */
    @Query("select * from " + Tables.PUSH_MESSAGE.TABLE_NAME + " where "
            + Tables.PUSH_MESSAGE.COLUMN_MESSAGE_CLASS + " = :type")
    public abstract MessagePushEntity[] queryMessagePushType(String type);


    @Query("select * from " + Tables.PUSH_MESSAGE.TABLE_NAME + " where "
            + Tables.PUSH_MESSAGE.COLUMN_HAS_READ + " = " + MessagePushEntity.MESSAGE_UNREAD)
    public abstract MessagePushEntity[] queryMessagePushNoRead();


    //----------------------insert or update-----------------------------//

    /**
     * 插入车辆健康度
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract void insertCarHealth(CarHealth carHealth);

    /**
     * 插入用油状态记录
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract void insertFuelStatus(FuelStatus... fuelStatuses);

    /**
     * 插入用油历史
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract void insertFuelHistory(FuelFillHistory... fillHistory);

    /**
     * 插入加油记录点
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract void insertFuelFillRecordPoint(List<FuelFillRecordPoint> lists);

    /**
     * 插入单词加油记录点
     */
    @Insert
    abstract void insertFuelSingleFillRecord(List<FuelSingleFillRecord> records);

    /**
     * 更新时间戳
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract void updateCacheTimestamp(CacheTimestamp... timestamps);

    /**
     * 插入当前翻页状态
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract void updateFuelSingleFillCount(SingleFuelRecord record);

    /**
     * 插入推送消息
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract long[] insertMessagePush(MessagePushEntity... entity);

    @Transaction
    public void insertMessagePushWithTime(MessagePushEntity... entities) {
        insertMessagePush(entities);
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.PUSH_MESSAGE.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
    }

    @Delete
    public abstract int deleteMessage(MessagePushEntity... entity);

    @Transaction
    public void deleteMessageWithTime(MessagePushEntity... entities) {
        deleteMessage(entities);
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.PUSH_MESSAGE.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
    }


    @Update
    public abstract int updateMessage(MessagePushEntity... entity);

    @Transaction
    public void updateMessageWithTime(MessagePushEntity... entities) {
        updateMessage(entities);
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.PUSH_MESSAGE.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
    }

    // ------------clear cache--------------//

    /**
     * 清除加油记录点
     */
    @Query("DELETE FROM " + Tables.FUEL_RECORD_POINT.TABLE_NAME)
    abstract void clearFuelRecordPoint();

    /**
     * 清除用油状态
     */
    @Query("DELETE FROM " + Tables.FUEL_STATUS.TABLE_NAME)
    abstract void clearFuelStatus();

    /**
     * 清除用油历史
     */
    @Query("DELETE FROM " + Tables.FUEL_FILL_HISTORY.TABLE_NAME)
    abstract void clearFuelHistory();

    /**
     * 清除单次加油记录
     */
    @Query("DELETE FROM " + Tables.FUEL_SINGLE_FILL_RECORD.TABLE_NAME)
    abstract void clearFuelSingleFillRecord();

    //------------------ operation transaction for easy usage ----------------//

    /**
     * 替换加油记录点
     */
    @Transaction
    public void replaceFuelFillRecordPoint(List<FuelFillRecordPoint> lists) {
        clearFuelRecordPoint();
        for (int i = 0; i < lists.size(); i++) {
            lists.get(i).id = i;
        }
        CacheTimestamp timestamp = new CacheTimestamp(Tables.FUEL_RECORD_POINT.TABLE_NAME, new Date());
        updateCacheTimestamp(timestamp);
        insertFuelFillRecordPoint(lists);
    }

    /**
     * 替换用油状态
     */
    @Transaction
    public void replaceFuelStatus(FuelStatus status) {
        clearFuelStatus();
        status.id = 0;
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.FUEL_STATUS.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
        insertFuelStatus(status);
    }

    /**
     * 替换用油历史 根据年份
     */
    @Transaction
    public void replaceFuelHistoryYear(FuelFillHistory fillHistory) {
        clearFuelHistory();
        fillHistory.id = 0;
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.FUEL_FILL_HISTORY.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
        insertFuelHistory(fillHistory);
    }

    /**
     * 替换用油历史 根据里程
     */
    @Transaction
    public void replaceFuelHistoryMile(FuelFillHistory fillHistory) {
        clearFuelHistory();
        fillHistory.id = 0;
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.FUEL_FILL_HISTORY.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
        insertFuelHistory(fillHistory);
    }

    /**
     * 替换单次加油记录
     */
    @Transaction
    public void replaceFuelSingleFillRecord(SingleFuelRecord records) {
        clearFuelSingleFillRecord();
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.FUEL_SINGLE_FILL_RECORD.TABLE_NAME,
                new Date()
        );
        updateCacheTimestamp(timestamp);
        records.name = Tables.FUEL_SINGLE_FILL_RECORD.TABLE_NAME;
        updateFuelSingleFillCount(records);
        insertFuelSingleFillRecord(records.page.content);
    }

    /**
     * 替换车辆健康信息
     */
    @Transaction
    public void replaceCarHealth(CarHealth carHealth) {
        CacheTimestamp timestamp = new CacheTimestamp(
                Tables.CAR_HEALTH.TABLE_NAME,
                new Date()
        );
        carHealth.id = 0;
        insertCarHealth(carHealth);
        updateCacheTimestamp(timestamp);
    }
}
