package com.uaes.android.ui.fuelaccount;

import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

import com.uaes.android.widget.FuelAccountTabView;
import com.uaes.android.widget.RatingBar;

/**
 * Created by Chrisaliang on 2018/2/6.
 * fuel account listener
 */

public interface FuelAccountListener extends View.OnClickListener,
        RatingBar.OnRatingChangeListener {

    void onItemClick(AdapterView<?> parent, View view, int position, long id);

    boolean onEditorAction(FuelAccountTabView parent, TextView v, int actionId, KeyEvent event);

}
