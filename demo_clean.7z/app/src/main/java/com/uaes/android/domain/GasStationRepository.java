package com.uaes.android.domain;

import com.uaes.android.viewmodel.GasStationViewModel;

import java.util.List;

import io.reactivex.Single;

/**
 * Created by Chrisaliang on 2017/11/2.
 * interface 加油站地图 数据接口
 */

public interface GasStationRepository {

    Single<List<GasStationViewModel>> gasStationList(double lat, double lon, int strategy);
}
