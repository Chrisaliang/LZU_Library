package com.uaes.android.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.pojo.DomainFuelState;
import com.uaes.android.widget.RetryView;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by aber on 11/27/2017.
 * Fuel State View model
 */

public class FuelStateViewModel extends ViewModel implements SingleObserver<DomainFuelState> {
    private static final String TAG = "FuelStateViewModel";

    private final MutableLiveData<DomainFuelState> fuelStatus = new MutableLiveData<>();

    private final MutableLiveData<Integer> status = new MutableLiveData<>();

    private final FuelManagerRepository managerRepository;

    private Disposable disposable;

    FuelStateViewModel(FuelManagerRepository managerRepository) {
        this.managerRepository = managerRepository;
    }

    public void update() {
        managerRepository.getFuelStatus().subscribe(this);
    }

    public LiveData<DomainFuelState> getFuelStatus() {
        return fuelStatus;
    }

    public LiveData<Integer> getStatue() {
        return status;
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSubscribe(Disposable d) {
        disposable = d;
        status.setValue(RetryView.RETRY_LOADING);
    }

    @Override
    public void onSuccess(DomainFuelState o) {
        fuelStatus.setValue(o);
        status.setValue(RetryView.RETRY_GONE);
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).d(e, "FuelStatus update error: ");
        status.postValue(RetryView.RETRY_RETRY);
    }
}
