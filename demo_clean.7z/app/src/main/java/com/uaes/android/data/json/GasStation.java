package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Chrisaliang on 2017/11/1.
 * data for station
 */

@SuppressWarnings("WeakerAccess")
public class GasStation {

    @SerializedName("name")
    public String stationName;

    @SerializedName("address")
    public String stationAddr;

    @SerializedName("brand")
    public String stationBrand;

    @SerializedName("distance")
    public int stationDistance;

    @SerializedName("duration")
    public int stationDuration;

    @SerializedName("rate")
    public float stationRate;

    @SerializedName("latitude")
    public double lat;

    @SerializedName("longitude")
    public double lon;

    @SerializedName("fillTime")
    public int fillTime;
}
