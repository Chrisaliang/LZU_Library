package com.uaes.android.data.maper;

import android.util.SparseBooleanArray;

import com.uaes.android.data.json.CarHealth;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.domain.pojo.DomainCarHealth;

/**
 * Created by Chrisaliang on 2018/1/24.
 * mapper car health data to domain data
 */

public class CarHealthMapper {

    private final static int SPARK_PLUG_1 = 1;
    private final static int SPARK_PLUG_2 = 2;
    private final static int SPARK_PLUG_3 = 4;
    private final static int SPARK_PLUG_4 = 8;

    public void map(GeneralAttributeReceive<CarHealth> receive, DomainCarHealth health) throws Exception {
        map(receive.msgContent, health);
    }

    public void map(CarHealth carHealth, DomainCarHealth health) throws Exception {
        health.batteryStatus = carHealth.batteryState;
        health.engineOilHealth = (int) carHealth.engineOilHealth;
        health.engineOilMileage = (int) carHealth.engineOilMileage;
        health.engineOilStatus = carHealth.engineOilState;
        int sparkPlugs = carHealth.sparkPlugState;
        if (sparkPlugs > 15 || sparkPlugs < 0)
            throw new Exception("spark plug status is more than 15 or less than 0");
        health.sparkingPlugs = new SparseBooleanArray();
        health.sparkingPlugs.append(0, !((sparkPlugs & SPARK_PLUG_4) == SPARK_PLUG_4));
        health.sparkingPlugs.append(1, !((sparkPlugs & SPARK_PLUG_3) == SPARK_PLUG_3));
        health.sparkingPlugs.append(3, !((sparkPlugs & SPARK_PLUG_1) == SPARK_PLUG_1));
        health.sparkingPlugs.append(2, !((sparkPlugs & SPARK_PLUG_2) == SPARK_PLUG_2));
    }
}
