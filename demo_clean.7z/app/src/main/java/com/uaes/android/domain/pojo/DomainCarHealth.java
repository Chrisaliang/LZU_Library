package com.uaes.android.domain.pojo;

import android.util.SparseBooleanArray;

/**
 * Created by aber on 1/22/2018.
 * 车状态健康
 */

public class DomainCarHealth {

    public final static DomainCarHealth EMPTY = new DomainCarHealth();

    /**
     * 0- 零号火花塞
     * 1- 一号火花塞
     * 2- 二号火花塞
     * 3- 三号火花塞
     */
    public SparseBooleanArray sparkingPlugs;

    /**
     * 机油健康度
     * 0-100%
     */
    public int engineOilHealth;

    /**
     * 是否立即更换0 ,1 , 2
     * 健康：0； 尽快更换： 1； 立即更换：2
     */
    public int engineOilStatus;

    /**
     * 电池状态 0 ，1
     * 健康：0；不健康：1
     */
    public int batteryStatus;

    /**
     * 机油剩余里程
     */
    public int engineOilMileage;
}
