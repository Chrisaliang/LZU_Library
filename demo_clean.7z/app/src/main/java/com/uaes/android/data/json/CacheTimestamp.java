package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import java.util.Date;

import static com.uaes.android.data.room.Tables.CACHE_EXPIRE.COLUMN_TABLE_NAME;
import static com.uaes.android.data.room.Tables.CACHE_EXPIRE.COLUMN_TIMESTAMP;
import static com.uaes.android.data.room.Tables.CACHE_EXPIRE.TABLE_NAME;

/**
 * Created by aber on 1/17/2018.
 * Timestamp for each table
 */
@Entity(tableName = TABLE_NAME)
public class CacheTimestamp {

    @PrimaryKey
    public int id;
    @ColumnInfo(name = COLUMN_TABLE_NAME)
    @NonNull
    public String name;

    @ColumnInfo(name = COLUMN_TIMESTAMP)
    @NonNull
    public Date timestamp;

    public CacheTimestamp(@NonNull String name, @NonNull Date timestamp) {
        this.name = name;
        this.timestamp = timestamp;
    }
}
