package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.uaes.android.BR;
import com.uaes.android.domain.pojo.DomainFuelRecord;
import com.uaes.android.viewmodel.FuelRecordViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Created by Chrisaliang on 2017/12/5.
 * data binding for fuel record
 */

public class FuelRecordViewObservable extends BaseObservable {


    private final FuelRecordViewModel viewModel;

    private int status = RetryView.RETRY_LOADING;

    private DomainFuelRecord record = DomainFuelRecord.getEmptyRecord();

    public FuelRecordViewObservable(FuelRecordViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void onClick(RetryView view) {
        viewModel.update();
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }


    @Bindable
    public DomainFuelRecord getRecord() {
        return record;
    }

    public void setRecord(DomainFuelRecord fuelRecord) {
        this.record = fuelRecord;
        notifyPropertyChanged(BR.record);
    }
}
