package com.uaes.android.ui.gasstation;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.navi.model.NaviLatLng;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.lcodecore.tkrefreshlayout.header.SinaRefreshView;
import com.uaes.android.R;
import com.uaes.android.domain.GasStationRepository;
import com.uaes.android.view.decorator.SpaceItemDecoration;
import com.uaes.android.viewmodel.GasStationViewModel;
import com.uaes.android.widget.HomeMenuTabTextView;
import com.uaes.android.widget.RatingBar;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Author: tianbing
 * Date: 2017/10/19
 * Overview: 显示加油站标记点 列表并将列表锚点显示在地图上
 */

public class GasStationListFragment extends MapMarkerBaseFragment
        implements View.OnClickListener, GasUIListener,
        MapMarkerActivity.OnMarkerClickListener {

    private static final String TAG = GasStationListFragment.class.getSimpleName();

    @Inject
    GasStationRepository repository;

    private View layoutStationDetail;
    private GasStationAdapter adapter;
    private View btnGotoStation;
    private View additionDistance;
    private View additionTime;
    private View additionEvaluation;
    private View selectedAdditionView;
    private RecyclerView recyclerView;
    private List<Marker> markers;
    private TwinklingRefreshLayout refreshLayout;
    private ProgressBar mFirstLoadingBar;
    private View btRetry;
    private View layoutProgress;
    private GasFooterView bottomView;
    private GasStationUIAdapter uiAdapter;

    private boolean isDetailShow;
    private ViewStub viewStub;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adapter = new GasStationAdapter();
        uiAdapter = new GasStationUIAdapter(getActivity(), repository, mClient);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_stub_fragment_gas_station_station_list, container, false);
        viewStub = view.findViewById(R.id.stub_view);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        uiAdapter.registerListener(this);
        uiAdapter.requestLocation();
    }

    @Override
    public void onStop() {
        super.onStop();
        uiAdapter.unRegisterListener(this);
        uiAdapter.cancelRequest();
    }

    private void initView(View view) {
        layoutStationDetail = view.findViewById(R.id.layout_station_detail);
        layoutStationDetail.findViewById(R.id.iv_back).setOnClickListener(this);
        mListener.setOnMarkerClickListener(this);
        btnGotoStation = view.findViewById(R.id.btn_goto_station);
        btnGotoStation.setOnClickListener(this);
        additionDistance = view.findViewById(R.id.strategy_distance);
        additionTime = view.findViewById(R.id.strategy_time);
        additionEvaluation = view.findViewById(R.id.strategy_evaluation);
        additionDistance.setOnClickListener(this);
        additionTime.setOnClickListener(this);
        additionEvaluation.setOnClickListener(this);
        selectedAdditionView = additionDistance;
        refreshLayout = view.findViewById(R.id.twink_refresh);
        mFirstLoadingBar = view.findViewById(R.id.loading_layout);
        layoutProgress = view.findViewById(R.id.layout_progress);
        btRetry = view.findViewById(R.id.layout_fail);
        btRetry.setOnClickListener(this);
        refreshLayout.setOnRefreshListener(new HelperRefreshAdapter());
        bottomView = new GasFooterView(getActivity());
        SinaRefreshView headerView = new SinaRefreshView(getActivity());
        bottomView.setArrowResource(R.drawable.up_page);
        headerView.setArrowResource(R.drawable.ic_arrow_down);
        headerView.setTextColor(getResources().getColor(R.color.gas_station_list_refresh_dark));
        headerView.setPullDownStr(getResources()
                .getString(R.string.gas_station_station_list_previous_page));
        recyclerView = view.findViewById(R.id.rv_gas_station);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.addItemDecoration(new SpaceItemDecoration(getActivity()));
        recyclerView.setAdapter(adapter);
        selectedAdditionView.setSelected(true);
        refreshLayout.setBottomView(bottomView);
        refreshLayout.setHeaderView(headerView);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (refreshLayout != null)
            refreshLayout.removeAllViews();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiAdapter.onDestroy();
    }

    @Override
    public void onClick(View v) {
        if (v == btRetry) {
            startRetry();
        } else if (v.getId() == R.id.iv_back) {
            hideDetail();
        } else if (v == btnGotoStation) {
            if (adapter.index != -1) {
                GasStationViewModel item = adapter.getSelectedItem();
                AMapLocation location = uiAdapter.getLocation();
                if (item == null || location == null) return;
                mListener.onRouterShow(
                        new NaviLatLng(item.lat, item.lon));
            }
        } else {
            switchAddition(v);
        }
    }

    private void hideDetail() {
        refreshLayout.setVisibility(View.VISIBLE);
        layoutStationDetail.setVisibility(View.GONE);
        isDetailShow = false;
    }

    private void switchAddition(View clickView) {
        hideDetail();
        if (selectedAdditionView != null) {
            if (selectedAdditionView == clickView) return;
            else selectedAdditionView.setSelected(false);
        }
        selectedAdditionView = clickView;
        selectedAdditionView.setSelected(true);
        additionQuery();
    }

    private void additionQuery() {
        additionEnable(false);
        adapter.index = -1;
        layoutProgress.setVisibility(View.VISIBLE);
        mFirstLoadingBar.setVisibility(View.VISIBLE);
        btRetry.setVisibility(View.GONE);
        refreshLayout.setVisibility(View.GONE);
        int additionIndex = Integer.parseInt((String) selectedAdditionView.getTag(), 10);
        if (additionIndex != -1)
            uiAdapter.queryStation(additionIndex);
    }

    private void additionEnable(boolean enable) {
        additionDistance.setEnabled(enable);
        additionTime.setEnabled(enable);
        additionEvaluation.setEnabled(enable);
    }

    @Override
    public void onFirstLocationUpdate(AMapLocation location) {
        mListener.showListLayout();
        mListener.animateToLocation(new LatLng(location.getLatitude(), location.getLongitude()));
        try {
            View view = viewStub.inflate();
            initView(view);
        } catch (Exception e) {
            Timber.tag(TAG).e(e);
        }
        if (selectedAdditionView != null)
            additionQuery();
    }

    @Override
    public void onFirstLocationError() {
        Toast.makeText(getActivity(), R.string.gas_station_location_error_retry, Toast.LENGTH_SHORT).show();
        uiAdapter.requestLocation();
    }

    @Override
    public void onLocationUpdate(AMapLocation location) {
        mListener.animateToLocation(new LatLng(location.getLatitude(), location.getLongitude()));
        if (viewStub.getParent() != null) {
            View view = viewStub.inflate();
            initView(view);
        }
        if (selectedAdditionView != null)
            additionQuery();
    }

    @Override
    public void onLocationError(int error) {
        if (error == 404)
            Timber.tag(TAG).d("onLocationError: 定位未完成");
        else {
            Toast.makeText(getActivity(), R.string.gas_station_location_error_retry, Toast.LENGTH_SHORT).show();
            uiAdapter.requestLocation();
        }
    }

    @Override
    public void onFirstResultError() {
        Timber.tag(TAG).d("onFirstResultError: ");
        showResultFail();
    }

    @Override
    public void onResult(List<GasStationViewModel> resultList) {
        Timber.tag(TAG).d("onResult: %s", resultList);
        refreshLayout.finishRefreshing();
        refreshLayout.finishLoadmore();
        showServerResultSuccess(resultList);
    }

    @Override
    public void onNextResultError(int pageNum) {
        Timber.tag(TAG).d("onNextResultError: %s", pageNum);
        refreshLayout.finishLoadmore();
    }

    @Override
    public void onPreviousResultError(int pageNum) {
        Timber.tag(TAG).d("onPreviousResultError: %s", pageNum);
        refreshLayout.finishRefreshing();
    }

    @Override
    public void onNoMoreResult() {
        Timber.tag(TAG).d("onNoMoreResult: ");
        refreshLayout.finishLoadmore();
        bottomView.setPullUpStr(getString(R.string.gas_station_station_list_last_page));
    }

    @Override
    public void onFirstPageNumArrived() {
        Timber.tag(TAG).d("onFirstPageNumArrived: ");
        refreshLayout.finishRefreshing();
    }

    @Override
    public void onResultError() {
        Timber.tag(TAG).d("onResultError: ");
        showResultFail();
    }

    private void startRetry() {
        layoutProgress.setVisibility(View.VISIBLE);
        btRetry.setVisibility(View.GONE);
        mFirstLoadingBar.setVisibility(View.VISIBLE);
        additionQuery();
    }

    private void showServerResultSuccess(List<GasStationViewModel> resultList) {
        additionEnable(true);
        refreshLayout.setVisibility(View.VISIBLE);
        btnGotoStation.setVisibility(View.VISIBLE);
        hideDetail();
        adapter.index = -1;
        layoutProgress.setVisibility(View.GONE);
        recyclerView.scrollToPosition(0);
        bottomView.setPullUpStr(getResources().getString(R.string.gas_station_station_list_show_page_number, uiAdapter.getCurrentPage()));
        ArrayList<MarkerOptions> markerOptions = new ArrayList<>();
        for (GasStationViewModel gasStation : resultList) {
            MarkerOptions options = new MarkerOptions().position(new LatLng(gasStation.lat, gasStation.lon))
                    .draggable(false)
                    .title(gasStation.stationName)
                    .snippet(gasStation.stationAddr);
            markerOptions.add(options);
        }
        mListener.clearMarker();
        if (markerOptions.size() > 0)
            markers = mListener.updateMarker(markerOptions);
        adapter.update(resultList);
        adapter.selectItem(0);
    }

    private void showResultFail() {
        additionEnable(true);
        mFirstLoadingBar.setVisibility(View.GONE);
        btnGotoStation.setVisibility(View.GONE);
        refreshLayout.setVisibility(View.GONE);
        layoutProgress.setVisibility(View.VISIBLE);
        btRetry.setVisibility(View.VISIBLE);
    }

    private void showStationDetail(GasStationViewModel detailInfo) {
        isDetailShow = true;
        TextView stationName = layoutStationDetail.findViewById(R.id.station_name);
        HomeMenuTabTextView brand = layoutStationDetail.findViewById(R.id.station_brand);
        HomeMenuTabTextView location = layoutStationDetail.findViewById(R.id.station_location);
        HomeMenuTabTextView distance = layoutStationDetail.findViewById(R.id.station_distance);
        HomeMenuTabTextView time = layoutStationDetail.findViewById(R.id.station_time);
        RatingBar ratingBar = layoutStationDetail.findViewById(R.id.station_rate);
//        TextView tvFillTime = layoutStationDetail.findViewById(R.id.station_fill_time);
//        tvFillTime.setText(detailInfo.stationFillDuration);
        stationName.setText(detailInfo.stationName);
        brand.setText(detailInfo.stationBrand);
        location.setText(detailInfo.stationAddr);
        distance.setText(detailInfo.stationDistance);
        time.setText(detailInfo.stationDuration);
        if (detailInfo.stationRate == 0f)
            detailInfo.stationRate = 4.5f;
        ratingBar.setCount((int) detailInfo.stationRate);
        layoutStationDetail.setVisibility(View.VISIBLE);
        refreshLayout.setVisibility(View.GONE);
        mListener.animateToLocation(new LatLng(detailInfo.lat, detailInfo.lon));
    }

    @Override
    public void onMarkerClick(int index) {

        adapter.selectItem(index);
    }


    private class GasStationAdapter extends RecyclerView.Adapter<GasStationViewHolder> {

        final List<GasStationViewModel> stationList;
        int index = -1;

        GasStationAdapter() {
            stationList = new ArrayList<>();
        }

        @Override
        public GasStationViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View view;
            LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
            view = inflater.inflate(R.layout.item_gas_station_item_station_list, viewGroup, false);
            return new GasStationViewHolder(view);
        }

        @Override
        public void onBindViewHolder(GasStationViewHolder holder, int i) {
            holder.bind(stationList.get(i));
        }

        @Override
        public int getItemCount() {
            return stationList.size();
        }

        void update(List<GasStationViewModel> stationList) {
            this.stationList.clear();
            this.stationList.addAll(stationList);
            notifyDataSetChanged();
        }

        GasStationViewModel getSelectedItem() {
            if (index == -1) return null;
            return stationList.get(index);
        }

        void selectItem(int index) {
            if (index != -1 && index != this.index) {
                Marker old;
                if (this.index == -1 || this.index >= markers.size()) old = null;
                else
                    old = markers.get(this.index);
                this.index = index;
                mListener.onMarkerSelected(old, markers.get(this.index));
                recyclerView.scrollToPosition(index);
                GasStationViewModel station = getSelectedItem();
                mListener.animateToLocation(new LatLng(station.lat, station.lon));
                notifyDataSetChanged();
                if (isDetailShow)
                    showStationDetail(getSelectedItem());
            }
        }
    }

    private class GasStationViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ImageView ivMore;
        private final TextView tvMore;
        private final TextView tvStationName;
        private final TextView tvDescription;
        private GasStationViewModel station;

        GasStationViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            ivMore = itemView.findViewById(R.id.iv_more);
            tvMore = itemView.findViewById(R.id.tv_more);
            tvDescription = itemView.findViewById(R.id.tv_description);
            tvStationName = itemView.findViewById(R.id.tv_station_name);
        }

        void bind(GasStationViewModel station) {
            this.station = station;
            tvStationName.setText(String.format(Locale.CHINA, "%d.%s",
                    getAdapterPosition() + 1, station.stationName));
            tvDescription.setText(station.secondStr);
            tvMore.setText(station.moreStr);
            if (getAdapterPosition() == adapter.index) {
                itemView.setSelected(true);
                ivMore.setVisibility(View.VISIBLE);
                tvMore.setVisibility(View.VISIBLE);
            } else {
                itemView.setSelected(false);
                ivMore.setVisibility(View.GONE);
                tvMore.setVisibility(View.GONE);
            }
        }

        @Override
        public void onClick(View v) {
            if (getAdapterPosition() == RecyclerView.NO_POSITION) {
                Timber.tag(TAG).d("onClick: 点击到正在layout中的holder");
                return;
            }
            if (adapter.index == getAdapterPosition()) {
                showStationDetail(station);
            } else {
                Marker old;
                if (adapter.index == -1) old = null;
                else
                    old = markers.get(adapter.index);
                mListener.animateToLocation(new LatLng(station.lat, station.lon));
                adapter.index = getAdapterPosition();
                mListener.onMarkerSelected(old, markers.get(adapter.index));
                adapter.notifyDataSetChanged();
                LatLng position = markers.get(adapter.index).getPosition();
                Timber.tag(TAG).e("onMarkerClick: " + position.latitude + "-------" + position.longitude);
            }
        }
    }

    private class HelperRefreshAdapter extends RefreshListenerAdapter {
        @Override
        public void onLoadMore(TwinklingRefreshLayout refreshLayout) {
            super.onLoadMore(refreshLayout);
            uiAdapter.queryNext();
        }

        @Override
        public void onRefresh(TwinklingRefreshLayout refreshLayout) {
            super.onRefresh(refreshLayout);
            uiAdapter.queryPrevious();
        }
    }

}
