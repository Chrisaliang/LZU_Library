package com.uaes.android.data;

import android.content.Context;
import android.net.ConnectivityManager;

import com.uaes.android.AuthFunction;
import com.uaes.android.data.http.MaintenanceApi;
import com.uaes.android.data.internal.NetworkCheckMap;
import com.uaes.android.data.maper.CarHealthMapper;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.domain.MaintenanceRepository;
import com.uaes.android.domain.pojo.DomainCarHealth;
import com.uaes.android.domain.pojo.DomainMaintenanceRecord;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by aber on 1/22/2018.
 * Get Car health information
 */

public class MaintenanceRepositoryImpl implements MaintenanceRepository {

    // memory cache
    private final DomainCarHealth domainCarHealth = new DomainCarHealth();
    private final Context context;
    private final ConnectivityManager cm;
    private MaintenanceApi maintenanceApi;
    private CarHealthMapper carHealthMapper;
    private CacheDao mCacheDao;

    public MaintenanceRepositoryImpl(MaintenanceApi maintenanceApi, CacheDao dao, Context ctx) {
        this.maintenanceApi = maintenanceApi;
        this.carHealthMapper = new CarHealthMapper();
        this.mCacheDao = dao;
        this.context = ctx;
        this.cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    @Override
    public Single<DomainCarHealth> getCarHealth() {

        return Single.just(cm).map(new NetworkCheckMap()).flatMap(
                isConnected ->
                        isConnected ? maintenanceApi.carHealth()
                                .map(res -> {
                                    if (res.msgContent == null) {
                                        return DomainCarHealth.EMPTY;
                                    }
                                    carHealthMapper.map(res, domainCarHealth);
                                    mCacheDao.replaceCarHealth(res.msgContent);
                                    return domainCarHealth;
                                }) : mCacheDao.queryCarHealth()
                                .map(carHealth -> {
                                    carHealthMapper.map(carHealth, domainCarHealth);
                                    return domainCarHealth;
                                })
        ).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<DomainMaintenanceRecord> maintenanceRecord() {
        return null;
    }
}
