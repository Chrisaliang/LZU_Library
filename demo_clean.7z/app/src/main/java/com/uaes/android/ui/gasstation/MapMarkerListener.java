package com.uaes.android.ui.gasstation;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.navi.model.AMapNaviPath;
import com.amap.api.navi.model.NaviLatLng;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Author: tianbing
 * Date: 2017/10/19
 * Overview:
 */

public interface MapMarkerListener {
    /**
     * 显示列表布局
     */
    void showListLayout();
    /**
     * 在地图上显示加油站标记点
     *
     * @param markers 新增的marker点参数,如果为空,则将地图中的所有标记点清空
     * @return 返回标记点，用于下次更新地图
     */
    List<Marker> updateMarker(ArrayList<MarkerOptions> markers);
    /**
     * 清楚地图标记点
     */
    void clearMarker();
    /**
     * 更新地图被选择的标记
     *
     * @param older 原来被选择的标记，可能为null，标识原来没有选择
     * @param newer 现在需要被更新的标记，不可以为null
     */
    @Deprecated
    void onMarkerSelected(@Nullable Marker older, @NonNull Marker newer);
    /**
     * 更新地图被选择的标记
     *
     * @param older 原来被选择的标记，如果为-1 则原来为没有选择
     * @param newer
     * */
    void onMarkerSelected(int older, int newer);
    /**
     * 返回到上一级列表
     */
    void backPreviewLevel();
    /**
     * 移动视图到目标定位点
     */
    void animateToLocation(LatLng target);

    /**
     * 移动到指定区域
     *
     * @param targets       目标区域经纬度
     * @param paddingLeft   目标区域左边缘距离 mapView 左边缘的间隙距离
     * @param paddingRight  目标区域右边缘距离 mapView 右边缘的间隙距离
     * @param paddingTop    目标区域上边缘距离 mapView 上边缘的间隙距离
     * @param paddingBottom 目标区域下边缘距离 mapView 下边缘的间隙距离
     */
    void animateToBound(LatLngBounds targets,
                        int paddingLeft,
                        int paddingRight,
                        int paddingTop,
                        int paddingBottom);
    /**
     * 设置标记点点击事件
     */
    void setOnMarkerClickListener(OnMarkerClickListener OnMarkerClickListener);

    /**
     * 设置路径查询接口
     */
    void setRouteListener(OnRouteListener listener);

    /**
     * 选定目标加油站地点后，跳转到路径fragment则调用此方法
     *
     * @param to 目标地点坐标
     */
    void onRouterShow(NaviLatLng to);

    /**
     * 开始计算距离目标地点的路径
     */
    void calculateRoute();

    /**
     * 选中某个路径
     *
     * @param routeIndex 路径path
     */
    void selectRoute(int routeIndex);

    /**
     * 子组建实现此方法来异步接受父组建的事件
     */
    interface OnMarkerClickListener {
        /**
         * 地图中的锚点被点击
         */
        void onMarkerClick(int index);
    }

    interface OnRouteListener {
        /**
         * 算路成功后回调此函数
         */
        void onRouteSuccess(int[] routeIds, HashMap<Integer, AMapNaviPath> routes);

        /**
         * 算路失败后回调此函数, 高德地图sdk错误code
         */
        void onRouteFailed(int errorCode);
    }
}
