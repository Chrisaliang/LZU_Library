package com.uaes.android.data.http;

import com.uaes.android.data.json.CarHealth;
import com.uaes.android.data.json.GeneralAttributeReceive;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * Created by Chrisaliang on 2018/1/24.
 * car health api
 */

public interface MaintenanceApi {

    @GET("/car/v1/carCurrentAttr/app/carCurrentAttrDetail")
    Single<GeneralAttributeReceive<CarHealth>> carHealth();

    @POST("/iss/v1/maintenance/app/record")
    Single<Boolean> maintenanceRecord();
}
