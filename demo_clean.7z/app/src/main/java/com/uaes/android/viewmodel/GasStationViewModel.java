package com.uaes.android.viewmodel;

import android.text.Spanned;

/**
 * Created by Chrisaliang on 2017/11/1.
 * data for station
 */

@SuppressWarnings("WeakerAccess")
public class GasStationViewModel {

    public String stationName;

    public String secondStr;
    public String moreStr;

    public String stationAddr;

    public String stationBrand;

    public Spanned stationDistance;

    public Spanned stationDuration;

    public Spanned stationFillDuration;

    public float stationRate;

    public double lat;

    public double lon;

    public int fillTime;
}
