package com.uaes.android.data.http;

import com.uaes.android.data.json.FuelBookkeeping;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by Administrator on 2017/11/10 0010.
 * fuel account api
 */

public interface FuelAccountApi {

    @POST("/fuelfill/v1/fillRecord/registFillRecord")
    Single<FuelBookkeeping> setFuelAccount(@Body RequestBody body);

}
