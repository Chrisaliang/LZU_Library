package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.uaes.android.BR;
import com.uaes.android.viewmodel.BatteryAssistantViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Created by Chrisaliang on 2018/1/30.
 * battery assistant view observable
 */

public class BatteryAssistantViewObservable extends BaseObservable {
    private final BatteryAssistantViewModel viewModel;

    private int batteryStatus;

    private int status = RetryView.RETRY_LOADING;

    public BatteryAssistantViewObservable(BatteryAssistantViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void onClick(RetryView view) {
        viewModel.update();
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public int getBatteryStatus() {
        return batteryStatus;
    }

    public void setBatteryStatus(int batteryStatus) {
        this.batteryStatus = batteryStatus;
        notifyPropertyChanged(BR.batteryStatus);
    }
}
