package com.uaes.android.domain;

import com.uaes.android.domain.pojo.DomainCarHealth;
import com.uaes.android.domain.pojo.DomainMaintenanceRecord;

import io.reactivex.Single;

/**
 * Created by aber on 1/22/2018.
 * Car Information.
 */

public interface MaintenanceRepository {
    Single<DomainCarHealth> getCarHealth();

    /**
     * 保养记录
     */
    Single<DomainMaintenanceRecord> maintenanceRecord();
}
