package com.uaes.android.ui.message;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.MessagePushEntity;
import com.uaes.android.databinding.FragmentMessageBinding;
import com.uaes.android.domain.message.CountAllUnreadMessage;
import com.uaes.android.ui.TopLevelFragment;
import com.uaes.android.ui.message.listener.SelectListener;
import com.uaes.android.ui.message.malfunction.AllTypeMessageFragment;
import com.uaes.android.widget.HomeMenuTabTextView;
import com.uaes.common.Intents;

import java.util.Map;

import javax.inject.Inject;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/11.
 * Des : This is 消息界面的Fragmnent
 */

public class MessageFragment extends TopLevelFragment implements SelectListener {

    private static final String TAG = MessageFragment.class.getSimpleName();
    private static final String EXTRA_SELECTED = "com.uaes.android.MessageFragment.SELECTED";
    private final SparseArray<Fragment> mFragments = new SparseArray<>();
    @Inject
    CountAllUnreadMessage countAllUnreadMessage;
    FragmentMessageBinding binding;
    private Disposable mDisposable;
    private HomeMenuTabTextView recommendView;//推荐
    private int selectedId = View.NO_ID;
    private HomeMenuTabTextView malfunctionView; // 故障
    private HomeMenuTabTextView warningView; // 预警
    private HomeMenuTabTextView notificationView; // 通知
    private final BroadcastReceiver messageChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intents.MESSAGE.EXTRA_MESSAGE_SAVE.equals(action)
                    || Intents.MESSAGE.EXTRA_MESSAGE_UPDATE.equals(action)
                    || Intents.MESSAGE.EXTRA_MESSAGE_DELETE.equals(action)) {
                queryMessage();
            } else {
                Timber.tag(TAG).e("error action: %s", action);
            }
        }
    };

    private void queryMessage() {
        countAllUnreadMessage.execute().subscribe(new SingleObserver<Map<String, Integer>>() {
            @Override
            public void onSubscribe(Disposable d) {
                mDisposable = d;
            }

            @Override
            public void onSuccess(Map<String, Integer> stringIntegerMap) {
                for (Map.Entry<String, Integer> stringIntegerEntry : stringIntegerMap.entrySet()) {
                    String key = stringIntegerEntry.getKey();
                    Integer value = stringIntegerEntry.getValue();
                    updateMessageCount(key, value);
                }
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }
        });
    }

    private void updateMessageCount(String key, Integer value) {
        switch (key) {
            case MessagePushEntity.MESSAGE_CLASS_ADVICE:
                recommendView.setMessageNum(value);
                break;
            case MessagePushEntity.MESSAGE_CLASS_MALFUNCTION:
                malfunctionView.setMessageNum(value);
                break;
            case MessagePushEntity.MESSAGE_CLASS_NOTIFICATION:
                notificationView.setMessageNum(value);
                break;
            case MessagePushEntity.MESSAGE_CLASS_WARN:
                warningView.setMessageNum(value);
                break;
            default:
                break;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null)
            selectedId = savedInstanceState.getInt(EXTRA_SELECTED);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_message, container, false);
        binding.setListeners(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recommendView = view.findViewById(R.id.message_recommend_menu);
        recommendView.enableNumBubble(false);
        malfunctionView = view.findViewById(R.id.message_malfunction_menu);
        malfunctionView.enableNumBubble(false);

        warningView = view.findViewById(R.id.message_warning_menu);
        notificationView = view.findViewById(R.id.message_notification_menu);
        warningView.enableNumBubble(false);
        notificationView.enableNumBubble(false);

    }

    @Override
    public void onStart() {
        super.onStart();
        if (selectedId == View.NO_ID)
            updateSelectedMenu(R.id.message_recommend_menu);
        else
            updateSelectedMenu(selectedId);
        queryMessage();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_SAVE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_UPDATE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_DELETE);
        intentFilter.addAction(Intents.MESSAGE.EXTRA_MESSAGE_QUERY);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(messageChangeReceiver, intentFilter);
    }

    @Override
    public void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(messageChangeReceiver);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mDisposable != null && !mDisposable.isDisposed())
            mDisposable.dispose();
    }

    private void updateSelectedMenu(int clickId) {
        View view = getView();
        if (view != null) {
            updateSelectedMenu(view.findViewById(selectedId), view.findViewById(clickId));
        }
    }

    private void updateSelectedMenu(View selectedView, View clickView) {
        if (clickView == null)
            clickView = recommendView;
        if (selectedView != null && selectedView != clickView)
            selectedView.setSelected(false);
        switchFragment(clickView);
        clickView.setSelected(true);
        selectedId = clickView.getId();
    }

    private void switchFragment(View view) {
        realTransactFragment(getFragment(view.getId()), getFragment(selectedId));
    }

    private void realTransactFragment(Fragment shouldShow, Fragment shouldHidden) {
        if (shouldShow == null) return;
        if (shouldShow == shouldHidden) return;
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_message_layout, shouldShow, null);
        transaction.commit();
    }

    private Fragment createFragmentByViewId(@IdRes int id) {
        Fragment fragment = new AllTypeMessageFragment();
        Bundle bundle = new Bundle();
        if (id == R.id.message_recommend_menu) {
            bundle.putString(Intents.MESSAGE_FRAGMENT_ARGUMENTS,
                    MessagePushEntity.MESSAGE_CLASS_ADVICE);
        } else if (id == R.id.message_malfunction_menu) {
            bundle.putString(Intents.MESSAGE_FRAGMENT_ARGUMENTS,
                    MessagePushEntity.MESSAGE_CLASS_MALFUNCTION);
        } else if (id == R.id.message_warning_menu) {
            bundle.putString(Intents.MESSAGE_FRAGMENT_ARGUMENTS,
                    MessagePushEntity.MESSAGE_CLASS_WARN);
        } else if (id == R.id.message_notification_menu) {
            bundle.putString(Intents.MESSAGE_FRAGMENT_ARGUMENTS,
                    MessagePushEntity.MESSAGE_CLASS_NOTIFICATION);
        }
        fragment.setArguments(bundle);
        mFragments.put(id, fragment);
        return fragment;
    }

    private Fragment getFragment(@IdRes int id) {
        Fragment fragment = mFragments.get(id);
        if (fragment == null) {
            fragment = createFragmentByViewId(id);
        }
        return fragment;
    }

    @Override
    public void onClick(View v) {
        updateSelectedMenu(v.getId());
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (selectedId != View.NO_ID)
            outState.putInt(EXTRA_SELECTED, selectedId);
    }


    @Override
    public void back() {
//        getChildFragmentManager().popBackStack();
    }

    @Override
    public void onPause() {
        super.onPause();
        selectedId = View.NO_ID;
    }


}
