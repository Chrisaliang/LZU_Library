package com.uaes.android;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;
import android.text.TextUtils;

import com.alibaba.sdk.android.push.CloudPushService;
import com.alibaba.sdk.android.push.CommonCallback;
import com.alibaba.sdk.android.push.noonesdk.PushServiceFactory;
import com.uaes.android.di.DaggerApplicationComponent;
import com.uaes.common.AuthProvider;

import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.inject.Inject;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLSocketFactory;

import dagger.android.AndroidInjector;
import dagger.android.support.DaggerApplication;
import timber.log.Timber;

/**
 * Created by hand on 2017/10/30.
 * Base Application
 */

public class UaesIotApplication extends DaggerApplication implements CommonCallback {

    private static final String TAG = UaesIotApplication.class.getSimpleName();
    private final AppStatusTracker appStatusTracker = AppStatusTracker.getInstance();
    @Inject
    AuthProvider mAuthProvider;

    public static Application app;

    @Override
    protected AndroidInjector<? extends DaggerApplication> applicationInjector() {
        return DaggerApplicationComponent.builder().create(this);
    }

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        Timber.plant(new Timber.DebugTree());
        initCloudChannel();
        registerActivityLifecycleCallbacks(appStatusTracker);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        unregisterActivityLifecycleCallbacks(appStatusTracker);
    }

    public void initCloudChannel() {
        PushServiceFactory.init(getApplicationContext());
        CloudPushService pushService = PushServiceFactory.getCloudPushService();
        pushService.setLogLevel(CloudPushService.LOG_OFF);
        pushService.register(this, this);
        String vinCode = mAuthProvider.getVinCode();
        if (!TextUtils.isEmpty(vinCode)) {
            Timber.tag(TAG).d("initCloudChannel: bind account: %s", vinCode);
            pushService.bindAccount(vinCode, this);
        }
    }

    @Override
    public void onSuccess(String response) {
        Timber.tag(TAG).d("init cloudchannel success%s", response);
        CloudPushService pushService = PushServiceFactory.getCloudPushService();
        Timber.tag(TAG).d("deviceId:  %s", pushService.getDeviceId());
    }

    @Override
    public void onFailed(String errorCode, String errorMessage) {
        Timber.tag(TAG).d("init cloudchannel failed -- errorcode:" + errorCode + " -- errorMessage:" + errorMessage);
    }
}
