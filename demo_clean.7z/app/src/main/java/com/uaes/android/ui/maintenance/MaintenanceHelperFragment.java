package com.uaes.android.ui.maintenance;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentMaintenanceHelperBinding;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.ui.maintenance.engineoil.EngineOilFragment;
import com.uaes.android.ui.maintenance.listener.LeftMenuSelectListener;
import com.uaes.android.ui.maintenance.sparkingplug.SparkingPlugFragment;
import com.uaes.android.widget.HomeMenuTabTextView;
import com.uaes.common.Intents;

/**
 * Author : 张 涛
 * Time : 2018/1/22.
 * Des : This is
 */

public class MaintenanceHelperFragment extends NavigatorFragment implements LeftMenuSelectListener {
    private static final String EXTRA_SELECTED = "com.uaes.android.MaintenanceHelperFragment.SELECTED";
    private final SparseArray<Fragment> mFragments = new SparseArray<>();
    FragmentMaintenanceHelperBinding binding;
    private int selectedId = View.NO_ID;
    private HomeMenuTabTextView sparkingPlugView;
    private int toTag = -1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null)
            selectedId = savedInstanceState.getInt(EXTRA_SELECTED);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_maintenance_helper, container, false);
        binding.setListener(this);
        if (getArguments() != null) {
            int tag = getArguments().getInt(Intents.MAINTENANCE_HELPER_FRAGMENT_ARGUMENTS);
            if (selectedId == View.NO_ID)
                toTag = tag;
        }
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sparkingPlugView = view.findViewById(R.id.maintenance_helper_single_sparking_plug_menu);
    }

    @Override
    public void onStart() {
        super.onStart();
        // 显示
        mNavigator.showBackButton();
        if (selectedId == View.NO_ID) {
            if (toTag == 0) {
                updateSelectedMenu(R.id.maintenance_helper_single_engine_oil_menu);
            } else if (toTag == 1) {
                updateSelectedMenu(R.id.maintenance_helper_single_sparking_plug_menu);
            } else {
                updateSelectedMenu(R.id.maintenance_helper_single_sparking_plug_menu);
            }
        } else
            updateSelectedMenu(selectedId);
    }

    private void updateSelectedMenu(int clickId) {
        View view = getView();
        if (view != null) {
            updateSelectedMenu(view.findViewById(selectedId), view.findViewById(clickId));
        }
    }

    private void updateSelectedMenu(View selectedView, View clickView) {
        if (clickView == null)
            clickView = sparkingPlugView;
        if (selectedView != null && selectedView != clickView)
            selectedView.setSelected(false);
        switchFragment(clickView);
        clickView.setSelected(true);
        selectedId = clickView.getId();
    }

    private void switchFragment(View view) {
        realTransactFragment(getFragment(view.getId()), getFragment(selectedId));
    }

    private Fragment getFragment(@IdRes int id) {
        Fragment fragment = mFragments.get(id);
        if (fragment == null) {
            fragment = createFragmentByViewId(id);
        }
        return fragment;
    }

    private Fragment createFragmentByViewId(@IdRes int id) {
        Fragment fragment;
        if (id == R.id.maintenance_helper_single_sparking_plug_menu) {
            fragment = new SparkingPlugFragment();
        } else if (id == R.id.maintenance_helper_single_engine_oil_menu) {
            fragment = new EngineOilFragment();
        } else if (id == R.id.maintenance_helper_single_expect1_menu) {
            fragment = null;
        } else if (id == R.id.maintenance_helper_single_expect2_menu) {
            fragment = null;
        } else {
            fragment = null;
        }
        mFragments.put(id, fragment);
        return fragment;
    }

    private void realTransactFragment(Fragment shouldShow, Fragment shouldHidden) {
        if (shouldShow == null) return;
        if (shouldShow == shouldHidden) return;
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.replace(R.id.maintenance_helper_fragment_replace_layout, shouldShow, null);
        transaction.commit();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (selectedId != View.NO_ID)
            outState.putInt(EXTRA_SELECTED, selectedId);
    }

    @Override
    public void onStop() {
        super.onStop();
        mNavigator.hideBackButton();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden)
            mNavigator.hideBackButton();
        else
            mNavigator.showBackButton();
    }

    @Override
    public void onClick(View view) {
        updateSelectedMenu(view.getId());
    }
}
