package com.uaes.android.data.maper;

import com.uaes.android.data.json.FuelFillHistory;
import com.uaes.android.domain.pojo.DomainFuelHistory;

import java.util.Locale;
import java.util.zip.DataFormatException;

/**
 * Created by Chrisaliang on 2017/12/6.
 * fuel history mapper
 */

public class FuelHistoryMapper {

    private DomainFuelHistory domainFuelHistory;

    public DomainFuelHistory map(FuelFillHistory msgContent) throws DataFormatException {
        if (domainFuelHistory == null)
            domainFuelHistory = new DomainFuelHistory();
        domainFuelHistory.fuelCost = getRmbStr(msgContent.fuelCost);
        domainFuelHistory.fuelUse = getFuelStr(msgContent.fuelUse);
        domainFuelHistory.acUse = getFuelStr(msgContent.acUse);
        domainFuelHistory.driverUse = getFuelStr(msgContent.driverUse);
        domainFuelHistory.idleUse = getFuelStr(msgContent.idleUse);
        domainFuelHistory.otherUse = getFuelStr(msgContent.otherUse);
        double acUse = (msgContent.acUse / msgContent.fuelUse) * 100;
        double driverUse = (msgContent.driverUse / msgContent.fuelUse) * 100;
        double idleUse = (msgContent.idleUse / msgContent.fuelUse) * 100;
        double otherUse = (msgContent.otherUse / msgContent.fuelUse) * 100;
        if (msgContent.fuelUse <= 0)
            driverUse = idleUse = otherUse = acUse = 0;
        domainFuelHistory.acUseMoney = getRmbStr(msgContent.fuelCost * acUse / 100);
        domainFuelHistory.driverUseMoney = getRmbStr(msgContent.fuelCost * driverUse / 100);
        domainFuelHistory.idleUseMoney = getRmbStr(msgContent.fuelCost * idleUse / 100);
        domainFuelHistory.otherUseMoney = getRmbStr(msgContent.fuelCost * otherUse / 100);
        domainFuelHistory.acUsePercent = String.format(Locale.CHINESE, "%.1f%%", acUse);
        domainFuelHistory.driverUsePercent = String.format(Locale.CHINESE, "%.1f%%", driverUse);
        domainFuelHistory.idleUsePercent = String.format(Locale.CHINESE, "%.1f%%", idleUse);
        domainFuelHistory.otherUsePercent = String.format(Locale.CHINESE, "%.1f%%", otherUse);
        return domainFuelHistory;
    }

    /**
     * format fuel use
     *
     * @param fuel data layer data
     * @return format fuel use
     * @throws DataFormatException data is not normal
     */
    private String getFuelStr(double fuel) throws DataFormatException {
        String fuelStr;
        if (fuel < 0)
            throw new DataFormatException("data format exception");
        else if (fuel < 1000)
            fuelStr = String.format(Locale.CHINESE, "%.1f升", fuel);
        else if (fuel < 100000)
            fuelStr = String.format(Locale.CHINESE, "%d升", (int) fuel);
        else
            fuelStr = String.format(Locale.CHINESE, "%.1f万升", fuel / 10000);
        return fuelStr;
    }

    /**
     * format fuel rmb
     *
     * @param rmb data layer data
     * @return format rmb
     * @throws DataFormatException data is not normal
     */
    private String getRmbStr(double rmb) throws DataFormatException {
        String rmbStr;
        if (rmb < 0)
            throw new DataFormatException("data format exception");
        else if (rmb < 100)
            rmbStr = String.format(Locale.CHINESE, "%.2f元", rmb);
        else if (rmb < 1000)
            rmbStr = String.format(Locale.CHINESE, "%.1f元", rmb);
        else if (rmb < 10000)
            rmbStr = String.format(Locale.CHINESE, "%d元", (int) rmb);
        else
            rmbStr = String.format(Locale.CHINESE, "%.1f万元", rmb / 10000);
        return rmbStr;
    }
}
