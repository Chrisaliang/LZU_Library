package com.uaes.android.domain;

import com.uaes.android.domain.pojo.DomainSetting;

import io.reactivex.Single;

/**
 * Created by Chrisaliang on 2017/11/9.
 * repository for setting
 * 设置 数据接口
 */

public interface SettingRepository {

    Single<DomainSetting> lowFuelWarningSent(int lowOilNum);

    Single<DomainSetting> lowFuelWarningReceive();
}
