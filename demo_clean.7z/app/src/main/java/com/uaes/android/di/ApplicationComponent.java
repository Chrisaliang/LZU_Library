package com.uaes.android.di;

import com.uaes.android.NetModule;
import com.uaes.android.UaesIotApplication;

import javax.inject.Singleton;

import dagger.android.AndroidInjector;
import dagger.android.support.AndroidSupportInjectionModule;

/**
 * Created by aber on 1/24/2018.
 * Application Component for dagger2.
 * Top level component.
 */
@Singleton
@dagger.Component(
        modules = {
                // add all you module class in here
                AndroidSupportInjectionModule.class,
                AndroidComponentModule.class,
                JsonModule.class,
                PersistentModule.class,
                RepositoryModule.class,
                NetModule.class
        })
public interface ApplicationComponent extends AndroidInjector<UaesIotApplication> {

    @dagger.Component.Builder
    abstract class Builder extends AndroidInjector.Builder<UaesIotApplication> {
    }

}
