package com.uaes.android.data.internal;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Function;

/**
 * Created by aber on 1/16/2018.
 * NetStatus
 */

public class NetworkCheckMap implements Function<ConnectivityManager, Boolean> {

    @Override
    public Boolean apply(@NonNull ConnectivityManager manager) throws Exception {
        // check network
        NetworkInfo info = manager.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }
}
