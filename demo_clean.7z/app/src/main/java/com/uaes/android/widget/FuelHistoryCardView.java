package com.uaes.android.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.uaes.android.R;

/**
 * Created by Chrisaliang on 2018/2/6.
 * fuel history tab
 */

@BindingMethods({
        @BindingMethod(type = FuelHistoryCardView.class, attribute = "hcv_cardValue", method = "setCardValue"),
        @BindingMethod(type = FuelHistoryCardView.class, attribute = "hcv_cardClickedValue", method = "setCardClickedValue"),
        @BindingMethod(type = FuelHistoryCardView.class, attribute = "hcv_cardValuePercent", method = "setCardValuePercent")
})
public class FuelHistoryCardView extends FrameLayout {

    private TextView cardValue;
    private TextView cardValuePercent;
    private boolean clicked;
    private TextView cardTitle;

    private CharSequence clickedTitle;
    private CharSequence clickedValue;
    private CharSequence unClickTitle;
    private CharSequence unClickValue;

    public FuelHistoryCardView(@NonNull Context context) {
        this(context, null);
    }

    public FuelHistoryCardView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FuelHistoryCardView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public FuelHistoryCardView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs);
    }

    @BindingAdapter(value = "hcv_cardValue")
    public static void setCardValue(FuelHistoryCardView view, CharSequence value) {
        view.unClickValue = value;
        view.cardValue.setText(view.clicked ? view.clickedValue : view.unClickValue);
    }

    @BindingAdapter(value = "hcv_cardClickedValue")
    public static void setCardClickedValue(FuelHistoryCardView view, CharSequence clickedValue) {
        view.clickedValue = clickedValue;
    }

    @BindingAdapter(value = "hcv_cardValuePercent")
    public static void setCardValuePercent(FuelHistoryCardView view, CharSequence valuePercent) {
        view.cardValuePercent.setText(valuePercent);
    }

    private void init(Context context, AttributeSet attrs) {
        inflate(context, R.layout.widget_fuel_history_card, this);
        ImageView cardIcon1 = findViewById(R.id.fuel_history_cars_icon);
        cardTitle = findViewById(R.id.fuel_history_card_title);
        cardValue = findViewById(R.id.fuel_history_card_value);
        cardValuePercent = findViewById(R.id.fuel_history_card_value_percent);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.FuelHistoryCardView);
        Drawable cardIcon = typedArray.getDrawable(R.styleable.FuelHistoryCardView_hcv_cardIcon);
        if (cardIcon != null)
            cardIcon1.setImageDrawable(cardIcon);
        clickedTitle = typedArray.getString(R.styleable.FuelHistoryCardView_hcv_cardClickedTitle);
        clickedValue = typedArray.getString(R.styleable.FuelHistoryCardView_hcv_cardClickedValue);
        unClickTitle = typedArray.getString(R.styleable.FuelHistoryCardView_hcv_cardTitle);
        cardTitle.setText(clicked ? clickedTitle : unClickTitle);
        unClickValue = typedArray.getString(R.styleable.FuelHistoryCardView_hcv_cardValue);
        cardValue.setText(clicked ? clickedValue : unClickValue);
        String percent = typedArray.getString(R.styleable.FuelHistoryCardView_hcv_cardValuePercent);
        cardValuePercent.setText(percent);

        typedArray.recycle();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
                // Toast.makeText(getContext(), "action", Toast.LENGTH_SHORT).show();
                changeText();
                break;
        }
        return true;
    }

    public void changeText() {
        if (clicked) {
            cardTitle.setText(unClickTitle);
            cardValue.setText(unClickValue);
        } else {
            cardTitle.setText(clickedTitle);
            cardValue.setText(clickedValue);
        }
        clicked = !clicked;
    }
}
