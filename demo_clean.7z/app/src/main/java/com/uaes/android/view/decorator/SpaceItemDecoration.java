package com.uaes.android.view.decorator;

import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.DimenRes;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.uaes.android.R;

/**
 * Created by Chrisaliang on 2017/10/30.
 * Padding ItemDecoration
 */

@SuppressWarnings("unused")
public class SpaceItemDecoration extends RecyclerView.ItemDecoration {

    private static final int DEFAULT_PADDING = R.dimen.default_list_item_padding;

    private int mPaddingTopAndBottom;
    private int mPaddingStartAndEnd;

    public SpaceItemDecoration(Context context) {
        mPaddingTopAndBottom = context.getResources().getDimensionPixelSize(DEFAULT_PADDING);
        mPaddingStartAndEnd = 0;
    }

    public SpaceItemDecoration(Context context, @DimenRes int padding) {
        mPaddingStartAndEnd = context.getResources().getDimensionPixelSize(padding);
        mPaddingTopAndBottom = mPaddingStartAndEnd;
    }

    public SpaceItemDecoration(Context context, @DimenRes int topAndBottom, @DimenRes int startAndEnd) {
        mPaddingStartAndEnd = context.getResources().getDimensionPixelSize(startAndEnd);
        mPaddingTopAndBottom = context.getResources().getDimensionPixelSize(topAndBottom);
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        //super.getItemOffsets(outRect, view, parent, state);
        outRect.set(mPaddingStartAndEnd, mPaddingTopAndBottom, mPaddingStartAndEnd, mPaddingTopAndBottom);
    }
}
