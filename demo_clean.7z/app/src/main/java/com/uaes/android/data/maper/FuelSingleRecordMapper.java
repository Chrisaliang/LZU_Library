package com.uaes.android.data.maper;

import android.content.res.Resources;
import android.text.TextUtils;

import com.github.mikephil.charting.data.BarEntry;
import com.uaes.android.R;
import com.uaes.android.data.json.FuelSingleFillRecord;
import com.uaes.android.data.json.SingleFuelRecord;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;
import com.uaes.android.viewmodel.PageViewModel;
import com.uaes.android.viewmodel.SingleRecordItemViewModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by aber on 11/27/2017.
 * Data layer mapper
 */

public class FuelSingleRecordMapper {

    private final static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM", Locale.CHINESE);
    private final static SimpleDateFormat detailFormat = new SimpleDateFormat("yyyy/MM/dd", Locale.CHINA);
    private final Resources resources;


    public FuelSingleRecordMapper(Resources resources) {
        this.resources = resources;
    }

    private static String DateFormat(Date date) {
        return simpleDateFormat.format(date);
    }

    private static String nullCheck(String str) {
        return TextUtils.isEmpty(str) ? "" : str;
    }

    public DomainFuelSingleRecord map(SingleFuelRecord record) {
        return map(record, record.page.content);
    }

    public DomainFuelSingleRecord map(SingleFuelRecord record, List<FuelSingleFillRecord> recordList) {
        if (recordList == null || recordList.size() <= 0)
            return DomainFuelSingleRecord.getEmptySingleRecord();
        DomainFuelSingleRecord model = new DomainFuelSingleRecord();
        model.barData = new PageViewModel<>();
        model.barData.currentPageIndex = record.page.number;
        model.barData.pageCapacity = record.page.size;
        model.barData.totalPages = record.page.totalPages;
        model.barData.totalSize = record.page.totalElements;
        ArrayList<BarEntry> yValues = new ArrayList<>();
        String[] labels = new String[recordList.size()];
        for (int i = 0; i < recordList.size(); i++) {
            FuelSingleFillRecord item = recordList.get(i);
            SingleRecordItemViewModel itemViewModel = new SingleRecordItemViewModel();
            itemViewModel.count = (int) Math.min(5, item.evaluateLevel);
            itemViewModel.eventId = item.eventId;
            itemViewModel.descriptionOne = resources.getString(
                    R.string.fuel_manager_fuel_single_record_detail_description_one,
                    detailFormat.format(item.fillDate),
                    item.fillCharge,
                    item.fillAmount == 0 ?item.ecuFillAmount : item.fillAmount,
                    nullCheck(item.gasName),
                    nullCheck(item.gasLocation)
            );
            itemViewModel.descriptionTwo = resources.getString(
                    R.string.fuel_manager_fuel_single_record_detail_description_two,
                    item.fillUsed,
                    item.speedAvg,
                    item.usedAvg,
                    item.millageDrive,
                    item.economicRank * 100
            );
            yValues.add(new BarEntry(i, (float) item.fillAmount, itemViewModel));
            labels[i] = DateFormat(item.fillDate);
        }
        model.labels = labels;
        model.barData.contents = yValues;
        model.fillCount = String.valueOf(record.fillCount);
        model.fillAmountSum = String.format(Locale.CHINA, "%.2f", record.fillAmountSum);
        return model;
    }
}
