package com.uaes.android.domain;

import io.reactivex.Single;

/**
 * Created by Chrisaliang on 2018/3/8.
 * 用例，代表一个动作，该动作需要至少两个元素
 * 1.执行动作的实体， 非空
 * 2.执行动作需要的参数， 可为空
 */

public interface UseCase<T> {
    Single<T> execute();
}
