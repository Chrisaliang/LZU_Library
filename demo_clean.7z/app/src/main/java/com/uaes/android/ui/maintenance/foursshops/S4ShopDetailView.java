package com.uaes.android.ui.maintenance.foursshops;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;

import com.uaes.android.R;
import com.uaes.android.databinding.LayoutDetailFoursshopBinding;
import com.uaes.android.viewobservable.FourSShopsOverallObservable;

/**
 * Created by aber on 3/6/2018.
 * 用于显示 4S店信息详情
 */

public class S4ShopDetailView extends LinearLayoutCompat {

    private FourSShopsOverallObservable detailInfoOf4sShop;
    private FourSShopListener mListener;
    private LayoutDetailFoursshopBinding binding;

    public S4ShopDetailView(Context context) {
        this(context, null);
    }

    public S4ShopDetailView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public S4ShopDetailView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        LayoutInflater factory = LayoutInflater.from(getContext());
        binding = DataBindingUtil.inflate(factory, R.layout.layout_detail_foursshop, this, true);
    }

    public FourSShopsOverallObservable getDetail() {
        return detailInfoOf4sShop;
    }

    public void setDetail(FourSShopsOverallObservable detail) {
        this.detailInfoOf4sShop = detail;
        updateDetail();
    }

    public FourSShopListener getListener() {
        return mListener;
    }

    public void setListener(FourSShopListener listener) {
        this.mListener = listener;
        updateDetail();
    }

    private void updateDetail() {
        if (detailInfoOf4sShop != null)
            binding.setFoursshopentity(detailInfoOf4sShop);
        if (mListener != null)
            binding.setMlistener(mListener);
    }
}
