package com.uaes.android.domain.pojo;

import com.google.gson.annotations.SerializedName;

/**
 * Created by aber on 1/23/2018.
 * 广告
 */

public class DomainAd {

    /**
     * 机油广告
     */
    public static final String AD_TYPE_ENGINE_OIL = "adEngineOil";

    /**
     * 火花塞广告
     */
    public static final String AD_TYPE_SPARKING_PLUGS = "adSparkPlug";

    // 广告类型Code
    @SerializedName("code")
    public String code;

    @SerializedName("title")
    public String title;

    @SerializedName("description")
    public String description;

    @SerializedName("messageType")
    public String messageType;

    @SerializedName("messageClassification")
    public String messageClassification;
}
