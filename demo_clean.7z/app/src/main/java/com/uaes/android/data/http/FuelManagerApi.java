package com.uaes.android.data.http;

import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.data.json.FuelFillHistory;
import com.uaes.android.data.json.FuelFillRecordPoint;
import com.uaes.android.data.json.FuelStatus;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.json.SingleFuelRecord;

import java.util.List;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by Chrisaliang on 2017/11/6.
 * api for oil manager
 */

public interface FuelManagerApi {

    // 累计加油记录
    @GET("/fuelconp/v1/usedKm/addFuel")
    Single<GeneralAttributeReceive<List<FuelFillRecordPoint>>> fuelRecord();

    // 单次加油记录
    @GET("/fuelfill/v1/fillRecord/app/findListPageApp")
    Single<SingleFuelRecord> singleFuelRecord(@Query("page") int page, @Query("size") int size);

    // 获取用油状态
    @GET("/cars/v1/carService/app/getFuelHelperByVin")
    Single<GeneralAttributeReceive<FuelStatus>> fuelStatus();

    // 根据年份获取用油历史
    @GET("/fuelconp/v1/fuel/consumption/dashboard/queryByYear")
    Single<GeneralAttributeReceive<FuelFillHistory>> getFuelHistoryByYear(@Query("type") Integer time);

    // 根据里程获取用油历史
    @GET("/fuelconp/v1/fuel/consumption/dashboard/queryByMile")
    Single<GeneralAttributeReceive<FuelFillHistory>> getFuelHistoryByMile(@Query("lastMileage") Integer mile);

    @POST("/fuelfill/v1/fillRecord/registFillRecord")
    Single<FuelBookkeeping> setFuelAccount(@Body RequestBody body);
}
