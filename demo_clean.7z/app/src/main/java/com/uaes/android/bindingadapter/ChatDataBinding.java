package com.uaes.android.bindingadapter;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.uaes.android.R;
import com.uaes.android.domain.pojo.DomainFuelRecord;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by Chrisaliang on 2017/12/5.
 * data binding for chart
 */

@BindingMethods({
        @BindingMethod(type = LineChart.class, attribute = "line_data_set", method = "updateLineData"),
        @BindingMethod(type = BarChart.class, attribute = "bar_data_set", method = "updateBarData")
})
public class ChatDataBinding {

    @BindingAdapter(value = "line_data_set")
    public static void updateLineData(LineChart lineChart, DomainFuelRecord chartData) {
        if (lineChart.getData() != null && lineChart.getData().getDataSetCount() > 0) {
            lineChart.getData().clearValues();
            for (ILineDataSet lineDatum : chartData.lineData) {
                lineChart.getData().addDataSet(lineDatum);
            }
            lineChart.getData().notifyDataChanged();
        } else {
            LineData data = new LineData(chartData.lineData);
            lineChart.setData(data);
        }
        lineChart.getXAxis().setAxisMaximum(chartData.xMax * 1.1f);
        lineChart.getXAxis().setGranularity(chartData.xMax / 5);
        lineChart.getXAxis().setLabelCount(6);
        lineChart.getXAxis().setValueFormatter((value, axis) ->
                String.valueOf((int) value)
        );
        lineChart.getAxisLeft().setGranularity(chartData.yMax / 5);
        lineChart.getAxisLeft().setValueFormatter((value, axis) -> {
            if (value > Math.round((chartData.yMax / 5) * 4))
                return String.format(Locale.CHINESE, "%.1f", value);
            else return "";
        });
        lineChart.getAxisLeft().setAxisMaximum(chartData.yMax * 1.1f);
//        if (!dataSets.isEmpty())
        lineChart.getAxisLeft().removeAllLimitLines();
        lineChart.getAxisLeft().addLimitLine(createNewLine(chartData.yMax,
                lineChart.getContext().getString(R.string.fuel_manager_fuel_record_limit_line_label)));
        //绘制图表
        lineChart.getData().notifyDataChanged();
        lineChart.invalidate();
    }

    private static LimitLine createNewLine(float limit, String label) {
        LimitLine l = new LimitLine(limit, "");
        l.setLineColor(Color.parseColor("#0BA9FC"));
        l.setTextColor(Color.WHITE);
        l.setYOffset(18);
        l.setTextSize(18);
        l.setLineWidth(1);
        l.enableDashedLine(20, 10, 0);
        l.setLabelPosition(LimitLine.LimitLabelPosition.LEFT_TOP);
        return l;
    }

    @BindingAdapter(value = "bar_data_set")
    public static void updateBarData(BarChart barChart, DomainFuelSingleRecord record) {
        barChart.getXAxis().setValueFormatter((value, axis) -> {
            int index = (int) value;
            String la = "";
            if (index < record.labels.length) {
                la = record.labels[index];
            }
            return la == null ? "" : la;
        });
        BarDataSet set;
        if (barChart.getData() != null && barChart.getData().getDataSetCount() > 0) {
            set = (BarDataSet) barChart.getData().getDataSetByIndex(0);
            set.setValues(record.barData.contents);
            barChart.getData().notifyDataChanged();
            barChart.notifyDataSetChanged();
            barChart.invalidate();
        } else {
            set = new BarDataSet(record.barData.contents, null);
            set.setDrawIcons(false);
            set.setColor(barChart.getContext().getResources()
                    .getColor(R.color.fuel_manager_single_bar_chart_color_normal));
            set.setHighLightColor(barChart.getContext().getResources()
                    .getColor(R.color.fuel_manager_single_bar_chart_color_selected));
            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set);
            BarData data = new BarData(dataSets);
            data.setBarWidth(0.6f);
            data.setDrawValues(true);
            data.setValueTextColor(Color.WHITE);
            set.setValueFormatter((value, entry, dataSetIndex, viewPortHandler)
                    -> String.format(Locale.CHINESE, "%.1f", value));
            barChart.setData(data);
            barChart.invalidate();
        }
    }
}
