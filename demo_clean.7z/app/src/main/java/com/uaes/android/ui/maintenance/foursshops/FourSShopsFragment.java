package com.uaes.android.ui.maintenance.foursshops;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.amap.api.location.AMapLocation;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.navi.model.NaviLatLng;
import com.uaes.android.R;
import com.uaes.android.databinding.FragmentFoursshopsBinding;
import com.uaes.android.domain.pojo.Domain4SShop;
import com.uaes.android.ui.gasstation.MapMarkerActivity;
import com.uaes.android.ui.gasstation.MapMarkerBaseFragment;
import com.uaes.android.view.decorator.SpaceItemDecoration;
import com.uaes.android.viewmodel.FourSShopsViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.FourSShopsObservable;
import com.uaes.android.viewobservable.FourSShopsOverallObservable;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/25.
 * Des : This is
 */

public class FourSShopsFragment extends MapMarkerBaseFragment
        implements FourSShopListener, MapMarkerActivity.OnMarkerClickListener {

    private static final String TAG = "FourSShopsFragment";
    @Inject
    RepositoryVMProvider factory;
    private FourSShopsViewModel mViewModel;
    private FragmentFoursshopsBinding binding;
    private FourSShopsAdapter adapter;
    private List<FourSShopsObservable> data = new ArrayList<>();
    private FourSShopsOverallObservable overallObservable = new FourSShopsOverallObservable();
    private List<Marker> markers;
    private String fromTag = "";

    private AMapLocation currentLocation;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mViewModel = ViewModelProviders.of(this, factory).get(FourSShopsViewModel.class);
        if (getArguments() != null) {
            fromTag = getArguments().getString(MapMarkerActivity.EXTRA_SUBTYPE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_foursshops, container, false);
        binding.setMlistener(this);
        binding.setFoursshopentity(overallObservable);
        binding.rvFoursshopStation.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rvFoursshopStation.addItemDecoration(new SpaceItemDecoration(getActivity()));
        adapter = new FourSShopsAdapter(overallObservable, this, mListener);
        binding.rvFoursshopStation.setAdapter(adapter);
        mListener.setOnMarkerClickListener(this);
        overallObservable.setShowStatus(FourSShopsOverallObservable.LOADING);
        mViewModel.getFourSShopList().observe(this, domain4SShops -> {
            mListener.showListLayout();
            if (domain4SShops == null || domain4SShops.size() == 0) {
                //加载失败
                overallObservable.setShowStatus(FourSShopsOverallObservable.ERROR);
                return;
            }
            //获取到所有的4S店
            returnToActivityLocation(domain4SShops);
            data.clear();
            for (int i = 0; i < domain4SShops.size(); i++) {
                data.add(new FourSShopsObservable(domain4SShops.get(i), i));
            }
            if (adapter != null) {
                adapter.addAll(data);
            }
            overallObservable.setShowStatus(FourSShopsOverallObservable.LIST);
        });
        mViewModel.getAdFromType().observe(this, domainAd -> {
            //获取到相应类型的广告
            mListener.showListLayout();
            overallObservable.setDomainAd(domainAd);
        });

        mViewModel.getLocation().observe(this, aMapLocation -> {
            //获取到定位信息
            if (aMapLocation != null) {
                currentLocation = aMapLocation;
//                mListener.animateToLocation(
//                        new LatLng(aMapLocation.getLatitude(), aMapLocation.getLongitude()));
            } else
                Timber.tag(TAG).d("can' t get current location.");
        });
        return binding.getRoot();
    }

    //返回获取到的信息到Activity的地图界面
    private void returnToActivityLocation(List<Domain4SShop> domain4SShops) {
        ArrayList<MarkerOptions> markerOptions = new ArrayList<>();
        LatLngBounds.Builder bounds = new LatLngBounds.Builder();

        for (Domain4SShop station : domain4SShops) {
            LatLng ll = new LatLng(station.latitude, station.longitude);
            bounds.include(ll);
            MarkerOptions options = new MarkerOptions().position(ll)
                    .draggable(false)
                    .title(station.name)
                    .snippet(station.serviceAddress);
            markerOptions.add(options);
        }
        if (markerOptions.size() > 0) {
            markers = mListener.updateMarker(markerOptions);
            handler.postDelayed(() -> {
                adapter.selectItem(0);
                mListener.animateToBound(bounds.build(), 500, 96, 0, 0);
            }, 250);
        }
    }

    private Handler handler = new Handler();

    @Override
    public void onStart() {
        super.onStart();
        mViewModel.getFourSShops(mClient);
        mViewModel.getAD(fromTag);
    }

    @Override
    public void onCloseAd(View view) {
        //广告去除的×
        overallObservable.setAdShow(false);
    }

    @Override
    public void onBack(View view) {
        //返回去list界面
        overallObservable.setShowStatus(FourSShopsOverallObservable.LIST);
    }

    @Override
    public void onShowRoute(FourSShopsOverallObservable mFourSShopsOverallObservable) {
        //去4s店的点击事件 跳转Activity
        if (mFourSShopsOverallObservable.getLatitude() != 0.0 && mFourSShopsOverallObservable.getLongitude() != 0.0) {
            NaviLatLng foursShop
                    = new NaviLatLng(
                    mFourSShopsOverallObservable.getLatitude(),
                    mFourSShopsOverallObservable.getLongitude());
            mListener.onRouterShow(foursShop);
        }
    }

    @Override
    public void onLoadClick(View view) {
        //loading 重新加载
        mViewModel.getFourSShops(mClient);
        overallObservable.setShowStatus(FourSShopsOverallObservable.LOADING);
    }

    @Override
    public void onItemClick(FourSShopsObservable newer) {
        adapter.selectItem(newer.getPosition());
    }

    @Override
    public void onMarkerClick(int index) {
        adapter.selectItem(index);
        binding.rvFoursshopStation.scrollToPosition(index);
    }
}
