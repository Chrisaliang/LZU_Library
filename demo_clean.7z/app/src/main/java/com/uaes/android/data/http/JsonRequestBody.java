package com.uaes.android.data.http;

import android.support.annotation.NonNull;

import java.io.IOException;

import javax.annotation.Nullable;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

/**
 * Created by aber on 1/25/2018.
 * Json Request body
 */

public class JsonRequestBody extends RequestBody {

    private static final MediaType JSON_TYPE = MediaType.parse("application/json");

    private final String jsonString;

    public JsonRequestBody(String jsonString) {
        this.jsonString = jsonString;
    }

    @Nullable
    @Override
    public MediaType contentType() {
        return JSON_TYPE;
    }

    @Override
    public void writeTo(@NonNull BufferedSink sink) throws IOException {
        sink.writeUtf8(jsonString);
    }

    public String getJson() {
        return jsonString;
    }
}
