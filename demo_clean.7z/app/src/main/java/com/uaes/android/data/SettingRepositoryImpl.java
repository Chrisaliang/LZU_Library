package com.uaes.android.data;

import android.content.Context;

import com.google.gson.Gson;
import com.uaes.android.AuthFunction;
import com.uaes.android.data.http.JsonRequestBody;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.json.GeneralAttributeSent;
import com.uaes.android.data.room.LowFuelWarningDao;
import com.uaes.android.data.room.LowFuelWarningSettingEntity;
import com.uaes.android.domain.SettingRepository;
import com.uaes.android.domain.pojo.DomainSetting;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by Chrisaliang on 2017/11/9.
 * data from sever
 */

public class SettingRepositoryImpl implements SettingRepository {
    private static final String LOW_FUEL_JSON_TYPE = "CSthreshold";
    private final SettingApi settingApi;
    private final Gson gson;
    private final LowFuelWarningDao dao;
    private final Context context;
    private final DomainSetting domainSetting = new DomainSetting();

    public SettingRepositoryImpl(LowFuelWarningDao dao, SettingApi settingApi, Gson gson, Context context) {
        this.settingApi = settingApi;
        this.gson = gson;
        this.dao = dao;
        this.context = context;
    }


    @Override
    public Single<DomainSetting> lowFuelWarningSent(int lowFuelNum) {
        return Single.just(lowFuelNum).flatMap(lowFuelNum1 -> {
            GeneralAttributeSent attributeData = new GeneralAttributeSent();
            List<GeneralAttributeSent.GeneralAttribute> list = new ArrayList<>();
            GeneralAttributeSent.GeneralAttribute attr = new GeneralAttributeSent.GeneralAttribute();
            attr.attributeType = LOW_FUEL_JSON_TYPE;
            attr.attributeValue = String.valueOf(lowFuelNum1);
            list.add(attr);
            attributeData.attributeList = list;
            JsonRequestBody body = new JsonRequestBody(gson.toJson(attributeData));
            return settingApi.lowFuelWarningSent(body);
        }).map(res -> {
            LowFuelWarningSettingEntity entity = new LowFuelWarningSettingEntity();
            entity.setId(0);
            entity.setTime(System.currentTimeMillis());
            domainSetting.lowOilLevel = Integer.parseInt(res.msgContent.attributeList.get(0).attributeValue, 10);
            entity.lowFuelWarning = domainSetting.lowOilLevel;
            dao.insertLowFuelWarning(entity);
            return domainSetting;
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    // ["string"]
    // {"msgCode":"10000","msg":"OK","content":{"attributeList":[{"attributeType":"CSthreshold","attributeValue":"14"}]},"status":1,"total":1}
    @Override
    public Single<DomainSetting> lowFuelWarningReceive() {
        return Single.just(domainSetting).map(domainSetting -> {
            LowFuelWarningSettingEntity result = null;
            try {
                result = dao.queryLowFuelWarning();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (result == null) {
                domainSetting.lowOilLevel = 7;
            } else {
                domainSetting.lowOilLevel = result.lowFuelWarning;
            }
            return domainSetting;
        }).onErrorReturn(new AuthFunction<>(context))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io());
    }
}
