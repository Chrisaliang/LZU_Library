package com.uaes.android.domain;

import io.reactivex.Single;

/**
 * Created by aber on 1/27/2018.
 * Cache
 */

public interface CacheTimeRepository {

    Single<Long> queryCacheTimeByTableName(String tableName);
}
