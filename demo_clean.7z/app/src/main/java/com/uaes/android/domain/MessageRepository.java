package com.uaes.android.domain;

import com.uaes.android.domain.pojo.DomainMessage;

import java.util.List;

import io.reactivex.Single;

/**
 * Author : 张 涛
 * Time : 2018/1/16.
 * Des : 用来提供维护消息的功能，例如
 * 消息的保存，修改，删除
 */

public interface MessageRepository {
    /**
     * 保存推送的来的消息
     */
    Single<Boolean> saveMessage(DomainMessage... messages);

    Single<Boolean> updateMessage(DomainMessage... messages);

    Single<Boolean> deleteMessage(DomainMessage... messages);

    @Deprecated
    Single<List<DomainMessage>> queryMessage(int readState);

    /**
     * 统计某大类型未读消息数量
     */
    Single<Integer> countUnreadMessage(String messageClass);

    /**
     * 查询大类型全部消息
     */
    Single<List<DomainMessage>> queryMessage(String messageClass);
}
