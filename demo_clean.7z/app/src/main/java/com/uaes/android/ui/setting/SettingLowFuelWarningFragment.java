package com.uaes.android.ui.setting;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.uaes.android.R;
import com.uaes.android.domain.AuthorizationSingleObserver;
import com.uaes.android.domain.SettingRepository;
import com.uaes.android.domain.pojo.DomainSetting;
import com.uaes.android.ui.TopLevelFragment;

import java.util.Locale;

import javax.inject.Inject;

import io.reactivex.disposables.Disposable;
import timber.log.Timber;
import uaes.com.view.StepSettingView;

/**
 * Created by Chrisaliang on 2017/11/3.
 * low fuel waring fragment
 * todo refresh
 */

public class SettingLowFuelWarningFragment extends TopLevelFragment
        implements StepSettingView.OnChangeListener {

    private static final double FUEL_CAPACITY = 55.0;
    //    private static final int DEFAULT_LOW_FUEL_SETTING = 7;
    private static final String TAG = SettingLowFuelWarningFragment.class.getSimpleName();

    //    private static final String LOW_FUEL_WARNING = "low_fuel_warning";
    @Inject
    SettingRepository repository;
    private TextView lowFuelResultTv;
    private TextView lowFuelPercentTv;
    private StepSettingView progressFuel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_low_fuel, container, false);
        lowFuelResultTv = view.findViewById(R.id.tv_low_fuel_result);
        lowFuelPercentTv = view.findViewById(R.id.tv_fuel_percent);
        progressFuel = view.findViewById(R.id.progress_low_fuel);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressFuel.setOnChangeListener(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        repository.lowFuelWarningReceive().subscribe(new SettingLowFuelObserver(getActivity()));
    }

    @Override
    public void onStop() {
        super.onStop();
        if (sendDisposable != null) {
            sendDisposable.dispose();
        }

        if (queryDisposable != null) {
            queryDisposable.dispose();
        }
    }

    private void sentLowFuelWaringSetting(int lowFuelSetting) {
        repository.lowFuelWarningSent(lowFuelSetting)
                .subscribe(new SendLowFuelObserver(getActivity()));
    }

    @Override
    public void back() {

    }

    @Override
    public void onChange(int i) {
        lowFuelResultTv.setText(String.format(Locale.CHINESE, "%d", i));
        lowFuelPercentTv.setText(String.format("%s", Math.round((i / FUEL_CAPACITY) * 100)));
    }

    @Override
    public void onUp(int i) {
        sentLowFuelWaringSetting(i);
        Log.d(TAG, "onUp: ");
        lowFuelResultTv.setText(String.format(Locale.CHINESE, "%d", i));
        lowFuelPercentTv.setText(String.format("%s", Math.round((i / FUEL_CAPACITY) * 100)));
    }

    private Disposable sendDisposable;

    private class SendLowFuelObserver extends AuthorizationSingleObserver<DomainSetting> {

        SendLowFuelObserver(Context context) {
            super(context);
        }

        @Override
        public void onSubscribe(Disposable d) {
            sendDisposable = d;
        }

        @Override
        public void onSuccess(DomainSetting generalAttributeSent) {
            Timber.tag(TAG).d("onSuccess: %s", generalAttributeSent);
        }

        @Override
        public void onError(Throwable e) {
            super.onError(e);
            Timber.tag(TAG).d(e);
            Toast.makeText(getActivity(), "保存失败", Toast.LENGTH_SHORT).show();
        }
    }

    private Disposable queryDisposable;

    private class SettingLowFuelObserver extends AuthorizationSingleObserver<DomainSetting> {

        SettingLowFuelObserver(Context context) {
            super(context);
        }

        @Override
        public void onSubscribe(Disposable d) {
            queryDisposable = d;
        }

        @Override
        public void onSuccess(DomainSetting domainSetting) {
            progressFuel.setCurrentProgress(domainSetting.lowOilLevel);
            lowFuelResultTv.setText(String.format(Locale.CHINESE, "%d", domainSetting.lowOilLevel));
            lowFuelPercentTv.setText(String.format("%s", Math.round((domainSetting.lowOilLevel / FUEL_CAPACITY) * 100)));
        }

        @Override
        public void onError(Throwable e) {
            super.onError(e);
            Timber.tag(TAG).d(e);
        }
    }
}
