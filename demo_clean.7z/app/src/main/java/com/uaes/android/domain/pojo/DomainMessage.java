package com.uaes.android.domain.pojo;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Author : 张 涛
 * Time : 2018/1/16.
 * Des : This is
 */

public class DomainMessage implements Parcelable {

    public static final String MESSAGE_TYPE_0 = "fuelFill"; // 记账提醒 // 通知
    public static final String MESSAGE_TYPE_1 = "fuelWarn"; // 低油量预警 // 通知
    public static final String MESSAGE_TYPE_2 = "engineOilQu"; // 建议尽快更换机油
    public static final String MESSAGE_TYPE_3 = "sparkPlugAg1"; // 火花塞老化
    public static final String MESSAGE_TYPE_4 = "sparkPlugAg2"; //
    public static final String MESSAGE_TYPE_5 = "sparkPlugAg3";
    public static final String MESSAGE_TYPE_6 = "sparkPlugAg4";
    public static final String MESSAGE_TYPE_7 = "engineOilIm"; // 建立立即更换机油 // 故障
    public static final String MESSAGE_TYPE_8 = "batteryPowerSh"; // 蓄电池电量不足

    public long id;
    public String title;//消息的头
    public String body;//消息的内容
    public String type;//消息小类，APP 根据该key 决定下一步具体操作。
    public String messageClass;//消息大类，APP 根据该key 决定推送汇总界面的显示
    public String systemTime;//消息的的系统时间
    public int hasRead;//0表示未读，1表示已读
    public String contentJson; // actual action

    public DomainMessage() {
    }

    public DomainMessage(String title, String body, String type, String messageClass, String systemTime, String contentJson) {
        this.title = title;
        this.body = body;
        this.type = type;
        this.messageClass = messageClass;
        this.systemTime = systemTime;
        this.hasRead = 0;
        this.contentJson = contentJson;
    }


    public DomainMessage(DomainMessage last, int hasRead) {
        this.id = last.id;
        this.title = last.title;
        this.body = last.body;
        this.type = last.type;
        this.messageClass = last.messageClass;
        this.systemTime = last.systemTime;
        this.contentJson = last.contentJson;
        this.hasRead = hasRead;
    }

    protected DomainMessage(Parcel in) {
        id = in.readLong();
        title = in.readString();
        body = in.readString();
        type = in.readString();
        messageClass = in.readString();
        systemTime = in.readString();
        hasRead = in.readInt();
        contentJson = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(title);
        dest.writeString(body);
        dest.writeString(type);
        dest.writeString(messageClass);
        dest.writeString(systemTime);
        dest.writeInt(hasRead);
        dest.writeString(contentJson);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<DomainMessage> CREATOR = new Creator<DomainMessage>() {
        @Override
        public DomainMessage createFromParcel(Parcel in) {
            return new DomainMessage(in);
        }

        @Override
        public DomainMessage[] newArray(int size) {
            return new DomainMessage[size];
        }
    };
}
