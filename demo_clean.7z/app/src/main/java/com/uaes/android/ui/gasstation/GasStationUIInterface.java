package com.uaes.android.ui.gasstation;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationListener;
import com.uaes.android.viewmodel.GasStationViewModel;

import java.util.List;

/**
 * Created by Chrisaliang on 2017/11/3.
 * interface for ui adapter
 */

public interface GasStationUIInterface extends AMapLocationListener {

    int getCurrentPage();

    AMapLocation getLocation();

    void queryStation(int strategy);

    void queryNext();

    void queryPrevious();

    void onDestroy();
}

interface GasUIListener {
    /**
     * 第一次定位成功回调
     */
    void onFirstLocationUpdate(AMapLocation location);

    /**
     * 第一次定位失败时回调此方法
     */
    void onFirstLocationError();

    /**
     * 后续定位成功回调
     */
    void onLocationUpdate(AMapLocation location);

    /**
     * 后续定位失败回调
     */
    void onLocationError(int error);

    /**
     * 第一次Poi查询失败
     */
    void onFirstResultError();

    /**
     * 查询结果
     */
    void onResult(List<GasStationViewModel> resultList);

    /**
     * 下翻页翻页失败结果
     *
     * @param pageNum 打算请求的页面
     */
    @SuppressWarnings("SameParameterValue")
    void onNextResultError(int pageNum);

    /**
     * 上翻页失败结果
     *
     * @param pageNum 打算请求的页面
     */
    @SuppressWarnings("SameParameterValue")
    void onPreviousResultError(int pageNum);

    /**
     * 已经没有更多数据了
     */
    void onNoMoreResult();

    /**
     * 现在已经是第一页了
     */
    void onFirstPageNumArrived();

    /**
     * 返回结果失败
     */
    void onResultError();
}