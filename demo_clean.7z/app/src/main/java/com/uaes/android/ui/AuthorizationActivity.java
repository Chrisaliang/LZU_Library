package com.uaes.android.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

import com.uaes.android.data.http.HapAuthorizationInterceptor;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.common.Intents;

import javax.inject.Inject;

/**
 * Created by hand on 2017/11/8.
 * 基础 Token 类
 */

public abstract class AuthorizationActivity extends BaseActivity {

    @Inject
    HapAuthorizationInterceptor hapAuthorizationInterceptor;

    @Inject
    RepositoryVMProvider factory;

    private BroadcastReceiver authorizationsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intents.ACTION_AUTHORIZATION.equals(intent.getAction())) {
                finishAffinity();
                hapAuthorizationInterceptor.inValid();
                Intent reCertification = new Intent(context, LauncherActivity.class);
                startActivity(reCertification);
            }
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intents.ACTION_AUTHORIZATION);
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(authorizationsReceiver, intentFilter);

    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this)
                .unregisterReceiver(authorizationsReceiver);
    }
}
