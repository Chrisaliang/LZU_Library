package com.uaes.android.viewmodel;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;

import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.MaintenanceRepository;
import com.uaes.android.domain.MessageRepository;
import com.uaes.android.domain.Super4SRepository;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Created by aber on 12/4/2017.
 * View model Factory
 */
@Singleton
public class RepositoryVMProvider implements ViewModelProvider.Factory {

    private final FuelManagerRepository fuelManagerRepository;

    private final MessageRepository mMessageRepository;

    private final MaintenanceRepository maintenanceRepository;

    private final Super4SRepository mSuper4SRepository;

    @Inject
    public RepositoryVMProvider(FuelManagerRepository fuelManagerRepository,
                                MessageRepository mMessageRepository,
                                MaintenanceRepository maintenanceRepository,
                                Super4SRepository mSuper4SRepository) {
        this.fuelManagerRepository = fuelManagerRepository;
        this.mMessageRepository = mMessageRepository;
        this.maintenanceRepository = maintenanceRepository;
        this.mSuper4SRepository = mSuper4SRepository;
    }

    @SuppressWarnings("unchecked")
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(FuelStateViewModel.class)) {
            return (T) new FuelStateViewModel(fuelManagerRepository);
        } else if (modelClass.isAssignableFrom(FuelSingleRecordViewModel.class)) {
            return (T) new FuelSingleRecordViewModel(fuelManagerRepository);
        } else if (modelClass.isAssignableFrom(FuelRecordViewModel.class)) {
            return (T) new FuelRecordViewModel(fuelManagerRepository);
        } else if (modelClass.isAssignableFrom(FuelHistoryViewModel.class)) {
            return (T) new FuelHistoryViewModel(fuelManagerRepository);
        } else if (modelClass.isAssignableFrom(MessageStateViewModel.class)) {
            return (T) new MessageStateViewModel(mMessageRepository);
        } else if (modelClass.isAssignableFrom(SparkingPlugViewModel.class)) {
            return (T) new SparkingPlugViewModel(maintenanceRepository);
        } else if (modelClass.isAssignableFrom(FourSShopsViewModel.class)) {
            return (T) new FourSShopsViewModel(mSuper4SRepository);
        } else if (modelClass.isAssignableFrom(BatteryAssistantViewModel.class)) {
            return (T) new BatteryAssistantViewModel(maintenanceRepository);
        }
        throw new IllegalArgumentException("not support the class:" + modelClass);
    }
}
