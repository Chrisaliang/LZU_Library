package com.uaes.android.domain.exception;

import com.amap.api.location.AMapLocation;

/**
 * Created by aber on 1/23/2018.
 * When AMap Location got a error or can't get correct location by network.
 */

public class LocationFailException extends IllegalStateException {

    public final AMapLocation errorLocation;

    public LocationFailException(AMapLocation errorLocation) {
        super(errorLocation.getErrorInfo());
        this.errorLocation = errorLocation;
    }
}
