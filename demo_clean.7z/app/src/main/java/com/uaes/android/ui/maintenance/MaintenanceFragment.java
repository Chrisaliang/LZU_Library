package com.uaes.android.ui.maintenance;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.uaes.android.R;
import com.uaes.android.ui.TopLevelFragment;
import com.uaes.android.ui.maintenance.engineoil.EngineOilFragment;
import com.uaes.common.Intents;

import java.util.List;

/**
 * Created by hand on 2017/11/9.
 * holder
 */

public class MaintenanceFragment extends TopLevelFragment implements View.OnClickListener {
    private static final String MAINTENANCE_HELPER_TAG = "MAINTENANCE_HELPER_TAG_FRAGMENT";
    private ImageView engineOilView;//机油
    private ImageView sparkingPlugView;//火花塞
    private View home;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_maintain_helper, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        engineOilView = view.findViewById(R.id.maintain_helper_engine_oil);
        sparkingPlugView = view.findViewById(R.id.maintain_helper_sparking_plug);
        home = view.findViewById(R.id.maintain_helper_home);
        engineOilView.setOnClickListener(this);
        sparkingPlugView.setOnClickListener(this);

        Bundle args = getArguments();
        if (args != null) {
            String subPage = args.getString("subPage");
            View clickView;
            if (EngineOilFragment.class.getSimpleName().equals(subPage)) {
                clickView = engineOilView;
            } else {
                clickView = sparkingPlugView;
            }
            onClick(clickView);
        }
    }

    @Override
    public void back() {
        home.setVisibility(View.VISIBLE);
        getChildFragmentManager().popBackStack();
//        getFragmentManager().popBackStack();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        List<Fragment> fragments = getChildFragmentManager().getFragments();
        for (Fragment fragment : fragments) {
            fragment.onHiddenChanged(hidden);//传递当前fragmengt的显示状态
        }
    }

    @Override
    public void onClick(View v) {
        home.setVisibility(View.INVISIBLE);
        FragmentManager fm = getChildFragmentManager();
//        FragmentManager fm = getFragmentManager();
        Fragment fragment = fm.findFragmentByTag(MAINTENANCE_HELPER_TAG);
        if (fragment == null) {
            fragment = new MaintenanceHelperFragment();
        }
        Bundle bundle = new Bundle();
        if (v == engineOilView) {//机油
            bundle.putInt(Intents.MAINTENANCE_HELPER_FRAGMENT_ARGUMENTS, 0);
        } else if (v == sparkingPlugView) {//火花塞
            bundle.putInt(Intents.MAINTENANCE_HELPER_FRAGMENT_ARGUMENTS, 1);
        }
        fragment.setArguments(bundle);
        FragmentTransaction transaction = fm.beginTransaction();
        transaction.replace(R.id.maintain_helper_parent, fragment, MAINTENANCE_HELPER_TAG)
                .addToBackStack(MAINTENANCE_HELPER_TAG)
                .commit();
    }
}
