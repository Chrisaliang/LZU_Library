package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.uaes.android.BR;
import com.uaes.android.viewmodel.FuelStateViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Created by aber on 12/4/2017.
 * Data Binding for Fuel Status
 */

public class FuelStatsViewObservable extends BaseObservable {
    private final FuelStateViewModel viewModel;
    // 经济性排名 百分数
    private int rank;
    // 经济性排名的颜色
    private int rankRingColor;
    // 剩余油量的颜色
    private int remainFuelRingColor;
    //    // 剩余油量 单位为升 字符串
//    private String fuelRest;
    // 剩余油量 单位 升 数值
    private int fuelRestValue;
    // 汽油牌号
    private String fuelNum;
    // 剩余里程
    private String fuelMiles;
    // 百公里油耗
    private String costOfHundredMiles;
    private int status = RetryView.RETRY_LOADING;

    public FuelStatsViewObservable(FuelStateViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void onClick(RetryView view) {
        viewModel.update();
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public int getRankRingColor() {
        return rankRingColor;
    }

    public void setRankRingColor(int rankRingColor) {
        this.rankRingColor = rankRingColor;
        notifyPropertyChanged(BR.rankRingColor);
    }

    @Bindable
    public int getRemainFuelRingColor() {
        return remainFuelRingColor;
    }

    public void setRemainFuelRingColor(int remainFuelRingColor) {
        this.remainFuelRingColor = remainFuelRingColor;
        notifyPropertyChanged(BR.remainFuelRingColor);
    }

    @Bindable
    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
        notifyPropertyChanged(BR.rank);
    }

//    @Bindable
//    public String getFuelRest() {
//        return fuelRest;
//    }

//    @Bindable
//    public void setFuelRest(String fuelRest) {
//        this.fuelRest = fuelRest;
//        notifyPropertyChanged(BR.fuelRest);
//    }

    @Bindable
    public int getFuelRestValue() {
        return fuelRestValue;
    }

    public void setFuelRestValue(int fuelRestValue) {
        this.fuelRestValue = fuelRestValue;
        notifyPropertyChanged(BR.fuelRestValue);
    }

    @Bindable
    public String getFuelNum() {
        return fuelNum;
    }

    public void setFuelNum(String fuelNum) {
        this.fuelNum = fuelNum;
        notifyPropertyChanged(BR.fuelNum);
    }

    @Bindable
    public String getFuelMiles() {
        return fuelMiles;
    }

    public void setFuelMiles(String fuelMiles) {
        this.fuelMiles = fuelMiles;
        notifyPropertyChanged(BR.fuelMiles);
    }

    @Bindable
    public String getCostOfHundredMiles() {
        return costOfHundredMiles;
    }

    public void setCostOfHundredMiles(String costOfHundredMiles) {
        this.costOfHundredMiles = costOfHundredMiles;
        notifyPropertyChanged(BR.costOfHundredMiles);
    }
}
