package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.support.annotation.NonNull;

import com.uaes.android.BR;
import com.uaes.android.domain.pojo.DomainAd;

import java.text.DecimalFormat;

/**
 * Author : 张 涛
 * Time : 2018/1/26.
 * Des : This is
 */

public class FourSShopsOverallObservable extends BaseObservable {

    public static final int ERROR = -1;
    public static final int LOADING = 0;
    public static final int LIST = 1;
    public static final int DETAIL = 2;

    ////////////////////////////////4S店Entity
    private String name;
    private String serviceAddress;
    private String phone;
    private String distance;
    private String duration;
    // 经度
    private double longitude;
    //维度
    private double latitude;
    ////////////////////////////////

    ////////////////////////////////广告
    private String adTitle;//广告头
    private String adDes;//广告描述
    ////////////////////////////////

    private boolean isShowAd;//广告是否显示

    private int showStatus;

    public FourSShopsOverallObservable() {
        this.isShowAd = true;//默认广告显示
        showStatus = LOADING;
    }


    public void setFourSShopsObservable(FourSShopsObservable mFourSShopsObservable) {
        this.setLatitude(mFourSShopsObservable.getLatitude());
        this.setLongitude(mFourSShopsObservable.getLongitude());
        this.setName(mFourSShopsObservable.getName());
        this.setServiceAddress("位置：" + mFourSShopsObservable.getServiceAddress());
        this.setDistance("距离：" + getTotalLen(mFourSShopsObservable.getDistance()));
        this.setDuration("预计耗时：" + getTimeStr(mFourSShopsObservable.getDuration()));
        this.setPhone("服务电话：" + mFourSShopsObservable.getServiceTel());
    }

    private String getTimeStr(int second) {
        if (second <= 0) return "未知";
        StringBuilder time = new StringBuilder("约");
        if (second < 60) return time.append(second).append("秒").toString();
        int minutes = (int) Math.round(second / 60.0);
        if (minutes < 60) return time.append(minutes).append("分钟").toString();
        else {
            int hour = minutes / 60;
            time.append(hour).append("小时");
            if (minutes % 60 != 0) time.append(minutes % 60).append("分钟");
        }
        return time.toString();
    }


    @NonNull
    private String getTotalLen(int length) {
        if (length < 0) return "";
        if (length < 1000) return length + "米";
        else return new DecimalFormat("#.0").format(length / 1000.0) + "公里";
    }


    @Bindable
    public boolean isShowError() {
        return showStatus == ERROR;
    }

    @Bindable
    public boolean isShowDetail() {
        return showStatus == DETAIL;
    }

    @Bindable
    public boolean isLoading() {
        return showStatus == LOADING;
    }

    @Bindable
    public boolean isShowList() {
        return showStatus == LIST;
    }

    public void setShowStatus(int status) {
        this.showStatus = status;
        notifyPropertyChanged(BR.loading);
        notifyPropertyChanged(BR.showDetail);
        notifyPropertyChanged(BR.showError);
        notifyPropertyChanged(BR.showList);
    }

    @Bindable
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
        notifyPropertyChanged(BR.longitude);
    }

    @Bindable
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
        notifyPropertyChanged(BR.latitude);
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
    }

    @Bindable
    public String getServiceAddress() {
        return serviceAddress;
    }

    public void setServiceAddress(String serviceAddress) {
        this.serviceAddress = serviceAddress;
        notifyPropertyChanged(BR.serviceAddress);
    }

    @Bindable
    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
        notifyPropertyChanged(BR.distance);
    }

    @Bindable
    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
        notifyPropertyChanged(BR.duration);
    }

    public void setDomainAd(DomainAd mDomainAd) {
        this.setAdTitle(mDomainAd.title);
        this.setAdDes(mDomainAd.description);
    }

    @Bindable
    public String getAdTitle() {
        return adTitle;
    }

    public void setAdTitle(String adTitle) {
        this.adTitle = adTitle;
        notifyPropertyChanged(BR.adTitle);
    }

    @Bindable
    public String getAdDes() {
        return adDes;
    }

    public void setAdDes(String adDes) {
        this.adDes = adDes;
        notifyPropertyChanged(BR.adDes);
    }

    @Bindable
    public boolean getShowAd() {
        return isShowAd;
    }

    public void setAdShow(boolean adShow) {
        this.isShowAd = adShow;
        notifyPropertyChanged(BR.showAd);
    }

    @Bindable
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
        notifyPropertyChanged(BR.phone);
    }
}
