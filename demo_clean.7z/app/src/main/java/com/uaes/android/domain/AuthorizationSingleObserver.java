package com.uaes.android.domain;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.CallSuper;
import android.support.v4.content.LocalBroadcastManager;

import io.reactivex.SingleObserver;
import retrofit2.HttpException;
import timber.log.Timber;

/**
 * Created by hand on 2017/11/8.
 * Base Authorization SingleObserver
 */

@SuppressWarnings("unused")
public abstract class AuthorizationSingleObserver<T> implements SingleObserver<T> {

    protected Context context;

    public AuthorizationSingleObserver(Context context) {
        this.context = context.getApplicationContext();
    }

    @Override
    @CallSuper
    public void onError(Throwable e) {
        if (e instanceof HttpException) {
            HttpException exception = (HttpException) e;
            if (exception.code() == 401) {
                Intent intent = new Intent("com.uaes.iot.INVALID_TOKEN");
                LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            }
            Timber.tag("HTTP ERROR").d("onError: %s", exception.message());
        }
    }
}
