package com.uaes.android.ui.message.adapter;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.domain.pojo.DomainMessage;
import com.uaes.android.ui.message.listener.ImageChooseClickListener;
import com.uaes.android.ui.message.listener.RecycleViewItemOnClick;
import com.uaes.android.viewmodel.MessageStateViewModel;
import com.uaes.android.viewobservable.MessageStatesItemObservable;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Author : 张 涛
 * Time : 2018/1/15.
 * Des : This is 消息界面的RecyclerView的Adapter
 */

public class MessagesAdapter extends RecyclerView.Adapter<BindingViewHolder> implements RecycleViewItemOnClick {

    private static final String TAG = "MessagesAdapter";
    private List<MessageStatesItemObservable> mMessageList;
    private boolean mEditMode = false;//是否为编辑状态
    private MessageStateViewModel mViewModel;
    private ImageChooseClickListener jumpListener;

    public MessagesAdapter(MessageStateViewModel mViewModel, ImageChooseClickListener listener) {
        this.mViewModel = mViewModel;
        mMessageList = new ArrayList<>();
        this.jumpListener = listener;
    }

    @Override
    public BindingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ViewDataBinding binding;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        binding = DataBindingUtil.inflate(inflater,
                R.layout.adapter_item_message, parent, false);
        return new BindingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(BindingViewHolder holder, final int position) {
        final MessageStatesItemObservable mMessages = mMessageList.get(position);
        holder.getBinding().setVariable(com.uaes.android.BR.item, mMessages);
        holder.getBinding().setVariable(BR.itemlistener, this);
        holder.getBinding().executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return mMessageList.size();
    }

    //选中事件
    @Override
    public void onItemClick(MessageStatesItemObservable mMessageStatesItemObservable) {
        if (mEditMode) {
            mMessageStatesItemObservable.setSelect(!mMessageStatesItemObservable.getSelect());
        }
    }

    //点击查看事件
    @Override
    public void onNoSelectItemClick(MessageStatesItemObservable mMessageStatesItemObservable) {
        if (mMessageStatesItemObservable.getCurrentClick()) {
            jumpListener.jumpToMessageType(mMessageStatesItemObservable);
            return;
        }
        if (mMessageList != null) {
            for (int i = 0; i < mMessageList.size(); i++) {
                mMessageList.get(i).setCurrentClick(false);
            }
        }
        if (mMessageStatesItemObservable.getMessageEntity().hasRead != 1) {
            mViewModel.updateMessage(new DomainMessage(mMessageStatesItemObservable.getMessageEntity(), 1)).subscribe(new SingleObserver<Boolean>() {
                @Override
                public void onSubscribe(Disposable d) {

                }

                @Override
                public void onSuccess(Boolean aBoolean) {
                    mMessageStatesItemObservable.setMessageEntity(new DomainMessage(mMessageStatesItemObservable.getMessageEntity(), 1));
                }

                @Override
                public void onError(Throwable e) {
                    Timber.tag(TAG).d(e);
                }
            });
        }
        mMessageStatesItemObservable.setCurrentClick(true);
    }


    public void addAll(List<MessageStatesItemObservable> employees) {
        mMessageList.addAll(employees);
        notifyDataSetChanged();
    }

    public void addNewAll(List<MessageStatesItemObservable> employees) {
        mMessageList.clear();
        mMessageList.addAll(employees);
        notifyDataSetChanged();
    }

    public void setEditMode(boolean mode) {
        mEditMode = mode;
        if (mMessageList != null) {
            for (int i = 0; i < mMessageList.size(); i++) {
                mMessageList.get(i).setAllowEdit(mode);
            }
        }
        notifyDataSetChanged();
    }

    public void setAllSelect(boolean hasSelect) {
        if (mMessageList != null) {
            for (int i = 0; i < mMessageList.size(); i++) {
                mMessageList.get(i).setSelect(hasSelect);
            }
        }
        notifyDataSetChanged();
    }

    public void setClearClick() {
        if (mMessageList != null) {
            for (int i = 0; i < mMessageList.size(); i++) {
                mMessageList.get(i).setCurrentClick(false);
            }
        }
        notifyDataSetChanged();
    }

    public DomainMessage[] getNeedDelete(String tag) {
        List<DomainMessage> deleteMessage = new ArrayList<>();
        for (MessageStatesItemObservable message : mMessageList) {
            if (message.getSelect() && message.getMessageEntity().messageClass.equals(tag)) {
                deleteMessage.add(message.getMessageEntity());
            }
        }
        return deleteMessage.toArray(new DomainMessage[deleteMessage.size()]);
    }

}
