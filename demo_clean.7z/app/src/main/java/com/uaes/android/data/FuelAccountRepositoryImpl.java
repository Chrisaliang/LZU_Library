package com.uaes.android.data;

import android.content.Context;

import com.google.gson.Gson;
import com.uaes.android.AuthFunction;
import com.uaes.android.data.http.FuelAccountApi;
import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.domain.FuelAccountRepository;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Created by Administrator on 2017/11/10 0010.
 * impl interface of account
 */

public class FuelAccountRepositoryImpl implements FuelAccountRepository {

    private final FuelAccountApi fuelAccountApi;
    private final Gson gson;
    private final Context context;

    public FuelAccountRepositoryImpl(Context context, FuelAccountApi fuelAccountApi, Gson gson) {
        this.context = context;
        this.fuelAccountApi = fuelAccountApi;
        this.gson = gson;
    }

    @Override
    public Single<FuelBookkeeping> setFuelAccount(FuelBookkeeping fuelBookkeeping) {

        return Single.just(fuelBookkeeping)
                .flatMap(fuelBookkeeping1 -> {
                    String json = gson.toJson(fuelBookkeeping1);
                    RequestBody body = RequestBody
                            .create(MediaType.parse("application/json"), json);
                    return fuelAccountApi.setFuelAccount(body);
                })
                .onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
