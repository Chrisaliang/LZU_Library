package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import static com.uaes.android.data.room.Tables.FUEL_RECORD_POINT.COLUMN_FUEL_USE_SUM;
import static com.uaes.android.data.room.Tables.FUEL_RECORD_POINT.COLUMN_MILEAGE;
import static com.uaes.android.data.room.Tables.FUEL_RECORD_POINT.TABLE_NAME;


/**
 * Created by Chrisaliang on 2017/11/7.
 * each point in chart
 */

@Entity(tableName = TABLE_NAME)
public class FuelFillRecordPoint {

    @PrimaryKey
    @Expose(serialize = false, deserialize = false)
    public long id;

    @SerializedName(COLUMN_MILEAGE)
    @ColumnInfo(name = COLUMN_MILEAGE)
    public float xValue;

    @SerializedName(COLUMN_FUEL_USE_SUM)
    @ColumnInfo(name = COLUMN_FUEL_USE_SUM)
    public float yValue;

    @Override
    public String toString() {
        return "FuelFillRecordPoint{" +
                "id=" + id +
                ", xValue=" + xValue +
                ", yValue=" + yValue +
                '}';
    }
}
