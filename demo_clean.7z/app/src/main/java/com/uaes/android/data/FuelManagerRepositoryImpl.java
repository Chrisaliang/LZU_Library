package com.uaes.android.data;

import android.content.Context;
import android.net.ConnectivityManager;

import com.google.gson.Gson;
import com.uaes.android.AuthFunction;
import com.uaes.android.data.http.FuelManagerApi;
import com.uaes.android.data.internal.NetworkCheckMap;
import com.uaes.android.data.json.FuelBookkeeping;
import com.uaes.android.data.json.SingleFuelRecord;
import com.uaes.android.data.maper.FuelHistoryMapper;
import com.uaes.android.data.maper.FuelRecordMapper;
import com.uaes.android.data.maper.FuelSingleRecordMapper;
import com.uaes.android.data.maper.FuelStateMapper;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.domain.FuelManagerRepository;
import com.uaes.android.domain.pojo.DomainFuelHistory;
import com.uaes.android.domain.pojo.DomainFuelRecord;
import com.uaes.android.domain.pojo.DomainFuelSingleRecord;
import com.uaes.android.domain.pojo.DomainFuelState;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Created by Chrisaliang on 2017/11/6.
 * impl in local
 */

public class FuelManagerRepositoryImpl implements FuelManagerRepository {

    private final FuelManagerApi fuelManagerApi;

    private final FuelSingleRecordMapper mFuelSingleMapper;

    private final FuelStateMapper mFuelStateMapper;

    private final FuelRecordMapper fuelRecordMapper;

    private final FuelHistoryMapper fuelHistoryMapper;

    private final CacheDao mCacheDao;

    private final Gson gson;

    private final Context context;

    private final ConnectivityManager cm;

    public FuelManagerRepositoryImpl(Context context, FuelManagerApi fuelManagerApi,
                                     Gson gson, CacheDao dao) {
        this.fuelManagerApi = fuelManagerApi;
        this.mFuelSingleMapper = new FuelSingleRecordMapper(context.getResources());
        this.mFuelStateMapper = new FuelStateMapper(context.getResources());
        this.fuelRecordMapper = new FuelRecordMapper();
        this.fuelHistoryMapper = new FuelHistoryMapper();
        this.gson = gson;
        this.context = context;
        mCacheDao = dao;
        cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    @Override
    public Single<DomainFuelRecord> FuelRecord() {
        return Single.just(cm).map(new NetworkCheckMap())
                .flatMap(
                        isConnected -> isConnected ?
                                fuelManagerApi.fuelRecord().map(
                                        listGeneralAttributeReceive -> {
                                            mCacheDao.replaceFuelFillRecordPoint(listGeneralAttributeReceive.msgContent);
                                            return fuelRecordMapper.map(listGeneralAttributeReceive);
                                        })
                                :
                                mCacheDao.queryFuelRecord().map(
                                        fuelRecordMapper::map
                                )
                )
                .onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<DomainFuelSingleRecord> singleFuelRecord(final int page, int size) {
        final Single<SingleFuelRecord> singleFuelRecordSingle = fuelManagerApi.singleFuelRecord(page, size);

        return Single.just(cm).map(new NetworkCheckMap())
                .flatMap(aBoolean ->
                        aBoolean ? singleFuelRecordSingle.map(
                                singleFuelRecord -> {
                                    mCacheDao.replaceFuelSingleFillRecord(singleFuelRecord);
                                    return mFuelSingleMapper.map(singleFuelRecord);
                                })
                                : mCacheDao.queryFuelSingleRecord()
                                .zipWith(mCacheDao.querySingleRecordCount(),
                                        (list, record) -> mFuelSingleMapper.map(record, list))
                ).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<DomainFuelState> getFuelStatus() {
        return Single.just(cm).map(new NetworkCheckMap())
                .flatMap(isConnection -> isConnection ?
                        fuelManagerApi.fuelStatus()
                                .map(receive -> {
                                    mCacheDao.replaceFuelStatus(receive.msgContent);
                                    return mFuelStateMapper.map(receive.msgContent);
                                }) : mCacheDao.queryFuelStatus()
                        .map(mFuelStateMapper::map)
                ).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<DomainFuelHistory> getFuelHistoryByYear(Integer time) {
        return Single.just(cm).map(new NetworkCheckMap())
                .flatMap(isConnection -> isConnection ?
                        fuelManagerApi.getFuelHistoryByYear(time)
                                .map(receive -> {
                                    mCacheDao.replaceFuelHistoryYear(receive.msgContent);
                                    return fuelHistoryMapper.map(receive.msgContent);
                                }) : mCacheDao.queryFuelHistoryYear()
                        .map(fuelHistoryMapper::map)
                ).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<DomainFuelHistory> getFuelHistoryByMile(Integer mile) {
        return Single.just(cm).map(new NetworkCheckMap())
                .flatMap(isConnection -> isConnection ?
                        fuelManagerApi.getFuelHistoryByMile(mile)
                                .map(receive -> {
                                    mCacheDao.replaceFuelHistoryMile(receive.msgContent);
                                    return fuelHistoryMapper.map(receive.msgContent);
                                }) : mCacheDao.queryFuelHistoryMile()
                        .map(fuelHistoryMapper::map)
                ).onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<FuelBookkeeping> setFuelAccount(FuelBookkeeping fuelBookkeeping) {
        return Single.just(fuelBookkeeping)
                .flatMap(fuelBookkeeping1 -> {
                    String json = gson.toJson(fuelBookkeeping1);
                    RequestBody body = RequestBody
                            .create(MediaType.parse("application/json"), json);
                    return fuelManagerApi.setFuelAccount(body);
                })
                .onErrorReturn(new AuthFunction<>(context))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
}
