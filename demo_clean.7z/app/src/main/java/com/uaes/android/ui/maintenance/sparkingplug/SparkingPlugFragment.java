package com.uaes.android.ui.maintenance.sparkingplug;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentSparkingPlugBinding;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewmodel.SparkingPlugViewModel;
import com.uaes.android.viewobservable.SparkingPlugViewObservable;

import javax.inject.Inject;

/**
 * Author : 张 涛
 * Time : 2018/1/10.
 * Des : This is 火花塞Fragment界面
 */

public class SparkingPlugFragment extends NavigatorFragment {
    private static final String TAG = SparkingPlugFragment.class.getSimpleName();

    @Inject
    RepositoryVMProvider factory;
    private FragmentSparkingPlugBinding binding;
    private SparkingPlugViewModel viewModel;
    private SparkingPlugViewObservable mSparkingPlugViewObservable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(SparkingPlugViewModel.class);
        mSparkingPlugViewObservable = new SparkingPlugViewObservable(viewModel);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_sparking_plug, container, false);
        binding.setSparkingState(mSparkingPlugViewObservable);
        viewModel.getCarHealth().observe(this, domainCarHealth -> {
            if (domainCarHealth == null) return;
            mSparkingPlugViewObservable.setFistVat(domainCarHealth.sparkingPlugs.get(0));
            mSparkingPlugViewObservable.setSecondVat(domainCarHealth.sparkingPlugs.get(1));
            mSparkingPlugViewObservable.setThirdVat(domainCarHealth.sparkingPlugs.get(2));
            mSparkingPlugViewObservable.setFourthVat(domainCarHealth.sparkingPlugs.get(3));

            if (domainCarHealth.sparkingPlugs.get(0) &&
                    domainCarHealth.sparkingPlugs.get(1) &&
                    domainCarHealth.sparkingPlugs.get(2) &&
                    domainCarHealth.sparkingPlugs.get(3)) {
                mSparkingPlugViewObservable.setHealth(true);
                mSparkingPlugViewObservable.setTitle(getString(R.string.spark_plug_health_suggest_title));
                mSparkingPlugViewObservable.setSuggest(getString(R.string.spark_plug_health_suggest_str));
            } else {
                mSparkingPlugViewObservable.setHealth(false);
                mSparkingPlugViewObservable.setTitle(getString(R.string.spark_plug_ageing_suggest_title));
                mSparkingPlugViewObservable.setSuggest(getString(R.string.spark_plug_ageing_suggest_str));
            }
            refreshTime(Tables.CAR_HEALTH.TABLE_NAME);
        });

        viewModel.getStatue().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            mSparkingPlugViewObservable.setStatus(integer);
        });
        return binding.getRoot();
    }

    @Override
    public void refresh() {
        super.refresh();
        viewModel.getCarState();
    }

    @Override
    public void onStart() {
        super.onStart();
        viewModel.getCarState();
    }

}
