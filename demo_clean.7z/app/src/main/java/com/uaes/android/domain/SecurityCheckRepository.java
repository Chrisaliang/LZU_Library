package com.uaes.android.domain;

import com.uaes.android.domain.pojo.DomainSecurityResult;

import io.reactivex.Single;

/**
 * Created by aber on 2/27/2018.
 */

public interface SecurityCheckRepository {

    Single<DomainSecurityResult> checkSecurity();

}
