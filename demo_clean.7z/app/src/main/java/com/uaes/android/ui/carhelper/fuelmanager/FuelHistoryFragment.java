package com.uaes.android.ui.carhelper.fuelmanager;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentFuelManagerFuelHistoryBinding;
import com.uaes.android.domain.pojo.DomainFuelHistory;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.view.decorator.SpaceItemDecoration;
import com.uaes.android.viewmodel.FuelHistoryViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.FuelHistoryListViewClickHandler;
import com.uaes.android.viewobservable.FuelHistoryViewObservable;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Created by hand on 2017/11/6.
 * fuel_manager_fuel_history_normal
 */

public class FuelHistoryFragment extends NavigatorFragment implements Observer<DomainFuelHistory> {

    private static final String TAG = "FuelHistoryFragment";

    @Inject
    RepositoryVMProvider factory;
    private FragmentFuelManagerFuelHistoryBinding binding;
    private FuelHistoryViewModel viewModel;
    private FuelHistoryViewObservable viewObservable;
    private FuelHistoryListViewClickHandler handler;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(FuelHistoryViewModel.class);
        viewObservable = new FuelHistoryViewObservable(viewModel);
        handler = new FuelHistoryListViewClickHandler(viewModel);
    }

    @Override
    public void refresh() {
        viewModel.queryAgain();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_fuel_manager_fuel_history, container, false);
        binding.setHistory(viewObservable);
        viewModel.getFuelHistory().observe(this, this);
        viewModel.getStatus().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            viewObservable.setStatus(integer);
        });
        viewModel.getSelectedItem().observe(this, fuelHistoryListViewData -> {
            if (fuelHistoryListViewData == null) return;
            Timber.tag(TAG).d("onChanged: %s", fuelHistoryListViewData.toString());
            final FuelHistoryListViewData.Type type = fuelHistoryListViewData.mType;
            FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter resetAdapter;
            FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter selectedAdapter;
            switch (type) {
                case YEAR:
                    resetAdapter
                            = (FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter)
                            binding.fuelHistoryListMile.getAdapter();
                    selectedAdapter = (FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter)
                            binding.fuelHistoryListYear.getAdapter();
                    break;
                case MILE:
                    resetAdapter = (FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter)
                            binding.fuelHistoryListYear.getAdapter();
                    selectedAdapter = (FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter)
                            binding.fuelHistoryListMile.getAdapter();
                    break;
                default:
                    throw new IllegalArgumentException("Error type ..." + type);
            }
            resetAdapter.updateSelected(-1);
            selectedAdapter.updateSelected(fuelHistoryListViewData.position);
        });
        initRecyclerView();
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        Timber.tag(TAG).d("onResume: %s", binding.fuelHistoryListMile.getWidth());
    }

    private void initRecyclerView() {
        LinearLayoutManager layoutManagerYear = new LinearLayoutManager(getActivity());
        layoutManagerYear.setOrientation(LinearLayoutManager.HORIZONTAL);
        binding.fuelHistoryListYear.setLayoutManager(layoutManagerYear);
        binding.fuelHistoryListYear.addItemDecoration(new SpaceItemDecoration(getActivity(),
                R.dimen.fuel_history_search_list_item_padding, R.dimen.fuel_history_search_list_item_padding));
        FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter year
                = new FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter(
                "year", handler, viewModel.getYearDataSets());
        binding.fuelHistoryListYear.setAdapter(year);
        binding.fuelHistoryListYear.scrollToPosition(year.selectedPosition);

        LinearLayoutManager layoutManagerInstance = new LinearLayoutManager(getActivity());
        layoutManagerInstance.setOrientation(LinearLayoutManager.HORIZONTAL);
        binding.fuelHistoryListMile.setLayoutManager(layoutManagerInstance);
        FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter mile
                = new FuelHistoryListViewClickHandler.FuelHistoryListViewAdapter(
                "mile", handler, viewModel.getMileDataSets());
        binding.fuelHistoryListMile.setAdapter(mile);
        binding.fuelHistoryListMile.addItemDecoration(new SpaceItemDecoration(getActivity(),
                R.dimen.fuel_history_search_list_item_padding, R.dimen.fuel_history_search_list_item_padding));
    }

    @Override
    public void onStart() {
        super.onStart();
        //初始显示当前年份用油历史
        viewModel.queryAgain();
    }

    @Override
    public void onChanged(@Nullable DomainFuelHistory fuelHistory) {
        if (fuelHistory == null) return;
        viewObservable.setAcUse(fuelHistory.acUse);
        viewObservable.setAcUseMoney(fuelHistory.acUseMoney);
        viewObservable.setAcUsePercent(fuelHistory.acUsePercent);
        viewObservable.setDriverUse(fuelHistory.driverUse);
        viewObservable.setDriverUseMoney(fuelHistory.driverUseMoney);
        viewObservable.setDriverUsePercent(fuelHistory.driverUsePercent);
        viewObservable.setFuelCost(fuelHistory.fuelCost);
        viewObservable.setIdleUse(fuelHistory.idleUse);
        viewObservable.setIdleUseMoney(fuelHistory.idleUseMoney);
        viewObservable.setIdleUsePercent(fuelHistory.idleUsePercent);
        viewObservable.setOtherUse(fuelHistory.otherUse);
        viewObservable.setOtherUseMoney(fuelHistory.otherUseMoney);
        viewObservable.setOtherUsePercent(fuelHistory.otherUsePercent);
        viewObservable.setFuelUse(fuelHistory.fuelUse);
        refreshTime(Tables.FUEL_FILL_HISTORY.TABLE_NAME);
    }
}
