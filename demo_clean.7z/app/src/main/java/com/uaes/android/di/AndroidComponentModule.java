package com.uaes.android.di;

import com.uaes.android.APushMessageReceiver;
import com.uaes.android.ui.AuthorizationActivity;
import com.uaes.android.ui.HomeActivity;
import com.uaes.android.ui.LauncherActivity;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.ui.carhelper.CarAssistantFragment;
import com.uaes.android.ui.carhelper.battery.BatteryFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelHistoryFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelManagerFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelRecordFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelSingleRecordFragment;
import com.uaes.android.ui.carhelper.fuelmanager.FuelStatusFragment;
import com.uaes.android.ui.fuelaccount.FuelAccountFragment;
import com.uaes.android.ui.gasstation.GasStationListFragment;
import com.uaes.android.ui.gasstation.MapMarkerActivity;
import com.uaes.android.ui.gasstation.MapRouterFragment;
import com.uaes.android.ui.home.HomeFragment;
import com.uaes.android.ui.maintenance.MaintenanceFragment;
import com.uaes.android.ui.maintenance.MaintenanceHelperFragment;
import com.uaes.android.ui.maintenance.engineoil.EngineOilFragment;
import com.uaes.android.ui.maintenance.foursshops.FourSShopsFragment;
import com.uaes.android.ui.maintenance.sparkingplug.SparkingPlugFragment;
import com.uaes.android.ui.malfunction.MalfunctionFragment;
import com.uaes.android.ui.message.MessageFragment;
import com.uaes.android.ui.message.malfunction.AllTypeMessageFragment;
import com.uaes.android.ui.setting.SettingAboutFragment;
import com.uaes.android.ui.setting.SettingFragment;
import com.uaes.android.ui.setting.SettingLowFuelWarningFragment;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

/**
 * Created by aber on 1/24/2018.
 * Load all activity for dagger2.
 */
@Module
public abstract class AndroidComponentModule {

    @ContributesAndroidInjector
    @ActivityScope
    public abstract MapMarkerActivity gasStationActivity();

    @ContributesAndroidInjector
    @ActivityScope
    public abstract LauncherActivity launcherActivity();

    @ActivityScope
    @ContributesAndroidInjector
    public abstract HomeActivity homeActivity();

    @ActivityScope
    @ContributesAndroidInjector
    public abstract AuthorizationActivity authorizationActivity();

    @ContributesAndroidInjector
    public abstract APushMessageReceiver getAPushMessageReceiver();


    // ---------------------------------------------------------

    @FragmentScope
    @ContributesAndroidInjector
    public abstract NavigatorFragment navigatorFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract MessageFragment messageFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract SettingFragment settingFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract SettingLowFuelWarningFragment settingLowFuelWarningFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract SettingAboutFragment settingAboutFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract CarAssistantFragment carAssistantFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract HomeFragment homeFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract MalfunctionFragment malfunctionFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract MaintenanceFragment maintenanceFragment();

    @FragmentScope
    @ContributesAndroidInjector
    public abstract FuelAccountFragment fuelAccountFragment();

    @ContributesAndroidInjector
    @FragmentScope
    public abstract MapRouterFragment contributesGasStationRouterFragment();

    @ContributesAndroidInjector
    @FragmentScope
    public abstract GasStationListFragment contributesGasStationFragment();


    @ContributesAndroidInjector
    @FragmentScope
    public abstract FourSShopsFragment contributesFourSShopsFragment();

    //-------------------------------
    @ChildFragmentScope
    @ContributesAndroidInjector
    public abstract FuelManagerFragment fuelManagerFragment();

    @ChildFragmentScope
    @ContributesAndroidInjector
    public abstract BatteryFragment batteryFragment();

    @ChildFragmentScope
    @ContributesAndroidInjector
    public abstract MaintenanceHelperFragment maintenanceHelperFragment();

    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract AllTypeMessageFragment allTypeMessageFragment();

    //--------------------------------------
    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract FuelHistoryFragment oilHistoryFragment();

    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract FuelSingleRecordFragment oilSingleRecordFragment();

    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract FuelStatusFragment oilStatusFragment();

    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract FuelRecordFragment oilRecordFragment();

    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract EngineOilFragment engineOilFragment();

    @SecondChildFragmentScope
    @ContributesAndroidInjector
    public abstract SparkingPlugFragment sparkingPlugFragment();

}
