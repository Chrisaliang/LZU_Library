package com.uaes.android.domain.pojo;

/**
 * Created by Chrisaliang on 2017/12/6
 * data for fuel history to show
 */

public class DomainFuelHistory {
    //*总消费*/
    public String fuelCost;
    //*总耗油量*/
    public String fuelUse;
    //*怠速耗油量*/
    public String idleUse;
    //*怠速耗 费用*/
    public String idleUseMoney;
    public String idleUsePercent;
    //*行驶消耗油量 */
    public String driverUse;
    //*行驶消耗 费用 */
    public String driverUseMoney;
    public String driverUsePercent;
    //*空调消耗 多少油量 L*/
    public String acUse;
    //*空调消耗 费用 */
    public String acUseMoney;
    public String acUsePercent;
    //*其他消耗油量*/
    public String otherUse;
    //*其他消耗 费用*/
    public String otherUseMoney;
    public String otherUsePercent;
}
