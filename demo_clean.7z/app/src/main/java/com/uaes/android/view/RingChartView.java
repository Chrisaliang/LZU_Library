package com.uaes.android.view;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import timber.log.Timber;

/**
 * Created by aber on 1/11/2018.
 * Show a ring with precent value in center of it.
 * We can set ring width and percent value, and ring's color
 */

public class RingChartView extends View {

    private static final String TAG = "RingChartView";

    private static final int MAX_PERCENT = 100;
    private static final int MIN_PERCENT = 0;

    private static final int STEP_FIRST_MAX = 5;
    private static final int STEP_SECOND_MAX = 7;
    private static final int STEP_THIR_MAX = 30;

    private static final int STEP_SIZE = 10;

    private static final float STEP_DIF = 10;

    private static final float RING_FACOTR = 0.7f;
    private final int ringColor = Color.RED;
    private final int textColor = Color.WHITE;
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float ringWidth = 64;
    //
    private float percent = MIN_PERCENT;
    private BlurMaskFilter maskFilter;
    private DashPathEffect dashPathEffect;
    private float blurRaduis = 16;

    private float cx;
    private float cy;

    private float radius;


    public RingChartView(Context context) {
        super(context);
        init(context, null);
    }

    public RingChartView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public RingChartView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        ringPaint.setColor(ringColor);
        textPaint.setColor(textColor);
        ringPaint.setStrokeWidth(ringWidth);
        ringPaint.setStyle(Paint.Style.STROKE);
        outRingPaint.setStyle(Paint.Style.STROKE);
        outRingPaint.setStrokeWidth(0.1f);
        blurRaduis = 16;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Timber.tag(TAG).d("onSizeChanged: w:%d, h: %d", w, h);
        if (w == oldw && h == oldh) return;
        cx = w / 2;
        cy = h / 2;

        radius = Math.min(w, h) / 2 - blurRaduis - ringWidth / 2;

        maskFilter = new BlurMaskFilter(blurRaduis, BlurMaskFilter.Blur.SOLID);
        // the offset of dash ring is useless for now.
        // we are using the canvas.rotate() to fix the offset of ring draw.
        final double perimeter = radius * 2 * Math.PI;

        double step = perimeter / STEP_SIZE;

        dashPathEffect = new DashPathEffect(
                new float[]{(float) (step * RING_FACOTR), (float) (step * (1 - RING_FACOTR))},
                0);
        ringPaint.setMaskFilter(maskFilter);
        ringPaint.setPathEffect(dashPathEffect);
        setLayerType(LAYER_TYPE_SOFTWARE, ringPaint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
//        canvas.save();
//        canvas.rotate(90f);
        canvas.drawCircle(cx, cy, radius, ringPaint);
//        canvas.restore();
    }

}
