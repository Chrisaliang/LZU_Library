package com.uaes.android.domain.pojo;

/**
 * Created by aber on 1/25/2018.
 * App Setting
 */

public class DomainSetting {

    /**
     * 低油量预警值
     */
    public int lowOilLevel;

}
