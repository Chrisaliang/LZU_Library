package com.uaes.android.domain.pojo;

/**
 * Created by aber on 2/27/2018.
 * 安全检查结果
 */

public class DomainSecurityResult {

    /**
     * 设备被root
     */
    public final static int FLAG_ROOT = 0x01;
    /**
     * 用户没有同意用户协议
     */
    public final static int FLAG_USER_AGREEMENT = 0x02;

    /**
     * 用户使用的时二次打包应用，需要重新下载安装正版应用
     */
    public final static int FLAG_SIGNATURE = 0x04;

    /**
     * Check code result
     */
    public int resultCode;

    public String errorMessage;
}
