package com.uaes.android.viewobservable;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.text.TextUtils;

import com.uaes.android.BR;
import com.uaes.android.viewmodel.MessageStateViewModel;
import com.uaes.android.widget.RetryView;

/**
 * Author : 张 涛
 * Time : 2018/1/26.
 * Des : This is
 */

public class AllTypeMessageObservable extends BaseObservable {
    private final MessageStateViewModel mMessageStateViewModel;
    private boolean hasDisplay;
    private String fragmentTag = "";
    private int status = RetryView.RETRY_GONE;

    public AllTypeMessageObservable(MessageStateViewModel mMessageStateViewModel) {
        this.mMessageStateViewModel = mMessageStateViewModel;
    }

    public void onClick(RetryView view) {
        if (!TextUtils.isEmpty(fragmentTag)) {
            mMessageStateViewModel.queryMessage(fragmentTag);
        }
    }

    @Bindable
    public String getFragmentTag() {
        return fragmentTag;
    }

    public void setFragmentTag(String fragmentTag) {
        this.fragmentTag = fragmentTag;
        notifyPropertyChanged(BR.fragmentTag);
    }

    @Bindable
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
        notifyPropertyChanged(BR.status);
    }

    @Bindable
    public boolean getHasDisplay() {
        return hasDisplay;
    }

    public void setHasDisplay(boolean hasDisplay) {
        this.hasDisplay = hasDisplay;
        notifyPropertyChanged(BR.hasDisplay);
    }

}
