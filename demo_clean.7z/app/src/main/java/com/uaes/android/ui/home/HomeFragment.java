package com.uaes.android.ui.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.ui.TopLevelFragment;

/**
 * Created by hand on 2017/11/2.
 * home_normal
 */

public class HomeFragment extends TopLevelFragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.waitting_for_implement_layout, container, false);
    }

    @Override
    public void back() {

    }
}
