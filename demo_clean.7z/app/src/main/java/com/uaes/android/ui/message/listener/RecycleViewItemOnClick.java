package com.uaes.android.ui.message.listener;

import com.uaes.android.viewobservable.MessageStatesItemObservable;

/**
 * Created by hand on 2018/1/18.
 * item click
 */

public interface RecycleViewItemOnClick {
    void onItemClick(MessageStatesItemObservable mMessageStatesItemObservable);

    void onNoSelectItemClick(MessageStatesItemObservable mMessageStatesItemObservable);
}
