package com.uaes.android.data.http;

import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.json.GeneralAttributeSent;

import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by Chrisaliang on 2017/11/8.
 * api for setting
 */

public interface SettingApi {

    /**
     * @param body structure like this
     *             {
     *             "attributeList": [
     *             {
     *             "attributeType": "string",
     *             "attributeValue": "string"
     *             }
     *             ],
     *             "vin": "string"
     *             }
     */
    @POST("/car/v1/carAttribute/app/create")
    Single<GeneralAttributeReceive<GeneralAttributeSent>> lowFuelWarningSent(@Body JsonRequestBody body);

    /**
     * @param body same as method lowFuelWarningSent's parameter @body
     * @return jsonObject which include setting parameter
     */
    @POST("/car/v1/carAttribute/app/byAttributes")
    Single<GeneralAttributeReceive<GeneralAttributeSent>> lowFuelWarningReceive(@Body JsonRequestBody body);
}
