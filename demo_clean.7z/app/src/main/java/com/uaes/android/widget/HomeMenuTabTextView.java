package com.uaes.android.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.AttributeSet;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.view.BubbleImageView;
import com.uaes.android.view.FontTextView;

/**
 * Created by Chrisaliang on 2018/1/10.
 * complex tab's text and image
 */
@BindingMethods({
        @BindingMethod(type = HomeMenuTabTextView.class, attribute = "ttv_tabTitle", method = "setTabTitle")
})
public class HomeMenuTabTextView extends LinearLayoutCompat {

    private final BubbleImageView mTabIcon;
    private final FontTextView mTabTitle;

    public HomeMenuTabTextView(@NonNull Context context) {
        this(context, null);
    }

    public HomeMenuTabTextView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HomeMenuTabTextView(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.widget_home_menu_tab, this);
        mTabIcon = findViewById(R.id.widget_menu_tab_icon);
        mTabTitle = findViewById(R.id.widget_menu_tab_title);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.HomeMenuTabTextView);
        Drawable drawable = a.getDrawable(R.styleable.HomeMenuTabTextView_ttv_iconStart);
        if (drawable != null)
            mTabIcon.setImageDrawable(drawable);
        int drawableWidth = a.getDimensionPixelSize(R.styleable.HomeMenuTabTextView_ttv_iconWidth, 0);
        int drawableHeight = a.getDimensionPixelSize(R.styleable.HomeMenuTabTextView_ttv_iconHeight, 0);
        int drawablePadding = a.getDimensionPixelSize(R.styleable.HomeMenuTabTextView_ttv_iconPadding, 0);
        int iconVisibility = a.getInteger(R.styleable.HomeMenuTabTextView_ttv_iconVisibility, 0);
        mTabIcon.setVisibility(iconVisibility == 0 ? VISIBLE : GONE);
        ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) mTabIcon.getLayoutParams();
        layoutParams.width = drawableWidth;
        layoutParams.height = drawableHeight;
        layoutParams.rightMargin = drawablePadding;
        String title = a.getString(R.styleable.HomeMenuTabTextView_ttv_tabTitle);
        int titleSize = a.getDimensionPixelSize(R.styleable.HomeMenuTabTextView_ttv_titleSize, 26);
        mTabTitle.setTextSize(titleSize);
        mTabTitle.setText(title);
        a.recycle();
    }

    @BindingAdapter(value = "ttv_tabTitle")
    public static void setTabTitle(HomeMenuTabTextView view, CharSequence title) {
        view.mTabTitle.setText(title);
    }

    @SuppressWarnings("unused")
    @BindingAdapter(value = "ttv_tabTitle")
    public static void setTabTitle(HomeMenuTabTextView view, @StringRes int title) {
        view.mTabTitle.setText(title);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
    }

    public void setMessageNum(int num) {
        mTabIcon.setNum(num);
    }

    public void setText(CharSequence title) {
        mTabTitle.setText(title);
    }

    public void setIcon(Bitmap bitmap) {
        mTabIcon.setImageBitmap(bitmap);
    }

    public void setIcon(Drawable editIcon) {
        mTabIcon.setImageDrawable(editIcon);
    }

    public void enableNumBubble(boolean isEnable) {
        mTabIcon.enableNum(isEnable);
    }
}
