package com.uaes.android.ui.carhelper.fuelmanager;

import android.view.View;

import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

/**
 * Created by Chrisaliang on 2018/2/7.
 * fuel single record listener
 */

public interface FuelSingleRecordListener extends View.OnClickListener, OnChartValueSelectedListener {
}
