package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import static com.uaes.android.data.room.Tables.FUEL_STATUS.COLUMN_ECONOMIC_RANK;
import static com.uaes.android.data.room.Tables.FUEL_STATUS.COLUMN_FUEL_GRADE;
import static com.uaes.android.data.room.Tables.FUEL_STATUS.COLUMN_FUEL_REST;
import static com.uaes.android.data.room.Tables.FUEL_STATUS.COLUMN_FUEL_USE_KM;
import static com.uaes.android.data.room.Tables.FUEL_STATUS.COLUMN_MILEAGE_REST;
import static com.uaes.android.data.room.Tables.FUEL_STATUS.TABLE_NAME;

/**
 * Created by hand on 2017/11/7.
 * 用油状态
 */

@Entity(tableName = TABLE_NAME)
public class FuelStatus {

    //"msgCode":"10000","msg":"OK",
    // "content":{"fuelRest":27.27272727272727,
    // "economicRank":0.0,
    // "fuelGrade":"92#",
    // "fuelUsedKm":2.2,
    // "mileageRest":0.0},
    // "status":1,"total":1}

    @PrimaryKey(autoGenerate = true)
    @Expose(serialize = false, deserialize = false)
    public long id;

    @SerializedName(COLUMN_FUEL_GRADE)
    @ColumnInfo(name = COLUMN_FUEL_GRADE)
    public String fuelGrade;

    @SerializedName(COLUMN_FUEL_REST)
    @ColumnInfo(name = COLUMN_FUEL_REST)
    public double fuelRest;

    @SerializedName(COLUMN_FUEL_USE_KM)
    @ColumnInfo(name = COLUMN_FUEL_USE_KM)
    public double fuelUsedKm;

    @SerializedName(COLUMN_MILEAGE_REST)
    @ColumnInfo(name = COLUMN_MILEAGE_REST)
    public double mileageRest;

    @SerializedName(COLUMN_ECONOMIC_RANK)
    @ColumnInfo(name = COLUMN_ECONOMIC_RANK)
    public double economicRank;

    @Override
    public String toString() {
        return "FuelStatus{" +
                "id=" + id +
                ", fuelGrade='" + fuelGrade + '\'' +
                ", fuelRest=" + fuelRest +
                ", fuelUsedKm=" + fuelUsedKm +
                ", mileageRest=" + mileageRest +
                ", economicRank=" + economicRank +
                '}';
    }
}
