package com.uaes.android.domain;

import com.uaes.android.data.json.FuelBookkeeping;

import io.reactivex.Single;

/**
 * Created by Administrator on 2017/11/10 0010.
 * 加油记账 数据层 数据接口
 */

public interface FuelAccountRepository {

    /**
     * 请求记账
     *
     * @return 提交记账的数据
     */
    Single<FuelBookkeeping> setFuelAccount(FuelBookkeeping oilAccount);
}
