package com.uaes.android.viewmodel;

import java.util.List;

/**
 * Created by aber on 11/27/2017.
 * Page View Model
 */

public class PageViewModel<T> {

    // 从0开始
    public int currentPageIndex;

    // 总页数
    public int totalPages;

    // 总元素数量
    public int totalSize;

    // 每页的容量 contents 的 size不可以超过这个容量
    public int pageCapacity;

    // 实际请求的数据项
    public List<T> contents;

    public boolean isFirstPage() {
        return currentPageIndex == 0;
    }

    public boolean isLastPage() {
        return (totalPages - 1) == currentPageIndex;
    }

    public int getNextPageIndex() {
        return currentPageIndex + 1;
    }

    public int getPreviousPageIndex() {
        return currentPageIndex - 1;
    }
}
