package com.uaes.android.ui;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

/**
 * Created by hand on 2017/11/2.
 * Top Level fragment
 * set top level animation
 */

public abstract class TopLevelFragment extends NavigatorFragment {

    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
        return enter ? AnimationUtils.loadAnimation(getContext(), android.R.anim.fade_in) :
                AnimationUtils.loadAnimation(getContext(), android.R.anim.fade_out);
    }

    /**
     * Back stack of current fragment for status restore.
     */
    public abstract void back();
}
