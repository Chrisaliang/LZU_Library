package com.uaes.android.ui;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

import com.uaes.android.domain.CacheTimeRepository;

import javax.inject.Inject;

import dagger.android.support.DaggerFragment;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by hand on 2017/11/2.
 * Navigator fragment
 */

public abstract class NavigatorFragment extends DaggerFragment {

    final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refresh();
        }
    };
    protected IPageNavigator mNavigator;
    protected Disposable cacheTimeDisposable;
    @Inject
    CacheTimeRepository timeRepository;

    public void refresh() {
    }

    protected void refreshTime(String tableName) {
        this.timeRepository.queryCacheTimeByTableName(tableName).subscribe(
                new CacheTimeObserver());
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mNavigator = (IPageNavigator) context;
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mNavigator = (IPageNavigator) activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mNavigator = null;
    }

    @Override
    public void onStop() {
        super.onStop();
        if (cacheTimeDisposable != null) {
            cacheTimeDisposable.dispose();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(HomeActivity.REFRESH_ACTION);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mReceiver, filter);
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mReceiver);
    }

    private class CacheTimeObserver implements SingleObserver<Long> {
        @Override
        public void onSubscribe(Disposable d) {
            cacheTimeDisposable = d;
        }

        @Override
        public void onSuccess(Long aLong) {
            mNavigator.updateTime(aLong);
        }

        @Override
        public void onError(Throwable e) {
            Timber.tag("cacheTimeTag").e(e);
        }
    }
}
