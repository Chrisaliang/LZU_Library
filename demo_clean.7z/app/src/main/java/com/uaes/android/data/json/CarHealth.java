package com.uaes.android.data.json;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.uaes.android.data.room.Tables;

/**
 * Created by Chrisaliang on 2018/1/24.
 * car health json
 */

@Entity(tableName = Tables.CAR_HEALTH.TABLE_NAME)
public class CarHealth {

    @PrimaryKey
    @Expose(deserialize = false, serialize = false)
    public long id;
    // 机油状态
    @ColumnInfo(name = Tables.CAR_HEALTH.COLUMN_ENGINE_OIL_STATE)
    @SerializedName(Tables.CAR_HEALTH.COLUMN_ENGINE_OIL_STATE)
    public int engineOilState;
    // 机油剩余可行驶里程
    @ColumnInfo(name = Tables.CAR_HEALTH.COLUMN_ENGINE_OIL_MILEAGE)
    @SerializedName(Tables.CAR_HEALTH.COLUMN_ENGINE_OIL_MILEAGE)
    public double engineOilMileage;
    // 机油健康度
    @ColumnInfo(name = Tables.CAR_HEALTH.COLUMN_ENGINE_OIL_HEALTH)
    @SerializedName(Tables.CAR_HEALTH.COLUMN_ENGINE_OIL_HEALTH)
    public double engineOilHealth;
    // 火花塞状态 1111
    @ColumnInfo(name = Tables.CAR_HEALTH.COLUMN_SPARK_PLUG_STATE)
    @SerializedName(Tables.CAR_HEALTH.COLUMN_SPARK_PLUG_STATE)
    public int sparkPlugState;
    // 电池状态
    @ColumnInfo(name = Tables.CAR_HEALTH.COLUMN_BATTERY_STATE)
    @SerializedName(Tables.CAR_HEALTH.COLUMN_BATTERY_STATE)
    public int batteryState;
}
