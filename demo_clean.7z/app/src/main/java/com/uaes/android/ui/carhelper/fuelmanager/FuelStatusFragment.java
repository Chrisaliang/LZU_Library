package com.uaes.android.ui.carhelper.fuelmanager;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.data.room.Tables;
import com.uaes.android.databinding.FragmentFuelManagerFuelStatusBinding;
import com.uaes.android.domain.pojo.DomainFuelState;
import com.uaes.android.ui.NavigatorFragment;
import com.uaes.android.viewmodel.FuelStateViewModel;
import com.uaes.android.viewmodel.RepositoryVMProvider;
import com.uaes.android.viewobservable.FuelStatsViewObservable;

import javax.inject.Inject;

/**
 * Created by hand on 2017/11/6.
 * 用油状态
 */

public class FuelStatusFragment extends NavigatorFragment implements Observer<DomainFuelState> {

    private static final String TAG = FuelStatusFragment.class.getSimpleName();
    @Inject
    RepositoryVMProvider factory;
    private FragmentFuelManagerFuelStatusBinding binding;
    private FuelStateViewModel viewModel;
    private FuelStatsViewObservable statsViewObservable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(FuelStateViewModel.class);
        statsViewObservable = new FuelStatsViewObservable(viewModel);
    }

    @Override
    public void refresh() {
        viewModel.update();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_fuel_manager_fuel_status, container, false);
        binding.setStatus(statsViewObservable);
        viewModel.getFuelStatus().observe(this, this);
        viewModel.getStatue().observe(this, integer -> {
            if (integer == null) throw new NullPointerException(TAG + " status is null");
            statsViewObservable.setStatus(integer);
        });
        return binding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();
        viewModel.update();
    }

    @Override
    public void onChanged(@Nullable DomainFuelState state) {
        if (state == null) return;
        statsViewObservable.setCostOfHundredMiles(state.costOfHundredMiles);
        statsViewObservable.setFuelMiles(state.fuelMiles);
        statsViewObservable.setRank(state.rank);
        statsViewObservable.setFuelRestValue(state.fuelRestValue);
        statsViewObservable.setFuelNum(state.fuelNum);
        int rankColor;
        if (state.rank < 20) {
            rankColor = getResources().getColor(R.color.ring_chart_ring_color_empty);
        } else if (state.rank < 40) {
            rankColor = getResources().getColor(R.color.ring_chart_ring_color_half);
        } else {
            rankColor = getResources().getColor(R.color.ring_chart_ring_color_full);
        }
        statsViewObservable.setRankRingColor(rankColor);
        int remainFuelColor;
        if (state.fuelRestValue < 10) {
            remainFuelColor = getResources().getColor(R.color.ring_chart_ring_color_empty);
        } else if (state.fuelRestValue < 30) {
            remainFuelColor = getResources().getColor(R.color.ring_chart_ring_color_half);
        } else {
            remainFuelColor = getResources().getColor(R.color.ring_chart_ring_color_full);
        }
        statsViewObservable.setRemainFuelRingColor(remainFuelColor);
        refreshTime(Tables.FUEL_STATUS.TABLE_NAME);
//        statsViewObservable.setFuelRest(o.fuelRest);
    }
}
