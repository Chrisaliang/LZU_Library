package com.uaes.android.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;

/**
 * Created by Chrisaliang on 2017/11/15.
 * auto show select option
 */

public class AutoSelectCompleteTextView extends android.support.v7.widget.AppCompatAutoCompleteTextView {
    public AutoSelectCompleteTextView(Context context) {
        super(context);
    }

    public AutoSelectCompleteTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public AutoSelectCompleteTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    public boolean enoughToFilter() {
        return true;
    }

    @Override
    protected void onFocusChanged(boolean focused, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(focused, direction, previouslyFocusedRect);
        if (focused && getAdapter() != null) {
            performFiltering(getText(), 0);
        }
    }
}
