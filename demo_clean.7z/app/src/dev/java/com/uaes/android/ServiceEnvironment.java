package com.uaes.android;

/**
 * Created by aber on 12/20/2017.
 * service
 */

public interface ServiceEnvironment {
    //    String baseUrl = "http://dev.api.iot.uaes.com"; // dev环境
    // TODO: 2018/3/14 delete it
    String baseUrl = "https://stag-api-iot.uaes.com"; // 预生产环境
    long appKey = 24675829; // 开发环境
}
