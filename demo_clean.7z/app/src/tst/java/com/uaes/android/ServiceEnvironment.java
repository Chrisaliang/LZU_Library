package com.uaes.android;


/**
 * Created by aber on 12/20/2017.
 * 测试环境
 */

public interface ServiceEnvironment {
    String baseUrl = "http://tst-api-iot.uaes.com"; // 测试环境
    long appKey = 24695401; // 测试环境
}
