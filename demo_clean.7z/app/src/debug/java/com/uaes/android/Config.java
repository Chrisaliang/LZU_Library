package com.uaes.android;

/**
 * Created by aber on 1/24/2018.
 * DEBUG 配hi
 */

public interface Config {

    boolean DEBUG = true;

    String APP_SIGNATURE = "AF2F2ED2BC7A1624BDA25BDC510B9F006B24199B";
//    String APP_SIGNATURE = "EF2F2ED2BC7A1624BDA25BDC510B9F006B24199B"; // 假的不正确的签名，用于测试

    String AMAP_STYLE_ID = "4783c5c58b9d98ecf624be3dd1369682";

}
