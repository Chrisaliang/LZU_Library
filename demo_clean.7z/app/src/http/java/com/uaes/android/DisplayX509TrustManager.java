package com.uaes.android;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Created by Chrisaliang on 2018/3/14.
 * trust manager
 */

public class DisplayX509TrustManager implements X509TrustManager {

    private X509TrustManager rootManager;

    private DisplayX509TrustManager(Certificate ca) throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
        String keyStoreType = KeyStore.getDefaultType();
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        keyStore.load(null, null);
        keyStore.setCertificateEntry("ca", ca);
        String defaultAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(defaultAlgorithm);
        tmf.init(keyStore);
        rootManager = (X509TrustManager) tmf.getTrustManagers()[0];
    }

    public static DisplayX509TrustManager create(Context context) throws IOException, CertificateException, KeyStoreException, NoSuchAlgorithmException {
        InputStream inputStream = context.getAssets().open("GeoTrust_Primary_CA.pem");
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate ca;
        try {
            ca = cf.generateCertificate(inputStream);
        } finally {
            inputStream.close();
        }
        return new DisplayX509TrustManager(ca);
    }

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        rootManager.checkClientTrusted(chain,authType);
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        rootManager.checkServerTrusted(chain, authType);
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
    }
}
