package com.uaes.android;

import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;

import com.google.gson.Gson;
import com.uaes.android.data.http.FuelAccountApi;
import com.uaes.android.data.http.FuelManagerApi;
import com.uaes.android.data.http.GasStationApi;
import com.uaes.android.data.http.HapAuthorizationInterceptor;
import com.uaes.android.data.http.MaintenanceApi;
import com.uaes.android.data.http.S4ShopApi;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.http.SslSocketFactory;
import com.uaes.android.data.http.TokenApi;
import com.uaes.android.data.http.TokenAuthenticator;

import java.security.KeyStore;
import java.security.Provider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.inject.Singleton;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import dagger.Module;
import dagger.Provides;
import okhttp3.CipherSuite;
import okhttp3.ConnectionSpec;
import okhttp3.OkHttpClient;
import okhttp3.TlsVersion;
import okhttp3.internal.connection.ConnectionSpecSelector;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import timber.log.Timber;

/**
 * Created by hand on 2017/11/1.
 * Net work module
 */

@Module
public abstract class NetModule {

    private static final String LOG_HTTP = "HTTP";

    @Provides
    @Singleton
    static HttpLoggingInterceptor.Logger logger() {
        return new HttpLogger();
    }

    @Provides
    @Singleton
    static HttpLoggingInterceptor loggingInterceptor(HttpLoggingInterceptor.Logger logger) {
        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor(logger);
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return httpLoggingInterceptor;
    }

    @Provides
    @Singleton
    static HapAuthorizationInterceptor hapAuthorizationInterceptor(SharedPreferences sharedPreferences) {
        return new HapAuthorizationInterceptor(sharedPreferences);
    }

    @Provides
    @Singleton
    static TokenAuthenticator tokenAuthenticator(Gson gson, SharedPreferences sp, UaesIotApplication application,
                                                 HapAuthorizationInterceptor interceptor) {
        return new TokenAuthenticator(gson, sp, LocalBroadcastManager.getInstance(application), interceptor);
    }

    @Provides
    @Singleton
    static OkHttpClient okHttpClient(HttpLoggingInterceptor interceptor,
                                     HapAuthorizationInterceptor hapAuthorizationInterceptor,
                                     TokenAuthenticator tokenAuthenticator,
                                     UaesIotApplication ctx) {
        try {
            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(
                     TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init((KeyStore) null);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
            if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
                throw new IllegalStateException("Unexpected default trust managers:"
                         +Arrays.toString(trustManagers));
            }
            X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
            builder.sslSocketFactory(SslSocketFactory.createSSLSocketFactory(trustManager), trustManager);
            SSLContext sc = SSLContext.getInstance("TLSv1.2");
            sc.init(null, null, null);
//            builder.sslSocketFactory(new TLSSocketFactory());
            return builder
                    .addNetworkInterceptor(hapAuthorizationInterceptor)
                    .addNetworkInterceptor(interceptor)
                    .authenticator(tokenAuthenticator)
                    .build();
        } catch (Exception e) {
            return null;
        }
    }

    @Provides
    @Singleton
    static Retrofit retrofit(OkHttpClient client, Gson gson) {
        return new Retrofit.Builder()
                .baseUrl(ServiceEnvironment.baseUrl)
                .client(client)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    @Provides
    @Singleton
    static TokenApi tokenInterface(Retrofit retrofit) {
        return retrofit.create(TokenApi.class);
    }

    @Provides
    @Singleton
    static FuelManagerApi fuelManagerApi(Retrofit retrofit) {
        return retrofit.create(FuelManagerApi.class);
    }

    @Provides
    @Singleton
    static SettingApi settingApi(Retrofit retrofit) {
        return retrofit.create(SettingApi.class);
    }

    @Provides
    @Singleton
    static GasStationApi gasStationApi(Retrofit retrofit) {
        return retrofit.create(GasStationApi.class);
    }

    @Provides
    @Singleton
    static FuelAccountApi fuelAccountApi(Retrofit retrofit) {
        return retrofit.create(FuelAccountApi.class);
    }

    @Provides
    @Singleton
    static MaintenanceApi carHealthApi(Retrofit retrofit) {
        return retrofit.create(MaintenanceApi.class);
    }

    @Provides
    @Singleton
    static S4ShopApi s4ShopApi(Retrofit retrofit) {
        return retrofit.create(S4ShopApi.class);
    }

    private static class HttpLogger implements HttpLoggingInterceptor.Logger {

        @Override
        public void log(@NonNull String s) {
            Timber.tag(LOG_HTTP).d(s);
        }
    }
}
