package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.http.HapAuthorizationInterceptor;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import timber.log.Timber;

import static com.uaes.android.ServiceEnvironment.baseUrl;

/**
 * Created by aber on 1/24/2018.
 * Service Config.
 */

@Module
public abstract class ServerModule {

    @Provides
    @Singleton
    static HttpLoggingInterceptor.Logger logger() {
        return message -> Timber.tag("OkHTTP").d(message);
    }

    @Provides
    @Singleton
    static HttpLoggingInterceptor httpLogging(HttpLoggingInterceptor.Logger logger) {
        HttpLoggingInterceptor httpLoggingInterceptor =
                new HttpLoggingInterceptor(logger);
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return httpLoggingInterceptor;
    }

    @Provides
    @Singleton
    static OkHttpClient client(
            HttpLoggingInterceptor loggingInterceptor,
            HapAuthorizationInterceptor hapAuthorizationInterceptor) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addNetworkInterceptor(hapAuthorizationInterceptor);
        if (Config.DEBUG)
            builder.addNetworkInterceptor(loggingInterceptor);
        return builder.build();
    }

    @Provides
    @Singleton
    static Retrofit provideRetrofit(Gson gson, OkHttpClient client) {
        return new Retrofit.Builder().addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(baseUrl)
                .client(client)
                .build();
    }
}
