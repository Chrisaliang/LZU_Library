package com.uaes.android;

import android.content.Context;
import android.util.Log;

import com.google.common.hash.Hashing;
import com.uaes.android.common.CarInfoProvider;
import com.uaes.android.common.PhoneManagerUtils;

import java.nio.charset.Charset;

/**
 * Created by Chrisaliang on 2017/12/7.
 * Query Vin and sha384 code for
 */

public class RealCarInfoProvider implements CarInfoProvider {

    private static final String TAG = RealCarInfoProvider.class.getSimpleName();

    private static final boolean PRE_BUILD = true;

    private static final String VIN = "LNBSCUAK5HF043610";
    private static final String IMEI = "863010031601284";

    private static RealCarInfoProvider INSTANCE;

    private String vinStr;

    private String sha384;

    private String imei;


    private RealCarInfoProvider(Context context) {
        parser(context, this);
    }

    public static RealCarInfoProvider getInstance(Context context) {
        if (INSTANCE == null)
            INSTANCE = new RealCarInfoProvider(context);
        return INSTANCE;
    }

    private static void parser(Context context, RealCarInfoProvider realCarInfoProvider) {
        if (PRE_BUILD) {
            realCarInfoProvider.vinStr = VIN;
            realCarInfoProvider.imei = IMEI;
        } else {
            realCarInfoProvider.vinStr = PhoneManagerUtils.getAutoId();
            realCarInfoProvider.imei = PhoneManagerUtils.getIMEIStr(context);
        }
        realCarInfoProvider.sha384 = Hashing.sha384().hashString(
                realCarInfoProvider.vinStr + ":" + realCarInfoProvider.imei,
                Charset.defaultCharset()).toString();
        Log.d(TAG, "vin: " + realCarInfoProvider.vinStr + " ,imei: " + realCarInfoProvider.imei + " ,sha384:" + realCarInfoProvider.sha384);
    }

    @Override
    public String getVin() {
        return vinStr;
    }

    @Override
    public String getIMEI() {
        return imei;
    }

    @Override
    public String getSHA384() {
        return sha384;
    }

    @Override
    public String debugString() {
        return toString();
    }

    @Override
    public String toString() {
        return "RealCarInfoProvider{" +
                "vinStr='" + vinStr + '\'' +
                ", sha384='" + sha384 + '\'' +
                ", imei='" + imei + '\'' +
                '}';
    }
}
