package com.uaes.android;

import com.uaes.android.common.CarInfoProvider;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
class C51EModule {

    @Provides
    @Singleton
    static CarInfoProvider provider(App app) {
        return RealCarInfoProvider.getInstance(app);
    }
}
