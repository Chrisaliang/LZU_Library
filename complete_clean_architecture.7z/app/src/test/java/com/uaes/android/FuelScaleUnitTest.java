package com.uaes.android;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FuelScaleUnitTest {



    @Test
    public void testDateFormat() {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd\nHH:mm:ss");

        String format = simpleDateFormat.format(new Date());

        System.out.println(format);

    }
}
