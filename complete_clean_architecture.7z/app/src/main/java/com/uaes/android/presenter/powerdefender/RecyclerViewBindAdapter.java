package com.uaes.android.presenter.powerdefender;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.uaes.android.R;
import com.uaes.android.presenter.powerdefender.pojo.CarFaultHistory;

import java.util.List;
import java.util.Objects;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
@BindingMethods({
        @BindingMethod(type = RecyclerView.class, attribute = "historyFaults", method = "bindFaults"),


})
public class RecyclerViewBindAdapter {

    @BindingAdapter(value = "historyFaults")
    public static void bindFaults(RecyclerView recyclerView, List<CarFaultHistory> faultHistoryList) {
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        HistoryFaultAdapter adapter = new HistoryFaultAdapter();
        adapter.appendAll(faultHistoryList);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL);
        dividerItemDecoration.setDrawable(Objects.requireNonNull(ContextCompat.getDrawable(recyclerView.getContext(), R.drawable.divider_rv_fault)));
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setAdapter(adapter);
    }


}
