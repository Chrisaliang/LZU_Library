package com.uaes.android.presenter.maintainsecretary;

public interface MaintainOnClickListener {

    void onClick(int type);

    void onCheckedChanged(boolean isChecked);
}
