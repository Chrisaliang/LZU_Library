package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentPhoneAppointmentBinding;
import com.uaes.android.presenter.BaseFragment;

/**
 * Created by ${GY} on 2018/5/10
 * des：电话预约
 */

public class MaintainPhoneAppointFragment extends BaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainPhoneAppointFragment_";
    private MaintainFragmentPhoneAppointmentBinding binding;
    private MaintainPhoneViewModel maintainAppointItem;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_phone_appointment, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        maintainAppointItem = ViewModelProviders.of(this).get(MaintainPhoneViewModel.class);
        binding.setMaintainOnClickListener(this);
//        binding.setMaintainAppointItemViewModel(maintainAppointItem);
        initView();
    }

    private void initView() {
//        Bundle arguments = getArguments();
        maintainAppointItem.maintainAddress.setValue("ddddddd");
        maintainAppointItem.maintainPhone.setValue("222222");
    }


    @Override
    public void onClick(int type) {
        //close

    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }

}
