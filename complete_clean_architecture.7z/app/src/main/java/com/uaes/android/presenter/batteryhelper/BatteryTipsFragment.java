package com.uaes.android.presenter.batteryhelper;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.uaes.android.R;
import com.uaes.android.databinding.BatteryHelperFragmentTipsBinding;

import java.util.Objects;

import dagger.android.support.DaggerAppCompatDialogFragment;

public class BatteryTipsFragment extends DaggerAppCompatDialogFragment implements BatteryOnClickListener {

    private static final String TAG = "BatteryTipsFragment";

    BatteryHelperFragmentTipsBinding binding;

//    @NonNull
//    @Override
//    public Dialog onCreateDialog(Bundle savedInstanceState) {
//        Dialog dialog = super.onCreateDialog(savedInstanceState);
//        WindowManager.LayoutParams attributes
//                = Objects.requireNonNull(dialog.getWindow()).getAttributes();
//        // 弹出窗口 背景透明度
//        attributes.dimAmount = 0f;
//        attributes.width = getResources().getDimensionPixelSize(R.dimen.dialog_width);
//        attributes.height = getResources().getDimensionPixelSize(R.dimen.dialog_height);
//        attributes.x = getResources().getDimensionPixelSize(R.dimen.dialog_offestX);
//        dialog.getWindow().setAttributes(attributes);
//        return dialog;
//    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.battery_helper_fragment_tips, container, false);
        binding.setBatteryOnClickListener(this);
        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        WindowManager.LayoutParams attributes
                = Objects.requireNonNull(getDialog().getWindow()).getAttributes();
        attributes.dimAmount = 0f;
        attributes.width = getResources().getDimensionPixelSize(R.dimen.battery_helper_tips_dialog_width);
        attributes.height = getResources().getDimensionPixelSize(R.dimen.battery_helper_tips_dialog_height);
        attributes.x = getResources().getDimensionPixelSize(R.dimen.battery_helper_tips_dialog_offset_X);

        getDialog().getWindow().setAttributes(attributes);
    }

    @Override
    public void onClick(View view) {
        dismiss();
    }
}
