package com.uaes.android.domain;

/**
 * Base Executable Unit in the Business logic.
 * Normally developer should not use this class ,instead using SingleUseCase  for brevity.
 * Interactor will not hold Presenter or  Data layer's status. Itself process data,
 * and product data.
 *
 * @see SingleUseCase
 * */
public interface Interactor<Result> {
    /**
     * call this method the business logic will be executed.
     * */
    Result execute();
}
