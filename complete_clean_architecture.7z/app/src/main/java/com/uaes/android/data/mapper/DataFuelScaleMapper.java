package com.uaes.android.data.mapper;

import com.uaes.android.data.json.FuelScale;
import com.uaes.android.domain.entity.DMFuelScale;

import io.reactivex.functions.Function;

public class DataFuelScaleMapper implements Function<FuelScale, DMFuelScale> {
    @Override
    public DMFuelScale apply(FuelScale fuelScaleGeneralAttributeReceive) {
        return new DMFuelScale(
                Integer.parseInt(fuelScaleGeneralAttributeReceive.getValueByKey(FuelScale.KEY_IDLE_USE)),
                Integer.parseInt(fuelScaleGeneralAttributeReceive.getValueByKey(FuelScale.KEY_AC_USE)),
                Integer.parseInt(fuelScaleGeneralAttributeReceive.getValueByKey(FuelScale.KEY_DRIVER_USE)),
                Integer.parseInt(fuelScaleGeneralAttributeReceive.getValueByKey(FuelScale.KEY_OTHER_USE))
        );
    }
}
