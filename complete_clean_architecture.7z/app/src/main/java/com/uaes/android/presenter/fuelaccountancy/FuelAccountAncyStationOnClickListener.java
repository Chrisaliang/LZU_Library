package com.uaes.android.presenter.fuelaccountancy;

public interface FuelAccountAncyStationOnClickListener {

    void onClick(int type);

}
