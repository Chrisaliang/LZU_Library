package com.uaes.android.presenter;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;

import com.uaes.android.R;
import com.uaes.android.presenter.batteryhelper.BatteryHelperFragment;
import com.uaes.android.presenter.driver.DriverMasterFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancySettingMainFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainGuideMangerFragment;
import com.uaes.android.presenter.message.MessageCenterFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerDefenderFragment;

import dagger.android.support.DaggerAppCompatActivity;
import timber.log.Timber;

public class MainActivity extends DaggerAppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final String EXTRA_SELECTED_ITEM = "com.uaes.android.presenter";

    private int selectedViewId = View.NO_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            onTabSelected(findViewById(R.id.main_tab_item_fuel_helper));
        } else {
            selectedViewId = savedInstanceState.getInt(EXTRA_SELECTED_ITEM);
            findViewById(selectedViewId).setSelected(true);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(EXTRA_SELECTED_ITEM, selectedViewId);
    }

    public void onTabSelected(View view) {
        final int newId = view.getId();
        Timber.tag(TAG).d("origin id:  %d, newId: %d", selectedViewId, newId);
        if (newId == selectedViewId) return;
        if (selectedViewId != View.NO_ID)
            findViewById(selectedViewId).setSelected(false);
        selectedViewId = newId;
        view.setSelected(true);
        Fragment fragment = getFragment(selectedViewId);
        if (fragment == null) return;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_container, fragment)
                .setPrimaryNavigationFragment(fragment)
                .commit();
    }

    private Fragment getFragment(int id) {
        switch (id) {
            case R.id.main_tab_item_fuel_helper:
                return new FuelAccountancySettingMainFragment();
            case R.id.main_tab_item_battery_helper:
                return new BatteryHelperFragment();
            case R.id.main_tab_item_master_driver:
                return new DriverMasterFragment();
            case R.id.main_tab_item_message_center:
                return new MessageCenterFragment();
            case R.id.main_tab_item_maintain_secretary:
                return new MaintainGuideMangerFragment();
            case R.id.main_tab_item_power_defender:
                return new PowerDefenderFragment();
        }
        return null;
    }

//    public void onCall(View view) {
//        Intent intent = new Intent();
//        intent.setAction("com.iflytek.action.CALL");
//        intent.putExtra("tel", "11111");
//        startActivity(intent);
//    }
}
