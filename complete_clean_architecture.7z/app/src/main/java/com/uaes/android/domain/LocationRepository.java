package com.uaes.android.domain;

import com.uaes.android.domain.entity.DMLocation;

import io.reactivex.Single;

public interface LocationRepository {
    /**
     * 启动单次查询
     */
    Single<DMLocation> create();
}
