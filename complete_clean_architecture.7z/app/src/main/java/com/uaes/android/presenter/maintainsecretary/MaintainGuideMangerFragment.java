package com.uaes.android.presenter.maintainsecretary;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.presenter.BaseFragment;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainGuideMangerFragment extends BaseFragment implements MaintainNavigator {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.maintain_guide_manger, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState == null) {
            getChildFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_maintain_content, new MaintainDetailFragment())
                    .commit();
        }
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof MaintainBaseFragment) {
            ((MaintainBaseFragment) childFragment).mNavigator = this;
        }
    }

   /* @Override
    public boolean back() {
        return getChildFragmentManager().popBackStackImmediate();
    }*/

    @Override
    public void showMaintainPoint() {
        setFragment(new MaintainAppointFragment(), null);
    }

    @Override
    public void showSetting() {
        setFragment(new MaintainSettingsFragment(), null);
    }

    @Override
    public void showHistory() {
        setFragment(new MaintainHistoryFragment(), null);
    }

    @Override
    public void showMaintainConrtentDetail(int position) {
        setFragment(new MaintainContentDetailFragment(), null);
    }

    @Override
    public void showQRCode() {
        setFragment(new MaintainQRcodeFragment(), null);
    }

    @Override
    public void showGrade(Bundle bundle) {
        setFragment(new MaintainGradeFragment(), bundle);
    }

    @Override
    public void showDriveSceheme() {
        setFragment(new MaintainDriveSchemeFragment(), null);
    }


    @Override
    public void onBack() {
        getChildFragmentManager().popBackStack(null, 0);
    }

    private void setFragment(Fragment fragment, Bundle bundle) {
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        getChildFragmentManager()
                .beginTransaction()
                .replace(R.id.fl_maintain_content, fragment)
                .addToBackStack(null)
                .commit();
    }

}
