package com.uaes.android.presenter.driver;

public interface BackListener {
    void popupBack();
}
