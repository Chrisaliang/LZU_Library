package com.uaes.android.domain;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * Single result emitter
 * */
public abstract class SingleUseCase<T>
        implements Interactor<Single<Result<T>>> {

    /**
     * Subclass must override this method to implement itself business logic
     * */
    protected abstract Single<T> buildSingle();

    @Override
    public Single<Result<T>> execute() {
        final Single<T> real = buildSingle();
        if (real == null)
            throw new IllegalArgumentException("This UseCase must has a params!");
        return real.map(new Function<T, Result<T>>() {
            @Override
            public Result<T> apply(T t) {
                return new Result<>(t);
            }
        });
    }
}
