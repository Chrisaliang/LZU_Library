package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMFuelSetting;
import com.uaes.android.domain.usecase.FuelSettingQuery;
import com.uaes.android.domain.usecase.FuelSettingUpdate;

import java.util.Objects;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class FuelAccountancySettingViewModel extends ViewModel
        implements FuelAccountancySettingOnClickListener {
    private static final String TAG = "FuelAccountancySetViewM";

    /**
     * 加油站类型 ： 0：全部,1：中石油,2：中石化
     * <p>
     * chick:fuel_accountancy_station_set_fuel_tab_bg_left
     * fuel_accountancy_station_set_fuel_tab_bg_middle
     * fuel_accountancy_station_set_fuel_tab_bg_right
     * <p>
     * unChick:fuel_accountancy_station_set_fuel_num_color_transparent
     */
    public final MutableLiveData<Integer> stationType = new MutableLiveData<>();

    public final MutableLiveData<Integer> fuelNum = new MutableLiveData<>();

//    public MutableLiveData<Drawable> stationAllBg = new MutableLiveData<>();
//    public MutableLiveData<Drawable> stationSyBg = new MutableLiveData<>();
//    public MutableLiveData<Drawable> stationShBg = new MutableLiveData<>();


    private FuelSettingQuery fuelSettingQuery;
    private Disposable disposableSettingQuery;

    private FuelSettingUpdate fuelSettingUpdate;
    private Disposable disposableFuelSettingUpdate;

    public final MutableLiveData<Boolean> isSuccess = new MutableLiveData<>();

    public FuelAccountancySettingViewModel(FuelSettingQuery fuelSettingQuery, FuelSettingUpdate fuelSettingUpdate) {
        this.fuelSettingQuery = fuelSettingQuery;
        this.fuelSettingUpdate = fuelSettingUpdate;
    }


    //get net data
    public void subscription() {
        fuelSettingQuery.execute()
                .subscribe(new SingleObserver<Result<DMFuelSetting>>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        if (disposableSettingQuery != null) disposableSettingQuery.dispose();
                        disposableSettingQuery = d;
                    }

                    @Override
                    public void onSuccess(Result<DMFuelSetting> dmFuelSettingResult) {
                        Timber.tag(TAG).d("get net data dmFuelSettingResult" + dmFuelSettingResult.content.gasQuery
                                + "  " + dmFuelSettingResult.content.fuelThreshold);
                        initData(dmFuelSettingResult.content);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.tag(TAG).e(e);
                    }
                });
    }

    private void initData(DMFuelSetting dmFuelSetting) {
        stationType.setValue(dmFuelSetting.gasQuery);
        fuelNum.setValue(dmFuelSetting.fuelThreshold);
    }

    public void unSubscribe() {
        if (disposableSettingQuery != null) {
            disposableSettingQuery.dispose();
        }
        if (disposableFuelSettingUpdate != null) {
            disposableFuelSettingUpdate.dispose();
        }
    }

    @Override
    public void onStationTypeSelected(int type) {
        stationType.setValue(type);
    }

    //post data for net
    public void saveData() {
        Timber.tag(TAG).d("save data in FuelAccountancySettingViewModel:" + stationType.getValue() + "  " + fuelNum.getValue());
        DMFuelSetting dmFuelSetting = new DMFuelSetting();
        dmFuelSetting.gasQuery = Objects.requireNonNull(stationType.getValue());
        dmFuelSetting.fuelThreshold = Objects.requireNonNull(fuelNum.getValue());
        fuelSettingUpdate.setSetting(dmFuelSetting);
        fuelSettingUpdate.execute().subscribe(new SingleObserver<Result<Boolean>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (disposableFuelSettingUpdate != null) disposableFuelSettingUpdate.dispose();
                disposableFuelSettingUpdate = d;
            }

            @Override
            public void onSuccess(Result<Boolean> booleanResult) {
                isSuccess.setValue(booleanResult.content);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
                isSuccess.setValue(false);
            }
        });
    }
}
