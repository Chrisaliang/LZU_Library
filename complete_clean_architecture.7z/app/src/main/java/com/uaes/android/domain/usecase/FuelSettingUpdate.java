package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMFuelSetting;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 更新用油会计配置
 */
public class FuelSettingUpdate extends SingleUseCase<Boolean> {

    private JobThread jobThread;

    private FuelHelperRepository fuelHelperRepository;

    private DMFuelSetting dmFuelSetting;

    public FuelSettingUpdate(JobThread jobThread, FuelHelperRepository fuelHelperRepository) {
        this.jobThread = jobThread;
        this.fuelHelperRepository = fuelHelperRepository;
    }

    @Override
    protected Single<Boolean> buildSingle() {
        return Single.just(fuelHelperRepository).map(new Function<FuelHelperRepository, Boolean>() {
            @Override
            public Boolean apply(FuelHelperRepository repository) throws Exception {
                return dmFuelSetting != null && repository.updateFuelSetting(dmFuelSetting);
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }

    public void setSetting(DMFuelSetting setting) {
        this.dmFuelSetting = setting;
    }
}
