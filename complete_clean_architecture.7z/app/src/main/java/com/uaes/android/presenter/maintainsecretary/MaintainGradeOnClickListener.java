package com.uaes.android.presenter.maintainsecretary;

public interface MaintainGradeOnClickListener {

    void onClick(int type);

    void onRateChanged(int type, float rating);
}
