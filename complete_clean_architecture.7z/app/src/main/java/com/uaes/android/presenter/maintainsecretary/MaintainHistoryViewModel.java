package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainHistoryViewModel extends ViewModel {
    private final MutableLiveData<List<MaintainHistoryItem>> maintainHistoryDataObserver = new MutableLiveData<>();


    public void getMaintainHistoryItem() {
        List<MaintainHistoryItem> maintainHistoryItems = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            MaintainHistoryItem maintainHistoryItem = new MaintainHistoryItem();
            maintainHistoryItem.maintainIsComment = i != 2;
            maintainHistoryItem.maintainDate = "2018-03-31 17 : 30";
            maintainHistoryItem.maintainAddress = "上海市浦东新区北汽4s店";
            maintainHistoryItem.maintainPoint = "4.6";
            maintainHistoryItem.maintainShowContent = false;
            maintainHistoryItem.maintainMiles = "17025KM";
            maintainHistoryItem.maintainContent1 = "机油更换:半合成机油套餐";
            maintainHistoryItem.maintainContent2 = "更换空气滤芯";
            maintainHistoryItem.maintainContent3 = "更换机油滤清器";
            maintainHistoryItem.maintainPosition = i;
            maintainHistoryItem.maintainServicePoint = 2;
            maintainHistoryItem.maintainAttitudePoint = 4;
            maintainHistoryItem.maintainChargePoint = 2;
            maintainHistoryItems.add(maintainHistoryItem);
        }
        maintainHistoryDataObserver.setValue(maintainHistoryItems);
    }


    public MutableLiveData<List<MaintainHistoryItem>> getMaintainHistoryDataObserver() {
        return maintainHistoryDataObserver;
    }
}
