package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainDetailViewModel extends ViewModel implements MaintainOnClickListener{
    private static final int SURPLUS_DAYS = 0;
    private static final int SURPLUS_MILES = 1;
    private int contentType = SURPLUS_DAYS;

    public final MutableLiveData<Boolean> showMiles = new MutableLiveData<>();
    public final MutableLiveData<Boolean> showDays = new MutableLiveData<>();
    private final MutableLiveData<List<MaintainDetailItem>> maintainDetailItemsObserver = new MutableLiveData<>();


    public LiveData<List<MaintainDetailItem>> getMessageItems() {
        return maintainDetailItemsObserver;
    }

    private void initContent() {
        if (contentType == SURPLUS_DAYS) {
            contentType = SURPLUS_MILES;
            showMiles.setValue(true);
            showDays.setValue(false);
            maintainDetailItemsObserver.setValue(getTestData());
        } else {
            contentType = SURPLUS_DAYS;
            showMiles.setValue(false);
            showDays.setValue(true);
            maintainDetailItemsObserver.setValue(getTestData1());
        }
    }

    private ArrayList<MaintainDetailItem> getTestData() {
        ArrayList<MaintainDetailItem> datalist = new ArrayList<>();
        MaintainDetailItem maintainDetailItem = new MaintainDetailItem(0, "更换机油滤清器", false);
        MaintainDetailItem maintainDetailItem1 = new MaintainDetailItem(1, "更换发动机机油", true);
        MaintainDetailItem maintainDetailItem2 = new MaintainDetailItem(2, "更换变速器油", false);
        MaintainDetailItem maintainDetailItem3 = new MaintainDetailItem(3, "更换发动机机油", false);
        MaintainDetailItem maintainDetailItem4 = new MaintainDetailItem(4, "更换变速器油", false);
        MaintainDetailItem maintainDetailItem5 = new MaintainDetailItem(5, "更换发动机机油", false);
        datalist.add(maintainDetailItem);
        datalist.add(maintainDetailItem1);
        datalist.add(maintainDetailItem2);
        datalist.add(maintainDetailItem3);
        datalist.add(maintainDetailItem4);
        datalist.add(maintainDetailItem5);
        return datalist;
    }

    private ArrayList<MaintainDetailItem> getTestData1() {
        ArrayList<MaintainDetailItem> datalist = new ArrayList<>();
        MaintainDetailItem maintainDetailItem = new MaintainDetailItem(0, "更换机油滤清器", false);
        MaintainDetailItem maintainDetailItem1 = new MaintainDetailItem(1, "更换发动机机油", true);
        MaintainDetailItem maintainDetailItem2 = new MaintainDetailItem(2, "更换变速器油", false);
        datalist.add(maintainDetailItem);
        datalist.add(maintainDetailItem1);
        datalist.add(maintainDetailItem2);

        return datalist;
    }

    public void getItemData() {
        maintainDetailItemsObserver.setValue(getTestData());
    }

    @Override
    public void onClick(int type) {
        initContent();
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }
}
