package com.uaes.android.common;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.uaes.android.R;
import com.uaes.android.presenter.powerdefender.pojo.CarFaultHistory;
import com.uaes.android.presenter.powerdefender.pojo.CarIndicateEntity;

@BindingMethods({
        @BindingMethod(type = TextView.class, attribute = "selected", method = "changeState"),
        @BindingMethod(type = ImageView.class, attribute = "line", method = "showLine"),
        @BindingMethod(type = ImageView.class, attribute = "warning", method = "showWaring"),
        @BindingMethod(type = TextView.class, attribute = "fault", method = "showFaultNum"),
        @BindingMethod(type = TextView.class, attribute = "carStatusColor", method = "showStatusColor"),
        @BindingMethod(type = TextView.class, attribute = "textFaultColor", method = "showFaultColor"),

})
public class CommonBindAdapter {

    private static final int[][] RESOURCE_INDEX = new int[][]{
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_rhxt, R.drawable.ic_power_red_rhxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_kqxt, R.drawable.ic_power_red_kqxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_dhxt, R.drawable.ic_power_red_dhxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_gdxt, R.drawable.ic_power_red_gdxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_gyxt, R.drawable.ic_power_red_gyxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_czxt, R.drawable.ic_power_red_czxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_rglxt, R.drawable.ic_power_red_rglxt},
            new int[]{Integer.MAX_VALUE, R.drawable.ic_power_yellow_pqxt, R.drawable.ic_power_red_pqxt},


    };

    private static int colors[] = new int[]{
            R.color.colorExcellent,
            R.color.colorFine,
            R.color.colorMiddle,
            R.color.colorBad,
            R.color.colorWhite,
    };


    @BindingAdapter(value = "selected")
    public static void changeState(TextView view, boolean selected) {
        view.setSelected(selected);
    }

    @BindingAdapter(value = "line")
    public static void showLine(ImageView imageView, CarIndicateEntity carIndicateEntity) {
        int x = carIndicateEntity.index;
        int y = carIndicateEntity.carIndicateStatus;
        if (y == 0) {
            imageView.setImageDrawable(null);
        } else {

            imageView.setImageResource(RESOURCE_INDEX[x][y]);
        }

    }

    @BindingAdapter(value = "warning")
    public static void showWaring(ImageView imageView, CarIndicateEntity carIndicateEntity) {

        switch (carIndicateEntity.carIndicateStatus) {
            case 0:
                imageView.setImageResource(R.drawable.ic_power_ok);
                break;


            case 1:
                imageView.setImageResource(R.drawable.ic_power_warning);
                break;


            case 2:
                imageView.setImageDrawable(null);
                break;
        }
    }


    @BindingAdapter(value = "fault")
    public static void showFaultNum(TextView textView, CarIndicateEntity carIndicateEntity) {
        switch (carIndicateEntity.carIndicateStatus) {
            case 0:
                textView.setVisibility(View.GONE);
                break;

            case 1:
                textView.setVisibility(View.GONE);
                break;


            case 2:
                textView.setText(carIndicateEntity.faultCount);
                break;

        }
    }

    @BindingAdapter(value = "textFaultColor")
    public static void showFaultColor(TextView tv, CarFaultHistory carFaultHistory) {

        if (TextUtils.equals(carFaultHistory.faultStatus, "待解决")) {
            tv.setTextColor(ContextCompat.getColor(tv.getContext(), R.color.colorBad));
        } else {
            tv.setTextColor(ContextCompat.getColor(tv.getContext(), R.color.colorWhite));
        }

    }

    @BindingAdapter(value = "carStatusColor")
    public static void showStatusColor(TextView tv, int store) {
        switch (store) {
            case 1:
                tv.setTextColor(ContextCompat.getColor(tv.getContext(), R.color.colorExcellent));
                break;

            case 2:
                tv.setTextColor(ContextCompat.getColor(tv.getContext(), R.color.colorFine));
                break;

            case 3:
                tv.setTextColor(ContextCompat.getColor(tv.getContext(), R.color.colorMiddle));
                break;

            case 4:
                tv.setTextColor(ContextCompat.getColor(tv.getContext(), R.color.colorBad));
                break;
        }

    }
}
