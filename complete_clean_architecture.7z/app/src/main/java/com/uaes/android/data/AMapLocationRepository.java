package com.uaes.android.data;

import com.uaes.android.App;
import com.uaes.android.data.internel.ObservableEx;
import com.uaes.android.data.mapper.AMapLocationMapper;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.entity.DMLocation;

import io.reactivex.Single;

/**
 * 高德地图适配数据层
 */
public class AMapLocationRepository implements LocationRepository {

    private App app;

    private final AMapLocationMapper mapper = new AMapLocationMapper();

    public AMapLocationRepository(App app) {
        this.app = app;
    }

    @Override
    public Single<DMLocation> create() {
        return ObservableEx.createAMapLocation(app).singleOrError()
                .map(mapper);
    }
}
