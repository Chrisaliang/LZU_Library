package com.uaes.android.domain.entity;

/**
 * 加油站
 */
public class DMGas {
    /**
     * 加油站名称
     */
    public String name;

    /**
     * 加油站地址详情
     */
    public String address;
    /**
     * 加油站距离 单位m
     */
    public int distance;
    /**
     * 加油站耗时 单位s
     */
    public int duration;
    /**
     * 加油站 评分
     */
    public int rate;
    /**
     * TODO
     */
    public String fillTime;

    /**
     * 加油站品牌
     */
    public String brand;
    /**
     * 经度
     */
    public double longitude;
    /**
     * 纬度
     */
    public double latitude;
}
