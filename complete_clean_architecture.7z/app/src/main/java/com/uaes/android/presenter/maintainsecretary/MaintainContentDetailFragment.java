package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentContenDetailBinding;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainContentDetailFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    MaintainFragmentContenDetailBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_conten_detail, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MaintainContentViewModel maintainContentViewModel = ViewModelProviders.of(this).get(MaintainContentViewModel.class);
        binding.setListener(this);
        binding.setViewModel(maintainContentViewModel);
        maintainContentViewModel.getContent();
    }


    @Override
    public void onClick(int type) {
        //close
        mNavigator.onBack();
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {


    }
}
