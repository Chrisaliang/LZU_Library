package com.uaes.android.data.http;

import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.json.GeneralAttributeSent;
import com.uaes.android.data.json.JsonRequestBody;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by Chrisaliang on 2017/11/8.
 * api for setting
 */

public interface SettingApi {

    /**
     * @param body structure like this
     *             {
     *             "attributeList": [
     *             {
     *             "attributeType": "string",
     *             "attributeValue": "string" 中石油 1 中石化 2  全部 0
     *             }
     *             ],
     *             "vin": "string"
     *             }
     */
    @POST("/car/v1/carAttribute/app/create")
    Call<GeneralAttributeReceive<GeneralAttributeSent>> lowFuelWarningSent(@Body JsonRequestBody body);

    /**
     * @param body same as method lowFuelWarningSent's parameter @body
     * @return jsonObject which include setting parameter
     */
    @POST("/car/v1/carAttribute/app/byAttributes")
    Call<GeneralAttributeReceive<GeneralAttributeSent>> lowFuelWarningReceive(@Body JsonRequestBody body);
}
