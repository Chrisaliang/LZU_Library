package com.uaes.android.presenter.driver;

import com.uaes.android.R;
import com.uaes.android.domain.entity.DMDriverMasterItem;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.functions.Function;

public class DriverMasterDetailListMapper implements Function<List<DMDriverMasterItem>, List<DriverMasterDetailItem>> {

    @Override
    public List<DriverMasterDetailItem> apply(List<DMDriverMasterItem> items) {
        List<DriverMasterDetailItem> list = new ArrayList<>(0);
        for (DMDriverMasterItem item : items) {
            DriverMasterDetailItem newItem = new DriverMasterDetailItem();
            newItem.time = item.time;
            newItem.dangerousRank = item.dangerousRank;
            newItem.duration = item.duration;
            newItem.locations = item.locations;
            newItem.locationStr = item.locationStr;
            if (item.dangerousRank <= 2)
                newItem.ratingRes = R.drawable.driver_master_rating_small_blue;
            else if (item.dangerousRank <= 4)
                newItem.ratingRes = R.drawable.driver_master_rating_small_yellow;
            else
                newItem.ratingRes = R.drawable.driver_master_rating_small_red;
            newItem.locationIcon = item.detailType < 4 ?
                    R.drawable.driver_master_navigator_location :
                    R.drawable.driver_master_navigator_route;
            list.add(newItem);
        }
        return list;
    }
}
