package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentSettingsBinding;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainSettingsFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private MaintainFragmentSettingsBinding binding;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_settings, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MaintainSettingsViewModel maintainSettingsViewModel = ViewModelProviders.of(this).get(MaintainSettingsViewModel.class);
        binding.setMaintainclickListener(maintainSettingsViewModel);
        binding.setViewolickListener(this);
        binding.setMaintainSettingsViewModel(maintainSettingsViewModel);
    }


    @Override
    public void onClick(int type) {
        mNavigator.onBack();
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }
}
