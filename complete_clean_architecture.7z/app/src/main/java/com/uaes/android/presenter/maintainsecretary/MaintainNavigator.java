package com.uaes.android.presenter.maintainsecretary;

import android.os.Bundle;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 * 业务接口,
 */
public interface MaintainNavigator {
    /**
     * 跳转到一键预约
     */
    void showMaintainPoint();

    /**
     * 跳转到保养设置
     */
    void showSetting();

    /**
     * 跳转保养历史
     */
    void showHistory();

    /**
     * 跳转保养详情
     *
     * @param position 条目
     */
    void showMaintainConrtentDetail(int position);

    /**
     * 打开二维码
     */
    void showQRCode();

    /**
     * 打开评分页面
     */
    void showGrade(Bundle bundle);

    /**
     *代开地图导航页面
     */
    void showDriveSceheme();

    /**
     * 回退
     */
    void onBack();
}
