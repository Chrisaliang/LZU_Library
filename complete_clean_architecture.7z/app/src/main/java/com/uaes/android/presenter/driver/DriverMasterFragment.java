package com.uaes.android.presenter.driver;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.DriverMasterFragmentBinding;
import com.uaes.android.presenter.BaseFragment;

import javax.inject.Inject;

public class DriverMasterFragment extends BaseFragment implements OnDetailClickListener, NavigatorListener, QueryTypeClickListener {

    private static final String TAG = "DriverMasterFragment";

    DriverMasterViewModel viewModel;
    @Inject
    ViewModelProvider.Factory factory;
    private DriverMasterFragmentBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.driver_master_fragment, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = ViewModelProviders.of(this, factory).get(DriverMasterViewModel.class);
        binding.setClick(this);
        binding.setQueryListener(this);
        binding.setDriveManager(viewModel);
//        binding.setVariable(BR.driveManager, viewModel);
    }

    @Override
    public void onResume() {
        super.onResume();
        viewModel.driverMasterSummery();
    }

    @Override
    public void changeFragment(int type) {
//        Toast.makeText(getActivity(), "点击：" + type, Toast.LENGTH_SHORT).show();
        binding.clDriverManagerDetail.setVisibility(View.GONE);
        Fragment fragment = new DriverMasterDetailFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(DriverMasterDetailFragment.FRAGMENT_TYPE, type);
        fragment.setArguments(bundle);
        getChildFragmentManager().beginTransaction()
                .replace(R.id.driverManagerLayoutContent, fragment)
                .addToBackStack(TAG)
                .commit();
    }

    @Override
    public void backPreviewLevel() {
        binding.clDriverManagerDetail.setVisibility(View.VISIBLE);
        getChildFragmentManager().popBackStack();
    }

    @Override
    public void queryType(int type) {
        viewModel.driverMasterSummery(type);
    }
}
