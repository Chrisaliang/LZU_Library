package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModel;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainQRcodeViewModel extends ViewModel {
    //填充二维码

}
