package com.uaes.android.domain.entity;

/**
 * 行驶到了一段距离的累计油耗
 */
public class DMAccumulativeFuelConsumption {

    /**
     * 表示已经行驶了的公里数 单位是 KM
     */
    @SuppressWarnings("WeakerAccess")
    public int traveledMiles;
    /**
     * 累计消耗的燃油量 单位是L
     */
    public float accumulativeConsumption;

    public DMAccumulativeFuelConsumption(int traveledMiles, float accumulativeConsumption) {
        this.traveledMiles = traveledMiles;
        this.accumulativeConsumption = accumulativeConsumption;
    }
}
