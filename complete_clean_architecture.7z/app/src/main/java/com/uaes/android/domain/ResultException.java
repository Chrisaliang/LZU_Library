package com.uaes.android.domain;

/**
 * Public exception used by Result
 * */
public class ResultException extends Exception {
    // debug usage
    private String debugMessage;

    public ResultException(String message, Throwable cause, String debugMessage) {
        super(message, cause);
        this.debugMessage = debugMessage;
    }
}
