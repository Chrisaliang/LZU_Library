package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentDriveSchemeBinding;
import com.uaes.android.databinding.MaintainItemDriveSchemeItemeBinding;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainDriveSchemeFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainDriveSchemeFrag_";
    private ArrayList<MaintainDriveSchemeItem> dataList;
    MaintainFragmentDriveSchemeBinding binding;
    private MaintainDriveSchemeAdapter maintainDriveSchemeAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_drive_scheme, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MaintainDriveSchemeViewModel maintainDriveSchemeViewModel = ViewModelProviders.of(this).get(MaintainDriveSchemeViewModel.class);
        binding.setMaintainDriveSchemeViewModel(maintainDriveSchemeViewModel);
        binding.setMaintainOnClickListener(this);

        maintainDriveSchemeAdapter = new MaintainDriveSchemeAdapter();
        binding.rclDriveScheme.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rclDriveScheme.setAdapter(maintainDriveSchemeAdapter);

        maintainDriveSchemeViewModel.getDriverSchemeData();
        maintainDriveSchemeViewModel.getDataObserver().observe(this, new Observer<List<MaintainDriveSchemeItem>>() {
            @Override
            public void onChanged(@Nullable List<MaintainDriveSchemeItem> maintainDriveSchemeItems) {
                maintainDriveSchemeAdapter.updataALL(maintainDriveSchemeItems);
            }
        });
    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 0:
                //返回按钮
                mNavigator.onBack();
                break;
            case 1:
                //开始导航
                break;
        }
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }

    private class MaintainDriveSchemeAdapter extends RecyclerView.Adapter<MaintainDriveSchemeViewHolder> {

        MaintainDriveSchemeAdapter() {
            dataList = new ArrayList<>();
        }

        @NonNull
        @Override
        public MaintainDriveSchemeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemDriveSchemeItemeBinding itemBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.maintain_item_drive_scheme_iteme, parent, false);
            return new MaintainDriveSchemeViewHolder(itemBinding);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainDriveSchemeViewHolder holder, int position) {
            holder.bind(dataList.get(position));
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public void updataALL(List<MaintainDriveSchemeItem> maintainDriveSchemeItems) {
            dataList.clear();
            dataList.addAll(maintainDriveSchemeItems);
            Timber.tag(TAG).w("dataList.size:" + dataList.size());
            notifyDataSetChanged();
        }

        public void selectItemAt(int position) {
            Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:" + position);
            for (int i = 0; i < dataList.size(); i++) {
                if (i == position) {
                    dataList.get(position).isChoice = true;
                } else {
                    dataList.get(i).isChoice = false;
                }
            }
            notifyDataSetChanged();
        }
    }

    private class MaintainDriveSchemeViewHolder extends RecyclerView.ViewHolder implements MaintainItemOnClickListener {

        private MaintainItemDriveSchemeItemeBinding itembinding;
        private MaintainDriveSchemeItem item;

        MaintainDriveSchemeViewHolder(MaintainItemDriveSchemeItemeBinding itembinding) {
            super(itembinding.getRoot());
            this.itembinding = itembinding;
        }

        public void bind(MaintainDriveSchemeItem item) {
            this.item = item;
            itembinding.setListener(this);
            itembinding.setItem(item);
            itembinding.executePendingBindings();
        }


        @Override
        public void onClick(int type, int position) {
            if (item.isChoice) return;
            maintainDriveSchemeAdapter.selectItemAt(position);
        }
    }

}
