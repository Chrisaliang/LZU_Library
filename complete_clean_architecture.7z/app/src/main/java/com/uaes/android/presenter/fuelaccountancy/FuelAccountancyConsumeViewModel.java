package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.usecase.FuelMonitorQuery;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import timber.log.Timber;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/9.
 */
public class FuelAccountancyConsumeViewModel extends ViewModel {

    private static final String TAG = "FuelAccountancyConsumeV";

    public final MutableLiveData<Integer> carRankNum = new MutableLiveData<>();

    public final MutableLiveData<List<BarEntry>> consumeAmount = new MutableLiveData<>();

    public final MutableLiveData<List<Entry>> accumulativeTrack = new MutableLiveData<>();

    private FuelMonitorQuery fuelMonitorQuery;

    private Disposable disposable;

    public FuelAccountancyConsumeViewModel(FuelMonitorQuery query) {
        fuelMonitorQuery = query;
    }

    public void init() {

        fuelMonitorQuery.execute().map(new Function<Result<ARFuelMonitor>, FuelAccountancyConsumeUIFactor>() {
            @Override
            public FuelAccountancyConsumeUIFactor apply(Result<ARFuelMonitor> arFuelMonitorResult) {
                FuelAccountancyConsumeUIFactor fuelAccountancyConsumeUiFactor = new FuelAccountancyConsumeUIFactor();
                ArrayList<BarEntry> entries = new ArrayList<>();
                for (int i = 0; i < arFuelMonitorResult.content.fuelConsumptionOfDay.length; i++) {
                    entries.add(new BarEntry(i, arFuelMonitorResult.content.fuelConsumptionOfDay[i].fuelConsumption,
                            arFuelMonitorResult.content.fuelConsumptionOfDay[i]));
                }
                fuelAccountancyConsumeUiFactor.barEntries = entries;

                fuelAccountancyConsumeUiFactor.rank = arFuelMonitorResult.content.rank;
                List<Entry> entries2 = new ArrayList<>();
                for (int i = 0; i < arFuelMonitorResult.content.accumulativeFuelConsumptions.length; i++) {
                    entries2.add(new Entry(i, arFuelMonitorResult.content.accumulativeFuelConsumptions[i].accumulativeConsumption,
                            arFuelMonitorResult.content.accumulativeFuelConsumptions[i]));
                }
                fuelAccountancyConsumeUiFactor.entries = entries2;
                return fuelAccountancyConsumeUiFactor;
            }
        }).subscribe(new SingleObserver<FuelAccountancyConsumeUIFactor>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (disposable != null)
                    disposable.dispose();
                disposable = d;
            }

            @Override
            public void onSuccess(FuelAccountancyConsumeUIFactor fuelAccountancyConsumeUiFactor) {
                consumeAmount.setValue(fuelAccountancyConsumeUiFactor.barEntries);
                accumulativeTrack.setValue(fuelAccountancyConsumeUiFactor.entries);
                carRankNum.setValue(fuelAccountancyConsumeUiFactor.rank);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposable != null)
            disposable.dispose();
    }

    private static class FuelAccountancyConsumeUIFactor {
        public int rank;
        public List<BarEntry> barEntries;
        public List<Entry> entries;
    }
}
