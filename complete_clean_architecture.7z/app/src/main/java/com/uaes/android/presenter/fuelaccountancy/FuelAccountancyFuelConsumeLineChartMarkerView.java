package com.uaes.android.presenter.fuelaccountancy;

import android.annotation.SuppressLint;
import android.content.Context;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.utils.MPPointF;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/10.
 */
@SuppressLint("ViewConstructor")
public class FuelAccountancyFuelConsumeLineChartMarkerView extends MarkerView {
    /**
     * Constructor. Sets up the MarkerView with a custom layout resource.
     *
     * @param context activity context
     * @param layoutResource the layout resource to use for the MarkerView
     */
    public FuelAccountancyFuelConsumeLineChartMarkerView(Context context, int layoutResource) {
        super(context, layoutResource);
    }

    @Override
    public MPPointF getOffset() {
        MPPointF mpPointF = super.getOffset();
        mpPointF.x = -getWidth() / 2;
        mpPointF.y = -getHeight();
        return mpPointF;
    }
}
