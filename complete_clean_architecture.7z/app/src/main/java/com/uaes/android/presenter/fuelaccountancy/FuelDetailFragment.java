package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.PieChart;
import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyMainFragmentFuelDetailsBinding;

import javax.inject.Inject;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelDetailFragment extends FuelAccountancyBaseFragment {

    @Inject
    ViewModelProvider.Factory factory;

    FuelAccountancyMainFragmentFuelDetailsBinding binding;
    FuelAccountancyDetailViewModel fuelAccountancyDetailViewModel;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_main_fragment_fuel_details, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fuelAccountancyDetailViewModel = ViewModelProviders.of(this, factory).get(FuelAccountancyDetailViewModel.class);
        binding.setViewModel(fuelAccountancyDetailViewModel);
        binding.setListener(fuelAccountancyDetailViewModel);
        initPieChart();
        fuelAccountancyDetailViewModel.init();
    }

    private void initPieChart() {
        PieChart mPieChart
                = binding.fuelMainPichart;
        mPieChart.setUsePercentValues(true);
        mPieChart.getDescription().setEnabled(false);
        mPieChart.setExtraOffsets(30, 15, 30, 15);
        mPieChart.setDragDecelerationFrictionCoef(0.95f);
        mPieChart.setDrawHoleEnabled(false);
        mPieChart.setRotationEnabled(true);
        mPieChart.setHighlightPerTapEnabled(true);
        mPieChart.setRotationEnabled(true);
        mPieChart.getLegend().setEnabled(false);

        mPieChart.setEntryLabelColor(Color.WHITE);
        mPieChart.setEntryLabelTextSize(20f);
        mPieChart.highlightValue(null);


    }
}
