package com.uaes.android;

import android.arch.lifecycle.ViewModelProvider;

import com.uaes.android.common.UaesViewModelProviderFactory;
import com.uaes.android.domain.usecase.BatteryStatusSubscription;
import com.uaes.android.domain.usecase.DriverMasterDetailQuery;
import com.uaes.android.domain.usecase.DriverMasterQuery;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;
import com.uaes.android.domain.usecase.FuelMonitorQuery;
import com.uaes.android.domain.usecase.FuelScaleQuery;
import com.uaes.android.domain.usecase.FuelScaleRealTimeQuery;
import com.uaes.android.domain.usecase.FuelSettingQuery;
import com.uaes.android.domain.usecase.FuelSettingUpdate;
import com.uaes.android.domain.usecase.GasListQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */

@Module
class ViewModelModule {

    @Singleton
    @Provides
    static ViewModelProvider.Factory providerFactory(
            App app,
            FuelScaleQuery case1,
            GasListQuery case2,
            FuelScaleRealTimeQuery case3,
            BatteryStatusSubscription case4,
            MessageCenterMsgQuery case5,
            MessageCenterMsgUpdate case6,
            FuelMonitorQuery case7,
            FuelHistoryFillListQuery case8,
            FuelSettingQuery case9,
            FuelSettingUpdate case10,
            DriverMasterDetailQuery case11,
            DriverMasterQuery case12
    ) {
        return new UaesViewModelProviderFactory(
                app, case1, case2, case3, case4, case5, case6, case7, case8, case9, case10,
                case11, case12);
    }
}
