package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.aggregation.ARFuelMonitor;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class FuelMonitorQuery extends SingleUseCase<ARFuelMonitor> {

    private FuelHelperRepository repository;

    private JobThread jobThread;

    public FuelMonitorQuery(FuelHelperRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<ARFuelMonitor> buildSingle() {
        return Single.just(repository).map(new Function<FuelHelperRepository, ARFuelMonitor>() {
            @Override
            public ARFuelMonitor apply(FuelHelperRepository repository) throws Exception {
                return repository.queryFuelMonitor();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
