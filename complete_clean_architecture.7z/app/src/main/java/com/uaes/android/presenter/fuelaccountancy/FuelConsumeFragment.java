package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyFragmentFuelconsumeBinding;
import com.uaes.android.domain.entity.DMFuelConsumptionOfDay;
import com.uaes.android.domain.entity.DMFuelScale;

import javax.inject.Inject;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelConsumeFragment extends FuelAccountancyBaseFragment {

    public static final String AC_USE = "AC_USE";
    public static final String DRIVER_USE = "DRIVER_USE";
    public static final String OTHER_USE = "OTHER_USE";
    public static final String IDLE_USE = "IDLE_USE";

    FuelAccountancyFragmentFuelconsumeBinding binding;

    @Inject
    ViewModelProvider.Factory factory;

    FuelAccountancyConsumeViewModel fuelAccountancyConsumeViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_fragment_fuelconsume, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fuelAccountancyConsumeViewModel = ViewModelProviders.of(this, factory).get(FuelAccountancyConsumeViewModel.class);
        binding.setViewModel(fuelAccountancyConsumeViewModel);
        initBarChart();
        initLineChart();
        fuelAccountancyConsumeViewModel.init();
    }

    private void initBarChart() {
        final BarChart barChart = binding.fuelAccountancyConsumeBarchart;
        barChart.setDrawBarShadow(false);
        barChart.setDrawValueAboveBar(false);
        barChart.setDescription(null);
        barChart.setDrawGridBackground(false);
        barChart.setScaleEnabled(false);
        barChart.disableScroll();

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(20f);
        xAxis.setTextColor(Color.parseColor("#c0fcfdfd"));

        YAxis leftAxis = barChart.getAxisLeft();
        leftAxis.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        leftAxis.setDrawLabels(true);
        leftAxis.setDrawGridLines(false);
        leftAxis.setTextSize(20f);
        leftAxis.setAxisMinimum(0);
        leftAxis.setTextColor(Color.parseColor("#c0fcfdfd"));
        leftAxis.setLabelCount(2, true);
        leftAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return (int) value == 0 ? "" : (int) value + "L/100KM";
            }
        });

        barChart.getAxisRight().setEnabled(false);
        barChart.setHighlightPerDragEnabled(false);
        barChart.setAutoScaleMinMaxEnabled(true);
        barChart.getLegend().setEnabled(false);
        barChart.setDrawBorders(false);
        barChart.setExtraOffsets(0, 30, 0, 13);

        barChart.setRenderer(new FuelAccountancyRoundCornerBarChartRender(barChart));

        barChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                FuelAccountancyFuelConsumeDetailFragment fragment = new FuelAccountancyFuelConsumeDetailFragment();
                Bundle args = new Bundle();
                DMFuelScale dmFuelScale = ((DMFuelConsumptionOfDay) e.getData()).scale;
                args.putInt(AC_USE, dmFuelScale.acUse);
                args.putInt(DRIVER_USE, dmFuelScale.driverUse);
                args.putInt(IDLE_USE, dmFuelScale.idleUse);
                args.putInt(OTHER_USE, dmFuelScale.otherUse);
                fragment.setArguments(args);
                fragment.setListener(listener);
                fragment.show(getChildFragmentManager(), null);
            }

            @Override
            public void onNothingSelected() {

            }
        });

    }

    private void initLineChart() {
        LineChart lineChart = binding.fuelAccountancyConsumeLinechart;
        lineChart.getLegend().setEnabled(false);
        lineChart.getDescription().setEnabled(false);
        lineChart.setScaleEnabled(false);
        lineChart.setHighlightPerDragEnabled(false);
        lineChart.setExtraOffsets(0, 30, 40, 13);

        FuelAccountancyFuelConsumeLineChartMarkerView markerView = new FuelAccountancyFuelConsumeLineChartMarkerView(getContext(), R.layout.fuel_accountancy_fragment_linechart_markview);
        final TextView view = markerView.findViewById(R.id.fuel_accountancy_consume_markerview_textview);
        lineChart.setMarker(markerView);
        lineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                view.setText(String.valueOf((int) e.getY()));
            }

            @Override
            public void onNothingSelected() {

            }
        });

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(20f);
        xAxis.setTextColor(Color.parseColor("#c0fcfdfd"));
        xAxis.setLabelCount(2, true);


        lineChart.getAxisRight().setEnabled(false);
        YAxis yAxis = lineChart.getAxisLeft();
        yAxis.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        yAxis.setLabelCount(1, true);
        yAxis.setTextColor(Color.parseColor("#c0fcfdfd"));
        yAxis.setTextSize(20f);
        yAxis.setDrawGridLines(false);
        yAxis.setAxisMinimum(0);
        yAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return (int) value == 0 ? "" : (int) value + "L";
            }
        });
    }

    private FuelAccountancyFuelConsumeDetailFragment.DetailDialogDismissListener listener = new FuelAccountancyFuelConsumeDetailFragment.DetailDialogDismissListener() {
        @Override
        public void onDismiss() {
            binding.fuelAccountancyConsumeBarchart.highlightValue(null);
        }
    };
}
