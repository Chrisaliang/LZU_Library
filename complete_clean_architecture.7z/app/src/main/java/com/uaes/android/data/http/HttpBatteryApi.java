package com.uaes.android.data.http;

import com.uaes.android.data.json.BatteryStatusJson;
import com.uaes.android.data.json.BatteryVolJson;
import com.uaes.android.data.json.GeneralAttributeReceive;

import retrofit2.Call;
import retrofit2.http.GET;

public interface HttpBatteryApi {
    /**
     * 读取电池状态接口
     */
    @GET("v2/battery/life")
    Call<GeneralAttributeReceive<BatteryStatusJson>> queryBatterStatus();

    /**
     * 读取电池电量
     */
    @GET("/v1/battery/power")
    Call<GeneralAttributeReceive<BatteryVolJson>> queryBatteryVol();
}
