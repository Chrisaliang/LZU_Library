package com.uaes.android.data;

import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.presenter.message.MessageCenterMsgItem;

import java.util.List;

import io.reactivex.Observable;

public class MessageCenterRepositoryImp implements MessageCenterRepository {
    @Override
    public List<MessageCenterMsgItem> queryMessage(int type) {
        return null;
    }

    @Override
    public Observable<MessageCenterMsgItem> updateMessage() {
        return null;
    }


}
