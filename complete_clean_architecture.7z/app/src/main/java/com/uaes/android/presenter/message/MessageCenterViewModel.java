package com.uaes.android.presenter.message;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;

import java.util.List;

import io.reactivex.Observer;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class MessageCenterViewModel extends ViewModel implements SingleObserver<Result<List<MessageCenterMsgItem>>> {


    private static final String TAG = "MessageCenterViewModel";
    public final MutableLiveData<Integer> selected = new MutableLiveData<>();

    //    private MessageMapper mapper;
    private MessageCenterMsgQuery msgQuery;
    private MessageCenterMsgUpdate msgUpdate;
    private MutableLiveData<List<MessageCenterMsgItem>> messageItems = new MutableLiveData<>();
    private MutableLiveData<MessageCenterMsgItem> updateMessageItem = new MutableLiveData<>();
    private Disposable disposable;
    private Disposable updateDisposable;

    public MessageCenterViewModel(MessageCenterMsgQuery msgQuery, MessageCenterMsgUpdate msgUpdate) {
        this.msgQuery = msgQuery;
        this.msgUpdate = msgUpdate;
//        mapper = new MessageMapper();
    }

    public MutableLiveData<List<MessageCenterMsgItem>> getMessageItems() {
        return messageItems;
    }

    public MutableLiveData<MessageCenterMsgItem> getUpdateMessageItem() {
        return updateMessageItem;
    }

    public void updateMessage() {
        updateMessage(0);
    }
    public void updateMessage(int type) {

        if (selected.getValue() != null && selected.getValue() == type) return;

        selected.setValue(type);

        msgQuery.setMessageType(type);

        msgQuery.execute().subscribe(this);
    }

    @Override
    public void onSubscribe(Disposable d) {
        checkDisposable();
        disposable = d;
    }

    private void checkDisposable() {
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSuccess(Result<List<MessageCenterMsgItem>> result) {
        messageItems.setValue(result.content);
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).d(e);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        checkDisposable();
    }

    public void subscribe() {
        msgUpdate.execute().subscribe(new Observer<MessageCenterMsgItem>() {
            @Override
            public void onSubscribe(Disposable d) {
                checkUpdateDisposable();
                updateDisposable = d;
            }

            @Override
            public void onNext(MessageCenterMsgItem item) {
                updateMessageItem.setValue(item);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }

            @Override
            public void onComplete() {
                Timber.tag(TAG).d("onComplete");
            }
        });
    }

    public void unSubscribe() {
        checkUpdateDisposable();
    }

    private void checkUpdateDisposable() {
        if (updateDisposable != null && !updateDisposable.isDisposed())
            updateDisposable.dispose();
    }
}
