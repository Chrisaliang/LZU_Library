package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainConstant {

    public static final String MAINTAINT_SERVICE_POINT = "service_point";
    public static final String MAINTAINT_ATTITUDE_POINT = "attitude_point";
    public static final String MAINTAINT_CHARGE_POINT = "charge_point";
    public static final String MAINTAINT_HISTORY_POSITION = "history_position";
    public static final String MAINTAINT_IS_ADD_COMMENT = "is_add_comment";
    public static final String BACK_TAG = "maintain";
}
