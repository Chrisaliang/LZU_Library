package com.uaes.android.domain;

import android.support.annotation.IntDef;

import com.uaes.android.domain.entity.DMPowerReport;
import com.uaes.android.domain.entity.DMPowerStatus;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

/**
 * 动力卫士
 */
public interface PowerDefenderRepository {
    /**
     * 优
     */
    int OVERALL_RATING_EXCELLENT = 0;
    /**
     * 良
     */
    int OVERALL_RATING_GOOD = 1;
    /**
     * 中
     */
    int OVERALL_RATING_QUALIFIED = 2;
    /**
     * 差
     */
    int OVERALL_RATING_POOR = 3;
    /**
     * 错误码-无错误
     */
    int ERROR_CODE_OK = 0;
    /**
     * 错误码-警告
     */
    int ERROR_CODE_WARN = 1;
    /**
     * 错误码-错误
     */
    int ERROR_CODE_ERROR = 2;

    /**
     * 查询车辆动力状态
     */
    DMPowerStatus queryPowerStatus() throws Exception;

    /**
     * 查询车辆历史维修报告
     */
    List<DMPowerReport> queryPowerReport() throws Exception;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({OVERALL_RATING_EXCELLENT, OVERALL_RATING_GOOD,
            OVERALL_RATING_QUALIFIED, OVERALL_RATING_POOR})
    @interface OverallRating {
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({ERROR_CODE_OK, ERROR_CODE_WARN, ERROR_CODE_ERROR})
    @interface ErrorCode {
    }
}
