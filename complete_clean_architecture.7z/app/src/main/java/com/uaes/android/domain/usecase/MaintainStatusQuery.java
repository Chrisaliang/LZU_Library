package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMaintainStatus;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 保养状态查询
 */
public class MaintainStatusQuery extends SingleUseCase<DMMaintainStatus> {

    private MaintainRepository repository;

    private JobThread jobThread;

    public MaintainStatusQuery(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<DMMaintainStatus> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, DMMaintainStatus>() {
            @Override
            public DMMaintainStatus apply(MaintainRepository repository) throws Exception {
                return repository.queryStatus();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
