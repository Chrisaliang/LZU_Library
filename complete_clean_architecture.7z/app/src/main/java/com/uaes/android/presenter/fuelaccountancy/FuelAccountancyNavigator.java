package com.uaes.android.presenter.fuelaccountancy;

public interface FuelAccountancyNavigator {

    void goToSetting();

    void goToSettingSuccess();

    void back();

}
