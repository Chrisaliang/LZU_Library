package com.uaes.android.presenter.fuelaccountancy;

public class FuelAccountancyPlanItemViewModel {
    /**
     * 方案编号
     */
    public int planNum;
    /**
     * 显示时间，距离，红绿灯个数
     */
    public String planTimeAndDistance;
    /**
     * 路线
     */
    public String planDes;
    /**
     * 策略
     */
    public String strategy;
    /**
     * 是否选中
     */
    public boolean isChecked;

    @Override
    public String toString() {
        return "FuelAccountancyPlanItemViewModel{" +
                "planNum=" + planNum +
                ", planTimeAndDistance='" + planTimeAndDistance + '\'' +
                ", planDes='" + planDes + '\'' +
                ", strategy='" + strategy + '\'' +
                ", isChecked=" + isChecked +
                '}';
    }
}
