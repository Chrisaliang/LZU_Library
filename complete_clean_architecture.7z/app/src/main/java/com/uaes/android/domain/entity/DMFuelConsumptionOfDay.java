package com.uaes.android.domain.entity;

import android.support.annotation.IntRange;

/**
 * 代表某一日百公里的燃料消耗
 */
public class DMFuelConsumptionOfDay {
    /**
     * 消耗的日期 日期格式： 2018-01-19
     */
    public String date;
    /**
     * 消耗的量 单位是 L/KM 每百公里油耗
     */
    @IntRange(from = 1, to = Integer.MAX_VALUE)
    public int fuelConsumption;
    /**
     * 详细油耗百分比
     */
    @SuppressWarnings("WeakerAccess")
    public DMFuelScale scale;


    public DMFuelConsumptionOfDay(String date, int fuelConsumption, DMFuelScale scale) {
        this.date = date;
        this.fuelConsumption = fuelConsumption;
        this.scale = scale;
    }


}
