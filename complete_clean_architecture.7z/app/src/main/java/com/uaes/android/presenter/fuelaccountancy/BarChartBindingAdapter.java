package com.uaes.android.presenter.fuelaccountancy;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.uaes.android.domain.entity.DMFuelConsumptionOfDay;
import com.uaes.android.domain.entity.DMFuelFillHistory;

import java.util.ArrayList;
import java.util.List;


/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/9.
 */
@BindingMethods({@BindingMethod(type = BarChart.class, attribute = "consumeBarData", method = "setConsumeBarData"),
        @BindingMethod(type = BarChart.class, attribute = "historyBarData", method = "setHistoryBarData")})
public abstract class BarChartBindingAdapter {

    @BindingAdapter(value = "consumeBarData")
    public static void setConsumeBarData(BarChart barChart, List<BarEntry> entries) {

        List<BarEntry> local = entries;
        if (local == null) {
            local = new ArrayList<>();
        }
        BarData barData = barChart.getData();
        if (barData == null) {
            barData = new BarData();
            barData.setDrawValues(false);
            barData.setBarWidth(0.4f);
            barData.setValueTextColor(Color.parseColor("#c0fcfdfd"));
            barData.setValueTextSize(11f);
            barChart.setData(barData);
        }

        BarDataSet dataSet = (BarDataSet) barData.getDataSetByIndex(0);
        if (dataSet == null) {
            dataSet = new BarDataSet(local, "BarChart");
            dataSet.setColors(Color.WHITE);
        } else {
            dataSet.setValues(local);
        }
        barData.addDataSet(dataSet);
        dataSet.setDrawValues(false);
        dataSet.setHighLightColor(Color.parseColor("#0ba9fc"));
        dataSet.setHighLightAlpha(255);
        barChart.getXAxis().setValueFormatter(new ConsumeDayFormatter(local));

        float sum = 0;
        float maxNum = 0;
        for (int i = 0; i < local.size(); i++) {
            if (maxNum < local.get(i).getY()) maxNum = local.get(i).getY();
            sum += local.get(i).getY();
        }

        LimitLine limitLine = new LimitLine(sum / local.size());
        limitLine.enableDashedLine(5f, 3f, 2f);
        limitLine.setLineColor(Color.parseColor("#C0C0C0"));
        barChart.getAxisLeft().addLimitLine(limitLine);
        barChart.getAxisLeft().setAxisMaximum(maxNum * 1.2f);

        barChart.notifyDataSetChanged();
        barChart.invalidate();
        if (dataSet.getValues().size() > 7) {
            barChart.zoom(entries.size() * 1.0f / 7, 1, 0, 0);
            barChart.centerViewTo(dataSet.getValues().size() - 1, dataSet.getValues().get(dataSet.getValues().size() - 1).getY(), null);
        }

    }

    @BindingAdapter(value = "historyBarData")
    public static void setHistoryBarData(BarChart barChart, List<BarEntry> entries) {
        List<BarEntry> local = entries;
        if (local == null) {
            local = new ArrayList<>();
        }
        BarData barData = barChart.getData();
        if (barData == null) {
            barData = new BarData();
            barData.setDrawValues(false);
            barData.setBarWidth(0.4f);
            barData.setValueTextColor(Color.parseColor("#c0fcfdfd"));
            barData.setValueTextSize(11f);
            barChart.setData(barData);
        }

        BarDataSet dataSet = (BarDataSet) barData.getDataSetByIndex(0);
        if (dataSet == null) {
            dataSet = new BarDataSet(local, "BarChart");
            dataSet.setColors(Color.WHITE);
        } else {
            dataSet.setValues(local);
        }
        barData.addDataSet(dataSet);
        dataSet.setDrawValues(false);
        dataSet.setHighLightColor(Color.parseColor("#0ba9fc"));
        dataSet.setHighLightAlpha(255);

        barChart.getXAxis().setValueFormatter(new HistoryDayFormatter(entries));
        barChart.getXAxis().setLabelCount(10);
        barChart.notifyDataSetChanged();
        barChart.invalidate();
        if (dataSet.getValues().size() > 10) {
            barChart.zoom(entries.size() * 0.1f, 1, 0, 0);
            barChart.centerViewTo(dataSet.getValues().size(), dataSet.getValues().get(dataSet.getValues().size() - 1).getY(), null);
        }
    }

    private static class ConsumeDayFormatter implements IAxisValueFormatter {

        private List<BarEntry> entries;

        ConsumeDayFormatter(List<BarEntry> entries) {
            this.entries = entries;
        }

        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            if (value < entries.size())
                return ((DMFuelConsumptionOfDay) entries.get((int) value).getData()).date.substring(5);
            else
                return "";
        }
    }

    private static class HistoryDayFormatter implements IAxisValueFormatter {

        private List<BarEntry> entries;

        HistoryDayFormatter(List<BarEntry> entries) {
            this.entries = entries;
        }

        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            return ((DMFuelFillHistory) entries.get((int) value).getData()).date.substring(5);
        }
    }


}
