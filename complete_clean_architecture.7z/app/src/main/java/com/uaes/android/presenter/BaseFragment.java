package com.uaes.android.presenter;

import android.content.Context;

import dagger.android.support.DaggerFragment;

public abstract class BaseFragment extends DaggerFragment {

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

}
