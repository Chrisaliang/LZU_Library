package com.uaes.android;

import com.uaes.android.domain.JobThread;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

@Module
abstract class SchedulerModule {

    @Provides
    @Singleton
    static JobThread providerJobThread() {
        return new JobThread() {
            @Override
            public Scheduler providerUi() {
                return AndroidSchedulers.mainThread();
            }

            @Override
            public Scheduler provideWorker() {
                return Schedulers.io();
            }
        };
    }
}
