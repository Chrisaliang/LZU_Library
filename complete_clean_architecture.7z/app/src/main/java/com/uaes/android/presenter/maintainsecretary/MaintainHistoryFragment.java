package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentHistoryBinding;
import com.uaes.android.databinding.MaintainItemHistoryBinding;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainHistoryFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainHistoryFragment_";
    MaintainFragmentHistoryBinding binding;
    private MaintainHistoryViewModel maintainHistoryViewModel;
    private MaintainHistoryAdapter maintainHistoryAdapter;
    private List<MaintainHistoryItem> dataList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_history, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        maintainHistoryViewModel = ViewModelProviders.of(this).get(MaintainHistoryViewModel.class);
        binding.setMaintainclickListener(this);
        binding.setMaintainHistoryViewModel(maintainHistoryViewModel);
        initAdapter();
        initObserver();
    }

    private void initAdapter() {
        maintainHistoryAdapter = new MaintainHistoryAdapter();
        binding.rclMatainHistory.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rclMatainHistory.setAdapter(maintainHistoryAdapter);
    }

    private void initObserver() {
        maintainHistoryViewModel.getMaintainHistoryItem();

        maintainHistoryViewModel.getMaintainHistoryDataObserver().observe(this, new Observer<List<MaintainHistoryItem>>() {
            @Override
            public void onChanged(@Nullable List<MaintainHistoryItem> maintainHistoryItems) {
                maintainHistoryAdapter.updataALL(maintainHistoryItems);
            }
        });
    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 0:
                //close
                mNavigator.onBack();
                break;
            case 1:
                //打开二维码
                mNavigator.showQRCode();
                break;
        }
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }


    private class MaintainHistoryAdapter extends RecyclerView.Adapter<MaintainHistoryViewHolder> {

        MaintainHistoryAdapter() {
            dataList = new ArrayList<>();
        }

        @NonNull
        @Override
        public MaintainHistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemHistoryBinding itembinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.maintain_item_history, parent, false);
            return new MaintainHistoryViewHolder(itembinding);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainHistoryViewHolder holder, int position) {
            holder.bind(dataList.get(position));
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public void updataALL(List<MaintainHistoryItem> maintainHistoryItems) {
            dataList.clear();
            dataList.addAll(maintainHistoryItems);
            Timber.tag(TAG).w("dataList.size:" + dataList.size());
            notifyDataSetChanged();
        }

        public void selectAtPosition(int position) {
            Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:" + position);
            for (int i = 0; i < dataList.size(); i++) {
                if (i == position) {
                    dataList.get(position).maintainShowContent = !dataList.get(position).maintainShowContent;
                }
            }
            notifyDataSetChanged();
        }
    }

    private class MaintainHistoryViewHolder extends RecyclerView.ViewHolder implements MaintainItemOnClickListener {
        private MaintainItemHistoryBinding itembinding;

        MaintainHistoryViewHolder(MaintainItemHistoryBinding itembinding) {
            super(itembinding.getRoot());
            this.itembinding = itembinding;
        }

        public void bind(MaintainHistoryItem maintainHistoryItem) {
            itembinding.setMaintainHistoryItem(maintainHistoryItem);
            itembinding.setViewListener(this);
            itembinding.executePendingBindings();
        }


        @Override
        public void onClick(int type, int position) {
            Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:" + type);
            switch (type) {
                case 0:
                    maintainHistoryAdapter.selectAtPosition(position);
                    break;
                case 1:
                    //添加点评
                    goGradeFragment(null, position);
                    break;
                case 2:
                    //修改点评
                    goGradeFragment(dataList.get(position), position);
                    break;
            }
        }
    }

    private void goGradeFragment(MaintainHistoryItem maintainHistoryItem, int position) {
        MaintainGradeFragment maintainGradeFragment = new MaintainGradeFragment();
        Bundle bundle = new Bundle();
        if (maintainHistoryItem == null) {
            bundle.putBoolean(MaintainConstant.MAINTAINT_IS_ADD_COMMENT, true);
            bundle.putInt(MaintainConstant.MAINTAINT_HISTORY_POSITION, position);
            maintainGradeFragment.setArguments(bundle);
        } else {
            bundle.putBoolean(MaintainConstant.MAINTAINT_IS_ADD_COMMENT, false);
            bundle.putFloat(MaintainConstant.MAINTAINT_SERVICE_POINT, maintainHistoryItem.maintainServicePoint);
            bundle.putFloat(MaintainConstant.MAINTAINT_ATTITUDE_POINT, maintainHistoryItem.maintainAttitudePoint);
            bundle.putFloat(MaintainConstant.MAINTAINT_CHARGE_POINT, maintainHistoryItem.maintainChargePoint);
            bundle.putInt(MaintainConstant.MAINTAINT_HISTORY_POSITION, position);
            maintainGradeFragment.setArguments(bundle);
        }
        mNavigator.showGrade(bundle);
    }


}
