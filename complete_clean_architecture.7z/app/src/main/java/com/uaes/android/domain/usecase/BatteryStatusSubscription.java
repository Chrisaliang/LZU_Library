package com.uaes.android.domain.usecase;

import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.entity.DMBatteryStatus;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Function;
import timber.log.Timber;

/**
 * 订阅电池状态用例
 */
public class BatteryStatusSubscription {

    private static final String TAG = "BatteryStatusSubscripti";

    private static final long INTERVAL = 3000;

    private BatteryRepository repository;

    private JobThread jobThread;

    private DMBatteryStatus status = new DMBatteryStatus();

    public BatteryStatusSubscription(BatteryRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public Observable<DMBatteryStatus> execute() {
        return Observable.interval(0, 3, TimeUnit.SECONDS, jobThread.provideWorker())
                .map(new Function<Long, DMBatteryStatus>() {
                    @Override
                    public DMBatteryStatus apply(Long aLong) throws Exception {
                        status = repository.queryBatteryStatus();
                        return status;
                    }
                }).onErrorReturn(new Function<Throwable, DMBatteryStatus>() {
                    @Override
                    public DMBatteryStatus apply(Throwable throwable) {
                        Timber.tag(TAG).e(throwable);
                        return status;
                    }
                })
                .observeOn(jobThread.providerUi());
    }
}
