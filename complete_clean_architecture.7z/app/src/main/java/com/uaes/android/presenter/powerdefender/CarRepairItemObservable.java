package com.uaes.android.presenter.powerdefender;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class CarRepairItemObservable {

    public String location;
    @SuppressWarnings("WeakerAccess")
    public String shopLocation;
    @SuppressWarnings("WeakerAccess")
    public String shopPhone;
    public int pos;

    public CarRepairItemObservable(String location) {
        this.location = location;
    }

    public CarRepairItemObservable(String location, String shopLocation, String shopPhone, int pos) {
        this.location = location;
        this.shopLocation = shopLocation;
        this.shopPhone = shopPhone;
        this.pos = pos;
    }
}
