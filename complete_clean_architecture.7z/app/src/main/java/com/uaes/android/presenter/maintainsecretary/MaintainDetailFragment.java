package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentDetailBinding;
import com.uaes.android.databinding.MaintainItemAdviceDetailsBinding;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainDetailFragment extends MaintainBaseFragment {

    private MaintainFragmentDetailBinding binding;
    private static final String TAG = "MaintainDetailFragment_";
    private MaintainDetailViewModel maintainDetailViewModel;
    private MaintainDetailsAdapter maintainDetailsAdapter;
    private List<MaintainDetailItem> dataList;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_detail, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        maintainDetailViewModel = ViewModelProviders.of(this).get(MaintainDetailViewModel.class);
        binding.setMaintainclickListener(mNavigator);
        binding.setMsgType(maintainDetailViewModel);
        binding.setModelonclickListener(maintainDetailViewModel);
        maintainDetailViewModel.showDays.setValue(true);
        maintainDetailViewModel.showMiles.setValue(false);
        initAdapter();
        initObserver();
    }

    private void initAdapter() {
        maintainDetailsAdapter = new MaintainDetailsAdapter();
        binding.lvAdviceMaintainDetailList.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.lvAdviceMaintainDetailList.setHasFixedSize(true);
        binding.lvAdviceMaintainDetailList.setAdapter(maintainDetailsAdapter);
    }

    private void initObserver() {
        maintainDetailViewModel.getItemData();
        maintainDetailViewModel.getMessageItems().observe(this, new Observer<List<MaintainDetailItem>>() {
            @Override
            public void onChanged(@Nullable List<MaintainDetailItem> maintainDetailItems) {
                maintainDetailsAdapter.updateData(maintainDetailItems);
            }
        });
    }


    private class MaintainDetailsAdapter extends RecyclerView.Adapter<MaintainDetaisViewHolder> {

        MaintainDetailsAdapter() {
            dataList = new ArrayList<>();
        }

        @NonNull
        @Override
        public MaintainDetaisViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemAdviceDetailsBinding itembinding = DataBindingUtil
                    .inflate(LayoutInflater.from(parent.getContext()), R.layout.maintain_item_advice_details, parent, false);
            return new MaintainDetaisViewHolder(itembinding);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainDetaisViewHolder holder, int position) {
            holder.bind(dataList.get(position));
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public void selectItemAt(int position) {
            Timber.tag(TAG).w("MaintainDetailsAdapter:onClick:" + position);
            for (int i = 0; i < dataList.size(); i++) {
                if (i == position) {
                    dataList.get(position).isChoice = true;
                } else {
                    dataList.get(i).isChoice = false;
                }
            }
            notifyDataSetChanged();
        }

        public void updateData(List<MaintainDetailItem> maintainDetailItems) {
            dataList.clear();
            dataList.addAll(maintainDetailItems);
            notifyDataSetChanged();
        }
    }

    private class MaintainDetaisViewHolder extends RecyclerView.ViewHolder implements MaintainItemOnClickListener {
        private MaintainItemAdviceDetailsBinding itembinding;
        private MaintainDetailItem item;

        MaintainDetaisViewHolder(MaintainItemAdviceDetailsBinding itembinding) {
            super(itembinding.getRoot());
            this.itembinding = itembinding;
        }

        public void bind(MaintainDetailItem maintainDetailItem) {
            item = maintainDetailItem;
            itembinding.setItem(item);
            itembinding.setListener(this);
            itembinding.executePendingBindings();
        }

        @Override
        public void onClick(int type, int position) {
            if (!item.isChoice) {
                maintainDetailsAdapter.selectItemAt(position);
            }
            mNavigator.showMaintainConrtentDetail(position);
        }
    }

}
