package com.uaes.android.presenter.powerdefender.pojo;

/**
 * Created by diaokaibin@gmail.com on 2018/5/13.
 */
public class AirSystem {
    public String functionDes;
    public String functionContent;

    public AirSystem(String functionDes, String functionContent) {
        this.functionDes = functionDes;
        this.functionContent = functionContent;
    }
}
