package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentAppointmentBinding;
import com.uaes.android.databinding.MaintainItemAppointmentBinding;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */

public class MaintainAppointFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainAppointFragment_";
    private ArrayList<MaintainAppointItem> dataList;
    private MaintainFragmentAppointmentBinding binding;
    private MaintainAppointViewModel maintainAppointViewModel;
    private MaintainAppointAdapter appointAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_appointment, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        maintainAppointViewModel = ViewModelProviders.of(this).get(MaintainAppointViewModel.class);
        binding.setMaintainAppointViewModel(maintainAppointViewModel);
        binding.setMaintainOnClickListener(this);
        initAdatpter();
        initObserver();
    }


    private void initAdatpter() {
        appointAdapter = new MaintainAppointAdapter();
        binding.rclAppoint.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rclAppoint.setAdapter(appointAdapter);
    }

    private void initObserver() {
        maintainAppointViewModel.getDataList();
        maintainAppointViewModel.getDataObserver().observe(this, new Observer<List<MaintainAppointItem>>() {
            @Override
            public void onChanged(@Nullable List<MaintainAppointItem> maintainAppointItems) {
                appointAdapter.updateALL(maintainAppointItems);
            }
        });
    }

    @Override
    public void onClick(int type) {
        mNavigator.onBack();
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }

    private class MaintainAppointAdapter extends RecyclerView.Adapter<MaintainAppointViewHolder> {

        MaintainAppointAdapter() {
            dataList = new ArrayList<>();
        }

        @NonNull
        @Override
        public MaintainAppointViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemAppointmentBinding itembinding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.maintain_item_appointment, parent, false);
            return new MaintainAppointViewHolder(itembinding);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainAppointViewHolder holder, int position) {
            holder.bind(dataList.get(position));
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public void updateALL(List<MaintainAppointItem> maintainAppointItems) {
            dataList.clear();
            dataList.addAll(maintainAppointItems);
            Timber.tag(TAG).w("dataList.size:" + dataList.size());
            notifyDataSetChanged();
        }
    }

    private class MaintainAppointViewHolder extends RecyclerView.ViewHolder implements MaintainItemOnClickListener {

        private MaintainItemAppointmentBinding itembinding;

        MaintainAppointViewHolder(MaintainItemAppointmentBinding itembinding) {
            super(itembinding.getRoot());
            this.itembinding = itembinding;
        }

        public void bind(MaintainAppointItem maintainAppointItem) {
            itembinding.setMaintainAppointclickListener(this);
            itembinding.setMaintainAppointItem(maintainAppointItem);
            itembinding.executePendingBindings();
        }


        @Override
        public void onClick(int type, int position) {
            Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:" + type);
            switch (type) {
                case 0:
                    Toast.makeText(getContext(), "电话 position:" + position, Toast.LENGTH_SHORT).show();
//                    onCall(dataList.get(position).maintainPhone.get());
                    break;
                case 1:
                    Toast.makeText(getContext(), "导航 position:" + position, Toast.LENGTH_SHORT).show();
                    mNavigator.showDriveSceheme();
                    break;
            }
        }
    }


    public void onCall(String number) {
        Intent intent = new Intent();
        intent.setAction("com.iflytek.action.CALL");
        intent.putExtra("tel", number);
        startActivity(intent);
    }
}
