package com.uaes.android.data.mapper;

import android.support.annotation.NonNull;

import com.google.common.base.Function;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.data.json.FuelScale;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.entity.DMAccumulativeFuelConsumption;
import com.uaes.android.domain.entity.DMFuelConsumptionOfDay;
import com.uaes.android.domain.entity.DMFuelScale;

public class FuelMonitorMapper implements Function<GeneralAttributeReceive<FuelMonitorJson>, ARFuelMonitor> {

    @Override
    public ARFuelMonitor apply(@NonNull GeneralAttributeReceive<FuelMonitorJson> input) {
        ARFuelMonitor arFuelMonitor = new ARFuelMonitor();
        arFuelMonitor.rank = input.msgContent.economicRank;
        arFuelMonitor.accumulativeFuelConsumptions
                = new DMAccumulativeFuelConsumption[input.msgContent.km.dataKey.length];
        arFuelMonitor.fuelConsumptionOfDay = new DMFuelConsumptionOfDay[input.msgContent.km.dataKey.length];
        for (int i = 0; i < input.msgContent.km.dataKey.length; i++) {
            arFuelMonitor.accumulativeFuelConsumptions[i] =
                    new DMAccumulativeFuelConsumption(
                            Integer.valueOf(input.msgContent.km.dataKey[i]),
                            Float.valueOf(input.msgContent.km.dataValue[i])
                    );
        }
        for (int i = 0; i < input.msgContent.week.dataKey.length; i++) {
            arFuelMonitor.fuelConsumptionOfDay[i] = new DMFuelConsumptionOfDay(
                    input.msgContent.week.dataKey[i], Integer.valueOf(input.msgContent.week.dataValue[i]),
                    new DMFuelScale(
                            Integer.valueOf(input.msgContent.week.fuelScales[i].getValueByKey(FuelScale.KEY_IDLE_USE)),
                            Integer.valueOf(input.msgContent.week.fuelScales[i].getValueByKey(FuelScale.KEY_AC_USE)),
                            Integer.valueOf(input.msgContent.week.fuelScales[i].getValueByKey(FuelScale.KEY_DRIVER_USE)),
                            Integer.valueOf(input.msgContent.week.fuelScales[i].getValueByKey(FuelScale.KEY_OTHER_USE))
                    )
            );
        }
        return arFuelMonitor;
    }
}
