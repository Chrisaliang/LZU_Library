package com.uaes.android.data.http;

import android.content.SharedPreferences;
import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.uaes.android.ServiceEnvironment;
import com.uaes.android.common.CarInfoProvider;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by hand on 2017/11/7.
 */

public class HapAuthorizationInterceptor implements Interceptor {

    private static final String KEY_TOKEN = "com.uaes.android.data.http.HapAuthorizationInterceptor.TOKEN";

    private static final String REFRESH_TOKEN = "com.uaes.android.data.http.REFRESH_TOKEN";

    private static final String TOKEN_URL = ServiceEnvironment.BASE_URL + "/car/v1/carAuth/viewAuth?accessKey=";

    private static final String DUMMY_TOKEN = "f22e2de2-f697-46a3-bf9d-0b5bd92e6b57";

    private final SharedPreferences sp;

    private String mToken;

    private OkHttpClient okHttpClient;

    private Gson gson = new Gson();

    private CarInfoProvider authProvider;

    public HapAuthorizationInterceptor(SharedPreferences sharedPreferences, CarInfoProvider authProvider) {
        sp = sharedPreferences;
        this.authProvider = authProvider;
        okHttpClient = new OkHttpClient.Builder().build();
    }

    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        if (mToken == null)
            mToken = sp.getString(KEY_TOKEN, DUMMY_TOKEN);
        Request newRequest;
//        if (TextUtils.isEmpty(mToken)) {
//            Request request = new Request.Builder().url(TOKEN_URL + authProvider.getSHA384()).get().build();
//            Call call = okHttpClient.newCall(request);
//            Response refreshResponse = call.execute();
//            if (refreshResponse != null && refreshResponse.isSuccessful()) {
//                TokenResponse tokenResponse = gson.fromJson(
//                        Objects.requireNonNull(refreshResponse.body()).string(), TokenResponse.class);
//                inValid();
//                sp.edit().putString(REFRESH_TOKEN, tokenResponse.refresh_token)
//                        .putString(REFRESH_TOKEN, tokenResponse.access_token).apply();
//                mToken = tokenResponse.access_token;
//            }
//        }
        Request.Builder builder = chain.request().newBuilder()
                .addHeader("Authorization", "Bearer " + mToken);
        newRequest = builder.build();
        return chain.proceed(newRequest);
    }

    public void inValid() {
        sp.edit().remove(KEY_TOKEN)
                .apply();
        mToken = null;
    }
}
