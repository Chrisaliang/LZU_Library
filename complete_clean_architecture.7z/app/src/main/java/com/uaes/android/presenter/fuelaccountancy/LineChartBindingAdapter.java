package com.uaes.android.presenter.fuelaccountancy;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.uaes.android.domain.entity.DMAccumulativeFuelConsumption;

import java.util.List;


/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/9.
 */
@BindingMethods({@BindingMethod(type = LineChart.class, attribute = "lineData", method = "setLineData")})
public abstract class LineChartBindingAdapter {

    @BindingAdapter(value = "lineData")
    public static void setLineChart(LineChart lineChart, List<Entry> entries) {
        if (entries == null) {
            return;
        }
        LineData lineData = lineChart.getLineData();
        if (lineData == null) {
            lineData = new LineData();
            lineData.setDrawValues(false);
            lineChart.setData(lineData);
        }

        LineDataSet dataSet = (LineDataSet) lineData.getDataSetByIndex(0);
        if (dataSet == null) {
            dataSet = new LineDataSet(entries, "LineChart");
            dataSet.setColor(Color.parseColor("#00a8ff"));
            dataSet.setDrawCircles(false);
            dataSet.setDrawCircleHole(false);
            dataSet.setHighlightEnabled(true);
            dataSet.setDrawHighlightIndicators(false);
            dataSet.setHighLightColor(Color.WHITE);
            dataSet.setDrawFilled(true);
        } else {
            dataSet.setValues(entries);
        }
        lineData.addDataSet(dataSet);
        dataSet.setDrawValues(false);

        lineChart.getXAxis().setValueFormatter(new ConsumeFormatter(entries));

        lineChart.notifyDataSetChanged();
        lineChart.invalidate();

    }

    private static class ConsumeFormatter implements IAxisValueFormatter {

        private List<Entry> entries;

        ConsumeFormatter(List<Entry> entries) {
            this.entries = entries;
        }

        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            if (value == 0) return "0";
            return ((DMAccumulativeFuelConsumption) entries.get((int) value).getData()).accumulativeConsumption + "km";
        }
    }

}
