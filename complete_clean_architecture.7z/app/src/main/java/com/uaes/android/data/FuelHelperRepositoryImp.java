package com.uaes.android.data;

import com.google.gson.Gson;
import com.uaes.android.App;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.data.json.FuelScale;
import com.uaes.android.data.json.FuelStationJson;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.json.GeneralAttributeSent;
import com.uaes.android.data.json.JsonRequestBody;
import com.uaes.android.data.mapper.DataFuelScaleMapper;
import com.uaes.android.data.mapper.FuelMonitorMapper;
import com.uaes.android.data.mapper.JsonGasStationMapper;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.entity.DMFuelFillHistory;
import com.uaes.android.domain.entity.DMFuelScale;
import com.uaes.android.domain.entity.DMFuelSetting;
import com.uaes.android.domain.entity.DMGas;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Response;

public class FuelHelperRepositoryImp implements FuelHelperRepository {
    private static final String TAG = "FuelHelperRepositoryImp";

    private static final String[] QUERY_KEYS = new String[]{
            "realTime", "week", "mon", "hundred", "thousand", "all"
    };

    private HttpFuelHelper api;

    private SettingApi settingApi;

    private DataFuelScaleMapper fuelScaleMapper = new DataFuelScaleMapper();

    private FuelMonitorMapper monitorMapper = new FuelMonitorMapper();

    private Gson gson;

    private App app;

    public FuelHelperRepositoryImp(HttpFuelHelper api, SettingApi settingApi, App app, Gson gson) {
        this.api = api;
        this.settingApi = settingApi;
        this.app = app;
        this.gson = gson;
    }

    @Override
    public DMFuelScale queryFuelScale(int type) throws Exception {
        Response<GeneralAttributeReceive<FuelScale>> response
                = api.getFuelScale(QUERY_KEYS[type]).execute();
        if (response.isSuccessful()) {
            return fuelScaleMapper.apply(Objects.requireNonNull(response.body()).msgContent);
        } else {
            return null;
        }
    }

    @Override
    public boolean updateFuelSetting(DMFuelSetting dmFuelSetting) throws Exception {
        Call<GeneralAttributeReceive<GeneralAttributeSent>> call = settingApi.lowFuelWarningSent(JsonRequestBody.createFuelSettingUpdate(gson, dmFuelSetting.gasQuery, dmFuelSetting.fuelThreshold));
        Response<GeneralAttributeReceive<GeneralAttributeSent>> execute = call.execute();
        GeneralAttributeSent msgContent = Objects.requireNonNull(execute.body()).msgContent;
        for (GeneralAttributeSent.GeneralAttribute item : msgContent.attributeList) {
            if (item.attributeType.equals("gasQuery") &&
                    dmFuelSetting.gasQuery != Integer.valueOf(item.attributeValue)) {
                return false;
            } else if (item.attributeType.equals("CSthreshold") &&
                    dmFuelSetting.fuelThreshold != Integer.valueOf(item.attributeValue)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public DMFuelSetting queryFuelSetting() throws Exception {
        Call<GeneralAttributeReceive<GeneralAttributeSent>> generalAttributeReceiveCall = settingApi.lowFuelWarningReceive(JsonRequestBody.createFuelSettingQuery(gson));
        Response<GeneralAttributeReceive<GeneralAttributeSent>> execute = generalAttributeReceiveCall.execute();
        DMFuelSetting setting = new DMFuelSetting();
        for (GeneralAttributeSent.GeneralAttribute item : Objects.requireNonNull(execute.body()).msgContent.attributeList) {
            if (item.attributeType.equals("CSthreshold")) {
                setting.fuelThreshold = Integer.valueOf(item.attributeValue);
            } else if (item.attributeType.equals("gasQuery")) {
                setting.gasQuery = Integer.valueOf(item.attributeValue);
            }
        }
        return setting;
    }

    @Override
    public List<DMGas> queryGasList(double longitude, double latitude, int strategy) throws Exception {
        Call<GeneralAttributeReceive<List<FuelStationJson>>> station = api.getStation(longitude + "," + latitude, strategy);
        Response<GeneralAttributeReceive<List<FuelStationJson>>> execute = station.execute();
        List<FuelStationJson> json = Objects.requireNonNull(execute.body()).msgContent;
        List<DMGas> dmGases = new ArrayList<>();
        for (FuelStationJson item : json) {
            dmGases.add(JsonGasStationMapper.map(item));
        }
        return dmGases;
    }

    @Override
    public ARFuelMonitor queryFuelMonitor() throws Exception {
        Call<GeneralAttributeReceive<FuelMonitorJson>> call = api.getMonitor();
        Response<GeneralAttributeReceive<FuelMonitorJson>> response = call.execute();
        return monitorMapper.apply(Objects.requireNonNull(response.body()));
    }

    @Override
    public List<DMFuelFillHistory> queryFuelFillHistory(int year) throws Exception {
        return null;
    }

    @Override
    public DMFuelFillHistory setFuelAccount(DMFuelFillHistory fuelBookkeeping) throws Exception {
        // TODO
        return null;
    }
}
