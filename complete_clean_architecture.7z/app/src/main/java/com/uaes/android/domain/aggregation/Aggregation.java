package com.uaes.android.domain.aggregation;

abstract class Aggregation {
}
