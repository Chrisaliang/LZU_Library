package com.uaes.android.domain.entity;

import com.uaes.android.domain.MaintainRepository;

/**
 * 保养秘书配置
 */
public class DMMaintainSetting {
    /**
     * 是否接收推送
     */
    public boolean isAllowedPush;

    /**
     * 距离保养多久开始接受推送
     */
    @MaintainRepository.PushType
    public int pushType;

    /**
     * 推送频率
     */
    @MaintainRepository.PushFrequency
    public int pushFrequency;
}
