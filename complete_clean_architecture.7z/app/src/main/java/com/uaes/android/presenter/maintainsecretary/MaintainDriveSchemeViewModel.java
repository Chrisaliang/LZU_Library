package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainDriveSchemeViewModel extends ViewModel {
    private final MutableLiveData<List<MaintainDriveSchemeItem>> dataObserver = new MutableLiveData<>();

    public void getDriverSchemeData() {
        List<MaintainDriveSchemeItem> dataList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            MaintainDriveSchemeItem maintainDriveSchemeItem = new MaintainDriveSchemeItem();
            maintainDriveSchemeItem.position = i;
            maintainDriveSchemeItem.isChoice = false;
            maintainDriveSchemeItem.minutes = "78";
            maintainDriveSchemeItem.miles = "89";
            maintainDriveSchemeItem.lightNumbers = "9";
            maintainDriveSchemeItem.detailPassWay = "G150上海绕城高速>S20外环高速>沪嘉高速";
            dataList.add(maintainDriveSchemeItem);
        }
        dataObserver.setValue(dataList);
    }

    public MutableLiveData<List<MaintainDriveSchemeItem>> getDataObserver() {
        return dataObserver;
    }
}
