package com.uaes.android.presenter.powerdefender.fragment;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderBinding;
import com.uaes.android.presenter.BaseFragment;
import com.uaes.android.presenter.powerdefender.PowerDefenderOnClickListener;
import com.uaes.android.presenter.powerdefender.viewmodel.CarStatusViewModel;

/**
 * Created by diaokaibin@gmail.com on 2018/5/7.
 */
public class PowerDefenderFragment extends BaseFragment implements PowerDefenderOnClickListener {

    private static final String FRAGMENT_TYPE_NEAR_BY = "1";
    private static final String FRAGMENT_TYPE_FAULT_HISTORY = "2";
    private static final String FRAGMENT_TYPE_AIR_SYS = "3";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        FragmentPowerDefenderBinding dataBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender, container, false);
        CarStatusViewModel carStatusViewModel = ViewModelProviders.of(this).get(CarStatusViewModel.class);
        dataBinding.setCarStatusViewModel(carStatusViewModel);
        dataBinding.setPowerClickListener(this);
        return dataBinding.getRoot();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 1:
                changFragment(new PowerDefenderNearByFragment(), FRAGMENT_TYPE_NEAR_BY);
                break;

            case 2:
                changFragment(new PowerDefenderFaultHistoryFragment(), FRAGMENT_TYPE_FAULT_HISTORY);
                break;

            case 3:
                changFragment(new PowerDefenderAirSysFragment(), FRAGMENT_TYPE_AIR_SYS);
                break;
        }
    }

    private void changFragment(Fragment f, String tag) {
        if (getFragmentManager() != null)
            getFragmentManager().beginTransaction()
                    .add(R.id.fl_power_defender_container, f, tag)
                    .addToBackStack(null)
                    .commit();
    }


    @Override
    public void onStart() {
        super.onStart();
    }

}
