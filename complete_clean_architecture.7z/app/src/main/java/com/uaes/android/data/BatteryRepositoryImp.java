package com.uaes.android.data;


import com.uaes.android.App;
import com.uaes.android.data.http.HttpBatteryApi;
import com.uaes.android.data.json.BatteryStatusJson;
import com.uaes.android.data.json.BatteryVolJson;
import com.uaes.android.data.json.GeneralAttributeReceive;
import com.uaes.android.data.mapper.BatteryStatusJsonMapper;
import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.entity.DMBatteryStatus;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Response;

public class BatteryRepositoryImp implements BatteryRepository {

    private HttpBatteryApi api;

    private App app;

    public BatteryRepositoryImp(App app, HttpBatteryApi api) {
        this.api = api;
        this.app = app;
    }

    @Override
    public DMBatteryStatus queryBatteryStatus() throws Exception {
        Call<GeneralAttributeReceive<BatteryStatusJson>> callStatus = api.queryBatterStatus();
        Response<GeneralAttributeReceive<BatteryStatusJson>> response = callStatus.execute();
        Call<GeneralAttributeReceive<BatteryVolJson>> callVol = api.queryBatteryVol();
        Response<GeneralAttributeReceive<BatteryVolJson>> response1 = callVol.execute();
        return BatteryStatusJsonMapper.map(
                Objects.requireNonNull(response.body()).msgContent,
                Objects.requireNonNull(response1.body()).msgContent,
                app);
    }
}
