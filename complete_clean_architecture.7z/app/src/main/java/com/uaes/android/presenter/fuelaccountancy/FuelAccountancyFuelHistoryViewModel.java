package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.github.mikephil.charting.data.BarEntry;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMFuelFillHistory;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import timber.log.Timber;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/11.
 */
public class FuelAccountancyFuelHistoryViewModel extends ViewModel implements FuelAccountancyOnSelectListener, FuelAcountancyHistoryOnYearSlideListener {

    private static final String TAG = "FuelAccountancyFuelHist";

    public final MutableLiveData<List<BarEntry>> fuelHistoryBarEntry = new MutableLiveData<>();
    public final MutableLiveData<DMFuelFillHistory> dmFuelFillHistory = new MutableLiveData<>();
    @SuppressWarnings("WeakerAccess")
    public final MutableLiveData<Integer> selectStatus = new MutableLiveData<>();
    public final ArrayList<Integer> years = new ArrayList<>();
    public final MutableLiveData<Integer> rightYearIndex = new MutableLiveData<>();

    private Disposable fuelHistoryDisposable;
    private FuelHistoryFillListQuery fuelHistoryFillListQuery;

    public FuelAccountancyFuelHistoryViewModel(FuelHistoryFillListQuery fuelHistoryFillListQuery) {
        this.fuelHistoryFillListQuery = fuelHistoryFillListQuery;
        selectStatus.setValue(2);
        years.add(2014);
        years.add(2015);
        years.add(2016);
        years.add(2017);
        years.add(2018);
        rightYearIndex.setValue(years.size() - 1);
    }

    public void init() {
        fuelHistoryFillListQuery.execute().map(new Function<Result<List<DMFuelFillHistory>>, List<BarEntry>>() {
            @Override
            public List<BarEntry> apply(Result<List<DMFuelFillHistory>> listResult) {
                List<BarEntry> entries = new ArrayList<>();
                for (int i = 0; i < listResult.content.size(); i++) {
                    entries.add(new BarEntry(i, listResult.content.get(i).volume, listResult.content.get(i)));
                }
                return entries;
            }
        }).subscribe(new SingleObserver<List<BarEntry>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (fuelHistoryDisposable != null) {
                    fuelHistoryDisposable.dispose();
                }
                fuelHistoryDisposable = d;
            }

            @Override
            public void onSuccess(List<BarEntry> barEntries) {
                Timber.tag(TAG).d(barEntries.toString());
                fuelHistoryBarEntry.setValue(barEntries);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }
        });

    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (fuelHistoryDisposable != null) {
            fuelHistoryDisposable.dispose();
        }
    }

    public void updateUI(DMFuelFillHistory dmFuelFillHistory) {
        this.dmFuelFillHistory.setValue(dmFuelFillHistory);
    }

    @Override
    public void onSelected(int type) {
        if (selectStatus.getValue() == null || selectStatus.getValue() == type)
            return;
        selectStatus.setValue(type);

        //delectedYear 表示当前选中的年份 2 表示当前选择item的最大的type
        int selectdYear = years.get(rightYearIndex.getValue() - 2 + selectStatus.getValue());
        Timber.tag(TAG).d(String.valueOf(selectdYear));
    }

    @Override
    public void onDirectionClick(DirectionType type) {
        switch (type) {
            case LEFT:
                rightYearIndex.setValue(rightYearIndex.getValue() - 1);
                selectStatus.setValue(selectStatus.getValue() + 1);
                break;
            case RIGHT:
                rightYearIndex.setValue(rightYearIndex.getValue() + 1);
                selectStatus.setValue(selectStatus.getValue() - 1);
                break;
            default:
                break;
        }
    }
}
