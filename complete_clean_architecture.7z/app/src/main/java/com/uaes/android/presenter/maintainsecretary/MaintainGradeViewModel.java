package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.Bundle;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/9
 * des：
 */
public class MaintainGradeViewModel extends ViewModel implements MaintainGradeOnClickListener {
    private static final String TAG = "MaintainGrageViewModel_";
    public final MutableLiveData<Float> maintainServicePoint = new MutableLiveData<>();
    public final MutableLiveData<Float> maintainAttitudePoint = new MutableLiveData<>();
    public final MutableLiveData<Float> maintainChargePoint = new MutableLiveData<>();
    private float servicePoint;
    private float attitudePoint;
    private float chargePoint;


    @Override
    public void onClick(int type) {

    }

    @Override
    public void onRateChanged(int type, float rating) {
        Timber.tag(TAG).w("onRateChanged:type:" + type + ",rating:" + rating);
        switch (type) {
            case 0:
                //服务评分
                servicePoint = rating;
                break;
            case 1:
                //态度评分
                attitudePoint = rating;
                break;
            case 2:
                //价格评分
                chargePoint = rating;
                break;
        }
    }

  /*  private void onSave() {
        Bundle bundle = new Bundle();
        bundle.putBoolean(MaintainConstant.MAINTAINT_IS_ADD_COMMENT, false);
        bundle.putFloat(MaintainConstant.MAINTAINT_SERVICE_POINT, servicePoint);
        bundle.putFloat(MaintainConstant.MAINTAINT_ATTITUDE_POINT, attitudePoint);
        bundle.putFloat(MaintainConstant.MAINTAINT_CHARGE_POINT, chargePoint);
        bundle.putInt(MaintainConstant.MAINTAINT_HISTORY_POSITION, position);
        changeContentObserver.setValue(bundle);
    }*/


    public void initData(Bundle arguments) {
        int position = arguments.getInt(MaintainConstant.MAINTAINT_HISTORY_POSITION);
        servicePoint = arguments.getFloat(MaintainConstant.MAINTAINT_SERVICE_POINT, 0f);
        attitudePoint = arguments.getFloat(MaintainConstant.MAINTAINT_ATTITUDE_POINT, 0f);
        chargePoint = arguments.getFloat(MaintainConstant.MAINTAINT_CHARGE_POINT, 0f);
        maintainServicePoint.setValue(servicePoint);
        maintainAttitudePoint.setValue(attitudePoint);
        maintainChargePoint.setValue(chargePoint);

    }
}
