package com.uaes.android.presenter.map;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.amap.api.maps.AMap;
import com.amap.api.maps.MapView;
import com.uaes.android.R;
import com.uaes.android.presenter.BaseFragment;

import java.util.Objects;

/**
 * 导航路径地图显示
 */
public class MapFragment extends BaseFragment {

    private static final String EXTRA_LATITUDE = "com.uaes.android.presenter.map.LATITUDE";
    private static final String EXTRA_LONGITUDE = "com.uaes.android.presenter.map.LONGITUDE";

    /**
     * 获取地图实例
     */
    public static MapFragment newInstance(double targetLatitude, double targetLongitude) {
        Bundle args = new Bundle();
        args.putDouble(EXTRA_LATITUDE, targetLatitude);
        args.putDouble(EXTRA_LONGITUDE, targetLongitude);
        MapFragment fragment = new MapFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private double targetLatitude;

    private double targetLongitude;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = savedInstanceState;
        if (bundle == null)
            bundle = getArguments();
        Objects.requireNonNull(bundle, "must call newInstance of MapFragment to create MapFragment");
        targetLatitude = bundle.getDouble(EXTRA_LATITUDE);
        targetLongitude = bundle.getDouble(EXTRA_LONGITUDE);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putDouble(EXTRA_LATITUDE, targetLatitude);
        outState.putDouble(EXTRA_LONGITUDE, targetLongitude);
    }


    // --------- 试图定义层 --------------- //

    private MapView mapView;

    private AMap aMap;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.map_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mapView = view.findViewById(R.id.map_view);
        mapView.onCreate(savedInstanceState);
        aMap = mapView.getMap();
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
