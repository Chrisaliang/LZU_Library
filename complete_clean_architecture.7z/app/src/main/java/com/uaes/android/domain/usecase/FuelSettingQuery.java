package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMFuelSetting;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class FuelSettingQuery extends SingleUseCase<DMFuelSetting> {

    private JobThread jobThread;

    private FuelHelperRepository repository;

    public FuelSettingQuery(JobThread jobThread, FuelHelperRepository repository) {
        this.jobThread = jobThread;
        this.repository = repository;
    }

    @Override
    protected Single<DMFuelSetting> buildSingle() {
        return Single.just(repository).map(new Function<FuelHelperRepository, DMFuelSetting>() {
            @Override
            public DMFuelSetting apply(FuelHelperRepository repository) throws Exception {
                return repository.queryFuelSetting();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
