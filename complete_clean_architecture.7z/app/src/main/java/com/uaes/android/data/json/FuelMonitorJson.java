package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

public class FuelMonitorJson {

    @SerializedName("economicRank")
    public int economicRank;

    @SerializedName("week")
    public Week week;

    @SerializedName("km")
    public Km km;

    public static class Week {
        @SerializedName("dataKey")
        public String[] dataKey;

        @SerializedName("dataValue")
        public String[] dataValue;

        @SerializedName("details")
        public FuelScale[] fuelScales;
    }

    public static class Km {
        @SerializedName("dataKey")
        public String[] dataKey;

        @SerializedName("dataValue")
        public String[] dataValue;
    }
}
