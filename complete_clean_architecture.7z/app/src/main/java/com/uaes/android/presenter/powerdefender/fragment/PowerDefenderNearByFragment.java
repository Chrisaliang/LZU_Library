package com.uaes.android.presenter.powerdefender.fragment;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderNearbyBinding;
import com.uaes.android.databinding.ItemPowerCarRepairBinding;
import com.uaes.android.presenter.BaseFragment;
import com.uaes.android.presenter.powerdefender.CarRepairItemObservable;
import com.uaes.android.presenter.powerdefender.PowerDefenderNearByOnClickListener;
import com.uaes.android.presenter.powerdefender.PowerDefenderOnClickListener;
import com.uaes.android.presenter.powerdefender.viewmodel.AutoRepairViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderNearByFragment extends BaseFragment implements PowerDefenderOnClickListener {

    private FragmentPowerDefenderNearbyBinding mNearbyBinding;
    private CarRepairAdapter mAdapter;
    private FragmentManager mFragmentManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mNearbyBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_nearby, container, false);
        return mNearbyBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        AutoRepairViewModel repairViewModel = ViewModelProviders.of(this).get(AutoRepairViewModel.class);
        mNearbyBinding.setAutoRepair(repairViewModel);
        mNearbyBinding.setPowerClickListener(this);
        mFragmentManager = getFragmentManager();

        mNearbyBinding.setVariable(BR.autoRepair, repairViewModel);
        mNearbyBinding.rvCarRepair.setLayoutManager(new LinearLayoutManager(getContext()));
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(Objects.requireNonNull(getActivity()), DividerItemDecoration.VERTICAL);
        dividerItemDecoration.setDrawable(Objects.requireNonNull(ContextCompat.getDrawable(Objects.requireNonNull(getContext()), R.drawable.divider_bg)));
        mNearbyBinding.rvCarRepair.addItemDecoration(dividerItemDecoration);

        mAdapter = new CarRepairAdapter();
        mNearbyBinding.rvCarRepair.setAdapter(mAdapter);

        repairViewModel.doAction();
        repairViewModel.getCarItems().observe(this, new Observer<List<CarRepairItemObservable>>() {
            @Override
            public void onChanged(@Nullable List<CarRepairItemObservable> observables) {
                mAdapter.upDate(observables);
            }
        });


    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onClick(int type) {
        mFragmentManager.popBackStack();
    }


    class CarRepairAdapter extends RecyclerView.Adapter<CarRepairViewHolder> {

        private List<CarRepairItemObservable> data;

        private CarRepairAdapter() {
            this.data = new ArrayList<>();
        }

        @NonNull
        @Override
        public CarRepairViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_power_car_repair, parent, false);
            return new CarRepairViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull CarRepairViewHolder holder, int position) {
            holder.bind(data.get(position));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        private void upDate(List<CarRepairItemObservable> itemObservables) {
            data.clear();
            data.addAll(itemObservables);
            notifyDataSetChanged();
        }
    }


    private class CarRepairViewHolder extends RecyclerView.ViewHolder implements PowerDefenderNearByOnClickListener {

        ItemPowerCarRepairBinding itemBinding;

        private CarRepairViewHolder(View itemView) {
            super(itemView);
            itemBinding = DataBindingUtil.bind(itemView);
            if (itemBinding != null) {
                itemBinding.setLifecycleOwner(PowerDefenderNearByFragment.this);
            }

        }

        private void bind(CarRepairItemObservable item) {
            itemBinding.setItemShopClick(this);
            itemBinding.setVariable(BR.carLocation, item);
            itemBinding.executePendingBindings();

        }

        @Override
        public void onClickPos(int type, int pos) {
//            Timber.tag("dd").d("type -" + type + "  pos " + pos);
            switch (type) {
                case 1:  // 电话

                    getChildFragmentManager().beginTransaction().add(R.id.fl_power_defender_near_car_container, new PowerDefenderPhoneFragment())
                            .addToBackStack(null)
                            .commit();
                    break;


                case 2:  // 导航


                    // TODO : 调到高德导航界面
                    break;
            }
        }
    }
}
