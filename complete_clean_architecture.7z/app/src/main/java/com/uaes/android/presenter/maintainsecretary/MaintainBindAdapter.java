package com.uaes.android.presenter.maintainsecretary;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.widget.TextView;

@BindingMethods({
        @BindingMethod(type = TextView.class, attribute = "selectedWhen", method = "changeWhenState"),
        @BindingMethod(type = TextView.class, attribute = "selectedRate", method = "changeRateState")
})
public class MaintainBindAdapter {

    @BindingAdapter(value = "selectedWhen")
    public static void changeWhenState(TextView view, boolean selected) {
        view.setSelected(selected);
    }

    @BindingAdapter(value = "selectedRate")
    public static void changeRateState(TextView view, boolean selected) {
        view.setSelected(selected);
    }
}
