package com.uaes.android.presenter.powerdefender.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.presenter.powerdefender.pojo.CarFaultHistory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class FaultHistoryViewModel extends ViewModel {


    public final MutableLiveData<List<CarFaultHistory>> faultItems = new MutableLiveData<>();

    public void doAction() {
        List<CarFaultHistory> value = new ArrayList<>();
        value.add(new CarFaultHistory("点火系统故障预警", "20170203", "待解决", "20120603"));
        value.add(new CarFaultHistory("客气系统增压功能故障", "20180501", "已解决", "20180601"));
        faultItems.setValue(value);
    }
}
