package com.uaes.android.presenter.powerdefender.viewholder;

import android.databinding.ViewDataBinding;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public class HistoryFaultHeader extends HistoryFaultBase {

    public HistoryFaultHeader(ViewDataBinding binding) {
        super(binding);
    }
}
