package com.uaes.android.domain;

import com.uaes.android.domain.entity.DMBatteryStatus;

/**
 * 电池助手
 * */
public interface BatteryRepository {
    /**
     * 查询电池状态
     */
    DMBatteryStatus queryBatteryStatus() throws Exception;
}
