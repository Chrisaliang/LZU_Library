package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.services.core.AMapException;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.route.BusRouteResult;
import com.amap.api.services.route.DrivePath;
import com.amap.api.services.route.DriveRouteResult;
import com.amap.api.services.route.DriveStep;
import com.amap.api.services.route.RideRouteResult;
import com.amap.api.services.route.RouteSearch;
import com.amap.api.services.route.WalkRouteResult;
import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyFragmentFuelstationBinding;
import com.uaes.android.domain.entity.DMLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import timber.log.Timber;

public class FuelStationFragment extends FuelAccountancyBaseFragment implements
        TabLayout.OnTabSelectedListener, FuelAccountAncyStationOnClickListener, RouteSearch.OnRouteSearchListener {
    private static final String TAG = "FuelStationFragment";

    @Inject
    ViewModelProvider.Factory factory;

    FuelAccountancyFragmentFuelstationBinding binding;
    FuelAccountancyStationViewModel stationViewModel;
    private FuelAccountancyStationAdapter stationAdapter;
    private List<FuelAccountancyStationItemViewModel> fuelAccountancyStationItemViewModels;
    private FuelAccountancyPlanAdapter planAdapter;

    private MapView mapView;
    private AMap aMap;
    private ArrayList<MarkerOptions> markerOptions = new ArrayList<>();
    private RouteSearch routeSearch;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_fragment_fuelstation, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setLifecycleOwner(this);
        stationViewModel = ViewModelProviders.of(this, factory).get(FuelAccountancyStationViewModel.class);
        binding.setStationViewModel(stationViewModel);
        binding.fuelAccountancyStationTab.addOnTabSelectedListener(this);
        binding.setOnClickListener(this);
        routeSearch = new RouteSearch(getContext());
        routeSearch.setRouteSearchListener(this);

        mapView = binding.stationMapView;
        mapView.onCreate(savedInstanceState);
        aMap = mapView.getMap();
        initMap();


        //station
        initStationAdapter();
        initStationObserver();

        //plan
        initPlanAdapter();

    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    private void initStationAdapter() {
        stationAdapter = new FuelAccountancyStationAdapter();
        binding.recycleViewStation.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.recycleViewStation.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getActivity()),
                DividerItemDecoration.VERTICAL));
        binding.recycleViewStation.setAdapter(stationAdapter);
    }

    private void initStationObserver() {
        stationViewModel.initStationList();
        stationViewModel.getStationListObservable().observe(this, new Observer<List<FuelAccountancyStationItemViewModel>>() {
            @Override
            public void onChanged(@Nullable List<FuelAccountancyStationItemViewModel> stationItemViewModels) {
                stationAdapter.updateStationAll(stationItemViewModels);

                //移动视图
                dmLocation = stationViewModel.locationLiveData.getValue();
                if (dmLocation != null) {
                    LatLng latLng = new LatLng(dmLocation.latitude, dmLocation.longitude);
                    Timber.tag(TAG).d("move view to location：" + dmLocation.latitude, dmLocation.longitude);
                    aMap.animateCamera(CameraUpdateFactory.newLatLngBoundsRect(
                            LatLngBounds.builder().include(latLng).build(), 150, 0, 0, 0));
                }

                //绘制maker
                setStationMakers(stationViewModel.stationViewModels);

                //编号
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(0);
                for (int i = 1; i <= fuelAccountancyStationItemViewModels.size(); i++) {
                    fuelAccountancyStationItemViewModels.get(i - 1).stationNum.set(i);
                }
                stationAdapter.updateStationAll(fuelAccountancyStationItemViewModels);
                stationViewModel.stationViewModels.get(0).isChecked.set(true);
            }
        });
    }

    private void initPlanAdapter() {
        planAdapter = new FuelAccountancyPlanAdapter();
        binding.recycleViewPlan.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.recycleViewPlan.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getActivity()),
                DividerItemDecoration.VERTICAL));
        binding.recycleViewPlan.setAdapter(planAdapter);
    }


    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        switch (tab.getPosition()) {
            case 0:
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(0);
                break;
            case 1:
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(1);
                break;
            case 2:
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(2);
                break;
            default:
                break;
        }
        for (int i = 1; i <= fuelAccountancyStationItemViewModels.size(); i++) {
            fuelAccountancyStationItemViewModels.get(i - 1).stationNum.set(i);
        }
        stationAdapter.updateStationAll(fuelAccountancyStationItemViewModels);
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    @Override
    public void onBusRouteSearched(BusRouteResult busRouteResult, int i) {

    }

    @Override
    public void onDriveRouteSearched(DriveRouteResult driveRouteResult, int i) {
        initPlanObserver(driveRouteResult);
    }

    @Override
    public void onWalkRouteSearched(WalkRouteResult walkRouteResult, int i) {

    }

    @Override
    public void onRideRouteSearched(RideRouteResult rideRouteResult, int i) {

    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 0://去加油->行车方案界面
                stationViewModel.isStation.setValue(false);
                initDrivePlan();
                break;
            case 1://返回加油站列表
                stationViewModel.isStation.setValue(true);
                break;
            case 2://开始导航
                startNavigation();
                break;
        }
    }

    private DMLocation dmLocation;

    //初始化行车方案的adapter
    private void initDrivePlan() {
        FuelAccountancyStationItemViewModel stationItemViewModel = getSelectItemStation();
        if (stationItemViewModel != null) {
            LatLonPoint from = new LatLonPoint(dmLocation.latitude, dmLocation.longitude);

            //121.634065,31.272911
            //LatLonPoint to = new LatLonPoint(stationItemViewModel.stationLat.get(),stationItemViewModel.stationLng.get());
            LatLonPoint to = new LatLonPoint(31.272911, 121.634065);
            RouteSearch.FromAndTo fromAndTo = new RouteSearch.FromAndTo(from, to);
            RouteSearch.DriveRouteQuery driveRouteQuery = new RouteSearch.DriveRouteQuery(fromAndTo, RouteSearch.DRIVING_MULTI_STRATEGY_FASTEST_SAVE_MONEY_SHORTEST,
                    null, null, "");
            try {
                DriveRouteResult result = routeSearch.calculateDriveRoute(driveRouteQuery);
                Timber.tag(TAG).d(result.toString());
            } catch (AMapException e) {
                Timber.tag(TAG).e("e.getErrorMessage():" + e.getErrorMessage()
                        + "          e.getErrorType()" + e.getErrorType()
                        + "          e.getErrorCode()" + e.getErrorCode()
                        + "          e.getErrorLevel()" + e.getErrorLevel());
            }
        } else {
            Toast.makeText(getContext(), "please select a station for plan", Toast.LENGTH_SHORT).show();
        }
    }

    //开始导航
    private void startNavigation() {
        Toast.makeText(getContext(), "start navigation ...", Toast.LENGTH_SHORT).show();
        FuelAccountancyPlanItemViewModel planItemViewModel = getSelectItemPlan();
//        planItemViewModel.stationLat.get()
    }


    private void initPlanObserver(DriveRouteResult driveRouteResult) {
        if (driveRouteResult != null && driveRouteResult.getPaths().size() > 0) {

            stationViewModel.planItemViewModels.clear();
            List<DrivePath> paths = driveRouteResult.getPaths();
            DrivePath drivePath;
            for (int i = 0; i < paths.size(); i++) {
                FuelAccountancyPlanItemViewModel planItemViewModel = new FuelAccountancyPlanItemViewModel();

                planItemViewModel.planNum = i + 1;
                drivePath = paths.get(i);
                long distance = (long) drivePath.getDistance();
                long duration = drivePath.getDuration();
                planItemViewModel.planTimeAndDistance = "约" + stationViewModel.getTimeString(duration) + "|"
                        + stationViewModel.getTotalLenString(distance) + "|" + drivePath.getTotalTrafficlights() + "个红绿灯";

                StringBuilder road = new StringBuilder("");
                for (int j = 0; j < drivePath.getSteps().size(); j++) {
                    DriveStep step = drivePath.getSteps().get(i);
                    road.append(step.getRoad());
                    if (j != drivePath.getSteps().size() - 1) road.append(">");
                }
                planItemViewModel.planDes = road.toString();
                planItemViewModel.strategy = drivePath.getStrategy();

                stationViewModel.planItemViewModels.add(planItemViewModel);

            }

            planAdapter.updatePlanAll(stationViewModel.planItemViewModels);


            stationViewModel.planItemViewModels.get(0).isChecked = true;
        }

    }

    //获取选中加油站
    public FuelAccountancyStationItemViewModel getSelectItemStation() {
        FuelAccountancyStationItemViewModel itemViewModel = null;
        for (FuelAccountancyStationItemViewModel fuelAccountancyStationItemViewModel : fuelAccountancyStationItemViewModels) {
            if (fuelAccountancyStationItemViewModel.isChecked.get()) {
                itemViewModel = fuelAccountancyStationItemViewModel;
            }
        }
        return itemViewModel;
    }

    //获取选中的导航路线
    public FuelAccountancyPlanItemViewModel getSelectItemPlan() {
        FuelAccountancyPlanItemViewModel itemViewModel = null;
        for (FuelAccountancyPlanItemViewModel planItemViewModel : stationViewModel.planItemViewModels) {
            if (planItemViewModel.isChecked) {
                itemViewModel = planItemViewModel;
            }
        }
        return itemViewModel;
    }


    private void initMap() {
        aMap = mapView.getMap();
        aMap.setMyLocationEnabled(false);
//        MyLocationStyle style = new MyLocationStyle();
//        style.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE);
//        style.showMyLocation(true);
//        style.interval(10000);
//        aMap.setMyLocationStyle(style);
//        aMap.moveCamera(CameraUpdateFactory.zoomTo(11));
        UiSettings uiSettings = aMap.getUiSettings();
        uiSettings.setZoomControlsEnabled(false);
        uiSettings.setMyLocationButtonEnabled(false);
        uiSettings.setAllGesturesEnabled(true);
        uiSettings.setLogoBottomMargin(-50);
        aMap.setMapCustomEnable(true);
    }


    private void setStationMakers(List<FuelAccountancyStationItemViewModel> stationItemViewModels) {
        markerOptions.clear();
        for (FuelAccountancyStationItemViewModel viewModel : stationItemViewModels) {
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(new LatLng(viewModel.stationLat.get(), viewModel.stationLng.get()));
            markerOption.draggable(false);//拖动
            markerOption.setFlat(true);
            markerOptions.add(markerOption);
        }
        aMap.addMarkers(markerOptions, true);
    }

}
