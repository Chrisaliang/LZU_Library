package com.uaes.android.domain.entity;

import com.uaes.android.domain.MaintainRepository;

import java.util.List;

/**
 * 当前车况保养状态
 * TODO
 */
public class DMMaintainStatus {
    /**
     * 剩余保养数值表示的值类型
     */
    @SuppressWarnings("WeakerAccess")
    @MaintainRepository.MaintainType
    public int maintainType;

    /**
     * 剩余保养的值， 代表了天数 或者里程 KM
     * 通过 {@link #maintainType} 判断
     */
    public int maintainValue;
    /**
     * 推荐保养清单
     */
    public List<String> maintainList;

}
