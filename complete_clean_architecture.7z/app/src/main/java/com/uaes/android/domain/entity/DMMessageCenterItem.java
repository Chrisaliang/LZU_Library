package com.uaes.android.domain.entity;

public class DMMessageCenterItem {
}
