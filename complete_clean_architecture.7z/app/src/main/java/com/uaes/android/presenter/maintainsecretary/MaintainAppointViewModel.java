package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainAppointViewModel extends ViewModel {

    private final MutableLiveData<List<MaintainAppointItem>> dataObserver = new MutableLiveData<>();


    public void getDataList() {
        List<MaintainAppointItem> dataList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            MaintainAppointItem maintainAppointItem = new MaintainAppointItem();
            maintainAppointItem.maintainAddress = "上海市浦东新区北汽4s店";
            maintainAppointItem.positon = i;
            maintainAppointItem.maintainPhone = "021-37658910";
            dataList.add(maintainAppointItem);
        }
        dataObserver.setValue(dataList);
    }

    public MutableLiveData<List<MaintainAppointItem>> getDataObserver() {
        return dataObserver;
    }
}
