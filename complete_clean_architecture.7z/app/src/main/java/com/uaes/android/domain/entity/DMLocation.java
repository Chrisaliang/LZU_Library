package com.uaes.android.domain.entity;

public class DMLocation {
    /**
     * 是否有效定位数据
     */
    public boolean isSucceed = false;
    /**
     * 维度
     */
    public double latitude;
    /**
     * 经度
     */
    public double longitude;
    /**
     * 地址
     */
    public String address;
    /**
     * 国家
     */
    public String country;
    /**
     * 省份
     */
    public String province;
    /**
     * 城市
     */
    public String city;
    /**
     * 城市代码
     */
    public String cityCode;
}
