package com.uaes.android.presenter.maintainsecretary;

import com.uaes.android.presenter.BaseFragment;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainBaseFragment extends BaseFragment {

    MaintainNavigator mNavigator;

}
