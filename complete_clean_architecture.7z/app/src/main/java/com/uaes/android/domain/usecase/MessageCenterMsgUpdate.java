package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.presenter.message.MessageCenterMsgItem;

import io.reactivex.Observable;

public class MessageCenterMsgUpdate {


    private MessageCenterRepository repository;

    private JobThread jobThread;

    public MessageCenterMsgUpdate(MessageCenterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public Observable<MessageCenterMsgItem> execute() {

        return repository.updateMessage()
                .observeOn(jobThread.providerUi())
                .subscribeOn(jobThread.provideWorker());
    }


}
