package com.uaes.android.data;

import android.content.Context;
import android.content.Intent;

import com.alibaba.sdk.android.push.MessageReceiver;
import com.alibaba.sdk.android.push.notification.CPushMessage;

import java.util.Map;

import dagger.android.AndroidInjection;
import timber.log.Timber;

public class AliPushMessageReceiver extends MessageReceiver {

    private static final String REC_TAG = "AliPushMessageReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        AndroidInjection.inject(this, context);
        super.onReceive(context, intent);
    }

    @Override
    public void onNotification(Context context, String title, String summary, Map<String, String> extraMap) {
        // TODO 处理推送通知
        Timber.tag(REC_TAG).e(
                "Receive notification, title: %s, summary: %s, extraMap: %s." ,
                title ,
                summary,
                extraMap.toString());
    }
    @Override
    public void onMessage(Context context, CPushMessage cPushMessage) {
        Timber.tag(REC_TAG).e(
                "onMessage, messageId: %s, title: %s, content: %s.",
                cPushMessage.getMessageId(),
                cPushMessage.getTitle(),
                cPushMessage.getContent());
    }
    @Override
    public void onNotificationOpened(Context context, String title, String summary, String extraMap) {
        Timber.tag(REC_TAG).e("onNotificationOpened, title: %s, summary: %s, extraMap: %s."
                , title ,summary , extraMap);
    }
    @Override
    protected void onNotificationClickedWithNoAction(Context context, String title, String summary, String extraMap) {
        Timber.tag(REC_TAG).e("onNotificationClickedWithNoAction, title: %s, summary: %s, extraMap: %s." ,
                title ,summary ,extraMap);
    }
    @Override
    protected void onNotificationReceivedInApp(Context context, String title, String summary, Map<String, String> extraMap, int openType, String openActivity, String openUrl) {
        Timber.tag(REC_TAG).e(
                "onNotificationReceivedInApp, title: %s, summary: %s, extraMap: %s, openType: %d, openActivity: %s, openUrl: %s",
                title ,summary ,extraMap , openType , openActivity , openUrl);
    }
    @Override
    protected void onNotificationRemoved(Context context, String messageId) {
        Timber.tag(REC_TAG).e( "onNotificationRemoved messageId: %s", messageId);
    }
}
