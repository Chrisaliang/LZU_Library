package com.uaes.android.presenter.powerdefender;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public interface PowerConstant {
    String PHONE = "power_phone";
    String ADDRESS = "power_shop_address";
}
