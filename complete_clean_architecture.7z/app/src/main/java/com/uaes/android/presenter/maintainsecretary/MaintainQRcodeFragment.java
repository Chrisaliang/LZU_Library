package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;

import com.uaes.android.databinding.MaintainFragmentQrcodeBinding;

/**
 * Created by ${GY} on 2018/5/9
 * des：
 */
public class MaintainQRcodeFragment extends MaintainBaseFragment implements MaintainOnClickListener {

    MaintainFragmentQrcodeBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_qrcode, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setLifecycleOwner(this);
        MaintainQRcodeViewModel maintainQRcodeViewModel = ViewModelProviders.of(this).get(MaintainQRcodeViewModel.class);
        binding.setMaintainQRcodeViewModel(maintainQRcodeViewModel);
        binding.setMaintainOnClickListener(this);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
     /*   WindowManager.LayoutParams attributes
                = Objects.requireNonNull(getDialog().getWindow()).getAttributes();
        getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        attributes.dimAmount = 0f;

        attributes.width = getResources().getDimensionPixelSize(R.dimen.maintain_secteray_tips_dialog_width);
        attributes.height = getResources().getDimensionPixelSize(R.dimen.maintain_secteray_tips_dialog_height);
        attributes.x = getResources().getDimensionPixelSize(R.dimen.maintain_secteray_tips_dialog_offset_X);

        getDialog().getWindow().setAttributes(attributes);*/
    }

    @Override
    public void onClick(int type) {
        mNavigator.onBack();
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {

    }
}
