package com.uaes.android.presenter.fuelaccountancy;

import android.annotation.SuppressLint;
import android.arch.lifecycle.ViewModelProvider;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyFragmentFuelConsumeDetailBinding;

import java.util.Objects;

import javax.inject.Inject;

import dagger.android.support.DaggerAppCompatDialogFragment;


/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/10.
 */
public class FuelAccountancyFuelConsumeDetailFragment extends DaggerAppCompatDialogFragment {

    FuelAccountancyFragmentFuelConsumeDetailBinding binding;

    @Inject
    ViewModelProvider.Factory factory;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_fragment_fuel_consume_detail, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle args = getArguments();
        binding.fuelAccountancyConsumeDetailAc.setText(String.valueOf(args.getInt(FuelConsumeFragment.AC_USE)) + "%");
        binding.fuelAccountancyConsumeDetailDriver.setText(String.valueOf(args.getInt(FuelConsumeFragment.DRIVER_USE)) + "%");
        binding.fuelAccountancyConsumeDetailIdle.setText(String.valueOf(args.getInt(FuelConsumeFragment.IDLE_USE)) + "%");
        binding.fuelAccountancyConsumeDetailOther.setText(String.valueOf(args.getInt(FuelConsumeFragment.OTHER_USE)) + "%");

        WindowManager.LayoutParams attributes = Objects.requireNonNull(getDialog().getWindow()).getAttributes();
        attributes.x = 320;
        attributes.y = 180;
        getDialog().getWindow().setDimAmount(0.0f);
        getDialog().getWindow().setAttributes(attributes);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


    }

    @Override
    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        if (listener != null)
            listener.onDismiss();
    }

    private DetailDialogDismissListener listener;


    public DetailDialogDismissListener getListener() {
        return listener;
    }

    public void setListener(DetailDialogDismissListener listener) {
        this.listener = listener;
    }

    public interface DetailDialogDismissListener {
        void onDismiss();
    }
}
