package com.uaes.android.presenter.fuelaccountancy;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.uaes.android.presenter.chartrenderer.CustomPieChartRenderer;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import timber.log.Timber;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
@BindingMethods({
        @BindingMethod(type = PieChart.class, attribute = "pieData", method = "setPieChartData")})
public abstract class PieChartBindingAdapter {

    private static final String TAG = "PieChartBindingAdapter";

    private static final ArrayList<Integer> COLORS = new ArrayList<>();

    static {
        COLORS.add(Color.parseColor("#F66A00"));
        COLORS.add(Color.parseColor("#FDA51E"));
        COLORS.add(Color.parseColor("#74FFFF"));
        COLORS.add(Color.parseColor("#0098EB"));
    }

    @BindingAdapter(value = "pieData")
    public static void setPieChartData(PieChart pieChart, ArrayList<PieEntry> entries) {
        if (entries == null || entries.size() == 0) return;

        pieChart.setRenderer(new CustomPieChartRenderer(pieChart, pieChart.getAnimator(), pieChart.getViewPortHandler()));

        Collections.sort(entries, new Comparator<PieEntry>() {
            @Override
            public int compare(PieEntry o1, PieEntry o2) {
                return Float.compare(o1.getValue(), o2.getValue());
            }
        });
        Timber.tag(TAG).d(entries.toString());
        PieData pieData = pieChart.getData();
        if (pieData == null) {
            pieData = new PieData();
            pieData.setValueTextColor(Color.WHITE);
            pieData.setValueFormatter(new PercentFormatter());
            pieData.setValueTextSize(11f);
        }

        PieDataSet dataSet = new PieDataSet(entries, "PieChart");
        dataSet.setValueFormatter(new PercentFormatter(new DecimalFormat("###,###,##0")) {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                if (value > 0)
                    return super.getFormattedValue(value, axis);
                else
                    return "";
            }

            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                if (value > 0)
                    return super.getFormattedValue(value, entry, dataSetIndex, viewPortHandler);
                else
                    return "";
            }
        });
        dataSet.setSliceSpace(0f);
        dataSet.setSelectionShift(16f);
        dataSet.setValueLineColor(Color.WHITE);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueLinePart1Length(0.7f);
        dataSet.setValueLinePart2Length(0.6f);
        dataSet.setValueLinePart1OffsetPercentage(90);
        dataSet.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        dataSet.setColors(COLORS);
        dataSet.setValueTextSize(20);
        pieChart.setEntryLabelTextSize(20);

        pieData.setDataSet(dataSet);
        pieChart.setData(pieData);
        pieChart.notifyDataSetChanged();
        pieChart.invalidate();
    }
}
