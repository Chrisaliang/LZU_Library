package com.uaes.android;

import android.content.Context;
import android.support.multidex.MultiDex;

import com.alibaba.sdk.android.push.CloudPushService;
import com.alibaba.sdk.android.push.CommonCallback;
import com.alibaba.sdk.android.push.noonesdk.PushServiceFactory;
import com.uaes.android.common.CarInfoProvider;

import javax.inject.Inject;

import dagger.android.AndroidInjector;
import dagger.android.support.DaggerApplication;
import timber.log.Timber;

public class App extends DaggerApplication implements CommonCallback {

    private static final String TAG = "App";

    @Inject
    CarInfoProvider authProvider;

    @Inject
    public void logInject() {
        Timber.tag(TAG).d("injector has invoke.");
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
//        Logger.addLogAdapter(new DiskLogAdapter());
//        Logger.addLogAdapter(new AndroidLogAdapter());
        Timber.plant(new Timber.DebugTree());

        PushServiceFactory.init(this);
        CloudPushService pushService = PushServiceFactory.getCloudPushService();
        pushService.setLogLevel(CloudPushService.LOG_OFF);
        pushService.register(this, this);
        // TODO
        pushService.bindAccount("TODO", this);
    }

    @Override
    protected AndroidInjector<? extends DaggerApplication> applicationInjector() {
        return DaggerAppComponent.builder().create(this);
    }

    @Override
    public void onSuccess(String response) {
        Timber.tag(TAG).d("Init aliPush success, response: %s", response);
    }

    @Override
    public void onFailed(String errorCode, String errorMessage) {
        Timber.tag(TAG).d("Init aliPush failed, errorCode: %s, errorMessage: %s", errorCode, errorMessage);
    }
}
