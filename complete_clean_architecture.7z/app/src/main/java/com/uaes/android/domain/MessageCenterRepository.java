package com.uaes.android.domain;


import android.support.annotation.IntDef;

import com.uaes.android.presenter.message.MessageCenterMsgItem;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

import io.reactivex.Observable;

/**
 * 消息中心
 */
public interface MessageCenterRepository {

    /**
     * 全部消息
     */
    int MESSAGE_CENTER_QUERY_ALL = 0;

    /**
     * 故障消息
     */
    int MESSAGE_CENTER_QUERY_MALFUNCTION = 1;

    /**
     * 预警消息
     */
    int MESSAGE_CENTER_QUERY_WARNING = 2;

    /**
     * 通知消息
     */
    int MESSAGE_CENTER_QUERY_NOTIFICATION = 3;

    /**
     * 根据传入查询类型获取消息列表
     *
     * @param type 查询类型
     * @return 消息列表
     */
    List<MessageCenterMsgItem> queryMessage(@MsgType int type);

    /**
     * 更新消息
     *
     * @return 新添加的消息
     */
    Observable<MessageCenterMsgItem> updateMessage();

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            MESSAGE_CENTER_QUERY_ALL, MESSAGE_CENTER_QUERY_MALFUNCTION,
            MESSAGE_CENTER_QUERY_WARNING, MESSAGE_CENTER_QUERY_NOTIFICATION
    })
    @interface MsgType {
    }


}
