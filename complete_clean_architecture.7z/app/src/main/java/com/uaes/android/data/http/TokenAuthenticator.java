package com.uaes.android.data.http;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.uaes.android.ServiceEnvironment;
import com.uaes.android.common.CarInfoProvider;
import com.uaes.android.common.Intents;

import java.io.IOException;
import java.util.Objects;

import javax.annotation.Nullable;

import okhttp3.Authenticator;
import okhttp3.Call;
import okhttp3.Credentials;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import timber.log.Timber;


/**
 * Created by aber on 2/13/2018.
 * refresh token
 */

public class TokenAuthenticator implements Authenticator {

    private static final String TAG = "TokenAuthenticator";

    private static final String REFRESH_TOKEN = "com.uaes.android.data.http.REFRESH_TOKEN";

    private static final String URL = ServiceEnvironment.BASE_URL + "/oauth/oauth/token";

    private static final String TOKEN_URL = ServiceEnvironment.BASE_URL + "/car/v1/carAuth/viewAuth?accessKey=";

    private SharedPreferences sharedPreferences;

    private LocalBroadcastManager manager;

    private Gson gson;

    private OkHttpClient okHttpClient;

    private HapAuthorizationInterceptor interceptor;

    private CarInfoProvider authProvider;

    public TokenAuthenticator(CarInfoProvider authProvider, Gson gson, SharedPreferences sharedPreferences, LocalBroadcastManager manager, HapAuthorizationInterceptor authorizationInterceptor) {
        this.manager = manager;
        this.sharedPreferences = sharedPreferences;
        this.interceptor = authorizationInterceptor;
        this.gson = gson;
        this.okHttpClient = new OkHttpClient.Builder().build();
        this.authProvider = authProvider;
    }

    @Nullable
    @Override
    public Request authenticate(@NonNull Route route, @NonNull Response response) throws IOException {
        if (response.request().header("Authorization") != null) {
            return null; // Give up, we've already failed to authenticate.
        }
        String reToken = sharedPreferences.getString(REFRESH_TOKEN, null);
        Response refreshResponse;
        if (TextUtils.isEmpty(reToken)) {
            Intent intent = new Intent(Intents.ACTION_AUTHORIZATION);
            manager.sendBroadcast(intent);
            Request request = new Request.Builder().url(TOKEN_URL + authProvider.getSHA384()).build();
            Call call = okHttpClient.newCall(request);
            refreshResponse = call.execute();
        } else {
            String credential = Credentials.basic("client", "secret");
            Request request = new Request.Builder().url(URL).post(new FormBody.Builder().add("grant_type", "refresh_token")
                    .add("refresh_token", reToken).build()).header("Authorization", credential).build();
            Call call = okHttpClient.newCall(request);
            try {
                Timber.tag(TAG).d("auth: " + request.toString());
                refreshResponse = call.execute();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        if (refreshResponse != null && refreshResponse.isSuccessful()) {
            TokenResponse tokenResponse = gson.fromJson(
                    Objects.requireNonNull(refreshResponse.body()).string(), TokenResponse.class);
            interceptor.inValid();
            sharedPreferences.edit().putString(REFRESH_TOKEN, tokenResponse.refresh_token)
                    .putString(REFRESH_TOKEN, tokenResponse.access_token).apply();
            return response.request().newBuilder()
                    .header("Authorization", "Bearer " + tokenResponse.access_token).build();
        } else {
            Intent intent = new Intent(Intents.ACTION_AUTHORIZATION);
            manager.sendBroadcast(intent);
            return null;
        }
    }
}
