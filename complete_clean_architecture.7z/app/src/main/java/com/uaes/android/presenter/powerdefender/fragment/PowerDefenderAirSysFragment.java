package com.uaes.android.presenter.powerdefender.fragment;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderAirSysBinding;
import com.uaes.android.presenter.BaseFragment;
import com.uaes.android.presenter.powerdefender.pojo.AirSystem;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderAirSysFragment extends BaseFragment {

    private FragmentPowerDefenderAirSysBinding mSysBinding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mSysBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_air_sys, container, false);
        return mSysBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        FragmentManager fragmentManager = getFragmentManager();
        mSysBinding.setAirSys(new AirSystem("增压功能失效", "车辆表现为加速不畅，不影响其他功能"));
        mSysBinding.setPresenter(new Presenter());
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    public class Presenter {
        public void close() {
            if (getFragmentManager() != null) {
                getFragmentManager().popBackStack();
            }

        }
    }


}
