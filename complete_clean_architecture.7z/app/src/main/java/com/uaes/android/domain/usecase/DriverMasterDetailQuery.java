package com.uaes.android.domain.usecase;

import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMDriverMasterItem;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class DriverMasterDetailQuery extends SingleUseCase<List<DMDriverMasterItem>> {

    private static final int DEFAULT_QUERY_TYPE = 0;

    private DriverMasterRepository repository;
    private JobThread jobThread;

    private int queryType = DEFAULT_QUERY_TYPE;

    public DriverMasterDetailQuery(DriverMasterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public void setQueryType(int queryType) {
        this.queryType = queryType;
    }


    @Override
    protected Single<List<DMDriverMasterItem>> buildSingle() {
        return Single.just(repository)
                .map(new Function<DriverMasterRepository, List<DMDriverMasterItem>>() {
                    @Override
                    public List<DMDriverMasterItem> apply(DriverMasterRepository driverMasterRepository) {
                        return repository.queryDetailList(queryType);
                    }
                })
                .subscribeOn(jobThread.provideWorker())
                .observeOn(jobThread.providerUi());
    }
}
