package com.uaes.android.presenter.driver;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMDriverMasterPage;
import com.uaes.android.domain.usecase.DriverMasterQuery;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class DriverMasterViewModel extends ViewModel implements SingleObserver<Result<DMDriverMasterPage>> {

    private static final String TAG = "DriverMasterViewModel";

    private DriverMasterQuery driverMasterQuery;

    public final MutableLiveData<Integer> selected = new MutableLiveData<>();

    public final MutableLiveData<String> titleSum = new MutableLiveData<>();

    public final MutableLiveData<String> titleDsc = new MutableLiveData<>();

    // 急加速
    public final MutableLiveData<Integer> acuteAcc = new MutableLiveData<>();

    // 急刹车
    public final MutableLiveData<Integer> acuteBreak = new MutableLiveData<>();

    // 急转弯
    public final MutableLiveData<Integer> acuteTurn = new MutableLiveData<>();

    // 连续加减速
    public final MutableLiveData<Integer> continueAccAndDec = new MutableLiveData<>();

    // 凌晨驾驶
    public final MutableLiveData<Integer> nightDrive = new MutableLiveData<>();

    private Disposable disposable;

    private DriverMasterPageMapper mapper;

    public DriverMasterViewModel(DriverMasterQuery driverMasterQuery) {
        this.driverMasterQuery = driverMasterQuery;
        mapper = new DriverMasterPageMapper();
    }

    public void driverMasterSummery() {
        driverMasterSummery(0);
    }

    public void driverMasterSummery(int type) {

        if (selected.getValue() != null && selected.getValue() == type) return;

        selected.setValue(type);

        driverMasterQuery.setQueryType(type);

        driverMasterQuery.execute().subscribe(this);

    }

    @Override
    public void onSubscribe(Disposable d) {
        checkDisposable();
        disposable = d;
    }

    @Override
    public void onSuccess(Result<DMDriverMasterPage> result) {
        DriverMasterPage masterPage = mapper.apply(result.content);
        titleSum.setValue(masterPage.titleSum);
        titleDsc.setValue(masterPage.titleDsc);
        acuteAcc.setValue(masterPage.acuteAcc);
        acuteBreak.setValue(masterPage.acuteBreak);
        acuteTurn.setValue(masterPage.acuteTurn);
        continueAccAndDec.setValue(masterPage.continueAccAndDec);
        nightDrive.setValue(masterPage.nightDrive);
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).e(e);
    }


    private void checkDisposable() {
        if (disposable != null && !disposable.isDisposed())
            disposable.dispose();
    }

}
