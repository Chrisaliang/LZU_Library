package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.entity.DMFuelScale;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Function;
import timber.log.Timber;

/**
 * 时实查询用油明细
 */
public class FuelScaleRealTimeQuery {

    private static final String TAG = "FuelScaleRealTimeQuery";

    private static final long DEFAULT_DELAY = 3;

    private FuelHelperRepository repository;

    private JobThread jobThread;

    @SuppressWarnings("FieldCanBeLocal")
    private long delay = DEFAULT_DELAY;

    private DMFuelScale lastItem = new DMFuelScale(100, 0, 0, 0);

    public FuelScaleRealTimeQuery(FuelHelperRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public Observable<DMFuelScale> execute() {
        return Observable.interval(0, delay, TimeUnit.SECONDS, jobThread.provideWorker()).map(new Function<Long, DMFuelScale>() {
            @Override
            public DMFuelScale apply(Long aLong) throws Exception {
                final DMFuelScale local = repository.queryFuelScale(FuelHelperRepository.TYPE_FUEL_REAL_TIME);
                if ((local.otherUse + local.idleUse + local.driverUse + local.acUse) != 0)
                    lastItem = local;
                return local;
            }
        }).onErrorReturn(new Function<Throwable, DMFuelScale>() {
            @Override
            public DMFuelScale apply(Throwable throwable) {
                Timber.tag(TAG).e(throwable);
                return lastItem;
            }
        })
                .observeOn(jobThread.providerUi());
    }
}
