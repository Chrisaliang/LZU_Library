package com.uaes.android.common;

/**
 * 全局Keys, Actions
 * */
public interface Intents {
    String ACTION_AUTHORIZATION = "com.uaes.android.common.ACTION_AUTHORIZATION";
}
