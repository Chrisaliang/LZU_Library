package com.uaes.android.data.mapper;

import com.google.gson.JsonObject;
import com.uaes.android.domain.entity.DMFuelFillHistory;

public class FuelMapper {

    public static DMFuelFillHistory map(JsonObject fuelBookkeeping) {
        //TODO
        return null;
    }
}
