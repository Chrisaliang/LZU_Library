package com.uaes.android.presenter.powerdefender.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.presenter.powerdefender.CarRepairItemObservable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class AutoRepairViewModel extends ViewModel {

    private MutableLiveData<Integer> changeObservable = new MutableLiveData<>();
    private MutableLiveData<List<CarRepairItemObservable>> carItems = new MutableLiveData<>();

    public AutoRepairViewModel() {
    }

    public MutableLiveData<List<CarRepairItemObservable>> getCarItems() {
        return carItems;
    }


    public MutableLiveData<Integer> getChangeObservable() {
        return changeObservable;
    }

    public void doAction() {
        List<CarRepairItemObservable> value = new ArrayList<>();
        value.add(new CarRepairItemObservable("上海市浦东新区北汽4S店", "浦东", "浦东phone", 0));
        value.add(new CarRepairItemObservable("上海市闵行区北汽4S店", "闵行", "闵行phone", 1));
        value.add(new CarRepairItemObservable("上海市黄浦区北汽4S店", "黄浦", "黄浦phone", 2));
        carItems.setValue(value);
    }
}
