package com.uaes.android;

import com.uaes.android.presenter.MainActivity;
import com.uaes.android.presenter.batteryhelper.BatteryHelperFragment;
import com.uaes.android.presenter.batteryhelper.BatteryTipsFragment;
import com.uaes.android.presenter.driver.DriverMasterDetailFragment;
import com.uaes.android.presenter.driver.DriverMasterFragment;
import com.uaes.android.presenter.driver.MapFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyFuelConsumeDetailFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyMainFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancySettingMainFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancySettingSuccessFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyStationSettingFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelConsumeFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelDetailFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelHistoryFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelStationFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainAppointFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainContentDetailFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainDetailFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainDriveSchemeFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainGradeFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainGuideMangerFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainHistoryFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainPhoneAppointFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainQRcodeFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainSettingsFragment;
import com.uaes.android.presenter.message.MessageCenterFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerDefenderAirSysFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerDefenderFaultHistoryFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerDefenderFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerDefenderNearByFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerDefenderPhoneFragment;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
abstract class AndroidComponentModule {

    @ContributesAndroidInjector
    public abstract MainActivity mainActivity();

    //**************** 消息中心 *************//
    @ContributesAndroidInjector
    public abstract MessageCenterFragment messageCenterFragment();

    // ************************  驾驶达人 **********************//
    @ContributesAndroidInjector
    public abstract DriverMasterFragment driveManagerFragment();

    @ContributesAndroidInjector
    public abstract DriverMasterDetailFragment driverManagerDetailFragment();

    @ContributesAndroidInjector
    public abstract MapFragment mapFragment();

    // *************** 电池助手 ********************* //
    @ContributesAndroidInjector
    public abstract BatteryHelperFragment batteryHelperFragment();

    @ContributesAndroidInjector
    public abstract BatteryTipsFragment batteryTipsFragment();

    //******************** Module of PowerDefender *********************//
    @ContributesAndroidInjector
    public abstract PowerDefenderFragment mPowerDefenderFragment();

    @ContributesAndroidInjector
    public abstract PowerDefenderNearByFragment mPowerDefenderNearByFragment();

    @ContributesAndroidInjector
    public abstract PowerDefenderAirSysFragment mPowerDefenderAirSysFragment();

    @ContributesAndroidInjector
    public abstract PowerDefenderFaultHistoryFragment mPowerDefenderFaultHistoryFragment();

    @ContributesAndroidInjector
    public abstract PowerDefenderPhoneFragment mDefenderPhoneFragment();


    //******************** Module of FuelAccountancy *********************//

    @ContributesAndroidInjector
    public abstract FuelAccountancyMainFragment fuelAccountancyMainFragment();

    @ContributesAndroidInjector
    public abstract FuelDetailFragment fuelDetailFragment();

    @ContributesAndroidInjector
    public abstract FuelHistoryFragment fuelHistoryFragment();

    @ContributesAndroidInjector
    public abstract FuelStationFragment fuelStationFragment();

    @ContributesAndroidInjector
    public abstract FuelConsumeFragment fuelConsumeFragment();

    @ContributesAndroidInjector
    public abstract FuelAccountancyStationSettingFragment fuelAccountancyStationSetFragment();

    @ContributesAndroidInjector
    public abstract FuelAccountancySettingSuccessFragment fuelAccountancySetSuccessFragment();

    @ContributesAndroidInjector
    public abstract FuelAccountancySettingMainFragment fuelAccountancySetMainFragment();

    @ContributesAndroidInjector
    public abstract FuelAccountancyFuelConsumeDetailFragment fuelAccountancyFuelConsumeDetailFragment();


    //******************** Module of FuelAccountancy *********************//


    //*******************Module of MaintainSecretary**********************//
    @ContributesAndroidInjector
    public abstract MaintainAppointFragment maintainAppointFragment();

    @ContributesAndroidInjector
    public abstract MaintainContentDetailFragment maintainContentDetailFragment();

    @ContributesAndroidInjector
    public abstract MaintainDetailFragment maintainDetailFragment();

    @ContributesAndroidInjector
    public abstract MaintainDriveSchemeFragment maintainDriveSchemeFragment();

    @ContributesAndroidInjector
    public abstract MaintainGradeFragment maintainGradeFragment();

    @ContributesAndroidInjector
    public abstract MaintainGuideMangerFragment maintainGuideMangerFragment();

    @ContributesAndroidInjector
    public abstract MaintainHistoryFragment maintainHistoryFragment();

    @ContributesAndroidInjector
    public abstract MaintainPhoneAppointFragment maintainPhoneAppointFragment();

    @ContributesAndroidInjector
    public abstract MaintainQRcodeFragment maintainQRcodeFragment();

    @ContributesAndroidInjector
    public abstract MaintainSettingsFragment maintainSettingsFragment();
    //*******************Module of MaintainSecretary**********************//
}
