package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainHistoryItem {
    private static final String TAG = "MaintainHistoryItemView_";
    public String maintainDate;
    public String maintainAddress;
    public String maintainPoint;

    public String maintainMiles;

    public String maintainContent1;
    public String maintainContent2;
    public String maintainContent3;
    public String maintainContent4;

    public float maintainServicePoint;
    public float maintainChargePoint;
    public float maintainAttitudePoint;
    public int maintainPosition;

    public boolean maintainShowContent;
    public boolean maintainIsComment;


  /*  @Override
    public void onClick(int type, int position) {
        switch (type) {
            case 0:
                //close or open content
                Timber.tag(TAG).w("onClick:" + type + ",position:" + position);
                maintainShowContent = !maintainShowContent;
                break;
        }
    }*/
}
