package com.uaes.android.common;

import android.app.Application;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;

import com.uaes.android.domain.usecase.BatteryStatusSubscription;
import com.uaes.android.domain.usecase.DriverMasterDetailQuery;
import com.uaes.android.domain.usecase.DriverMasterQuery;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;
import com.uaes.android.domain.usecase.FuelMonitorQuery;
import com.uaes.android.domain.usecase.FuelScaleQuery;
import com.uaes.android.domain.usecase.FuelScaleRealTimeQuery;
import com.uaes.android.domain.usecase.FuelSettingQuery;
import com.uaes.android.domain.usecase.FuelSettingUpdate;
import com.uaes.android.domain.usecase.GasListQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;
import com.uaes.android.presenter.batteryhelper.BatteryHelperViewModel;
import com.uaes.android.presenter.driver.DriverMasterDetailViewModel;
import com.uaes.android.presenter.driver.DriverMasterViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyConsumeViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyDetailViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyFuelHistoryViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancySettingViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyStationViewModel;
import com.uaes.android.presenter.message.MessageCenterViewModel;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class UaesViewModelProviderFactory implements ViewModelProvider.Factory {

    private FuelScaleQuery fuelScaleQuery;

    private FuelScaleRealTimeQuery fuelScaleRealTimeQuery;

    private GasListQuery gasListQuery;

    private FuelMonitorQuery fuelMonitorQuery;

    private BatteryStatusSubscription batteryStatusSubscription;

    private Application application;

    private MessageCenterMsgQuery msgQuery;

    private MessageCenterMsgUpdate msgUpdate;

    private DriverMasterDetailQuery driverMasterDetailQuery;

    private DriverMasterQuery driverMasterQuery;

    private FuelHistoryFillListQuery fuelHistoryFillListQuery;

    private FuelSettingQuery fuelSettingQuery;

    private FuelSettingUpdate fuelSettingUpdate;

    public UaesViewModelProviderFactory(
            Application application,
            FuelScaleQuery fuelScaleQuery,
            GasListQuery gasListQuery,
            FuelScaleRealTimeQuery fuelScaleRealTimeQuery,
            BatteryStatusSubscription batteryStatusSubscription,
            MessageCenterMsgQuery msgQuery,
            MessageCenterMsgUpdate msgUpdate,
            FuelMonitorQuery fuelMonitorQuery,
            FuelHistoryFillListQuery fuelHistoryFillListQuery,
            FuelSettingQuery fuelSettingQuery,
            FuelSettingUpdate fuelSettingUpdate,
            DriverMasterDetailQuery driverMasterDetailQuery,
            DriverMasterQuery driverMasterQuery
    ) {
        this.application = application;
        this.gasListQuery = gasListQuery;
        this.fuelScaleQuery = fuelScaleQuery;
        this.fuelScaleRealTimeQuery = fuelScaleRealTimeQuery;
        this.batteryStatusSubscription = batteryStatusSubscription;
        this.msgQuery = msgQuery;
        this.msgUpdate = msgUpdate;
        this.fuelMonitorQuery = fuelMonitorQuery;
        this.fuelHistoryFillListQuery = fuelHistoryFillListQuery;
        this.fuelSettingQuery = fuelSettingQuery;
        this.fuelSettingUpdate = fuelSettingUpdate;
        this.driverMasterDetailQuery = driverMasterDetailQuery;
        this.driverMasterQuery = driverMasterQuery;
    }

    @SuppressWarnings("unchecked")
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(FuelAccountancyDetailViewModel.class)) {
            return (T) new FuelAccountancyDetailViewModel(fuelScaleQuery, fuelScaleRealTimeQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancyConsumeViewModel.class)) {
            return (T) new FuelAccountancyConsumeViewModel(fuelMonitorQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancyFuelHistoryViewModel.class)) {
            return (T) new FuelAccountancyFuelHistoryViewModel(fuelHistoryFillListQuery);
        } else if (modelClass.isAssignableFrom(BatteryHelperViewModel.class)) {
            return (T) new BatteryHelperViewModel(application, batteryStatusSubscription);
        } else if (modelClass.isAssignableFrom(MessageCenterViewModel.class)) {
            return (T) new MessageCenterViewModel(msgQuery, msgUpdate);
        } else if (modelClass.isAssignableFrom(DriverMasterDetailViewModel.class)) {
            return (T) new DriverMasterDetailViewModel(driverMasterDetailQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancySettingViewModel.class)) {
            return (T) new FuelAccountancySettingViewModel(fuelSettingQuery, fuelSettingUpdate);
        } else if (modelClass.isAssignableFrom(DriverMasterViewModel.class)) {
            return (T) new DriverMasterViewModel(driverMasterQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancyStationViewModel.class)) {
            return (T) new FuelAccountancyStationViewModel(gasListQuery);
        }
        throw new IllegalArgumentException("not support the class:" + modelClass);
    }
}
