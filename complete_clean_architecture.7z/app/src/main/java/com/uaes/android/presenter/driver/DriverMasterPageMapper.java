package com.uaes.android.presenter.driver;

import com.uaes.android.domain.entity.DMDriverMasterPage;

import io.reactivex.functions.Function;

public class DriverMasterPageMapper implements Function<DMDriverMasterPage, DriverMasterPage> {

    @Override
    public DriverMasterPage apply(DMDriverMasterPage dmDriverMasterPage) {
        DriverMasterPage masterPage = new DriverMasterPage();
        masterPage.titleSum = dmDriverMasterPage.titleSum;
        masterPage.titleDsc = dmDriverMasterPage.titleDsc;
        masterPage.acuteAcc = dmDriverMasterPage.acuteAcc;
        masterPage.acuteBreak = dmDriverMasterPage.acuteBreak;
        masterPage.acuteTurn = dmDriverMasterPage.acuteTurn;
        masterPage.continueAccAndDec = dmDriverMasterPage.continueAccAndDec;
        masterPage.nightDrive = dmDriverMasterPage.nightDriver;
        return masterPage;
    }
}
