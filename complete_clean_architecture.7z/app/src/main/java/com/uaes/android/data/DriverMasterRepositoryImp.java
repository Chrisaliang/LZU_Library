package com.uaes.android.data;

import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.entity.DMDriverMasterItem;
import com.uaes.android.domain.entity.DMDriverMasterPage;

import java.util.List;

public class DriverMasterRepositoryImp implements DriverMasterRepository {
    @Override
    public List<DMDriverMasterItem> queryDetailList(int type) {
        return null;
    }

    @Override
    public DMDriverMasterPage queryDriverMasterPage(int type) {
        return null;
    }
}
