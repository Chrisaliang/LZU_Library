package com.uaes.android.presenter.powerdefender;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.presenter.powerdefender.pojo.CarFaultHistory;
import com.uaes.android.presenter.powerdefender.viewholder.HistoryFaultBase;
import com.uaes.android.presenter.powerdefender.viewholder.HistoryFaultContent;
import com.uaes.android.presenter.powerdefender.viewholder.HistoryFaultHeader;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public class HistoryFaultAdapter extends RecyclerView.Adapter<HistoryFaultBase> {

    private static final int HOLDER_HEADER = 0;
    private static final int HOLDER_CONTENT = 1;

    private static final CarFaultHistory HEADER
            = new CarFaultHistory("", "", "", "");

    private List<CarFaultHistory> dataSets;

    HistoryFaultAdapter() {
        dataSets = new ArrayList<>();
        dataSets.add(HEADER);
    }

    @NonNull
    @Override
    public HistoryFaultBase onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ViewDataBinding binding;
        switch (viewType) {
            case HOLDER_HEADER:
                binding = DataBindingUtil.inflate(inflater,
                        R.layout.item_power_car_history_fault_title, parent, false);
                return new HistoryFaultHeader(binding);
            case HOLDER_CONTENT:
                binding = DataBindingUtil.inflate(inflater,
                        R.layout.item_power_car_history_fault, parent, false);
                return new HistoryFaultContent(binding);
            default:
                throw new IllegalArgumentException("type :" + viewType + " unknown.");
        }
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryFaultBase holder, int position) {
        if (holder instanceof HistoryFaultContent) {
            holder.getBinding().setVariable(BR.faultDes, dataSets.get(position));
            holder.getBinding().executePendingBindings();
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) return HOLDER_HEADER;
        else return HOLDER_CONTENT;
    }

    @Override
    public int getItemCount() {
        return dataSets.size();
    }

    // operator
    public void appendAll(Collection<CarFaultHistory> collection) {
        dataSets.addAll(collection);
        notifyDataSetChanged();
    }

    public void replaceAll(Collection<CarFaultHistory> collection) {
        dataSets.clear();
        dataSets.add(HEADER);
        dataSets.addAll(collection);
        notifyDataSetChanged();
    }
}
