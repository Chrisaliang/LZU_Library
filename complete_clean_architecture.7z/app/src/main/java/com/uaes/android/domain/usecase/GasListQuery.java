package com.uaes.android.domain.usecase;

import android.support.annotation.Nullable;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMGas;
import com.uaes.android.domain.entity.DMLocation;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 查询加油站列表
 */
public class GasListQuery extends SingleUseCase<List<DMGas>> {

    private FuelHelperRepository repository;

    private LocationRepository locationRepository;

    private volatile DMLocation mLocation;

    private JobThread jobThread;

    @FuelHelperRepository.GasQueryStrategy
    private int type = FuelHelperRepository.STRATEGY_GAS_DISTANCE;

    public GasListQuery(JobThread jobThread, FuelHelperRepository repository, LocationRepository locationRepository) {
        this.repository = repository;
        this.locationRepository = locationRepository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<List<DMGas>> buildSingle() {
        return locationRepository.create().map(new Function<DMLocation, List<DMGas>>() {
            @Override
            public List<DMGas> apply(DMLocation dmLocation) throws Exception {
                mLocation = dmLocation;
                return repository.queryGasList(dmLocation.longitude, dmLocation.latitude, type);
            }
        }).subscribeOn(jobThread.provideWorker())
                .observeOn(jobThread.providerUi());
    }

    public void setStrategy(@FuelHelperRepository.GasQueryStrategy int strategy) {
        this.type = strategy;
    }

    public int getStrategy() {
        return type;
    }

    @Nullable
    public DMLocation getLocation() {
        return mLocation;
    }
}
