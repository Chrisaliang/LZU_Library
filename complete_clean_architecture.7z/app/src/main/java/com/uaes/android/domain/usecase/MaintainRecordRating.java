package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMaintainRating;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class MaintainRecordRating extends SingleUseCase<Boolean> {

    private MaintainRepository repository;

    private JobThread jobThread;

    private DMMaintainRating rating;

    public MaintainRecordRating(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<Boolean> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, Boolean>() {
            @Override
            public Boolean apply(MaintainRepository repository) throws Exception {
                return repository.ratingRecord(rating);
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }

    public void setRating(DMMaintainRating rating) {
        this.rating = rating;
    }

    /**
     * @param id                     保养记录的ID
     * @param serviceRating          服务高效
     * @param attitudeRating         服务态度
     * @param transparencyOfFeesRate 收费透明度
     */
    public void setRating(String id, int serviceRating, int attitudeRating, int transparencyOfFeesRate) {
        if (rating == null) {
            rating = new DMMaintainRating();
        }
        rating.id = id;
        rating.attitudeRating = attitudeRating;
        rating.serviceRating = serviceRating;
        rating.transparencyOfFeesRate = transparencyOfFeesRate;
    }
}
