package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainSettingsViewModel extends ViewModel implements MaintainOnClickListener {
    private static final String TAG = "MaintainSettingsViewMod_";
    private static final int CLOSE = 0;
    private static final int SAVE = 0;
    public final MutableLiveData<Integer> selectedWhen = new MutableLiveData<>();
    public final MutableLiveData<Integer> selectedRate = new MutableLiveData<>();

    private final MutableLiveData<Integer> changeContentObserver = new MutableLiveData<>();
    private final MutableLiveData<Integer> settingsDetailObserver = new MutableLiveData<>();

    @Override
    public void onClick(int type) {
        Timber.tag(TAG).w("MaintainSettingsViewModel onclick:" + type);
        // usecase TODO
        switch (type) {
            case 0:
                //close
                changeContentObserver.setValue(CLOSE);
                break;
            case 1:
                //打开或关闭button
                break;
            case 2:
                //200km/周
                selectedWhen.setValue(0);
                break;
            case 3:
                //500km/2周
                selectedWhen.setValue(1);
                break;
            case 4:
                //1000km/月
                selectedWhen.setValue(2);
                break;
            case 5:
                //每50km
                selectedRate.setValue(0);
                break;
            case 6:
                //每次驾驶
                selectedRate.setValue(1);
                break;
            case 7:
                //每天一次
                selectedRate.setValue(2);
                break;
            case 8:
                //每周一次
                selectedRate.setValue(3);
                break;
            case 9:
                //保存
                changeContentObserver.setValue(SAVE);
                break;
        }
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {
        Timber.tag(TAG).w("MaintainSettingsViewModel isChecked:" + isChecked);
    }

    public LiveData<Integer> getChangeContentObserver() {
        return changeContentObserver;
    }
}
