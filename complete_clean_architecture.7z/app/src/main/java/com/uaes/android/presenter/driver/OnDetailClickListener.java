package com.uaes.android.presenter.driver;

public interface OnDetailClickListener {

    void changeFragment(int type);
}
