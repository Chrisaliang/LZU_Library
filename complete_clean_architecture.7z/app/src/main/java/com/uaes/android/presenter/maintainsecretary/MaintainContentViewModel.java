package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainContentViewModel extends ViewModel {
    public final MutableLiveData<String> contentObserver = new MutableLiveData<>();


    public void getContent() {
        contentObserver.setValue("\t\t\t机油将发动机产生的杂质，结焦物带走，然后通过机油滤清器过滤，在循环使用" +
                "。颗粒杂质会堵塞机油滤清器，造成油路不畅。所以每次更换机油机油滤清器需要一并更换。" +
                "\n\t\t\t绅宝X55推荐使用北京汽车专用机油，机油品质通常为合成和半合成。推荐每半年更换一次。");
    }

}
