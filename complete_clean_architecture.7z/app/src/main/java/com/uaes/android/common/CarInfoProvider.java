package com.uaes.android.common;

public interface CarInfoProvider {

    /**
     * 提取Vin码
     */
    String getVin();

    /**
     * 提取IMEI
     */
    String getIMEI();

    /**
     * 提取认证码
     */
    String getSHA384();

    /**
     * debug 用
     */
    String debugString();
}
