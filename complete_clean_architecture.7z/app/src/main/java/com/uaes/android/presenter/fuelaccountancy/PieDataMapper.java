package com.uaes.android.presenter.fuelaccountancy;

import com.github.mikephil.charting.data.PieEntry;
import com.uaes.android.domain.entity.DMFuelScale;

import java.util.ArrayList;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
class PieDataMapper {

    public ArrayList<PieEntry> map(DMFuelScale scale) {
        ArrayList<PieEntry> list = new ArrayList<>();
        if (scale.acUse > 0)
            list.add(new PieEntry(scale.acUse / 100.f, "空调消耗"));
        if (scale.driverUse > 0)
            list.add(new PieEntry(scale.driverUse / 100.f, "正常驾驶"));
        if (scale.idleUse > 0)
            list.add(new PieEntry(scale.idleUse / 100.f, "怠速停车"));
        if (scale.otherUse > 0)
            list.add(new PieEntry(scale.otherUse / 100.f, "激烈驾驶"));
        return list;
    }
}
