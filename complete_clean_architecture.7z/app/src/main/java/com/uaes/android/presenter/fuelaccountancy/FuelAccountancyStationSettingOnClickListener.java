package com.uaes.android.presenter.fuelaccountancy;

public interface FuelAccountancyStationSettingOnClickListener {
    void onClick(int type);
}
