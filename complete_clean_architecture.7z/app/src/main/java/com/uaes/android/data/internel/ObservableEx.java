package com.uaes.android.data.internel;

import android.content.Context;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.functions.Function;
import io.reactivex.plugins.RxJavaPlugins;

/**
 * 项目内RxJava2扩展
 */
public final class ObservableEx {

    /**
     * 创建可观察的定位接口，使用默认配置 默认配置参考高德资料
     */
    public static Observable<AMapLocation> createAMapLocation(Context context) {
        AMapLocationClient aMapLocationClient = new AMapLocationClient(context.getApplicationContext());
        return RxJavaPlugins.onAssembly(new AMapLocationObservable(aMapLocationClient));
    }

    /**
     * 自定义配置
     *
     * @param function 自定义配置接口
     */
    public static Observable<AMapLocation> createAMapLocation(Context context, final AMapClientOptionFunction function) {
        AMapLocationClient aMapLocationClient = new AMapLocationClient(context.getApplicationContext());
        return Observable.just(aMapLocationClient).flatMap(new Function<AMapLocationClient, ObservableSource<? extends AMapLocation>>() {
            @Override
            public ObservableSource<? extends AMapLocation> apply(AMapLocationClient client) {
                function.onOption(client);
                return RxJavaPlugins.onAssembly(new AMapLocationObservable(client));
            }
        });
    }

    public interface AMapClientOptionFunction {
        /**
         * 配置该客户端
         */
        void onOption(AMapLocationClient client);
    }
}
