package com.uaes.android.presenter.batteryhelper;

import android.view.View;

public interface BatteryOnClickListener {
    void onClick(View view);
}
