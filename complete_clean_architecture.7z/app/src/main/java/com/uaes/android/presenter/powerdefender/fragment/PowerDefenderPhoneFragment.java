package com.uaes.android.presenter.powerdefender.fragment;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderPhoneBinding;
import com.uaes.android.presenter.BaseFragment;
import com.uaes.android.presenter.powerdefender.pojo.CallPhone;

import timber.log.Timber;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderPhoneFragment extends BaseFragment {

    private static final String TAG = "PowerDefenderPhoneFragment";
    private FragmentPowerDefenderPhoneBinding mPhoneBinding;
    private FragmentManager mFragmentManager;
    private CallPhone mPhone;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mPhoneBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_phone, container, false);
        return mPhoneBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mFragmentManager = getFragmentManager();
        mPhoneBinding.setPresenter(new Presenter());
        mPhone = new CallPhone();
        mPhone.address = "上海市黄浦区北汽浦东4S店";
        mPhone.phone = "021-666666";

        mPhoneBinding.setCallphone(mPhone);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    private void callPhone(String phone) {

        try {
            Intent intent = new Intent();
            intent.setAction("com.iflytek.action.CALL");
            intent.putExtra("tel", phone);
            startActivity(intent);
        } catch (Exception e) {
            Timber.tag(TAG).w(e);
        }

    }

    public class Presenter {
        public void close() {
            if (mFragmentManager != null) {
                mFragmentManager.popBackStack();
            }

        }

        public void dial() {
            callPhone(mPhone.phone);
        }
    }


}
