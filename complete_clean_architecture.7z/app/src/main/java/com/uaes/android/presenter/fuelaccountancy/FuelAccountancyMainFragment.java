package com.uaes.android.presenter.fuelaccountancy;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.uaes.android.R;

import java.util.Objects;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelAccountancyMainFragment extends FuelAccountancyFragment {

    private static final String TAG = "FuelAccountancyMainFrag";

    private String[] mTitles;
    private TabLayout mTabLayout;
    private Fragment[] fragments;

    private ImageView fuelMainGoSetIv;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fuel_accountancy_main_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fragments = new Fragment[]{new FuelConsumeFragment(), new FuelDetailFragment(), new FuelStationFragment(), new FuelHistoryFragment()};
        mTitles = Objects.requireNonNull(getContext()).getResources().getStringArray(R.array.fuel_accountancy_titles);
        mTabLayout = view.findViewById(R.id.fuel_main_tab_layout);
        fuelMainGoSetIv = view.findViewById(R.id.fuel_main_go_set_iv);
        initTabLayout();

        goStationSetListener();
    }

    private void goStationSetListener() {
        fuelMainGoSetIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到setting
                navigator.goToSetting();
            }
        });
    }

    private void initTabLayout() {
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                itemSelect(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[0]));
        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[1]));
        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[2]));
        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[3]));
    }

    private void itemSelect(int position) {
        Fragment fragment = null;
        if (position < fragments.length && position >= 0) {
            fragment = fragments[position];
        }
        if (fragment != null) {
            getChildFragmentManager().beginTransaction().replace(R.id.fuel_main_frame, fragment).commit();
        }
    }


}
