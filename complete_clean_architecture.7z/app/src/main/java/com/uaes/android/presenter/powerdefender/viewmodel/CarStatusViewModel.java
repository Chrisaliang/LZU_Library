package com.uaes.android.presenter.powerdefender.viewmodel;

import android.arch.lifecycle.ViewModel;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;

import com.uaes.android.presenter.powerdefender.pojo.CarIndicateEntity;

import io.reactivex.disposables.Disposable;

/**
 * Created by diaokaibin@gmail.com on 2018/5/8.
 */
public class CarStatusViewModel extends ViewModel {

    public final String TAG = this.getClass().getSimpleName();

    public final ObservableField<String> status = new ObservableField<>();
    public final ObservableField<String> statusDes = new ObservableField<>();
    public final ObservableBoolean mObservableBoolean = new ObservableBoolean();

    public final ObservableInt mObservableScore = new ObservableInt();
    public final ObservableArrayList<CarIndicateEntity> mEntityObservableArrayList = new ObservableArrayList<>();

    private Disposable disposable;
    private Disposable subscription;

    public CarStatusViewModel() {
        initData();
    }

    private void initData() {

        // 测试数据
        status.set("差");
        statusDes.set("车辆驾驶性能严重受损,建议立刻维修或呼叫车辆救援!");
        mObservableBoolean.set(true);
        mObservableScore.set(4);
        mEntityObservableArrayList.add(new CarIndicateEntity(0, 0, "1项故障"));
        mEntityObservableArrayList.add(new CarIndicateEntity(1, 1, "4项故障"));
        mEntityObservableArrayList.add(new CarIndicateEntity(2, 2, "2项故障"));
        mEntityObservableArrayList.add(new CarIndicateEntity(3, 0, "4项故障"));

        mEntityObservableArrayList.add(new CarIndicateEntity(4, 1, "6项故障"));
        mEntityObservableArrayList.add(new CarIndicateEntity(5, 2, "7项故障"));
        mEntityObservableArrayList.add(new CarIndicateEntity(6, 0, "8项故障"));
        mEntityObservableArrayList.add(new CarIndicateEntity(7, 1, "6项故障"));
    }


}
