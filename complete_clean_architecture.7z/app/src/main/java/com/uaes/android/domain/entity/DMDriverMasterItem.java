package com.uaes.android.domain.entity;

import com.amap.api.maps.model.LatLng;

public class DMDriverMasterItem {

    /**
     * 驾驶事件发生时间
     */
    public String time;

    /**
     * 驾驶事件危险程度
     */
    public int dangerousRank;

    /**
     * 驾驶事件持续时间
     */
    public String duration;

    /**
     * 驾驶事件发生地址
     */
    public String locationStr;

    /**
     * 驾驶记录分类
     */
    public int detailType;

    /**
     * 驾驶行为发生地点
     */
    public LatLng[] locations;
}
