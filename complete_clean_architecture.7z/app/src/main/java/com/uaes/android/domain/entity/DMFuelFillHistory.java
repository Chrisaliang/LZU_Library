package com.uaes.android.domain.entity;

import android.support.annotation.IntRange;

/**
 * 数据
 */
public class DMFuelFillHistory {
    /**
     * 主Id
     * */
    public int id;
    /**
     * 加油日期
     */
    public String date;
    /**
     * 加油量
     */
    public int volume;

    /**
     * 加油站名称
     */
    public String address;
    /**
     * 评分
     * 为 -1 表示没有点评
     */
    @IntRange(from = 0, to = 5)
    public int rating;
}
