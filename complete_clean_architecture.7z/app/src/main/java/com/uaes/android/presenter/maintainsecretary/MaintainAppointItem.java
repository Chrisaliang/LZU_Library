package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainAppointItem {
    private static final String TAG = "MaintainAppointItemViewModel_";
    /* public final ObservableField<String> maintainAddress = new ObservableField<>();
     public final ObservableField<String> maintainPhone = new ObservableField<>();
     public final ObservableInt positon = new ObservableInt();*/
    public String maintainAddress;
    public String maintainPhone;
    public int positon;


}
