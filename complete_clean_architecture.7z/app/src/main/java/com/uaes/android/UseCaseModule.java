package com.uaes.android;

import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.usecase.BatteryStatusSubscription;
import com.uaes.android.domain.usecase.DriverMasterDetailQuery;
import com.uaes.android.domain.usecase.DriverMasterQuery;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;
import com.uaes.android.domain.usecase.FuelMonitorQuery;
import com.uaes.android.domain.usecase.FuelScaleQuery;
import com.uaes.android.domain.usecase.FuelScaleRealTimeQuery;
import com.uaes.android.domain.usecase.FuelSettingQuery;
import com.uaes.android.domain.usecase.FuelSettingUpdate;
import com.uaes.android.domain.usecase.GasListQuery;
import com.uaes.android.domain.usecase.MaintainRecordQuery;
import com.uaes.android.domain.usecase.MaintainSettingQuery;
import com.uaes.android.domain.usecase.MaintainSettingUpdate;
import com.uaes.android.domain.usecase.MaintainStatusQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;
import com.uaes.android.domain.usecase.PowerReportQuery;
import com.uaes.android.domain.usecase.PowerStatusQuery;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
abstract class UseCaseModule {

    //*************************** 用油会计 ********************************//
    @Provides
    @Singleton
    static FuelScaleQuery providerFuelScaleQuery(FuelHelperRepository repository, JobThread jobThread) {
        return new FuelScaleQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static FuelScaleRealTimeQuery providerFuelScaleRealTimeQuery(FuelHelperRepository repository, JobThread jobThread) {
        return new FuelScaleRealTimeQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static GasListQuery providerGasListQuery(LocationRepository locationRepository, JobThread jobThread, FuelHelperRepository repository) {
        return new GasListQuery(jobThread, repository, locationRepository);
    }

    @Provides
    @Singleton
    static FuelSettingQuery providerFuelSettingQuery(FuelHelperRepository repository, JobThread jobThread) {
        return new FuelSettingQuery(jobThread, repository);
    }

    @Provides
    @Singleton
    static FuelSettingUpdate providerFuelSettingUpdate(FuelHelperRepository repository, JobThread jobThread) {
        return new FuelSettingUpdate(jobThread, repository);
    }

    @Provides
    @Singleton
    static FuelHistoryFillListQuery providerFuelHistoryFillListQuery(FuelHelperRepository repository, JobThread jobThread) {
        return new FuelHistoryFillListQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static FuelMonitorQuery providerFuelMonitorQuery(FuelHelperRepository repository, JobThread jobThread) {
        return new FuelMonitorQuery(repository, jobThread);
    }

    //****************************** 电池助手 ************************************//
    @Provides
    @Singleton
    static BatteryStatusSubscription providerBatteryStatusSubscription(BatteryRepository repository, JobThread jobThread) {
        return new BatteryStatusSubscription(repository, jobThread);
    }

    // ***************************** 驾驶达人 *************************************//
    @Provides
    @Singleton
    static DriverMasterDetailQuery providerDriverManagerListQuery(DriverMasterRepository repository, JobThread jobThread) {
        return new DriverMasterDetailQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static DriverMasterQuery providerDriverMasterQuery(DriverMasterRepository repository, JobThread jobThread) {
        return new DriverMasterQuery(repository, jobThread);
    }

    // ***************************** 消息中心 ***************************************** //
    @Provides
    @Singleton
    static MessageCenterMsgQuery providerMessageCenterMsgQuery(MessageCenterRepository repository, JobThread jobThread) {
        return new MessageCenterMsgQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static MessageCenterMsgUpdate providerMessageCenterMsgUpdate(MessageCenterRepository repository, JobThread jobThread) {
        return new MessageCenterMsgUpdate(repository, jobThread);
    }

    // ********************************* 保养秘书 ****************************************//
    @Provides
    @Singleton
    static MaintainSettingQuery providerMaintainSettingQuery(MaintainRepository repository, JobThread jobThread) {
        return new MaintainSettingQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static MaintainSettingUpdate providerMaintainSettingUpdate(MaintainRepository repository, JobThread jobThread) {
        return new MaintainSettingUpdate(repository, jobThread);
    }

    @Provides
    @Singleton
    static MaintainRecordQuery providerMaintainRecordQuery(MaintainRepository repository, JobThread jobThread) {
        return new MaintainRecordQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static MaintainStatusQuery providerMaintainStatusQuery(MaintainRepository repository, JobThread jobThread) {
        return new MaintainStatusQuery(repository, jobThread);
    }

    //*********************************** 动力卫士 *************************************//
    @Provides
    @Singleton
    static PowerStatusQuery providerPowerStatusQuery(PowerDefenderRepository repository, JobThread jobThread) {
        return new PowerStatusQuery(repository, jobThread);
    }

    @Provides
    @Singleton
    static PowerReportQuery providerPowerReportQuery(PowerDefenderRepository repository, JobThread jobThread) {
        return new PowerReportQuery(repository, jobThread);
    }
}
