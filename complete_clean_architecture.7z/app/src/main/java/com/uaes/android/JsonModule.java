package com.uaes.android;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Json Converter
 * */
@Module
public abstract class JsonModule {

    private static final String PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    @Provides
    @Singleton
    public static Gson gson() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat(PATTERN);
        gsonBuilder.serializeNulls();
        return gsonBuilder.create();
    }
}
