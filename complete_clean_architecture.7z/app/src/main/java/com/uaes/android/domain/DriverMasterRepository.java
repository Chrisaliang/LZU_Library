package com.uaes.android.domain;

import com.uaes.android.domain.entity.DMDriverMasterItem;
import com.uaes.android.domain.entity.DMDriverMasterPage;

import java.util.List;

public interface DriverMasterRepository {

    /**
     * 驾驶达人详细列表
     *
     * @param type 详细列表类型
     * @return 列表条目
     */
    List<DMDriverMasterItem> queryDetailList(int type);

    /**
     * 驾驶达人page页面
     *
     * @param type 行驶里程
     * @return 对应详情数据
     */
    DMDriverMasterPage queryDriverMasterPage(int type);
}
