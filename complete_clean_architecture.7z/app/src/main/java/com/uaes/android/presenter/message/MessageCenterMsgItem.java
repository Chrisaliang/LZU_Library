package com.uaes.android.presenter.message;

public class MessageCenterMsgItem {

    public String msgTime;
    public String msgContent;

}
