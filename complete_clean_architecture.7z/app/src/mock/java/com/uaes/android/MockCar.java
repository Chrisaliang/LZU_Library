package com.uaes.android;

/**
 * Created by aber on 1/24/2018.
 * 测试环境
 */

public interface MockCar {
    String MOCK_VIN = "LNBSCUAK5HF043610"; // 实车
    String MOCK_IMEI = "863010031601284"; // 实车
//    String MOCK_VIN = "test28"; // 实车
//    String MOCK_IMEI = "863010031601284"; // 实车
//    String MOCK_VIN = "LNBSCUAK5HF00001"; // mock new car 百公里油耗
//    String MOCK_IMEI = "12345600001"; // mock new car包公里友好
//    String MOCK_VIN = "LNBSCUAK5HF00002"; // mock new car 百公里油耗
//    String MOCK_IMEI = "20171219002"; // mock new car包公里友好
}
