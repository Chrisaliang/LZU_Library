package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.AMapLocationRepository;
import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.MessageCenterRepository;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
abstract class RepositoryModule {

    @Provides
    @Singleton
    static FuelHelperRepository providerFuelHelperRepository(Gson gson, App app) {
        return new MockFuelHelperRepository(app, gson);
    }

    @Provides
    @Singleton
    static BatteryRepository providerBatterRepository() {
        return new MockBatteryRepository();
    }

    @Provides
    @Singleton
    static LocationRepository providerLocationRepository(App app) {
        return new AMapLocationRepository(app);
    }

    @Provides
    @Singleton
    static MessageCenterRepository providerMessageCenterRepository() {
        return new MockMessageCenterRepository();
    }

    @Provides
    @Singleton
    static DriverMasterRepository providerDriverManagerRepository() {
        return new MockDriverMasterRepository();
    }

    @Provides
    @Singleton
    static MaintainRepository providerMaintainRepository(App app, Gson gson) {
        return new MockMaintainRepository(app, gson);
    }
}
