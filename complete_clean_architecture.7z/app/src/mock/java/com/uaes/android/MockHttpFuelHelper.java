package com.uaes.android;

import android.content.Context;
import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.data.json.FuelScale;
import com.uaes.android.data.json.FuelStationJson;
import com.uaes.android.data.json.GeneralAttributeReceive;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MockHttpFuelHelper implements HttpFuelHelper {

    private Context context;
    private Gson gson;

    MockHttpFuelHelper(Context context, Gson gson) {
        this.context = context;
        this.gson = gson;
    }

    @Override
    public Call<GeneralAttributeReceive<FuelScale>> getFuelScale(String queryType) {
        return new Call<GeneralAttributeReceive<FuelScale>>() {
            @Override
            public Response<GeneralAttributeReceive<FuelScale>> execute() throws IOException {
                InputStream inputStream = context.getAssets().open("fuel_scale.json");
                Type type = new TypeToken<GeneralAttributeReceive<FuelScale>>(){}.getType();
                GeneralAttributeReceive<FuelScale> result = gson.fromJson(new InputStreamReader(inputStream), type);
                inputStream.close();
                return Response.success(result);
            }

            @Override
            public void enqueue(@NonNull Callback<GeneralAttributeReceive<FuelScale>> callback) {

            }

            @Override
            public boolean isExecuted() {
                return false;
            }

            @Override
            public void cancel() {

            }

            @Override
            public boolean isCanceled() {
                return false;
            }

            @SuppressWarnings("MethodDoesntCallSuperMethod")
            @Override
            public Call<GeneralAttributeReceive<FuelScale>> clone() {
                return null;
            }

            @Override
            public Request request() {
                return null;
            }
        };
    }

    @Override
    public Call<GeneralAttributeReceive<FuelMonitorJson>> getMonitor() {
        return null;
    }

    @Override
    public Call<GeneralAttributeReceive<List<FuelStationJson>>> getStation(String location, int strategy) {
        return null;
    }

    @Override
    public Call<JsonObject> setFuelAccount(RequestBody body) {
        return null;
    }

    @Override
    public Call<JsonObject> singleFuelRecord(int page, int size) {
        return null;
    }
}
