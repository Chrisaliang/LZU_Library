package com.uaes.android;

import android.content.Context;
import android.util.Log;

import com.google.common.hash.Hashing;
import com.uaes.android.common.CarInfoProvider;
import com.uaes.android.common.PhoneManagerUtils;

import java.nio.charset.Charset;

/**
 * Created by Chrisaliang on 2017/12/7.
 * Query Vin and sha384 code for
 */

public class MockCarInfoProvider implements CarInfoProvider {

    private static final boolean MOCK = false;
    private static final boolean FAKE = true;

    private static final String TAG = MockCarInfoProvider.class.getSimpleName();

    private static MockCarInfoProvider INSTANCE;

    private String vinStr;

    private String sha384;

    private String imei;

    private CarConfigManager manager;

    private MockCarInfoProvider(Context context) {
        manager = new CarConfigManager(context);
        parser(context, this);
    }

    public static MockCarInfoProvider getInstance(Context context) {
        if (INSTANCE == null)
            INSTANCE = new MockCarInfoProvider(context);
        return INSTANCE;
    }

    private static void parser(Context context, MockCarInfoProvider mockCarInfoProvider) {
        if (MOCK) {
            mockCarInfoProvider.vinStr = mockCarInfoProvider.manager.getSelect().vin;
            mockCarInfoProvider.imei = mockCarInfoProvider.manager.getSelect().imei;
        } else if (FAKE) {
            mockCarInfoProvider.vinStr = MockCar.MOCK_VIN;
            mockCarInfoProvider.imei = MockCar.MOCK_IMEI;
        } else {
            mockCarInfoProvider.vinStr = PhoneManagerUtils.getAutoId();
            mockCarInfoProvider.imei = PhoneManagerUtils.getIMEIStr(context);
        }
        Log.d(TAG, "parser: VIN: " + mockCarInfoProvider.vinStr + ", imei: " + mockCarInfoProvider.imei);
        mockCarInfoProvider.sha384 = Hashing.sha384().hashString(
                mockCarInfoProvider.vinStr + ":" + mockCarInfoProvider.imei,
                Charset.defaultCharset()).toString();
    }

    public CarConfigManager getManager() {
        return manager;
    }

    @Override
    public String getVin() {
        return vinStr;
    }

    @Override
    public String getIMEI() {
        return imei;
    }

    @Override
    public String getSHA384() {
        return sha384;
    }

    @Override
    public String debugString() {
        return toString();
    }

    @Override
    public String toString() {
        return "MockCarInfoProvider{" +
                "vinStr='" + vinStr + '\'' +
                ", sha384='" + sha384 + '\'' +
                ", imei='" + imei + '\'' +
                ", manager=" + manager +
                '}';
    }
}
