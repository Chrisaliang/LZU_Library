package com.uaes.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by aber on 1/26/2018.
 * Cache Car's Vin code and Imei in android sp file.
 */

public class CarConfigManager {

    private static final String INFO = "com.uaes.iot.INFO";
    private static TypeToken<List<VinConfig>> token = new TypeToken<List<VinConfig>>() {
    };
    private Context ctx;
    private SharedPreferences sp;
    private VinConfig CONFIG;
    private Gson gson = new Gson();

    CarConfigManager(Context ctx) {
        this.ctx = ctx;
        sp = PreferenceManager.getDefaultSharedPreferences(ctx);
    }

    public void saveConfig(VinConfig vinConfig) {
        String old = sp.getString(INFO, "");
        List<VinConfig> configs = gson.fromJson(old, token.getType());
        if (configs == null) {
            configs = new ArrayList<>();
        }
        configs.add(vinConfig);
        saveList(configs);
    }

    public void readConfig(List<VinConfig> configs) {
        String code = sp.getString(INFO, "");
        List<VinConfig> vin = gson.fromJson(code, token.getType());
        if (vin != null)
            configs.addAll(vin);
    }

    private void saveList(List<VinConfig> list) {
        sp.edit().putString(INFO, gson.toJson(list)).apply();
    }

    public void select(VinConfig vinConfig) {
        CONFIG = vinConfig;
        sp.edit().putString("vin", vinConfig.vin)
                .putString("imei", vinConfig.imei)
                .apply();
    }

    public VinConfig getSelect() {
        if (CONFIG == null) {
            String vin = sp.getString("vin", MockCar.MOCK_VIN);
            String imei = sp.getString("imei", MockCar.MOCK_IMEI);
            if (TextUtils.isEmpty(vin) || TextUtils.isEmpty(imei))
                throw new NullPointerException("please first select a vin config");
            CONFIG = new VinConfig();
            CONFIG.vin = vin;
            CONFIG.imei = imei;
        }
        return CONFIG;
    }

    public void clearVin(VinConfig vinConfig) {
        List<VinConfig> configs = new ArrayList<>();
        readConfig(configs);
        configs.remove(vinConfig);
        saveList(configs);
    }
}
