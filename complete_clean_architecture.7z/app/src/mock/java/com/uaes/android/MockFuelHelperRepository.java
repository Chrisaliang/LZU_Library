package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.entity.DMFuelFillHistory;
import com.uaes.android.domain.entity.DMFuelScale;
import com.uaes.android.domain.entity.DMFuelSetting;
import com.uaes.android.domain.entity.DMGas;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class MockFuelHelperRepository implements FuelHelperRepository {

    private final DMFuelScale dmFuelScale = new DMFuelScale(97, 1, 1, 1);

    private final DMFuelSetting dmFuelSetting = new DMFuelSetting();

    private List<DMGas> dmGases;

    private ARFuelMonitor monitor;

    private List<DMFuelFillHistory> dmFuelFillHistories;

    private Gson gson;

    private Context context;

    public MockFuelHelperRepository(Context context, Gson gson) {
        this.context = context;
        this.gson = gson;
    }

    @Override
    public DMFuelScale queryFuelScale(int type) {
        dmFuelScale.acUse = 20;
        dmFuelScale.driverUse = 20;
        dmFuelScale.idleUse = 40;
        dmFuelScale.otherUse = 20;
        return dmFuelScale;
    }

    @Override
    public boolean updateFuelSetting(DMFuelSetting dmFuelSetting) {
        this.dmFuelSetting.fuelThreshold = dmFuelSetting.fuelThreshold;
        this.dmFuelSetting.gasQuery = dmFuelSetting.gasQuery;
        return true;
    }

    @Override
    public DMFuelSetting queryFuelSetting() {
        return dmFuelSetting;
    }

    @Override
    public List<DMGas> queryGasList(double longitude, double latitude, int strategy) throws Exception {
        if (dmGases == null || dmGases.size() == 0) {
            InputStream inputStream = null;
            try {
                inputStream = context.getAssets().open("fuel_gas_stations.json");
                Type type = new TypeToken<List<DMGas>>() {
                }.getType();
                dmGases = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), type);
            } finally {
                if (inputStream != null)
                    inputStream.close();
            }
        }
        return dmGases;
    }

    @Override
    public ARFuelMonitor queryFuelMonitor() throws Exception {
        if (monitor == null) {
            InputStream inputStream = null;
            try {
                inputStream = context.getAssets().open("fuel_monitor.json");
                monitor = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), ARFuelMonitor.class);
            } finally {
                if (inputStream != null)
                    inputStream.close();
            }
        }
        return monitor;
    }

    @Override
    public List<DMFuelFillHistory> queryFuelFillHistory(int year) throws Exception {
        if (dmFuelFillHistories == null || dmFuelFillHistories.size() == 0) {
            InputStream inputStream = null;
            try {
                inputStream = context.getAssets().open("fuel_fill_history_list.json");
                Type type = new TypeToken<List<DMFuelFillHistory>>() {
                }.getType();
                dmFuelFillHistories = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), type);
            } finally {
                if (inputStream != null)
                    inputStream.close();
            }
        }
        return dmFuelFillHistories;
    }

    @Override
    public DMFuelFillHistory setFuelAccount(DMFuelFillHistory updateItem) throws Exception {
        return null;
    }
}
