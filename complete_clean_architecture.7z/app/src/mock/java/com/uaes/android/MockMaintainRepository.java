package com.uaes.android;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.entity.DMMaintainRating;
import com.uaes.android.domain.entity.DMMaintainRecord;
import com.uaes.android.domain.entity.DMMaintainSetting;
import com.uaes.android.domain.entity.DMMaintainStatus;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MockMaintainRepository implements MaintainRepository {

    private App app;

    private Gson gson;

    private DMMaintainSetting dmMaintainSetting = new DMMaintainSetting();

    private DMMaintainStatus status;

    private List<DMMaintainRecord> records;


    MockMaintainRepository(App app, Gson gson) {
        this.app = app;
        this.gson = gson;
    }

    @Override
    public DMMaintainStatus queryStatus() {
        if (status == null) {
            status = new DMMaintainStatus();
            status.maintainType = MaintainRepository.TYPE_MAINTAIN_MILE;
            status.maintainValue = 4020;
            status.maintainList = new ArrayList<>();
            status.maintainList.add("推荐1");
            status.maintainList.add("推荐2");
            status.maintainList.add("推荐3");
            status.maintainList.add("推荐4");
            status.maintainList.add("推荐5");
            status.maintainList.add("推荐6");
            status.maintainList.add("推荐7");
            status.maintainList.add("推荐8");
            status.maintainList.add("推荐9");
            status.maintainList.add("推荐10");
        }
        return status;
    }

    @Override
    public DMMaintainSetting querySetting() {
        dmMaintainSetting.isAllowedPush = false;
        dmMaintainSetting.pushFrequency = PUSH_FREQUENCY_EVERY_50KM;
        dmMaintainSetting.pushType = TYPE_PUSH_200KM;
        return dmMaintainSetting;
    }

    @Override
    public boolean updateSetting(DMMaintainSetting setting) {
        dmMaintainSetting.pushType = setting.pushType;
        dmMaintainSetting.pushFrequency = setting.pushFrequency;
        dmMaintainSetting.pushType = setting.pushType;
        return true;
    }

    @Override
    public List<DMMaintainRecord> queryRecord() throws Exception {
        if (records == null) {
            InputStream inputStream = null;
            try {
                inputStream = app.getAssets().open("maintain_records.json");
                Type type = new TypeToken<List<DMMaintainRecord>>() {
                }.getType();
                records = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), type);
            } finally {
                if (inputStream != null)
                    inputStream.close();
            }
        }
        return records;
    }

    @Override
    public boolean ratingRecord(DMMaintainRating rating) throws Exception {
        return false;
    }
}
