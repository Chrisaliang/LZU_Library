package com.uaes.android;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.entity.DMPowerReport;
import com.uaes.android.domain.entity.DMPowerStatus;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class MockPowerRepository implements PowerDefenderRepository {

    private Gson gson;

    private App app;

    private DMPowerStatus status;

    private List<DMPowerReport> reports;

    public MockPowerRepository(Gson gson, App app) {
        this.gson = gson;
        this.app = app;
    }

    @Override
    public DMPowerStatus queryPowerStatus() throws Exception {
        InputStream inputStream = null;
        try {
            inputStream = app.getAssets().open("power_system_pars.json");
            status = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), DMPowerStatus.class);
        } finally {
            if (inputStream != null)
                inputStream.close();
        }
        return status;
    }

    @Override
    public List<DMPowerReport> queryPowerReport() throws Exception {
        if (reports == null) {
            InputStream inputStream = null;
            try {
                inputStream = app.getAssets().open("power_system_reports.json");
                Type type = new TypeToken<List<DMPowerReport>>() {
                }.getType();
                reports = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), type);
            } finally {
                if (inputStream != null)
                    inputStream.close();
            }
        }
        return reports;
    }
}
