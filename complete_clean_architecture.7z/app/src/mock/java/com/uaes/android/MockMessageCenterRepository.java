package com.uaes.android;

import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.presenter.message.MessageCenterMsgItem;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;

public class MockMessageCenterRepository implements MessageCenterRepository {

    private static ObservableEmitter<MessageCenterMsgItem> sourceEmitter;

    public static void updateUI(MessageCenterMsgItem item) {
        if (sourceEmitter != null) {
            sourceEmitter.onNext(item);
        }
    }

    @Override
    public List<MessageCenterMsgItem> queryMessage(int type) {
        List<MessageCenterMsgItem> list = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            MessageCenterMsgItem item = new MessageCenterMsgItem();
            item.msgTime = ("测试时间：" + type + (i + 1));
            item.msgContent = ("测试消息：-------------" + type + (i + 1));
            list.add(item);
        }
        return list;
    }

    @Override
    public Observable<MessageCenterMsgItem> updateMessage() {
        ObservableOnSubscribe<MessageCenterMsgItem> source = new ObservableOnSubscribe<MessageCenterMsgItem>() {
            @Override
            public void subscribe(ObservableEmitter<MessageCenterMsgItem> emitter) {
                sourceEmitter = emitter;
            }
        };
        return Observable.create(source);
    }
}
