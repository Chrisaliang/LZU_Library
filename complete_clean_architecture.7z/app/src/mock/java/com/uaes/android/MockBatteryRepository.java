package com.uaes.android;

import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.entity.DMBatteryStatus;

import java.util.Random;

public class MockBatteryRepository implements BatteryRepository {

    private DMBatteryStatus status = new DMBatteryStatus();
    private Random random = new Random();

    @Override
    public DMBatteryStatus queryBatteryStatus() {
        status.isAgeing = random.nextBoolean();
        status.isBatteryLifeFull = random.nextBoolean();
        status.hintDescription = "测试";
        return status;
    }
}
