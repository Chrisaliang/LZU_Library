package com.uaes.android;

import com.amap.api.maps.model.LatLng;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.entity.DMDriverMasterItem;
import com.uaes.android.domain.entity.DMDriverMasterPage;

import java.util.ArrayList;
import java.util.List;

public class MockDriverMasterRepository implements DriverMasterRepository {
    @Override
    public List<DMDriverMasterItem> queryDetailList(int type) {
        List<DMDriverMasterItem> list = new ArrayList<>(0);
        for (int i = 0; i < 5; i++) {
            DMDriverMasterItem item = new DMDriverMasterItem();
            item.detailType = type;
            item.time = "2018.05.11\n12:23:34";
            item.dangerousRank = i + 1;
            if (type == 4) {
                item.locationStr = "上海市浦东新区金海路申江路\n上海市报山区场北路";
                item.locations = new LatLng[]{
                        new LatLng(31.269605, 121.627926),
                        new LatLng(31.269685, 121.627816),
                        new LatLng(31.269835, 121.627686),
                        new LatLng(31.269935, 121.627636)
                };
            } else {
                item.locationStr = "上海市浦东新区金桥路";
                item.locations = new LatLng[]{new LatLng(31.269605, 121.627926)};
            }
            item.duration = "5.3s";
            list.add(item);
        }
        return list;
    }

    @Override
    public DMDriverMasterPage queryDriverMasterPage(int type) {
        DMDriverMasterPage dmDriverMasterPage = new DMDriverMasterPage();
        if (type == 0) {
            dmDriverMasterPage.titleSum = "心浮气躁";
            dmDriverMasterPage.titleDsc = "开车时心态要平和，小心一时心急误了大事哦！~~~";
            dmDriverMasterPage.acuteAcc = 30;
            dmDriverMasterPage.acuteBreak = 50;
            dmDriverMasterPage.acuteTurn = 70;
            dmDriverMasterPage.continueAccAndDec = 30;
            dmDriverMasterPage.nightDriver = 30;
        } else if (type == 1) {
            dmDriverMasterPage.titleSum = "稳扎稳打";
            dmDriverMasterPage.titleDsc = "开车时心态要平和，小心一时心急误了大事哦！~~~";
            dmDriverMasterPage.acuteAcc = 60;
            dmDriverMasterPage.acuteBreak = 20;
            dmDriverMasterPage.acuteTurn = 80;
            dmDriverMasterPage.continueAccAndDec = 40;
            dmDriverMasterPage.nightDriver = 50;
        } else {
            dmDriverMasterPage.titleSum = "狂野飙车";
            dmDriverMasterPage.titleDsc = "玩的就是刺激和心跳";
            dmDriverMasterPage.acuteAcc = 70;
            dmDriverMasterPage.acuteBreak = 30;
            dmDriverMasterPage.acuteTurn = 80;
            dmDriverMasterPage.continueAccAndDec = 20;
            dmDriverMasterPage.nightDriver = 30;
        }
        return dmDriverMasterPage;
    }
}
