package com.uaes.android;

import android.content.SharedPreferences;
import android.support.v4.content.LocalBroadcastManager;

import com.google.gson.Gson;
import com.uaes.android.common.CarInfoProvider;
import com.uaes.android.data.http.HapAuthorizationInterceptor;
import com.uaes.android.data.http.HttpBatteryApi;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.http.HttpLogger;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.http.TokenApi;
import com.uaes.android.data.http.TokenAuthenticator;

import java.security.KeyStore;
import java.util.Arrays;

import javax.inject.Singleton;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by hand on 2017/11/1.
 * Net work module
 */

@Module
public abstract class NetModule {

    @Provides
    @Singleton
    static HttpLoggingInterceptor.Logger logger() {
        return new HttpLogger();
    }

    @Provides
    @Singleton
    static HttpLoggingInterceptor loggingInterceptor(HttpLoggingInterceptor.Logger logger) {
        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor(logger);
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        return httpLoggingInterceptor;
    }

    @Provides
    @Singleton
    static HapAuthorizationInterceptor hapAuthorizationInterceptor(CarInfoProvider authProvider, SharedPreferences sharedPreferences) {
        return new HapAuthorizationInterceptor(sharedPreferences, authProvider);
    }

    @Provides
    @Singleton
    static TokenAuthenticator tokenAuthenticator(CarInfoProvider authProvider, Gson gson, SharedPreferences sp, App application,
                                                 HapAuthorizationInterceptor interceptor) {
        return new TokenAuthenticator(authProvider, gson, sp, LocalBroadcastManager.getInstance(application), interceptor);
    }

    @Provides
    @Singleton
    static OkHttpClient okHttpClient(HttpLoggingInterceptor interceptor,
                                     HapAuthorizationInterceptor hapAuthorizationInterceptor,
                                     TokenAuthenticator tokenAuthenticator) {
        try {
            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(
                    TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init((KeyStore) null);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
            if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
                throw new IllegalStateException("Unexpected default trust managers:"
                        +Arrays.toString(trustManagers));
            }
            X509TrustManager trustManager = (X509TrustManager) trustManagers[0];
            SSLContext sc = SSLContext.getInstance("TLSv1.2");
            sc.init(null, null, null);
//            builder.sslSocketFactory(new Tls12SocketFactory(sc.getSocketFactory()), trustManager);
            return builder
                    .addNetworkInterceptor(hapAuthorizationInterceptor)
                    .addNetworkInterceptor(interceptor)
                    .authenticator(tokenAuthenticator)
                    .build();
        } catch (Exception e) {
            return null;
        }
    }

    @Provides
    @Singleton
    static Retrofit retrofit(OkHttpClient client, Gson gson) {
        return new Retrofit.Builder()
                .baseUrl(ServiceEnvironment.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    @Provides
    @Singleton
    static TokenApi tokenInterface(Retrofit retrofit) {
        return retrofit.create(TokenApi.class);
    }

    @Provides
    @Singleton
    static HttpFuelHelper httpFuelHelper(Retrofit retrofit) {
        return retrofit.create(HttpFuelHelper.class);
    }

    @Provides
    @Singleton
    static HttpBatteryApi httpBatteryApi(Retrofit retrofit) {
        return retrofit.create(HttpBatteryApi.class);
    }

    @Provides
    @Singleton
    static SettingApi settingApi(Retrofit retrofit) {
        return retrofit.create(SettingApi.class);
    }
}
