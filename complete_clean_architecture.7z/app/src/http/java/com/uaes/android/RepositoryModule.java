package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.AMapLocationRepository;
import com.uaes.android.data.BatteryRepositoryImp;
import com.uaes.android.data.DriverMasterRepositoryImp;
import com.uaes.android.data.FuelHelperRepositoryImp;
import com.uaes.android.data.MessageCenterRepositoryImp;
import com.uaes.android.data.http.HttpBatteryApi;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.MessageCenterRepository;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public abstract class RepositoryModule {

    @Provides
    @Singleton
    static FuelHelperRepository providerFuelHelperRepository(HttpFuelHelper api, SettingApi settingApi, App app, Gson gson) {
        return new FuelHelperRepositoryImp(api, settingApi, app, gson);
    }

    @Provides
    @Singleton
    public static MessageCenterRepository messageCenterRepository() {
        return new MessageCenterRepositoryImp();
    }

    @Provides
    @Singleton
    public static DriverMasterRepository driverManagerDetailRepository() {
        return new DriverMasterRepositoryImp();
    }

    @Provides
    @Singleton
    static LocationRepository aMapLocationRepository(App app) {
        return new AMapLocationRepository(app);
    }

    @Provides
    @Singleton
    static BatteryRepository batteryRepository(HttpBatteryApi api, App app) {
        return new BatteryRepositoryImp(app, api);
    }

}
